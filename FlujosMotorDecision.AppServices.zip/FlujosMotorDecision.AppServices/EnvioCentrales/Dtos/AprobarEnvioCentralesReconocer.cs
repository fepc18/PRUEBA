﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarEnvioCentralesReconocer : AprobarActividadBase
    {
        public string ServidorFTP { get; set; }
        public string UsuarioFTP { get; set; }
        public string ContrasenaFTP { get; set; }
        public string DirectorioFTP { get; set; }
        public int NoClientesCargados { get; set; }
        public int NoClientesFosyga { get; set; }
        public int NoClientesAprobadosMotor { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }
        public bool EnvioFtpActivo { get; set; }
        public string RutaCompartida { get; set; }
    }
}