﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class ResultadoEnvioCentralesClientes
    {
        public int InstanciaProcesoId { get; set; }
        public int InstanciaActividadId { get; set; }
        public int ClientesCargados { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }
    }
}
