﻿using FlujosMotorDecision.AppServices.Dtos;
using System;

namespace FlujosMotorDecision.AppServices
{
    public interface IEnvioCentralesService
    {

        /// <summary>
        /// Retorna el dto con la informacion para realizar el envio a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarEnvioCentralesClientes GetAprobarEnvioCentralesClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el DTO con la informacion para el envio No Clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarEnvioCentralesNoClientes GetAprobarEnvioCentralesNoClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el DTO con la informacion para el envio No Clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarEnvioCentralesReconocer GetAprobarEnvioCentralesReconocer(int idProceso, int idActividad);

        /// <summary>
        /// Retorna un objeto con el resultado del cargue a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>        
        ResultadoEnvioCentralesClientes GetResultadoEnvioCentralesClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el reultado de la ejecucion del envio a centrales de No Clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoEnvioCentralesNoClientes GetResultadoEnvioCentralesNoClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el resultado del envio del archivo reconocer a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoEnvioCentralesReconocer GetResultadoEnvioCentralesReconocer(int idProceso, int idActividad);

        /// <summary>
        /// Realiza la carga del archivo de centrales de riesgo a datacredito via FTP
        /// </summary>
        /// <param name="dto"></param>
        void EnviarArchivoFTP(string servidor, string UsuarioFTP, string contrasena, string directorio, int idArchivo, string usuario);

        /// <summary>
        /// Envia el archivo con el ID especificado a la ruta comparttida
        /// </summary>
        /// <param name="ruta"></param>
        /// <param name="usuario"></param>
        /// <param name="idArchivo"></param>
        void EnviarArchivoRutaCompartida(string ruta, string usuario, int idArchivo);
    }
}
