﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System.Data.Entity;
using Renci.SshNet;
using System;
using System.IO;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public class EnvioCentralesService : IEnvioCentralesService
    {
        private readonly IProcesoService _procesoService;

        private readonly IAppContext _db;

        public EnvioCentralesService(IProcesoService procesoService, IAppContext db)
        {
            _procesoService = procesoService;
            _db = db;
        }
        /// <summary>
        /// Retorna el dto con la informacion para realizar el envio a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarEnvioCentralesClientes GetAprobarEnvioCentralesClientes(int idProceso, int idActividad)
        {
            var numClientes = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso).Count();
            //Para aprobar obtener archivo de la actividad de cargue
            var formatoNombreArchivoClientesConsulta = _db.Parametros.First(p => p.Nombre == "NombreArchivoClientesConsulta").Valor;
            var formatoNombreArchivoClientes = _db.Parametros.First(p => p.Nombre == "NombreArchivoClientes").Valor;

            InstanciaActividad actividadActual =_db.InstanciasActividad.Where(x => x.ActividadSiguienteId == idActividad).SingleOrDefault();
            var archivo = _db.Archivos.AsNoTracking()
                            .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                            .First(a => a.InstanciaActividadId == actividadActual.InstanciaActividadId && a.Nombre.Contains(formatoNombreArchivoClientes.Replace("{0}_", "")));

            var dto = new AprobarEnvioCentralesClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                ClientesCargados = numClientes,
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre,
                ServidorFTP = _db.Parametros.First(x => x.Nombre == "ServidorFTPCentrales").Valor,
                UsuarioFTP = _db.Parametros.First(x => x.Nombre == "UsuarioFTPCentrales").Valor,
                ContrasenaFTP = _db.Parametros.First(x => x.Nombre == "ContrasenaFTPCentrales").Valor,
                DirectorioFTP = _db.Parametros.First(x => x.Nombre == "RutaClientesFTPCentrales").Valor,
                RutaCompartida = _db.Parametros.First(x => x.Nombre == "RutaCompartidaClientes").Valor,
                EnvioFtpActivo = bool.Parse(_db.Parametros.First(p => p.Nombre == "FTPCentralesActivo").Valor)
            };

            return dto;
        }

        /// <summary>
        /// Retorna un objeto con el resultado del cargue a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoEnvioCentralesClientes GetResultadoEnvioCentralesClientes(int idProceso, int idActividad)
        {
            var numClientes = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso).Count();

            var dto = new ResultadoEnvioCentralesClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                ClientesCargados = numClientes
            };
            return dto;
        }

        /// <summary>
        /// Retorna el dto con la informacion para realizar el envio a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarEnvioCentralesNoClientes GetAprobarEnvioCentralesNoClientes(int idProceso, int idActividad)
        {
            var noClientesCargados = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso).ToList();
            var noClientesCentrales = noClientesCargados.Where(c => c.ApruebaFosyga).ToList();

            var archivo = _db.Archivos.Where(a => a.InstanciaActividadId == idActividad).FirstOrDefault();
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoNoClientes").Valor;
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorEnvioNoClientes").Valor;
            var nombreArchivo = _db.Parametros.First(x => x.Nombre == "NombreArchivoNoClientes").Valor;

            // Crear el archivo No Clientes si no existe
            if (archivo == null)
            {
                var sb = new StringBuilder();
                sb.AppendLine(encabezado);
                noClientesCentrales.ForEach(c => sb.AppendLine(c.TipoDocumento + separador + c.Documento));
                var contenido = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                archivo = new Archivo
                {
                    Nombre = String.Format(nombreArchivo, DateTime.Today.ToString("yyyyMMdd")),
                    Contenido = contenido,
                    Type = "text/plain",
                    Tamano = contenido.Length,
                    InstanciaActividadId = idActividad,
                    InstanciaProcesoId = idProceso
                };
                _db.Archivos.Add(archivo);
                _db.SaveChanges();
            }

            var dto = new AprobarEnvioCentralesNoClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                ServidorFTP = _db.Parametros.First(x => x.Nombre == "ServidorFTPCentrales").Valor,
                UsuarioFTP = _db.Parametros.First(x => x.Nombre == "UsuarioFTPCentrales").Valor,
                ContrasenaFTP = _db.Parametros.First(x => x.Nombre == "ContrasenaFTPCentrales").Valor,
                DirectorioFTP = _db.Parametros.First(x => x.Nombre == "RutaNoClientesFTPCentrales").Valor,
                NoClientesCargados = noClientesCargados.Count(),
                NoClientesFosyga = noClientesCentrales.Count,
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre,
                RutaCompartida = _db.Parametros.First(x => x.Nombre == "RutaCompartidaNoClientes").Valor,
                EnvioFtpActivo = bool.Parse(_db.Parametros.First(p => p.Nombre == "FTPCentralesActivo").Valor)
            };
            return dto;
        }

        /// <summary>
        /// Retorna un objeto con el resultado del cargue a centrales
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoEnvioCentralesNoClientes GetResultadoEnvioCentralesNoClientes(int idProceso, int idActividad)
        {
            var archivo = _db.Archivos.Where(a => a.InstanciaActividadId == idActividad).FirstOrDefault();
            var noClientes = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga).Count();
            var dto = new ResultadoEnvioCentralesNoClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                NoClientesEnviados = noClientes,
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre
            };
            return dto;
        }

        /// <summary>
        /// Retorna el dto con la informacion necesaria para aprobar el envio a centrales del archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarEnvioCentralesReconocer GetAprobarEnvioCentralesReconocer(int idProceso, int idActividad)
        {
            var noClientesCargados = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso).ToList();
            var noClientesReconocer = noClientesCargados.Where(c => c.ApruebaFosyga && c.ApruebaMotor).ToList();
            var archivo = _db.Archivos.Where(a => a.InstanciaActividadId == idActividad).FirstOrDefault();

            var nombreArchivo = _db.Parametros.First(x => x.Nombre == "NombreArchivoReconocer").Valor;
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoReconocer").Valor;
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoReconocer").Valor;
            // Crear el archivo No Clientes si no existe
            if (archivo == null)
            {
                var sb = new StringBuilder();
                sb.AppendLine(encabezado); //Encabezado
                noClientesReconocer.ForEach(c => sb.AppendLine(c.TipoDocumento + separador + c.Documento)); //Registros
                var contenido = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                archivo = new Archivo
                {
                    Nombre = String.Format(nombreArchivo, DateTime.Today.ToString("yyyyMMdd")),
                    Contenido = contenido,
                    Type = "text/plain",
                    Tamano = contenido.Length,
                    InstanciaActividadId = idActividad,
                    InstanciaProcesoId = idProceso
                };
                _db.Archivos.Add(archivo);
                _db.SaveChanges();
            }

            var dto = new AprobarEnvioCentralesReconocer
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                ServidorFTP = _db.Parametros.First(x => x.Nombre == "ServidorFTPCentrales").Valor,
                UsuarioFTP = _db.Parametros.First(x => x.Nombre == "UsuarioFTPCentrales").Valor,
                ContrasenaFTP = _db.Parametros.First(x => x.Nombre == "ContrasenaFTPCentrales").Valor,
                DirectorioFTP = _db.Parametros.First(x => x.Nombre == "RutaReconocerFTPCentrales").Valor,
                NoClientesCargados = noClientesCargados.Count(),
                NoClientesFosyga = noClientesCargados.Where(c => c.ApruebaFosyga).Count(),
                NoClientesAprobadosMotor = noClientesCargados.Where(c => c.ApruebaFosyga && c.ApruebaMotor).Count(),
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre,
                RutaCompartida = _db.Parametros.First(x => x.Nombre == "RutaCompartidaReconocer").Valor,
                EnvioFtpActivo = bool.Parse(_db.Parametros.First(p => p.Nombre == "FTPCentralesActivo").Valor)
            };
            return dto;
        }

        /// <summary>
        /// Retorna el dto con el resultado de la ejecucion del archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoEnvioCentralesReconocer GetResultadoEnvioCentralesReconocer(int idProceso, int idActividad)
        {
            var archivo = _db.Archivos.Where(a => a.InstanciaActividadId == idActividad).FirstOrDefault();
            var noClientes = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga && c.ApruebaMotor).Count();
            var dto = new ResultadoEnvioCentralesReconocer
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                NoClientesEnviados = noClientes,
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre
            };
            return dto;
        }

        /// <summary>
        /// Realiza la carga del archivo de centrales de riesgo a datacredito via FTP
        /// </summary>
        /// <param name="dto"></param>
        public void EnviarArchivoFTP(string servidor, string UsuarioFTP, string contrasena, string directorio, int idArchivo, string usuario)
        {
            var conn = new PasswordConnectionInfo(servidor, UsuarioFTP, contrasena);
            var archivo = _db.Archivos.Find(idArchivo);
            using (var sftp = new SftpClient(conn))
            {
                sftp.Connect();
                sftp.ChangeDirectory(directorio);

                sftp.WriteAllBytes(sftp.WorkingDirectory + archivo.Nombre, archivo.Contenido);
                sftp.Disconnect();
            }
            InstanciaActividad actividadCarga = _db.InstanciasActividad.Where(x => x.InstanciaActividadId == archivo.InstanciaActividadId).Single();
            ActividadProceso actividadProceso = _db.ActividadesProceso.Where(x => x.ActividadProcesoId == actividadCarga.ActividadProcesoId).Single();
            Actividad actividad = _db.Actividades.Where(x => x.ActividadId == actividadProceso.ActividadId).Single();
            if (actividad.Nombre.Contains("Cargar Archivo"))
            {

                InstanciaActividad actividadActual = _db.InstanciasActividad.Where(x => x.InstanciaActividadId == actividadCarga.ActividadSiguienteId).Single();
                _procesoService.CompletarActividadActual(archivo.InstanciaProcesoId, actividadActual.InstanciaActividadId, usuario);
            }
            else
            {
                _procesoService.CompletarActividadActual(archivo.InstanciaProcesoId, actividadCarga.InstanciaActividadId, usuario);
            }

        } 

        /// <summary>
        /// Realiza la carga del archivo de centrales de riesgo a datacredito via FTP
        /// </summary>
        /// <param name="dto"></param>
        public void EnviarArchivoRutaCompartida(string ruta, string usuario, int idArchivo)
        {
            var archivo = _db.Archivos.Find(idArchivo);

            //-> Generar Archivo
            File.WriteAllBytes(ruta + Path.DirectorySeparatorChar + archivo.Nombre, archivo.Contenido);
            InstanciaActividad actividadCarga = _db.InstanciasActividad.Where(x => x.InstanciaActividadId == archivo.InstanciaActividadId).Single();
            ActividadProceso actividadProceso = _db.ActividadesProceso.Where(x => x.ActividadProcesoId == actividadCarga.ActividadProcesoId).Single();
            Actividad actividad = _db.Actividades.Where(x => x.ActividadId == actividadProceso.ActividadId).Single();
            if (actividad.Nombre.Contains("Cargar Archivo"))
            {

                InstanciaActividad actividadActual = _db.InstanciasActividad.Where(x => x.InstanciaActividadId == actividadCarga.ActividadSiguienteId).Single();
                _procesoService.CompletarActividadActual(archivo.InstanciaProcesoId, actividadActual.InstanciaActividadId, usuario);
            }
            else
            {
                _procesoService.CompletarActividadActual(archivo.InstanciaProcesoId, actividadCarga.InstanciaActividadId, usuario);
            }

           
        }
    }
}
