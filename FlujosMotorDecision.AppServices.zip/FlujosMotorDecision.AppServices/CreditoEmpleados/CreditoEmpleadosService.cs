﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.DAL.Dtos;
using FlujosMotorDecision.EntityFramework;
using Hangfire;
using System;
using System.Data.Entity;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.CreditoEmpleados
{
    public class CreditoEmpleadosService : ICreditoEmpleadosService
    {
        private readonly IAppContext _db;
        private readonly IAdmisionDAL _dal;

        public CreditoEmpleadosService(IAppContext db, IAdmisionDAL dal)
        {
            _db = db;
            _dal = dal;
        }

        /// <summary>
        /// Retorna el dto de en trada para la carga de empleados
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public async Task<CargarCreditoEmpleadosInput> GetCargarCreditoEmpleadosInput()
        {
            var tamanoArchivo = int.Parse(ConfigurationManager.AppSettings["TamanoMaxArchivo"]);
            var separador = await _db.Parametros.FirstOrDefaultAsync(x => x.Nombre == "SeparadorArchivoCreditoEmpleados");
            var extension = await _db.Parametros.FirstOrDefaultAsync(x => x.Nombre == "ExtensionArchivoCreditoEmpleados");
            var estructura = await _db.Parametros.FirstOrDefaultAsync(x => x.Nombre == "EstructuraArchivoCreditoEmpleados");
            var horaEjecucion = await _db.Parametros.FirstOrDefaultAsync(p => p.Nombre == "HoraEjecucionCreditoEmpleados");
            var cargaHabilitada = await _db.Parametros.FirstOrDefaultAsync(p => p.Nombre == "EjecutarCargaCreditoEmpleados");
            
            var dto = new CargarCreditoEmpleadosInput
            {
                Separador = separador.Valor,
                Extension = extension.Valor,
                TamanoMaximoArchivo = tamanoArchivo / (1024 * 1024),
                Estructura = estructura.Valor,
                FechaEjecucion = DateTime.Today.Add(TimeSpan.Parse(horaEjecucion.Valor)),
                CargaHabilitada = bool.Parse(cargaHabilitada.Valor)
            };
            return dto;
        }

        /// <summary>
        /// Realiza las validaciones del archivo plano de Empleados
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="errores"></param>
        /// <returns></returns>
        public CargarCreditoEmpleadosInput ValidarArchivo(CargarCreditoEmpleadosInput dto, out string errores)
        {
            var sb = new StringBuilder();
            var registros = new List<RegistroMaestroAsignacionEmpleados>();

            using (var sr = new StreamReader(dto.Archivo.InputStream))
            {
                int numLinea = 1;
                while (!sr.EndOfStream)
                {
                    var linea = sr.ReadLine();
                    var separador = dto.Separador.ToCharArray()[0];
                    var data = linea.Split(separador);

                    if (data.Length != 19)
                    {
                        sb.AppendLine(String.Format("Registro {0} debe tener 19 columnas.", numLinea));
                    }
                    else
                    {
                        try
                        {
                            var registro = new RegistroMaestroAsignacionEmpleados
                            {
                                CUENTA_TDC = data[0],
                                FECHA_ASIGNACION = DateTime.Parse(data[1]),
                                TIPO_DOCUMENTO = int.Parse(data[2]),
                                NUMERO_DOCUMENTO = data[3],
                                FECHA_ACTUALIZACION_CENTRALES = DateTime.Parse(data[4]),
                                CLASIFICACION_CENTRALES = data[5],
                                SCORE_CENTRALES = decimal.Parse(data[6]),
                                NODO = decimal.Parse(data[7]),
                                CUOTAS_CREDITO = decimal.Parse(data[8]),
                                CONTINGENTES = decimal.Parse(data[9]),
                                SCORE_BEHAVIOUR = decimal.Parse(data[10]),
                                HABITO_PAGO_PROMEDIO = data[11],
                                ESTRATO = int.Parse(data[12]),
                                ASIGNA_CONSUMO = decimal.Parse(data[13]),
                                LINEA_ACTUAL_CONSUMO = float.Parse(data[14]),
                                SOPORTE_DOCUMENTOS = decimal.Parse(data[15]),
                                MONTO_PREAPROBADO_CONSUMO = float.Parse(data[16]),
                                FILTROS = data[17],
                                RESPUESTA = data[18],
                            };
                            registros.Add(registro);
                        }
                        catch (Exception ex)
                        {
                            sb.AppendLine(string.Format("Registro {0} falló las validaciones de formato:" + ex.Message, numLinea));
                        }
                    }
                    numLinea++;
                }
            }
            errores = sb.ToString();
            dto.Registros = registros;
            return dto;
        }

        /// <summary>
        /// Carga a la base de datos la información de empleados
        /// </summary>
        /// <param name="dto"></param>
        public void CargarArchivoEmpleados(CargarCreditoEmpleadosInput dto)
        {            
            _dal.insRegistrosMaestroAsignacionEmpleadosTmp(dto.Registros);
            BackgroundJob.Schedule<IAdmisionDAL>(x => x.cargarTablaMaestroAsignacionEmpleados(), dto.FechaEjecucion);
        }
    }
}
