﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.CreditoEmpleados
{
    public interface ICreditoEmpleadosService
    {
        Task<CargarCreditoEmpleadosInput> GetCargarCreditoEmpleadosInput();
        CargarCreditoEmpleadosInput ValidarArchivo(CargarCreditoEmpleadosInput dto, out string errores);
        void CargarArchivoEmpleados(CargarCreditoEmpleadosInput dto);

    }
}
