﻿using FlujosMotorDecision.AppServices.Validations;
using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class CargarCreditoEmpleadosInput : IValidatableObject
    {
        [Required(ErrorMessage = "Por favor seleccione un archivo.")]
        [ValidateInputFile]
        public HttpPostedFileBase Archivo { get; set; }
        public string Separador { get; set; }
        public int TamanoMaximoArchivo { get; set; }
        public IList<RegistroMaestroAsignacionEmpleados> Registros { get; set; }
        public string Extension { get; set; }
        public string Estructura { get; set; }
        public DateTime FechaEjecucion { get; set; }

        /// <summary>
        /// Validaciones adicionales para el modelo
        /// </summary>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var horaMinima = new TimeSpan(22, 0, 0);
            if (FechaEjecucion.TimeOfDay < horaMinima)
            {
                yield return new ValidationResult("Hora mínima de ejecución es a las " + horaMinima.ToString(@"hh\:mm\:ss"), new[] { "FechaEjecucion" });
            }
        }

        public bool CargaHabilitada { get; set; }
    }
}
