﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class ResultadoDescargarReconocer
    {
        public int InstanciaProcesoId { get; set; }
        public int InstanciaActividadId { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }
    }
}