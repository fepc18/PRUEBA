﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarDescargarReconocer : AprobarActividadBase
    {        
        public string ServidorFTP { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }
        public bool DescargarArchivo { get; set; }
        public bool FtpActivo { get; set; }
        public bool CargarAdmisiones { get; set; }
        public string DirectorioFTP { get; set; }
        public string RutaCompartida { get; set; }        
    }
}
