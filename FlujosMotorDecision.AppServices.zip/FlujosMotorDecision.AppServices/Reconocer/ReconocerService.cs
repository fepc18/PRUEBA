﻿using Excel;
using FastMember;
using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.DAL.Dtos;
using FlujosMotorDecision.EntityFramework;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace FlujosMotorDecision.AppServices.Reconocer
{
    public class ReconocerService : IReconocerService
    {
        private readonly IAppContext _db;
        private readonly IAdmisionDAL _admDal;
        private readonly IOdsDAL _odsDal;
        private readonly IProcesoService _procesoService;

        public ReconocerService(IAppContext db, IAdmisionDAL admDal, IOdsDAL odsDal, IProcesoService procesoService)
        {
            _db = db;
            _admDal = admDal;
            _odsDal = odsDal;
            _procesoService = procesoService;
        }

        /// <summary>
        /// Retorna el dto de entrada para el archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarDescargarReconocer GetAprobarDescargarReconocer(int idProceso, int idActividad)
        {
            var archivoReconocer = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId }).FirstOrDefault(a => a.InstanciaActividadId == idActividad);
            var ftp = _db.Parametros.First(x => x.Nombre == "ServidorFTPCentrales").Valor;
            var directorio = _db.Parametros.First(x => x.Nombre == "RutaReconocerFTPCentrales").Valor;
            var dto = new AprobarDescargarReconocer
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                ServidorFTP = ftp,
                DirectorioFTP = directorio,
                FtpActivo = bool.Parse(_db.Parametros.First(p => p.Nombre == "FTPCentralesActivo").Valor),
                RutaCompartida = _db.Parametros.First(x => x.Nombre == "RutaCompartidaReconocer").Valor
            };
            if (archivoReconocer == null)
            {
                dto.DescargarArchivo = true;
            }
            else
            {
                dto.NombreArchivo = archivoReconocer.Nombre;
                dto.ArchivoId = archivoReconocer.ArchivoId;
                dto.CargarAdmisiones = true;
            }
            return dto;
        }

        /// <summary>
        /// Retorna el resultado de la descarga reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoDescargarReconocer GetResultadoDescargarReconocer(int idProceso, int idActividad)
        {
            var archivoReconocer = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId }).First(a => a.InstanciaActividadId == idActividad);
            var dto = new ResultadoDescargarReconocer
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                ArchivoId = archivoReconocer.ArchivoId,
                NombreArchivo = archivoReconocer.Nombre
            };
            return dto;
        }

        /// <summary>
        /// Procesa el archivo reconocer y lo carga a admisiones
        /// </summary>
        /// <param name="dto"></param>
        public void CargarNoClientesAdmisiones(AprobarDescargarReconocer dto)
        {
            var tipoProceso = _db.Parametros.First(p => p.Nombre == "TipoProcesoNoClientes").Valor;
            var archivo = _db.Archivos.Find(dto.ArchivoId);
            var actividad = _db.InstanciasActividad.Find(dto.InstanciaActividadId);
            
            var registrosReconocer = new List<CliPreaProbDto>();
            var stream = new MemoryStream(archivo.Contenido);
            var registrosOds = _odsDal.GetNodoCliente(tipoProceso);

            using (var excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream))
            {
                var result = excelReader.AsDataSet();
                var datos = result.Tables[1];
                datos.Rows.RemoveAt(0);
                datos.Rows.RemoveAt(0);

                foreach (DataRow row in datos.Rows)
                {
                    int tipoId = Convert.ToInt32(row[0]);
                    string doc = row[1].ToString();
                    var regOds = registrosOds.Where(c => Convert.ToInt32(c.CMCLI_OFERTAPRODUCTOS_TIPO_ID) == tipoId && c.CMCLI_OFERTAPRODUCTOS_CEDULA == doc).SingleOrDefault();

                    var reg = new CliPreaProbDto
                    {
                        //identificacion
                        tipoId = Convert.IsDBNull(row[0]) ? (int?)null : Convert.ToInt32(row[0]),
                        numeroId = Convert.IsDBNull(row[1]) ? (int?)null : Convert.ToInt32(row[1]),
                        primerApellido = Convert.IsDBNull(row[2]) ? null : row[2].ToString().Truncate(20),
                        segundoApellido = Convert.IsDBNull(row[3]) ? null : row[3].ToString().Truncate(20),
                        primerNombre = Convert.IsDBNull(row[4]) ? null : row[4].ToString().Truncate(20),
                        segundoNombre = Convert.IsDBNull(row[5]) ? null : row[5].ToString().Truncate(20),
                        nombreCompleto = Convert.IsDBNull(row[6]) ? null : row[6].ToString().Truncate(50),
                        fechaExpedicion = String.IsNullOrEmpty(row[7].ToString()) || Convert.IsDBNull(row[7]) ? (DateTime?)null : Convert.ToDateTime(row[7]),
                        ciudadExpedicion = Convert.IsDBNull(row[8]) ? null : row[8].ToString().Truncate(25),
                        dptoExpedicion = Convert.IsDBNull(row[9]) ? null : row[9].ToString().Truncate(25),
                        genero = Convert.IsDBNull(row[10]) ? null : row[10].ToString().Truncate(5),
                        rangoEdad = Convert.IsDBNull(row[11]) ? null : row[11].ToString().Truncate(10),
                        ciiu = Convert.IsDBNull(row[12]) ? null : (int?)Convert.ToInt32(row[12]),
                        actividadEconomica = Convert.IsDBNull(row[13]) ? null : Convert.ToString(row[13]).Truncate(20),

                        //telefono 1
                        ciudadTelefono = Convert.IsDBNull(row[14]) ? null : row[14].ToString().Truncate(50),
                        dptoTelefono = Convert.IsDBNull(row[15]) ? null : row[15].ToString().Truncate(50),
                        codCiudadTelefono = Convert.IsDBNull(row[16]) ? (int?)null : Convert.ToInt32(row[16]),
                        codDANEdptoTelefono = Convert.IsDBNull(row[17]) ? (int?)null : Convert.ToInt32(row[17]),
                        numeroTelefono = Convert.IsDBNull(row[18]) ? (decimal?)null : Convert.ToDecimal(row[18]),
                        tipoTelefono = Convert.IsDBNull(row[19]) ? null : row[19].ToString().Truncate(10),
                        fechaUltimaActualizacionTelefono = String.IsNullOrEmpty(row[20].ToString()) || Convert.IsDBNull(row[20]) ? (DateTime?)null : Convert.ToDateTime(row[20]),
                        numDeEntidadesReportanTelefono = Convert.IsDBNull(row[21]) ? (int?)null : Convert.ToInt32(row[21]),

                        //telefono 2
                        ciudadTelefono2 = Convert.IsDBNull(row[22]) ? null : row[22].ToString(),
                        dptoTelefono2 = Convert.IsDBNull(row[23]) ? null : row[23].ToString(),
                        codCiudadTelefono2 = Convert.IsDBNull(row[24]) ? (int?)null : Convert.ToInt32(row[24]),
                        codDANEdptoTelefono2 = Convert.IsDBNull(row[25]) ? (int?)null : Convert.ToInt32(row[25]),
                        numeroTelefono2 = Convert.IsDBNull(row[26]) ? (decimal?)null : Convert.ToDecimal(row[26]),
                        tipoTelefono2 = Convert.IsDBNull(row[27]) ? null : row[27].ToString(),
                        fechaUltimaActualizacionTelefono2 = String.IsNullOrEmpty(row[28].ToString()) || Convert.IsDBNull(row[28]) ? (DateTime?)null : Convert.ToDateTime(row[28]),
                        numDeEntidadesReportanTelefono2 = Convert.IsDBNull(row[29]) ? (int?)null : Convert.ToInt32(row[29]),

                        //telefono 3
                        ciudadTelefono3 = Convert.IsDBNull(row[30]) ? null : row[30].ToString(),
                        dptoTelefono3 = Convert.IsDBNull(row[31]) ? null : row[31].ToString(),
                        codCiudadTelefono3 = Convert.IsDBNull(row[32]) ? (int?)null : Convert.ToInt32(row[32]),
                        codDANEdptoTelefono3 = Convert.IsDBNull(row[33]) ? (int?)null : Convert.ToInt32(row[33]),
                        numeroTelefono3 = Convert.IsDBNull(row[34]) ? (decimal?)null : Convert.ToDecimal(row[34]),
                        tipoTelefono3 = Convert.IsDBNull(row[35]) ? null : row[35].ToString(),
                        fechaUltimaActualizacionTelefono3 = String.IsNullOrEmpty(row[36].ToString()) || Convert.IsDBNull(row[36].ToString()) ? (DateTime?)null : Convert.ToDateTime(row[36]),
                        numDeEntidadesReportanTelefono3 = Convert.IsDBNull(row[37]) ? (int?)null : Convert.ToInt32(row[37]),

                        //direccion 1
                        ciudadDireccion = Convert.IsDBNull(row[38]) ? null : row[38].ToString(),
                        dptoDireccion = Convert.IsDBNull(row[39]) ? null : row[39].ToString(),
                        codCiudadDireccion = Convert.IsDBNull(row[40]) ? (int?)null : Convert.ToInt32(row[40]),
                        codDANEdptoDireccion = Convert.IsDBNull(row[41]) ? (int?)null : Convert.ToInt32(row[41]),
                        direccion = Convert.IsDBNull(row[42]) ? null : row[42].ToString(),
                        tipoDireccion = Convert.IsDBNull(row[43]) ? null : row[43].ToString(),
                        zona = Convert.IsDBNull(row[44]) ? null : row[44].ToString(),
                        estratoDireccion = Convert.IsDBNull(row[45]) ? (int?)null : Convert.ToInt32(row[45]),
                        fechaUltimaActualizacionDireccion = String.IsNullOrEmpty(row[46].ToString()) || Convert.IsDBNull(row[46]) ? (DateTime?)null : Convert.ToDateTime(row[46]),
                        numDeEntidadesReportanDireccion = Convert.IsDBNull(row[47]) ? (int?)null : Convert.ToInt32(row[47]),

                        //direccion 2
                        ciudadDireccion2 = Convert.IsDBNull(row[48]) ? null : row[48].ToString(),
                        dptoDireccion2 = Convert.IsDBNull(row[49]) ? null : row[49].ToString(),
                        codCiudadDireccion2 = Convert.IsDBNull(row[50]) ? (int?)null : Convert.ToInt32(row[50]),
                        codDANEdptoDireccion2 = Convert.IsDBNull(row[51]) ? (int?)null : Convert.ToInt32(row[51]),
                        direccion2 = Convert.IsDBNull(row[52]) ? null : row[52].ToString(),
                        tipoDireccion2 = Convert.IsDBNull(row[53]) ? null : row[53].ToString(),
                        zona2 = Convert.IsDBNull(row[54]) ? null : row[54].ToString(),
                        estratoDireccion2 = Convert.IsDBNull(row[55]) ? (int?)null : Convert.ToInt32(row[55]),
                        fechaUltimaActualizacionDireccion2 = String.IsNullOrEmpty(row[56].ToString()) || Convert.IsDBNull(row[56]) ? (DateTime?)null : Convert.ToDateTime(row[56]),
                        numDeEntidadesReportanDireccion2 = Convert.IsDBNull(row[57]) ? (int?)null : Convert.ToInt32(row[57]),

                        //direccion 3
                        ciudadDireccion3 = Convert.IsDBNull(row[58]) ? null : row[58].ToString(),
                        dptoDireccion3 = Convert.IsDBNull(row[59]) ? null : row[59].ToString(),
                        codCiudadDireccion3 = Convert.IsDBNull(row[60]) ? (int?)null : Convert.ToInt32(row[60]),
                        codDANEdptoDireccion3 = Convert.IsDBNull(row[61]) ? (int?)null : Convert.ToInt32(row[61]),
                        direccion3 = Convert.IsDBNull(row[62]) ? null : row[62].ToString(),
                        tipoDireccion3 = Convert.IsDBNull(row[63]) ? null : row[63].ToString(),
                        zona3 = Convert.IsDBNull(row[64]) ? null : row[64].ToString(),
                        estratoDireccion3 = Convert.IsDBNull(row[65]) ? (int?)null : Convert.ToInt32(row[65]),
                        fechaUltimaActualizacionDireccion3 = String.IsNullOrEmpty(row[66].ToString()) || Convert.IsDBNull(row[66]) ? (DateTime?)null : Convert.ToDateTime(row[66]),
                        numDeEntidadesReportanDireccion3 = Convert.IsDBNull(row[67]) ? (int?)null : Convert.ToInt32(row[67]),

                        //datos adicionales
                        email = Convert.IsDBNull(row[68]) ? null : row[68].ToString(),
                        email2 = Convert.IsDBNull(row[69]) ? null : row[69].ToString(),
                        celular = Convert.IsDBNull(row[70]) ? (decimal?)null : Convert.ToDecimal(row[70]),
                        celular2 = Convert.IsDBNull(row[71]) ? (decimal?)null : Convert.ToDecimal(row[71]),
                        producto = 1,
                        actividad = 14,
                    };
                    if (regOds != null)
                    {
                        //campos Ods
                        reg.ingreso = decimal.Parse(regOds.RSTNOCLI_OFERPROD_INGRESO);
                        reg.cuotasCredito = int.Parse(regOds.RSTNOCLI_OFERPROD_CUOTAS);
                        reg.cuotasContingentes = decimal.Parse(regOds.RSTNOCLI_OFERPROD_CONTINGENTES);
                        reg.cupo = decimal.Parse(regOds.RSTNOCLI_OFERTAPRODUCTOS_CUPO);
                    }
                    registrosReconocer.Add(reg);

                }
                excelReader.Close();

                //Update usando Dapper por motivos de performance
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
                {
                    conn.Open();
                    conn.Execute("IF OBJECT_ID('tempdb.dbo.#TEMP_NO_CLIENTES', 'U') IS NOT NULL  DROP TABLE #TEMP_NO_CLIENTES");
                    conn.Execute("CREATE TABLE #TEMP_NO_CLIENTES(TipoDocumento int, Documento int)");

                    var dt = new DataTable();
                    using (var reader = ObjectReader.Create(registrosReconocer, "tipoId", "numeroId"))
                    {
                        dt.Load(reader);
                    }
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                    {
                        bulkCopy.ColumnMappings.Add("tipoId", "TipoDocumento");
                        bulkCopy.ColumnMappings.Add("numeroId", "Documento");

                        bulkCopy.DestinationTableName = "#TEMP_NO_CLIENTES";
                        bulkCopy.WriteToServer(dt);
                    }

                    var command = @"UPDATE C SET ApruebaReconocer = 1 
FROM NoCliente C INNER JOIN #TEMP_NO_CLIENTES Temp 
ON C.TipoDocumento = Temp.TipoDocumento
AND C.Documento = CAST(Temp.Documento AS Varchar(40))
WHERE C.InstanciaProcesoId = @IdProceso 
";
                    conn.Execute(command, commandTimeout: 3600, param: new { IdProceso = dto.InstanciaProcesoId });
                    conn.Execute("DROP TABLE #TEMP_NO_CLIENTES");
                }

//                string documentos = string.Join("','", registrosReconocer.Select(c => c.numeroId));
//                var registros = _db.Database.ExecuteSqlCommand(@"UPDATE NoCliente SET ApruebaReconocer = 1 
//                WHERE InstanciaProcesoId =" + dto.InstanciaProcesoId + " AND Documento IN ('" + documentos + "')");


                _admDal.insertarDatosReconocer(registrosReconocer);
                _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
                _db.SaveChanges();
            }
        }

        /// <summary>
        /// Realiza la descarga del archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public Archivo DescargarArchivo(int idProceso, int idActividad)
        {
            Archivo archivo = null;
            var ftp = _db.Parametros.First(x => x.Nombre == "ServidorFTPCentrales").Valor;
            var usuario = _db.Parametros.First(x => x.Nombre == "UsuarioFTPCentrales").Valor;
            var contrasena = _db.Parametros.First(x => x.Nombre == "ContrasenaFTPCentrales").Valor;
            var directorio = _db.Parametros.First(x => x.Nombre == "RutaReconocerFTPCentrales").Valor;

            var conn = new PasswordConnectionInfo(ftp, usuario, contrasena);

            using (var sftp = new SftpClient(conn))
            {
                sftp.Connect();
                sftp.ChangeDirectory(directorio);
                var ftpFiles = sftp.ListDirectory(sftp.WorkingDirectory, null);

                foreach (var fileName in ftpFiles)
                {
                    if (Path.GetExtension(fileName.Name) == ".xls" || Path.GetExtension(fileName.Name) == ".xlsx")
                    {
                        using (var stream = new MemoryStream())
                        {
                            sftp.DownloadFile(fileName.FullName, stream, null);
                            sftp.Delete(fileName.FullName);

                            //Guardar en BD
                            archivo = new Archivo
                            {
                                Contenido = stream.ToArray(),
                                InstanciaActividadId = idActividad,
                                InstanciaProcesoId = idProceso,
                                Nombre = fileName.Name,
                                Type = "text/plain",
                                Tamano = stream.Length
                            };
                            _db.Archivos.Add(archivo);
                        }
                    }
                }
                sftp.Disconnect();
            }
            return archivo;
        }

        /// <summary>
        /// Realiza la descarga del archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public Archivo CopiarArchivo(int idProceso, int idActividad)
        {
            Archivo archivo = null;
            var rutaCompartida = _db.Parametros.First(x => x.Nombre == "RutaCompartidaReconocer").Valor;
            var files = Directory.EnumerateFiles(rutaCompartida, "*.xlsx");

            foreach (var fileName in files)
            {
                if (fileName.Contains("falrec+"))
                {
                    var contenido = File.ReadAllBytes(fileName);
                    //Guardar en BD
                    archivo = new Archivo
                    {
                        Contenido = contenido,
                        InstanciaActividadId = idActividad,
                        InstanciaProcesoId = idProceso,
                        Nombre = Path.GetFileName(fileName),
                        Type = "text/plain",
                        Tamano = contenido.Length
                    };
                    _db.Archivos.Add(archivo);
                }
            }
            return archivo;
        }
    }
}
