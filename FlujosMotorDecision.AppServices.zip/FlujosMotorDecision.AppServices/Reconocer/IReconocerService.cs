﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Reconocer
{
    public interface IReconocerService
    {
        /// <summary>
        /// Retorna el dto de entrada para el archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarDescargarReconocer GetAprobarDescargarReconocer(int idProceso, int idActividad);
        
        /// <summary>
        /// Retorna el resultado de la descarga reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoDescargarReconocer GetResultadoDescargarReconocer(int idProceso, int idActividad);        

        /// <summary>
        /// Realiza la descarga del archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        Archivo DescargarArchivo(int idProceso, int idActividad);

        /// <summary>
        /// Carga la información de no clientes a admiciones a partir del archivo Reconocer descargado
        /// </summary>
        /// <param name="dto"></param>
        void CargarNoClientesAdmisiones(AprobarDescargarReconocer dto);

        /// <summary>
        /// Buscar el archivo reconocer de una ruta compartida y copiarlos
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        Archivo CopiarArchivo(int p1, int p2);
    }
}
