﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class DetalleProcesoOutput
    {
        public InstanciaProceso Proceso { get; set; }

        public ICollection<InstanciaActividad> Actividades{ get; set; }

        public int CargadosRiesgo { get; set; }
        public int AprobadosMotor { get; set; }
        public int AprobadosFosyga { get; set; }
        public int EmpleadosCargados { get; set; }
        public int CargadosAdmisiones { get; set; }
        public int AprobadosReconocer { get; set; }
    }
}
