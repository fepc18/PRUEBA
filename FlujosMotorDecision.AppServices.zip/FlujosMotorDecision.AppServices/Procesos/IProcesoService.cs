﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public interface IProcesoService
    {
        /// <summary>
        /// Retorna el proeso asociado al TipoProceso recibido
        /// </summary>
        /// <returns></returns>
        Proceso GetByTipo(TipoProceso tipoProceso);
        /// <summary>
        /// Retorna todos las Instancias de Proceso segun el tipo
        /// </summary>
        /// <returns></returns>
        IEnumerable<InstanciaProceso> GetAllByTipo(TipoProceso tipoProceso);

        /// <summary>
        /// Retorna el proceso asociado a la InstanciaProceso con el id recibido
        /// </summary>
        /// <param name="idInstancia"></param>
        /// <returns></returns>
        Proceso GetProceso(int idInstancia);
        /// <summary>
        /// Retorna la instancia del proceso dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        InstanciaProceso GetInstancia(int id);

        /// <summary>
        /// Retorna la instancia del proceso dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        InstanciaProceso GetProcesoActivo(TipoProceso tipoProceso);

        /// <summary>
        /// Crea un nuevo Proceso del tipo indicado
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        InstanciaProceso Create(string usuario, TipoProceso tipoProceso);
        /// <summary>
        /// Calceña Proceso  indicado
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        InstanciaProceso Cancel(int idProceso,string usuario);
        /// <summary>
        /// Retorna el proceso activo segun el tipo
        /// Solo debe haber un proceso activo en el sistema
        /// </summary>
        /// <returns></returns>
        InstanciaActividad CompletarActividadActual(int idProceso, int idActividad, string usuario);

        /// <summary>
        /// Marca la actividad actual del proceso dado como terminada e inicia la siguiente actividad.
        /// Recibe un dbContext inicializado en otra transaccion
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="usuario"></param>        
        /// <returns>La actividad siguiente o null si no existe</returns>
        DetalleProcesoOutput GetDetalleProcesoClientes(int idProceso);

        object GetDetalleProcesoNoClientes(int idProceso);

        object GetDetalleCargaClientesOds(int idProceso);
    }
}
