﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public class ProcesoService : IProcesoService
    {
        private readonly IAppContext _db;

        public ProcesoService(IAppContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Retorna la instancia del proceso dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Proceso GetProceso(int idInstancia)
        {
            return _db.InstanciasProceso.Find(idInstancia).Proceso;
        }

        public Proceso GetByTipo(TipoProceso tipoProceso)
        {
            return _db.Procesos.Where(p => p.Tipo == tipoProceso).Single();
        }
        /// <summary>
        /// Retorna todos las Instancias de Proceso segun el tipo
        /// </summary>
        /// <returns></returns>
        public IEnumerable<InstanciaProceso> GetAllByTipo(TipoProceso tipoProceso)
        {
            try
            {
                return _db.InstanciasProceso.Where(p => p.Proceso.Tipo == tipoProceso)
                        .Include(a => a.Actividades).ToList();
            }
            catch (Exception ex) {
                ex.ToString();
            }
            return null;

        }

        /// <summary>
        /// Retorna la instancia del proceso dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public InstanciaProceso GetInstancia(int id)
        {

            return _db.InstanciasProceso.Where(p => p.InstanciaProcesoId == id)
                .Include(o => o.Actividades.Select(x => x.ActividadProceso.Actividad))
                .Include(p => p.Proceso)
                .Single();
        }

        /// <summary>
        /// Retorna la instancia del proceso dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DetalleProcesoOutput GetDetalleProcesoClientes(int idProceso)
        {
            var proceso = _db.InstanciasProceso.Find(idProceso);
            var actividades = _db.InstanciasActividad.Where(i => i.InstanciaProcesoId == idProceso).ToList();
                //.Include(a => a.ActividadProceso.Actividad).ToList();

            var dto = new DetalleProcesoOutput
            {
                CargadosRiesgo = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso).Count(),
                AprobadosMotor = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count(),
                AprobadosFosyga = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga).Count(),
                EmpleadosCargados = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.Empleado).Count(),
                CargadosAdmisiones = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga && c.ApruebaMotor).Count(),
                Proceso = proceso,
                Actividades = actividades
            };
            return dto;
        }

        /// <summary>
        /// Crea un nuevo Proceso del tipo indicado
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public InstanciaProceso Create(string usuario, TipoProceso tipoProceso)
        {
            // Cargar el proceso
            var proceso = _db.Procesos.First(x => x.Tipo == tipoProceso);
            // Las actividades parametrizadas para el proceso del tipo dado
            var actividadesProceso = _db.ActividadesProceso.Where(x => x.ProcesoId == proceso.ProcesoId).ToList();

            // Primera actividad a realizar
            var actividadInicial = actividadesProceso.Where(x => x.Tipo == TiposActividad.Inicial).First();

            // Instancia de las actividades del nuevo proceso
            var actividadesInstanciadas = new List<InstanciaActividad>();
            foreach (var actividadProceso in actividadesProceso)
            {
                if (actividadProceso.Tipo == TiposActividad.Inicial)
                {
                    var actividadCliente = new InstanciaActividad
                    {
                        ActividadProceso = actividadProceso,
                        CreadaPor = usuario,
                        Estado = EstadoActividad.Iniciada,
                        FechaCreacion = DateTime.Now,
                        FechaInicio = DateTime.Now,
                        IniciadaPor = usuario
                    };
                    actividadesInstanciadas.Add(actividadCliente);
                }
                else
                {
                    var actividadCliente = new InstanciaActividad
                    {
                        ActividadProceso = actividadProceso,
                        CreadaPor = usuario,
                        Estado = EstadoActividad.Pendiente,
                    };
                    actividadesInstanciadas.Add(actividadCliente);
                }
            }

            var instanciaProceso = new InstanciaProceso
            {
                CreadaPor = usuario,
                Estado = EstadoProceso.Iniciado,
                FechaInicio = DateTime.Now,
                IniciadaPor = usuario,
                Proceso = proceso,
                Actividades = actividadesInstanciadas
            };
            
            _db.InstanciasProceso.Add(instanciaProceso);

            // Llamar a SaveChanges en este punto asegura que las actividades son insertadas 
            // en la  tabla InstanciaActividad en el orden correcto.
            // Esperar al llamado Transaccional de SaveChanges haria que las actividades
            // sean insertadas en el orden contrario debido a la Foreign Key ActividadSiguienteId            
            _db.SaveChanges();
            
            // Establecer las actividades siguientes
            foreach (var instanciaActual in instanciaProceso.Actividades)
            {
                var intanciaSiguiente = actividadesInstanciadas
                    .Where(x => x.ActividadProceso.ActividadId == instanciaActual.ActividadProceso.ActividadSiguienteId)
                    .SingleOrDefault();

                if (intanciaSiguiente != null)
                {
                    instanciaActual.InstanciaSiguiente = intanciaSiguiente;
                }
            }
            return instanciaProceso;
        }
        /// <summary>
        /// Cancela un Proceso del tipo indicado
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public InstanciaProceso Cancel(int idProceso, string usuario)
        {
            var  instanciaProceso = _db.InstanciasProceso.Find(idProceso);
            var fecha = DateTime.Now;
            instanciaProceso.ModificadaPor = usuario;
            instanciaProceso.UltimaModificacion = fecha;
            instanciaProceso.FinalizadaPor = usuario;
            instanciaProceso.FechaFin = fecha;
            instanciaProceso.Estado = EstadoProceso.Cancelado;

            _db.SaveChanges();
            return instanciaProceso;
        }
        

        /// <summary>
        /// Retorna el proceso activo segun el tipo
        /// Solo debe haber un proceso activo en el sistema
        /// </summary>
        /// <returns></returns>
        public InstanciaProceso GetProcesoActivo(TipoProceso tipoProceso)
        {
            return _db.InstanciasProceso
                .Where(x => x.Proceso.Tipo == tipoProceso && x.Estado == EstadoProceso.Iniciado)
                .Include(x => x.Actividades).SingleOrDefault();

        }

        /// <summary>
        /// Marca la actividad actual del proceso dado como terminada e inicia la siguiente actividad.
        /// Recibe un dbContext inicializado en otra transaccion
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="usuario"></param>        
        /// <returns>La actividad siguiente o null si no existe</returns>
        public InstanciaActividad CompletarActividadActual(int idProceso, int idActividad, string usuario)
        {
            if (String.IsNullOrEmpty(usuario))
            {
                throw new Exception("No se puede completar una actividad sin asignar un usuario");
            }

            var actividadActual = _db.InstanciasActividad.Where(a => a.InstanciaActividadId == idActividad).Single();
            if (actividadActual.Estado == EstadoActividad.Terminada|| actividadActual.Estado == EstadoActividad.Pendiente)
            {
                throw new Exception("No se puede completar una actividad en estado distinto a Iniciada o en Ejecución");
            }

            var actividadesProceso = _db.InstanciasActividad.Where(x => x.InstanciaProcesoId == idProceso)
                                     .Include(i => i.ActividadProceso).ToList();

            var fecha = DateTime.Now;
            var proceso = _db.InstanciasProceso.Where(x => x.InstanciaProcesoId == idProceso)
                .Include(p => p.Actividades).Single();
            proceso.ModificadaPor = usuario;



            actividadActual.Estado = EstadoActividad.Terminada;
            actividadActual.ModificadaPor = usuario;
            actividadActual.FinalizadaPor = usuario;
            actividadActual.FechaFin = fecha;

            // Si la actividad es Final o es un proceso de 1 sola actividad (Actividad Inicial sin actividad siguiente)
            if (actividadActual.ActividadProceso.Tipo == TiposActividad.Final || (actividadActual.ActividadProceso.Tipo == TiposActividad.Inicial && actividadActual.ActividadSiguienteId == null))
            {
                proceso.Estado = EstadoProceso.Terminado;
                proceso.FinalizadaPor = usuario;
                proceso.FechaFin = fecha;
                return null;
            }
            else
            {
                int? idSiguiente = actividadActual.ActividadProceso.ActividadSiguienteId;
                var actividadSiguiente = actividadesProceso.Where(a => a.ActividadProceso.ActividadId == idSiguiente).Single();

                actividadSiguiente.Estado = EstadoActividad.Iniciada;
                actividadSiguiente.IniciadaPor = usuario;
                actividadSiguiente.ModificadaPor = usuario;
                actividadSiguiente.FechaInicio = fecha;

                return actividadSiguiente;
            }
        }


        public object GetDetalleProcesoNoClientes(int idProceso)
        {
            var proceso = _db.InstanciasProceso.Find(idProceso);
            var actividades = _db.InstanciasActividad.Where(i => i.InstanciaProcesoId == idProceso)
                .Include(a => a.ActividadProceso.Actividad).ToList();

            var dto = new DetalleProcesoOutput
            {
                CargadosRiesgo = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso).Count(),
                AprobadosMotor = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count(),
                AprobadosFosyga = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga).Count(),
                AprobadosReconocer = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaReconocer).Count(),
                CargadosAdmisiones = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga && c.ApruebaMotor && c.ApruebaReconocer).Count(),
                Proceso = proceso,
                Actividades = actividades
            };
            return dto;
        }

        public object GetDetalleCargaClientesOds(int idProceso)
        {
            var proceso = _db.InstanciasProceso.Find(idProceso);
            var actividades = _db.InstanciasActividad.Where(i => i.InstanciaProcesoId == idProceso)
                .Include(a => a.ActividadProceso.Actividad).ToList();

            var dto = new DetalleProcesoOutput
            {
                AprobadosMotor = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count(),
                Proceso = proceso,
                Actividades = actividades
            };
            return dto;
        }
    }
}
