﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public abstract class AprobarActividadBase
    {
        [Required]
        public int InstanciaProcesoId { get; set; }
        [Required]
        public int InstanciaActividadId { get; set; }
        public string Usuario { get; set; }
    }
}
