﻿using FlujosMotorDecision.AppServices.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices
{
    public interface ICargaAdmisionesService
    {
        /// <summary>
        /// Retorna el DTO para la carga del archivo de clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <returns>El dto para la vista de cargar archivo</returns>
        void CargarClientesAdmisiones(AprobarCargaAdmisiones dto);

        /// <summary>
        /// Carga inicial de los clientes subidos por el area de riesgo
        /// </summary>
        /// <param name="model"></param>
        AprobarCargaAdmisiones GetAprobarCargaAdmisiones(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el dto con la informacion del resultado de cargue del archivo clientes
        /// </summary>
        /// <param name="model"></param>
        ResultadoCargaAdmisiones GetResultadoCargaAdmisiones(int idProceso, int idActividad);
    }
}
