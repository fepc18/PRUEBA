﻿using FlujosMotorDecision.AppServices.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarCargaAdmisiones : AprobarActividadBase
    {
        public int CargadosRiesgo { get; set; }
        public int AprobadosMotor { get; set; }
        public int AprobadosFosyga { get; set; }
        public int EmpleadosCargados { get; set; }
        public int ClientesAdmisiones { get; set; }
        public DateTime HoraEjecucion { get; set; }
    }
}
