﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class ResultadoCargaAdmisiones
    {
        public int InstanciaProcesoId { get; set; }
        public int InstanciaActividadId { get; set; }

        public int CargadosAdmisiones { get; set; }
    }
}
