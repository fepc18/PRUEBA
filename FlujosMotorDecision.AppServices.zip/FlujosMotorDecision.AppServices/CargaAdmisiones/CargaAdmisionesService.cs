﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.DAL.Dtos;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace FlujosMotorDecision.AppServices
{
    public class CargaAdmisionesService : ICargaAdmisionesService
    {
        private readonly IOdsDAL _odsDal;
        private readonly IAdmisionDAL _admisionDal;
        private readonly IProcesoService _procesoService;
        private readonly IAppContext _db;

        public CargaAdmisionesService(IOdsDAL odsDal, IAdmisionDAL admisionDAL, IProcesoService procesoService, IAppContext db)
        {
            _admisionDal = admisionDAL;
            _odsDal = odsDal;
            _procesoService = procesoService;
            _db = db;
        }

        /// <summary>
        /// Realiza la carga en admisiones a partir de los datos recibidos del motor de decisión
        /// </summary>
        /// <param name="dto"></param>
        public void CargarClientesAdmisiones(AprobarCargaAdmisiones dto)
        {
            var tipoProceso = _db.Parametros.First(p => p.Nombre == "TipoProcesoClientes").Valor;
            var actividad = _db.InstanciasActividad.Find(dto.InstanciaActividadId);

            var clientesAprobados = _db.Clientes
                .Where(c => c.InstanciaProcesoId == dto.InstanciaProcesoId && c.ApruebaFosyga && c.ApruebaMotor)
                .Include(e => e.DetalleEmpleado)
                .Select(c => new { c.TipoDocumento, c.Documento, c.Empleado, c.ClienteId, c.DetalleEmpleado.CupoCC, c.DetalleEmpleado.CupoTDC });
            
            //var documentos = clientesAprobAdos.Select(c => c.Documento).ToList();

            var registrosNodoCliente = _odsDal.GetNodoCliente(tipoProceso);
            var registrosNodoSobregiro = _odsDal.GetNodoSobregiro(tipoProceso);
            var registrosNodoTarjeta = _odsDal.GetNodoTarjeta(tipoProceso);
                        
            var listaAdmisiones = new List<RegistroMaestroAsignacion>();

            Parallel.ForEach(clientesAprobados, new ParallelOptions { MaxDegreeOfParallelism = 20 }, c =>
            {
                var regAdmisiones = new RegistroMaestroAsignacion();

                var regNodoCliente = registrosNodoCliente.First(o => o.CLI_NUM_DOC == c.Documento && o.CLI_TIPO_DOC == c.TipoDocumento.ToString());
                var regNodoTarjeta = registrosNodoTarjeta.FirstOrDefault(o => o.CLAVE_UNICA_CLIENTE == regNodoCliente.CLI_TIPO_DOC + regNodoCliente.CLI_NUM_DOC);
                var regNodoSobregiro = registrosNodoSobregiro.FirstOrDefault(o => o.CLAVE_UNICA_CLIENTE == regNodoCliente.CLI_TIPO_DOC + regNodoCliente.CLI_NUM_DOC);

                if (regNodoCliente != null)
                {
                    if (regNodoTarjeta != null)
                        regAdmisiones.CUENTA_TDC = regNodoTarjeta.TDC_NUMERO_PRODUCTO;

                    regAdmisiones.FECHA_ASIGNACION = regNodoCliente.FECHA_PROCESO;
                    regAdmisiones.TIPO_DOCUMENTO = int.Parse(regNodoCliente.CLI_TIPO_DOC);
                    regAdmisiones.NUMERO_DOCUMENTO = regNodoCliente.CLI_NUM_DOC;
                    regAdmisiones.FECHA_ACTUALIZACION_CENTRALES = regNodoCliente.FECHA_PROCESO;
                    regAdmisiones.CLASIFICACION_CENTRALES = regNodoCliente.CMCLI_OFERPROD_CLASI_CENTRALES;
                    regAdmisiones.SCORE_CENTRALES = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_SCORE_CENTRALES);
                    regAdmisiones.NODO = decimal.Parse(regNodoCliente.CMCLI_OFERTAPRODUCTOS_NODO);
                    regAdmisiones.CUOTAS_CREDITO = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_CUOTAS_CREDITO);
                    regAdmisiones.CONTINGENTES = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_CONTINGENTES);
                    regAdmisiones.SCORE_BEHAVIOUR = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_SCORE_BEHAVIOUR);
                    regAdmisiones.ANTIGUEDAD = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_ANTIGUEDAD);
                    regAdmisiones.HABITO_PAGO_PROMEDIO = regNodoCliente.CMCLI_OFERPROD_HABI_PAGO_PROM;
                    regAdmisiones.ESTRATO = int.Parse(regNodoCliente.CMCLI_OFERTAPRODUCTOS_ESTRATO);
                    regAdmisiones.ASIGNA_AUMENTO = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_ASIGNA_AUMENTO);
                    regAdmisiones.ASIGNA_CONSUMO = decimal.Parse(regNodoCliente.CAMPCLIENTES_CF_ASIGNA_CONSUMO);
                    regAdmisiones.ASIGNA_SOBREGIRO = decimal.Parse(regNodoCliente.CMCLI_CF_ASIGNA_SOBREGIRO);
                    regAdmisiones.LINEA_ACTUAL_CONSUMO = float.Parse(regNodoCliente.CMCLI_CF_LINEA_ACTUAL_CONSUMO);
                    regAdmisiones.LINEA_ACTUAL_SOBREGIRO = float.Parse(regNodoCliente.CMCLI_CF_LINEA_ACT_SOBREGIRO);
                    regAdmisiones.LINEA_ACTUAL_TDC = float.Parse(regNodoCliente.CLI_CUPOTOTALACTUALTDC);
                    regAdmisiones.SOPORTE_DOCUMENTOS = decimal.Parse(regNodoCliente.CMCLI_OFERPROD_REQU_SOPOR_INGR);

                    if (regNodoSobregiro != null)
                        regAdmisiones.SALDO_SOBREGIRO = float.Parse(regNodoSobregiro.SGB_SALDO);

                    regAdmisiones.CAPITAL_ACTUAL_CONSUMO = float.Parse(regNodoCliente.CMCLI_CF_CAPITAL_ACT_CONSUMO);
                    if (c.Empleado)
                    {
                        regAdmisiones.MONTO_PREAPROBADO_TC = Convert.ToSingle(c.CupoTDC);
                        regAdmisiones.MONTO_PREAPROBADO_CONSUMO = Convert.ToSingle(c.CupoCC);
                    }
                    else
                    {
                        regAdmisiones.MONTO_PREAPROBADO_TC = float.Parse(regNodoCliente.CMCLI_OFERPROD_PREAPROBAUMCUPO);
                        regAdmisiones.MONTO_PREAPROBADO_CONSUMO = float.Parse(regNodoCliente.CMCLI_OFERPROD_PREAPROBCONSU);
                    }

                    regAdmisiones.MONTO_PREAPROBADO_SOBREGIRO = float.Parse(regNodoCliente.CMCLI_OFERPROD_PREAPROBSOBREGI);

                    listaAdmisiones.Add(regAdmisiones);
                }
            });

            _admisionDal.insertarRegistrosMaestroAsignacion(listaAdmisiones);
            _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
            _db.SaveChanges();


        }

        /// <summary>
        /// Retorna el dto de entrada para la Actividad de Carga a Admisiones
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarCargaAdmisiones GetAprobarCargaAdmisiones(int idProceso, int idActividad)
        {
            var horaEjecucion = _db.Parametros.FirstOrDefault(p => p.Nombre == "HoraEjecucionCreditoEmpleados");
            var dto = new AprobarCargaAdmisiones
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                CargadosRiesgo = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso).Count(),
                AprobadosMotor = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count(),
                AprobadosFosyga = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga).Count(),
                EmpleadosCargados = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.Empleado).Count(),
                ClientesAdmisiones = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga && c.ApruebaMotor).Count(),
                HoraEjecucion = DateTime.Today.Add(TimeSpan.Parse(horaEjecucion.Valor)),
            };
            return dto;
        }

        /// <summary>
        /// Retorna el Dto de salida de la actividad Carga Admisiones
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoCargaAdmisiones GetResultadoCargaAdmisiones(int idProceso, int idActividad)
        {
            var dto = new ResultadoCargaAdmisiones
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                CargadosAdmisiones = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga && c.ApruebaMotor).Count(),
            };
            return dto;
        }
    }
}
