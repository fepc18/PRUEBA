﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    class TarifaTasaConsumoService
    {
       private readonly IAppContext _db;

       public TarifaTasaConsumoService(IAppContext db)
        {
            _db = db;
        }
        
       
        public TarifaTasaConsumo Update(string usuario, TarifaTasaConsumo tarifaTasaConsumo)
        {
            var _tarifaTasaConsumo = _db.TarifaTasaConsumo.Find(tarifaTasaConsumo.TarifaTasaConsumoId);
            _tarifaTasaConsumo = tarifaTasaConsumo;
            _db.SaveChanges();
            return _tarifaTasaConsumo;
        }
    }
}
