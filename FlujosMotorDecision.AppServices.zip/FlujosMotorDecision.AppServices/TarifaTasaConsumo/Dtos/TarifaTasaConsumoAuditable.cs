﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class TarifaTasaConsumoAuditable
    {
        public TarifaTasaConsumo PreviousTarifaTasaConsumo { get; set; }
        public TarifaTasaConsumo CurrentTarifaTasaConsumo { get; set; }
    }
}
