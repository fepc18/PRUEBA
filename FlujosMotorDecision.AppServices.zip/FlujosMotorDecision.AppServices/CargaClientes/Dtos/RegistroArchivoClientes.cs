﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class RegistroArchivoClientes
    {
        [Required(ErrorMessage = "Tipo Documento es obligatorio")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Tipo Documento debe ser de 1 o 2 caracteres")]
        public string TipoDocumento { get; set; }

        [Required(ErrorMessage = "Documento es obligatorio")]
        public string Documento { get; set; }

        [Required(ErrorMessage = "Estado civil es obligatorio")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Estado civil debe ser de 1 o 2 caracteres")]
        public string EstadoCivil { get; set; }

        [Required(ErrorMessage = "Actividad economica es obligatorio")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Actividad economica debe ser de 1 o 2 caracteres")]
        public string ActividadEconomica { get; set; }
    }
}
