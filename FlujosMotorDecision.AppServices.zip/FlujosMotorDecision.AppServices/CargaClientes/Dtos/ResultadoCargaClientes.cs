﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class ResultadoCargaClientes
    {
        public int InstanciaProcesoId { get; set; }
        public int InstanciaActividadId { get; set; }
        public int NumeroClientes { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }             
    }
}
