﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FlujosMotorDecision.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.Web;
using FlujosMotorDecision.AppServices.Validations;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarCargaClientes : AprobarActividadBase
    {        
        public int InstanciaSiguientedId { get; set; }        

        [Required(ErrorMessage = "Por favor seleccione un archivo.")]
        [ValidateInputFile]
        public HttpPostedFileBase Archivo { get; set; }
        
        public string ExtensionesPermitidas { get; set; }

        public string SeparadorArchivoEntrada { get; set; }

        public int TamanoMaximoArchivo { get; set; }

        public string Encabezado { get; set; }
        public string Extension { get; set; }
        public Boolean TieneInconsistencias { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }

     
    }
}
