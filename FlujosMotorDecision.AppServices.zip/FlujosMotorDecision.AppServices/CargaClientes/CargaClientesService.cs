﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Logging;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using FlujosMotorDecision.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity;
namespace FlujosMotorDecision.AppServices
{
    public class CargaClientesService : ICargaClientesService
    {
        private readonly IProcesoService _procesoService;
        private readonly IAppContext _db;
        private ICargaClientesDAL _cargaClientesDAL;
        public ILogger Logger { get; set; }
        public CargaClientesService(IProcesoService procesoService, IAppContext db)
        {
            _procesoService = procesoService;
            _db = db;
            _db.Database.CommandTimeout = 0;

        }
        /// <summary>
        /// Retorna el DTO para la carga del archivo de clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <returns>El dto para la vista de cargar archivo</returns>
        public AprobarCargaClientes GetAprobarCargaClientes(int idProceso, int idActividad)
        {
            var actividad = _db.InstanciasActividad.Find(idActividad);

            var extensiones = _db.Parametros.First(x => x.Nombre == "ExtensionArchivoClientes").Valor;
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoClientes").Valor;
            var tamanoArchivo = int.Parse(ConfigurationManager.AppSettings["TamanoMaxArchivo"]);
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoClientes").Valor;
            separador = separador == '\t'.ToString() ? "TAB" : separador;
            var archivoId = 0;
            var nombreArchivo="";
           
            var tieneInconsistencia = errorCarga(idActividad, idProceso);
            if (tieneInconsistencia)
            {
                Archivo inconsistenciasArchivo = archivoErrorCarga(idActividad, idProceso);
                archivoId = inconsistenciasArchivo.ArchivoId;
                nombreArchivo = inconsistenciasArchivo.Nombre;
            }
            var dto = new AprobarCargaClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                InstanciaSiguientedId = actividad.ActividadSiguienteId.Value,
                ExtensionesPermitidas = extensiones,
                SeparadorArchivoEntrada = separador,
                TamanoMaximoArchivo = tamanoArchivo / (1024 * 1024),
                Encabezado = encabezado,
                Extension = extensiones,
                TieneInconsistencias=tieneInconsistencia,
                ArchivoId=archivoId,
                NombreArchivo=nombreArchivo
            };
            return dto;
        }

        /// <summary>
        /// Retorna el DTO para la carga del archivo de clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <returns>El dto para la vista de cargar archivo</returns>
        public ResultadoCargaClientes GetResultadoCargaClientes(int idProceso, int idActividad)
        {
            var numClientes = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso).Count();
            var archivo = _db.Archivos
                .Select(a => new { a.InstanciaActividadId, a.ArchivoId, a.Nombre })
                .Where(a => a.InstanciaActividadId == idActividad).First();

            var dto = new ResultadoCargaClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                NumeroClientes = numClientes,
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre
            };

            return dto;
        }


        /// <summary>
        /// Carga inicial de los clientes subidos por el area de riesgo
        /// </summary>
        /// <param name="model"></param>
        public void CargarArchivoClientes(AprobarCargaClientes dto)
        {
            if (errorCarga(dto.InstanciaActividadId, dto.InstanciaProcesoId))
            {
                var archivoInconsistencias = archivoErrorCarga(dto.InstanciaActividadId, dto.InstanciaProcesoId);
                _db.Archivos.Remove(archivoInconsistencias);
                _db.SaveChanges();
            }

            var dt = ObtenerDataTable(dto.Archivo.InputStream, dto.InstanciaProcesoId, dto.InstanciaActividadId);
            if (!errorCarga(dto.InstanciaActividadId, dto.InstanciaProcesoId)){
                


               // _cargaClientesDAL = (ICargaClientesDAL)(new CargaClientesDAL());
              //  _cargaClientesDAL.cargarClientes(dto.InstanciaProcesoId);
                //Archivo CARGADO -** PRIMERO SE GUARDAN LOS CLIENTES DEL PLANO Y POSTERIOR SE LEEN JUNTOS CON LA CONSULTA PARA CREAR EL ARCHIVO
                var copyStream = new MemoryStream();
                dto.Archivo.InputStream.CopyTo(copyStream);
                dto.Archivo.InputStream.Position = 0;


                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
                {
                    conn.Open();
                    using (var tr = conn.BeginTransaction())
                    {
                        using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
                        {
                            foreach (DataColumn col in dt.Columns)
                            {
                                bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                            }
                            bulkCopy.DestinationTableName = "dbo.Cliente";
                            bulkCopy.WriteToServer(dt);
                        }
                        tr.Commit();
                    }
                }

                var formatoNombre = _db.Parametros.First(p => p.Nombre == "NombreArchivoClientesConsulta").Valor;
                var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoClientes").Valor;
                var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoClientes").Valor;
                var tipo = "text/plain";

                _db.Database.CommandTimeout = 0;
                var nClientesCargados = _db.Clientes.AsNoTracking().Where(c => c.InstanciaProcesoId == dto.InstanciaProcesoId).ToList();
               
                var sb = new StringBuilder();
                sb.AppendLine(encabezado);
                nClientesCargados.ForEach(c => sb.AppendLine(c.TipoDocumento + separador + c.Documento + separador + c.EstadoCivil + separador + c.ActividadEconomica));
                var documentBytes = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                

                // Cargar archivo plano
                formatoNombre = _db.Parametros.First(p => p.Nombre == "NombreArchivoClientes").Valor;
                tipo = dto.Archivo.ContentType;
               

                var archivoCargado = new Archivo
                {
                    Nombre = String.Format(formatoNombre, DateTime.Today.ToString("yyyyMMdd")),
                    Contenido = documentBytes,
                    Type = tipo,
                    Tamano = documentBytes.Length,
                    InstanciaActividadId = dto.InstanciaActividadId,
                    InstanciaProcesoId = dto.InstanciaProcesoId
                };
                _db.Archivos.Add(archivoCargado);
            
                _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
            }
            

        }

        /// <summary>
        /// Transformar el archivo cargado a un DataTable de Clientes
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="idProceso"></param>
        /// <returns></returns>
        private DataTable ObtenerDataTable(Stream stream, int idProceso,int idActividad)
        {
            var dt = new DataTable();
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoClientes").Valor.ToCharArray()[0];

            using (var sr = new StreamReader(stream))
            {
                var colInstanciaProcesoId = new DataColumn();
                colInstanciaProcesoId.DataType = System.Type.GetType("System.Int32");
                colInstanciaProcesoId.ColumnName = "InstanciaProcesoId";
                dt.Columns.Add(colInstanciaProcesoId);

                var colTipoDocumento = new DataColumn();
                colTipoDocumento.DataType = System.Type.GetType("System.Int32");
                colTipoDocumento.ColumnName = "TipoDocumento";
                dt.Columns.Add(colTipoDocumento);

                dt.Columns.Add("Documento");

                var colEstadoCivil = new DataColumn();
                colEstadoCivil.DataType = System.Type.GetType("System.Int32");
                colEstadoCivil.ColumnName = "EstadoCivil";
                dt.Columns.Add(colEstadoCivil);

                var colActividadEconomica = new DataColumn();
                colActividadEconomica.DataType = System.Type.GetType("System.Int32");
                colActividadEconomica.ColumnName = "ActividadEconomica";
                dt.Columns.Add(colActividadEconomica);

                var colApruebaMotor = new DataColumn();
                colApruebaMotor.DataType = System.Type.GetType("System.Boolean");
                colApruebaMotor.ColumnName = "ApruebaMotor";
                dt.Columns.Add(colApruebaMotor);

                var colApruebaFosyga = new DataColumn();
                colApruebaFosyga.DataType = System.Type.GetType("System.Boolean");
                colApruebaFosyga.ColumnName = "ApruebaFosyga";
                dt.Columns.Add(colApruebaFosyga);

                var colEmpleado = new DataColumn();
                colEmpleado.DataType = System.Type.GetType("System.Boolean");
                colEmpleado.ColumnName = "Empleado";
                dt.Columns.Add(colEmpleado);
                 int numLinea = 0;
                int count = 0;
                sr.ReadLine(); // Descartar encabezado
                Boolean tieneInconsistencias = false;
                Byte[] documentBytes;
                var sb = new StringBuilder();
                
                 

                while (!sr.EndOfStream)
                {
                    var linea = sr.ReadLine();
                    var data = linea.Split(separador);
                    int tipoDocumento;
                    int estadoCivil;
                    int actividadEconomica;                    
                    bool es_valido = true;
                     numLinea++;

                    if (data.Count() != 4)
                    {
                        es_valido = false;
                    }
                    else if (!int.TryParse(data[0], out tipoDocumento))
                    {
                        es_valido = false;
                    }
                    else if (!int.TryParse(data[2], out estadoCivil))
                    {
                        es_valido = false;
                    }
                    else if (!int.TryParse(data[3], out actividadEconomica))
                    {
                        es_valido = false;
                    }
                    if (es_valido)
                    {
                        var row = dt.NewRow();
                        row["InstanciaProcesoId"] = idProceso;
                        row["TipoDocumento"] = int.Parse(data[0]);
                        row["Documento"] = data[1];
                        row["EstadoCivil"] = int.Parse(data[2]);
                        row["ActividadEconomica"] = int.Parse(data[3]);
                        row["ApruebaMotor"] = false;
                        row["ApruebaFosyga"] = false;
                        row["Empleado"] = false;
                        dt.Rows.Add(row);
                        count++;
                    }
                    else{
                        tieneInconsistencias = true;
                        Logger = (ILogger)(new Logger());
                        Logger.Warning(String.Format(Resources.Mensajes.ErrorValidacionLinea, numLinea), "CargaClientesService", "ObtenerDataTable");
                        sb.AppendLine(String.Format(Resources.Mensajes.ErrorValidacionLinea, numLinea));
                        

                        
                    }
                }
                if (tieneInconsistencias)
                {
                    documentBytes = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                    var archivo = new Archivo
                    {
                        Nombre = String.Format("INCONSISTENCIA_CARGA_CLIENTES_"+idProceso.ToString()+".txt"),
                        Contenido = documentBytes,
                        Type = "text/plain",
                        Tamano = documentBytes.Length,
                        InstanciaActividadId =idActividad,
                        InstanciaProcesoId = idProceso
                    };
                    _db.Archivos.Add(archivo);
                    _db.SaveChanges();
                }
            }
            return dt;
        }
        public Boolean errorCarga(int idActividad,int idProceso) {
            var narchivo = _db.Archivos
                           .Where(x => x.InstanciaActividadId == idActividad)                           
                           .Where(x => x.Nombre.Equals("INCONSISTENCIA_CARGA_CLIENTES_"+idProceso.ToString()+".txt")).Count();
            if (narchivo > 0)
                return true;
            else
                return false;
        }
        public Archivo archivoErrorCarga(int idActividad,int idProceso) {
            var archivo = _db.Archivos.Where(x => x.InstanciaProcesoId == idProceso)
                           .Where(x => x.InstanciaActividadId == idActividad)
                           .Where(x => x.InstanciaActividadId == idActividad)
                           .Where(x => x.Nombre.Contains("INCONSISTENCIA_CARGA_CLIENTES_" + idProceso.ToString() + ".txt")).First();
            return archivo;            
        }
        
        

    }
}
