﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
namespace FlujosMotorDecision.AppServices
{
    public interface ICargaClientesService
    {
        /// <summary>
        /// Retorna el DTO para la carga del archivo de clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <returns>El dto para la vista de cargar archivo</returns>
        void CargarArchivoClientes(AprobarCargaClientes dto);

        /// <summary>
        /// Carga inicial de los clientes subidos por el area de riesgo
        /// </summary>
        /// <param name="model"></param>
        AprobarCargaClientes GetAprobarCargaClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el dto con la informacion del resultado de cargue del archivo clientes
        /// </summary>
        /// <param name="model"></param>
        ResultadoCargaClientes GetResultadoCargaClientes(int idProceso, int idActividad);

        Boolean errorCarga(int idActividad, int idProceso);

        Archivo archivoErrorCarga(int idActividad, int idProceso);
    }
}
