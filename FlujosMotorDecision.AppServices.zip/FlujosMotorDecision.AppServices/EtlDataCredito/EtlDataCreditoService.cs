﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL.Contratos;
using FlujosMotorDecision.DAL.Dtos;
using FlujosMotorDecision.EntityFramework;
using Hangfire;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices
{
    public class EtlDataCreditoService : IEtlDataCreditoService
    {
        private readonly IAppContext _db;
        private readonly IProcesoService _procesoService;
        private readonly IDataCreditoDAL _dal;

        public EtlDataCreditoService(IAppContext db, IProcesoService procesoService, IDataCreditoDAL dal)
        {
            _db = db;
            _procesoService = procesoService;
            _dal = dal;
        }
        /// <summary>
        /// Retorna el dto de entrada para la ejecucion de la ETL de Data Crédito
        /// Busca en la ruta de archivos parametrizada para la ETL si hay archivos presentes. 
        /// En caso de encontrarlos los carga a la base de datos. Si no encuentra archivos
        /// en dicha ruta no se permite ejecutar la ETL
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarEtlDataCredito GetAprobarEtlDataCredito(int idProceso, int idActividad)
        {
            var proceso = _db.InstanciasProceso.Find(idProceso);
            string rutaFTP = "";
            var rutaArchivos = "";
            var job = "";

            if (proceso.Proceso.Tipo == TipoProceso.Clientes)
            {
                job = _db.Parametros.First(p => p.Nombre == "JobETLCargaClientes").Valor;
                rutaFTP = _db.Parametros.First(x => x.Nombre == "RutaClientesProcesadosFTPCentrales").Valor;
                rutaArchivos = _db.Parametros.First(x => x.Nombre == "ArchivosClientesETLCentrales").Valor;
            }
            else if (proceso.Proceso.Tipo == TipoProceso.NoClientes)
            {
                job = _db.Parametros.First(p => p.Nombre == "JobETLCargaNoClientes").Valor;
                rutaFTP = _db.Parametros.First(x => x.Nombre == "RutaNoClientesProcesadosFTPCentrales").Valor;
                rutaArchivos = _db.Parametros.First(x => x.Nombre == "ArchivosNoClientesETLCentrales").Valor;
            }

            string[] files = Directory.GetFiles(rutaArchivos);


            bool encontroArchivos = files.Any() ? true : false;
            var resultadoEjecucion = _dal.GetResultadoUltimaEjecucionJob(job);
            bool jobEnEjecucion = _dal.JobEnEjecucion(job);
           // var fechaEjecucion = DateTime.Parse("01/01/1900");
            //if(jobEnEjecucion)
            var fechaEjecucion=DateTime.ParseExact(resultadoEjecucion.UltimaFechaEjecucion.ToString() + resultadoEjecucion.UltimaHoraEjecucion.ToString().PadLeft(6, '0'), "yyyyMMddHHmmss", CultureInfo.InvariantCulture);

            var dto = new AprobarEtlDataCredito
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                RutaETL = rutaArchivos,
                EncontroArchivos = encontroArchivos,
                JobEnEjecucion = jobEnEjecucion,
                Job = job,
                UltimaFechaEjecucion = fechaEjecucion,
                EstadoUltimaEjecucion = resultadoEjecucion.Estado.ToString()
            };

            //nunca se ha ejecutado el job
            if (resultadoEjecucion == null)
            {
                dto.AprobarActividad = false;
            }
            // No esta en ejecucion y se ha ejecutado exitosamente el dia de hoy
            else if (!jobEnEjecucion && resultadoEjecucion.Estado == EstadoJob.Exitoso)
            {
                dto.AprobarActividad = true;
            }
            return dto;
        }

        /// <summary>
        /// Retorna el resultado de la ejecución de ETL Data Credito
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoEtlDataCredito GetResultadoEtlDataCredito(int idProceso, int idActividad)
        {
            var dto = new ResultadoEtlDataCredito
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                Archivos = _db.Archivos.Where(a => a.InstanciaActividadId == idActividad).ToList()
            };
            return dto;
        }

        /// <summary>
        /// Realiza la ejecucion de la ETL 
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="errores"></param>
        public void Ejecutar(AprobarEtlDataCredito dto)
        {
            var job = dto.Job;
            _dal.EjecutarJob(job);
        }

        /// <summary>
        /// Descarga los archivos Respuesta de DataCredito
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public int DescargarArchivos(int idProceso, int idActividad)
        {
            int archivosDescargados = 0;
            var ftp = _db.Parametros.First(x => x.Nombre == "ServidorFTPCentrales").Valor;
            var usuario = _db.Parametros.First(x => x.Nombre == "UsuarioFTPCentrales").Valor;
            var contrasena = _db.Parametros.First(x => x.Nombre == "ContrasenaFTPCentrales").Valor;
            var directorio = _db.Parametros.First(x => x.Nombre == "RutaClientesProcesadosFTPCentrales").Valor;
            var conn = new PasswordConnectionInfo(ftp, usuario, contrasena);
            var rutaEtl = _db.Parametros.First(x => x.Nombre == "ArchivosETLCentrales").Valor;

            using (var sftp = new SftpClient(conn))
            {
                sftp.Connect();
                sftp.ChangeDirectory(directorio);
                var ftpFiles = sftp.ListDirectory(sftp.WorkingDirectory, null);

                foreach (var fileName in ftpFiles)
                {
                    if (!fileName.IsDirectory)
                    {
                        using (var stream = new MemoryStream())
                        {
                            sftp.DownloadFile(fileName.FullName, stream, null);
                            sftp.WriteAllBytes(directorio + Path.DirectorySeparatorChar + fileName.Name, stream.ToArray());
                            sftp.Delete(fileName.FullName);

                            //Copiar a ruta de la ETL
                            using (var fileStream = File.Create(rutaEtl + fileName.Name))
                            {
                                stream.Seek(0, SeekOrigin.Begin);
                                stream.CopyTo(fileStream);
                            }
                            //Guardar en BD
                            var archivo = new Archivo
                            {
                                Contenido = stream.ToArray(),
                                InstanciaActividadId = idActividad,
                                InstanciaProcesoId = idProceso,
                                Nombre = fileName.Name,
                                Type = "text/plain",
                                Tamano = stream.Length
                            };
                            _db.Archivos.Add(archivo);
                            archivosDescargados++;
                        }
                    }
                }
                sftp.Disconnect();
            }
            if (archivosDescargados > 0)
            {
                RecurringJob.RemoveIfExists(idActividad.ToString());
            }
            return archivosDescargados;
        }


        public void AprobarActividad(AprobarEtlDataCredito dto)
        {
            _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
        }
    }
}
