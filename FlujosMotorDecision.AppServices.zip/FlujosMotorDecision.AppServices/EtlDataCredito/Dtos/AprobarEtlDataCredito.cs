﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarEtlDataCredito : AprobarActividadBase
    {                
        public bool EncontroArchivos { get; set; }
        public IList<Archivo> Archivos { get; set; }        
        public string RutaETL { get; set; }
        public bool AprobarActividad { get; set; }

        public string Job { get; set; }

        public bool JobEnEjecucion { get; set; }

        public DateTime UltimaFechaEjecucion { get; set; }

        public string EstadoUltimaEjecucion { get; set; }
    }
}
