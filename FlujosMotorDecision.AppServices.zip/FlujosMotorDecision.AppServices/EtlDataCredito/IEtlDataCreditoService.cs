﻿using FlujosMotorDecision.AppServices.Dtos;
using System;

namespace FlujosMotorDecision.AppServices
{
    public interface IEtlDataCreditoService
    {
        /// <summary>
        /// Retorna el dto de entrada para la ejecucion de la ETL de Data Crédito
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarEtlDataCredito GetAprobarEtlDataCredito(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el resultado de la ejecución de ETL Data Credito
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoEtlDataCredito GetResultadoEtlDataCredito(int idProceso, int idActividad);

        /// <summary>
        /// Realiza la ejecucion de la ETL 
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="errores"></param>
        void Ejecutar(AprobarEtlDataCredito model);

        /// <summary>
        /// Descargar los archivos de respuesta de la campaña clientes de datacredito
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        int DescargarArchivos(int idProceso, int idActividad);

        void AprobarActividad(AprobarEtlDataCredito dto);
    }
}
