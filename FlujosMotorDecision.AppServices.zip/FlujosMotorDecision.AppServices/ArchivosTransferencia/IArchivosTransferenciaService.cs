﻿using FlujosMotorDecision.AppServices.ArchivosTransferencia.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public interface IArchivosTransferenciaService
    {
        /// <summary>
        /// Retorna el registro del encabezado
        /// </summary>
        /// <returns></returns>
        string getRegistroHeader();

        /// <summary>
        /// Retorna el registro del final del archivo
        /// </summary>
        /// <param name="numRegistros">numero de registros que contiene el archivo</param>
        /// <returns></returns>
        string getRegistroTrailer(int numRegistros);

        /// <summary>
        /// Retorna el registro que indica el final del archivo
        /// </summary>
        /// <returns></returns>
        string getRegistroTransferenciaCliente(string tipoDocumento, string Documento, string nuevoTipoDocumento, string nuevoDocumento);

        /// <summary>
        /// Retorna el registro de transferencia para las centrales de riesgo
        /// </summary>
        /// <param name="tipoDocumento"></param>
        /// <param name="documento"></param>
        /// <param name="nuevoTipoDocumento"></param>
        /// <param name="nuevoDocumento"></param>
        /// <returns></returns>
        string getRegistroTransferenciaCR(string tipoDocumento, string documento, string nuevoTipoDocumento, string nuevoDocumento);        

        /// <summary>
        /// Retorna un string con el contenido del archivo de transferencia de clientes
        /// </summary>
        /// <param name="lineas"></param>
        /// <returns></returns>
        string generarArchivoClientes(IList<RegistroArchivoEntrada> lineas);


        /// <summary>
        /// Retorna un string con el contenido del archivo de transferencia para centrales de riesgo
        /// </summary>
        /// <param name="lineas"></param>
        /// <returns></returns>
        string generarArchivoCentralesRiesgo(IList<RegistroArchivoEntrada> lineas);


        /// <summary>
        /// Realiza el envio al servidor FTP
        /// </summary>
        /// <param name="archivoClientes"></param>
        /// <param name="archivoCentrales"></param>
        void enviarArchivosFTP(string archivoClientes, string archivoCentrales);

        /// <summary>
        /// Deja los archivos en la ruta compartida parametrizada
        /// </summary>
        /// <param name="strArchivoClientes"></param>
        /// <param name="strArchivoCentrales"></param>
        void enviarRutaCompartida(string strArchivoClientes, string strArchivoCentrales);
    }
}
