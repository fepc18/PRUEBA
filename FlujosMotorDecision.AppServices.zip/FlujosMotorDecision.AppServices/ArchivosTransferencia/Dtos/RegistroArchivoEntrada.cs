﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices.ArchivosTransferencia.DTOs
{
    public class RegistroArchivoEntrada
    {
        [Required(ErrorMessage ="Tipo Documento es obligatorio")]
        [StringLength(3, MinimumLength = 2, ErrorMessage = "Tipo Documento debe ser de 2 caracteres")]
        public string TipoDocumento { get; set; }
        [Required(ErrorMessage = "Documento es obligatorio")]
        public string Documento { get; set; }

        [Required(ErrorMessage = "Nuevo Tipo Documento es obligatorio")]
        [StringLength(3, MinimumLength = 2, ErrorMessage = "NuevoTipoDocumento debe ser de 2 caracteres")]
        public string NuevoTipoDocumento { get; set; }

        [Required(ErrorMessage = "Documento es obligatorio")]
        public string NuevoDocumento { get; set; }
    }
}
