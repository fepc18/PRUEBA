﻿using FlujosMotorDecision.AppServices.ArchivosTransferencia.DTOs;
using FlujosMotorDecision.EntityFramework;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public class ArchivosTransferenciaService : IArchivosTransferenciaService
    {
        private const char LOW_VALUE = '0';
        private const char HIGH_VALUE = 'F';

        private const int CLAVE_CLIENTE_LENGTH = 20;
        private const int CLAVE_CUENTA_LENGTH = 20;

        private const int RECORD_COUNT_LENGTH = 12;

        private const int ID_REGISTRO_TRANSFERENCIA = 25;
        private const string ID_CENTRALES_RIESGO = "SBS";

        private const string DATE_FORMAT = "yyyyMMdd";
        private const string TIME_FORMAT = "hhmm";

        private const string SEPARADOR = ",";

        private const string NOM_ARCHIVO_CLIENTES = "Input_{0}_TR_CL.csv";
        private const string NOM_ARCHIVO_CENTRALES = "Input_{0}_TR_SB.csv";

        private readonly IAppContext _db;

        public ArchivosTransferenciaService(IAppContext db)
        {
            _db = db;
        }
        /// <summary>
        /// Retorna el registro del encabezado
        /// </summary>
        /// <returns></returns>
        public string getRegistroHeader()
        {
            var sb = new StringBuilder();
            sb.Append(Repeat(LOW_VALUE, CLAVE_CLIENTE_LENGTH))
                .Append(Repeat(LOW_VALUE, CLAVE_CUENTA_LENGTH))
                .Append(SEPARADOR)
                .Append(DateTime.Today.ToString(DATE_FORMAT))
                .Append(SEPARADOR)
                .Append(DateTime.Now.ToString(TIME_FORMAT));

            return sb.ToString();
        }

        /// <summary>
        /// Retorna el registro del final del archivo
        /// </summary>
        /// <param name="numRegistros">numero de registros que contiene el archivo</param>
        /// <returns></returns>
        public string getRegistroTrailer(int numRegistros)
        {
            var sb = new StringBuilder();

            sb.Append(Repeat(HIGH_VALUE, CLAVE_CLIENTE_LENGTH))
                .Append(Repeat(HIGH_VALUE, CLAVE_CUENTA_LENGTH))
                .Append(SEPARADOR)
                .Append(numRegistros.ToString().PadLeft(RECORD_COUNT_LENGTH, LOW_VALUE));

            return sb.ToString();
        }

        /// <summary>
        /// Retorna el registro de transferencia para las centrales de riesgo
        /// </summary>
        /// <param name="tipoDocumento"></param>
        /// <param name="documento"></param>
        /// <param name="nuevoTipoDocumento"></param>
        /// <param name="nuevoDocumento"></param>
        /// <returns></returns>
        public string getRegistroTransferenciaCR(string tipoDocumento, string documento, string nuevoTipoDocumento, string nuevoDocumento)
        {
            string identificador = tipoDocumento + documento;

            string nuevoIdentificador = nuevoTipoDocumento + nuevoDocumento;
            var sb = new StringBuilder();

            sb.Append(identificador.PadLeft(20, LOW_VALUE)) //CLAVE_UNICA_CLIENTE
                .Append(SEPARADOR)
                .Append(ID_CENTRALES_RIESGO)
                .Append(identificador.PadLeft(17, LOW_VALUE))//CLAVE_UNICA_CUENTA
                .Append(SEPARADOR)
                .Append(ID_REGISTRO_TRANSFERENCIA)//RECORD_TYPE
                .Append(SEPARADOR)
                .Append(String.Empty.PadLeft(20, LOW_VALUE))//CLAVE_UNICA_CLIENTE_NUEVO
                .Append(SEPARADOR)
                .Append(ID_CENTRALES_RIESGO)
                .Append(nuevoIdentificador.PadLeft(17, LOW_VALUE));//CLAVE_UNICA_CUENTA_NUEVO

            return sb.ToString();
        }

        /// <summary>
        /// Retorna el registro de transferencia de cliente
        /// </summary>
        /// <param name="tipoDocumento"></param>
        /// <param name="documento"></param>
        /// <param name="nuevoTipoDocumento"></param>
        /// <param name="nuevoDocumento"></param>
        /// <returns></returns>
        public string getRegistroTransferenciaCliente(string tipoDocumento, string documento, string nuevoTipoDocumento, string nuevoDocumento)
        {
            string identificador = tipoDocumento + documento;

            string nuevoIdentificador = nuevoTipoDocumento + nuevoDocumento;
            var sb = new StringBuilder();

            sb.Append(identificador.PadLeft(20, LOW_VALUE))//CLAVE_UNICA_CLIENTE
                .Append(SEPARADOR)
                .Append(Repeat(LOW_VALUE, CLAVE_CUENTA_LENGTH))//CLAVE_UNICA_CUENTA
                .Append(SEPARADOR)
                .Append(ID_REGISTRO_TRANSFERENCIA)//RECORD_TYPE
                .Append(SEPARADOR)
                .Append(nuevoIdentificador.PadLeft(20, LOW_VALUE))//CLAVE_UNICA_CLIENTE_NUEVO
                .Append(SEPARADOR)
                .Append(String.Empty.PadLeft(20, LOW_VALUE));//CLAVE_UNICA_CLIENTE_NUEVO;

            return sb.ToString();
        }

        public string generarArchivoClientes(IList<RegistroArchivoEntrada> lineas)
        {
            var sb = new StringBuilder();
            sb.AppendLine(getRegistroHeader());

            foreach (var linea in lineas)
            {
                sb.AppendLine(getRegistroTransferenciaCliente(linea.TipoDocumento,
                                                              linea.Documento,
                                                              linea.NuevoTipoDocumento,
                                                              linea.NuevoDocumento));
            }

            sb.Append(getRegistroTrailer(lineas.Count));
            return sb.ToString();
        }

        /// <summary>
        /// Retorna un string con el contenido del archivo de transferencia de clientes
        /// </summary>
        /// <param name="lineas"></param>
        /// <returns></returns>
        public string generarArchivoCentralesRiesgo(IList<RegistroArchivoEntrada> lineas)
        {
            var sb = new StringBuilder();
            sb.AppendLine(getRegistroHeader());

            foreach (var linea in lineas)
            {
                sb.AppendLine(getRegistroTransferenciaCR(linea.TipoDocumento,
                                                              linea.Documento,
                                                              linea.NuevoTipoDocumento,
                                                              linea.NuevoDocumento));
            }

            sb.Append(getRegistroTrailer(lineas.Count));
            return sb.ToString();
        }

        /// <summary>
        /// Envia los archivos generados a la ruta parametrizada en el Web.Config
        /// </summary>
        /// <param name="strArchivoClientes"></param>
        /// <param name="strArchivoCentrales"></param>
        public void enviarArchivosFTP(string strArchivoClientes, string strArchivoCentrales)
        {
            var servidorFTP = _db.Parametros.First(x => x.Nombre == "ServidorFTPMotor").Valor;
            var usuarioFTP = _db.Parametros.First(x => x.Nombre == "UsuarioFTPMotor").Valor;
            var contrasenaFTP = _db.Parametros.First(x => x.Nombre == "ContrasenaFTPMotor").Valor;
            var directorioFTP = _db.Parametros.First(x => x.Nombre == "RutaArchivosMotor").Valor;

            var archivoClientes = Encoding.Default.GetBytes(strArchivoClientes);
            archivoClientes = Encoding.Default.GetPreamble().Concat(archivoClientes).ToArray();

            var archivoCentrales = Encoding.Default.GetBytes(strArchivoClientes);
            archivoCentrales = Encoding.Default.GetPreamble().Concat(archivoClientes).ToArray();

            var conn = new PasswordConnectionInfo(servidorFTP, usuarioFTP, contrasenaFTP);
            using (var sftp = new SftpClient(conn))
            {
                sftp.Connect();
                sftp.ChangeDirectory(directorioFTP);

                sftp.WriteAllBytes(sftp.WorkingDirectory + String.Format(NOM_ARCHIVO_CLIENTES, DateTime.Today.ToString(DATE_FORMAT)), archivoClientes);
                sftp.WriteAllBytes(sftp.WorkingDirectory + String.Format(NOM_ARCHIVO_CENTRALES, DateTime.Today.ToString(DATE_FORMAT)), archivoCentrales);
                sftp.Disconnect();
            }
        }

        /// <summary>
        /// Envia los archivos generados a la ruta parametrizada en el Web.Config
        /// </summary>
        /// <param name="strArchivoClientes"></param>
        /// <param name="strArchivoCentrales"></param>
        public void enviarRutaCompartida(string strArchivoClientes, string strArchivoCentrales)
        {
            var rutaCompartida = _db.Parametros.First(x => x.Nombre == "MOTOR_RUTA_COMPARTIDA").Valor;
            var archivoClientes = Encoding.Default.GetBytes(strArchivoClientes);
            archivoClientes = Encoding.Default.GetPreamble().Concat(archivoClientes).ToArray();

            var archivoCentrales = Encoding.Default.GetBytes(strArchivoClientes);
            archivoCentrales = Encoding.Default.GetPreamble().Concat(archivoClientes).ToArray();

            File.WriteAllBytes(rutaCompartida + Path.DirectorySeparatorChar + String.Format(NOM_ARCHIVO_CLIENTES, DateTime.Today.ToString(DATE_FORMAT)), archivoClientes);
            File.WriteAllBytes(rutaCompartida + Path.DirectorySeparatorChar + String.Format(NOM_ARCHIVO_CENTRALES, DateTime.Today.ToString(DATE_FORMAT)), archivoCentrales);
        }

        /// <summary>
        /// Repetir el caracter recibido el numero dado de veces
        /// </summary>
        /// <param name="c"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        private static string Repeat(char c, int count)
        {
            return String.Concat(Enumerable.Repeat(c, count));
        }
    }
}
