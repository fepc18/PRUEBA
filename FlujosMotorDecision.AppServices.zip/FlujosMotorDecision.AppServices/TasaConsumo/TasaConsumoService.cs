﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.SqlServer;
using System.IO;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public class TasaConsumoService : ITasaConsumoService
    {
        private readonly IAppContext _db;

        public TasaConsumoService(IAppContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Retorna la instancia del TasaConsumo dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public TasaConsumoMaestro GetTasaConsumoMaestro(int id)
        {
            return _db.TasaConsumoMaestro.Find(id);
        }
        /// <summary>
        /// Retorna la instancia del TasaConsumo dado el mes y el año
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Boolean ExistsTasaConsumoByMesAnio(Mes mes, int anio)
        {
             int n=_db.TasaConsumoMaestro.Where(x => x.Mes == mes).Where(x => x.Anio == anio).Count();
             if (n > 0)
                 return true;
             else
                 return false;
        }

         /// <summary>
        /// Retorna la instancia del TasaConsumo dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DetalleTasaConsumo GetTarifasByTasa(int idTasaConsumo)
        {
            var tasaConsumo = _db.TasaConsumoMaestro.Find(idTasaConsumo);
            var tarifas = _db.TarifaTasaConsumo.Where(x => x.TasaConsumoMaestroId == idTasaConsumo).ToList();
          /*  var list = from s in _db.TarifaTasaConsumo
                       select new
                           {
                               s.TarifaTasaConsumoId,
                               s.TasaConsumoMaestroId,
                               s.Grupo,
                              s.Tarifa ,
                               s.Observacion
                           } ;
            List<TarifaTasaConsumo> t = new List<TarifaTasaConsumo>();
            foreach (var item in list)
            {
                TarifaTasaConsumo tarifa= new TarifaTasaConsumo();
                tarifa.TarifaTasaConsumoId = item.TarifaTasaConsumoId;
                tarifa.TasaConsumoMaestroId = item.TasaConsumoMaestroId;
                tarifa.Grupo = item.Grupo;
                tarifa.Tarifa = 0;//Convert.ToDouble(item.Tarifa) ;
                tarifa.Observacion = item.Observacion;
                t.Add(tarifa);
                
            }*/

            var dto = new DetalleTasaConsumo
            {
                TasaConsumoMaestro = tasaConsumo,
                Tarifas = tarifas
            };
            return dto;
        }
         /// <summary>
        /// Retorna la instancia del TasaConsumo dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<TasaConsumoMaestro> GetAllTasaConsumoMaestro()
        {
            var tasasConsumo = _db.TasaConsumoMaestro.ToList();
            return tasasConsumo;
        }
        
        /// <summary>
        /// Crea un nuevo TasaConsumo del tipo indicado
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public TasaConsumoMaestro Create(string usuario, TasaConsumoMaestro tasaConsumoMaestro)
        {
            // Cargar el TasaConsumo
            _db.TasaConsumoMaestro.Add(tasaConsumoMaestro);
            _db.SaveChanges();
            // Las tarifas
            return tasaConsumoMaestro;
        }
        public TasaConsumoMaestro Update(string usuario, TasaConsumoMaestro tasaConsumoMaestro)
        {
            var _tasaConsumoMaestro = _db.TasaConsumoMaestro.Find(tasaConsumoMaestro.TasaConsumoMaestroId);
            _tasaConsumoMaestro.NumeroGrupos = tasaConsumoMaestro.NumeroGrupos;//Math.Round(tarifaTasaConsumo.Tarifa,5);
            _db.SaveChanges();
            return _tasaConsumoMaestro;
        }
        public TasaConsumoMaestro Delete(int id)
        {
            var TasaConsumo = _db.TasaConsumoMaestro.Find(id);
            _db.TasaConsumoMaestro.Remove(TasaConsumo);
            _db.SaveChanges();
            return TasaConsumo;
        }

        public TarifaTasaConsumo Create(string usuario, TarifaTasaConsumo tarifaTasaConsumo)
        {
            tarifaTasaConsumo.Observacion = tarifaTasaConsumo.Observacion == null ? "" : tarifaTasaConsumo.Observacion;
            _db.TarifaTasaConsumo.Add(tarifaTasaConsumo);
            _db.SaveChanges();
            return tarifaTasaConsumo;
        }
        public TarifaTasaConsumo GetTarifaById(int idTarifa)
        {
            return _db.TarifaTasaConsumo.Where(X => X.TarifaTasaConsumoId == idTarifa).First();
        }
        public TarifaTasaConsumo Update(string usuario, TarifaTasaConsumo tarifaTasaConsumo)
        {
            var _tarifaTasaConsumo = _db.TarifaTasaConsumo.Find(tarifaTasaConsumo.TarifaTasaConsumoId);
            _tarifaTasaConsumo.Tarifa = tarifaTasaConsumo.Tarifa;//Math.Round(tarifaTasaConsumo.Tarifa,5);
            _tarifaTasaConsumo.Observacion = tarifaTasaConsumo.Observacion == null ? "" : tarifaTasaConsumo.Observacion;
            _db.SaveChanges();            
            _tarifaTasaConsumo = _db.TarifaTasaConsumo.Find(tarifaTasaConsumo.TarifaTasaConsumoId);
            return _tarifaTasaConsumo;
        }
        public TarifaTasaConsumo DeleteTarifa(int id)
        {
            var Tarifa = _db.TarifaTasaConsumo.Find(id);
            _db.TarifaTasaConsumo.Remove(Tarifa);
            _db.SaveChanges();
            return Tarifa;
        }
        public int GetMaxGrupoTasaConsumo(int id) {
            return _db.TarifaTasaConsumo.Where(x => x.TasaConsumoMaestroId == id)
                    .Max(y => y.Grupo);
        }
    }
}

