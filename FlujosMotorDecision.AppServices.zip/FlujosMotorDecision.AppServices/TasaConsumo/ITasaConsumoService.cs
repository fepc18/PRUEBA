﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public interface ITasaConsumoService
    {
    
        /// <summary>
        /// Retorna la instancia del TasaConsumo dado su id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        TasaConsumoMaestro GetTasaConsumoMaestro(int id);
        Boolean ExistsTasaConsumoByMesAnio(Mes mes, int anio);

        IEnumerable<TasaConsumoMaestro> GetAllTasaConsumoMaestro();
        
        /// <summary>
        /// Crea un nuevo Maestro TasaConsumo 
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        TasaConsumoMaestro Create(string usuario, TasaConsumoMaestro tasaConsumoMaestro);
        
        /// <summary>
        /// Calceña TasaConsumo  indicado
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        TasaConsumoMaestro Delete(int id);
        TasaConsumoMaestro Update(string usuario, TasaConsumoMaestro tasaConsumoMaestro);
        
        DetalleTasaConsumo GetTarifasByTasa(int idTasaConsumo);

        TarifaTasaConsumo Create(string usuario, TarifaTasaConsumo tarifaTasaConsumo);
        TarifaTasaConsumo GetTarifaById(int idTarifa);
        TarifaTasaConsumo Update(string usuario, TarifaTasaConsumo tarifaTasaConsumo);
        TarifaTasaConsumo DeleteTarifa(int id);
        int GetMaxGrupoTasaConsumo(int id);
    }
}
