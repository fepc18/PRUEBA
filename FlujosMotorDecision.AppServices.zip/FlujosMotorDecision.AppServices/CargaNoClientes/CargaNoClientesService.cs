﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using FlujosMotorDecision.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices
{
    public class CargaNoClientesService : ICargaNoClientesService
    {
        private readonly IProcesoService _procesoService;
        private readonly IAppContext _db;
        public ILogger Logger { get; set; }

        public CargaNoClientesService(IProcesoService procesoService, IAppContext db)
        {
            _procesoService = procesoService;
            _db = db;
        }

        /// <summary>
        /// Realiza la carga de los NoClientes recibidos en la base de datos
        /// </summary>
        /// <param name="dto"></param>
        public void CargarArchivoNoClientes(AprobarCargaNoClientes dto)
        {
            if (errorCarga(dto.InstanciaActividadId, dto.InstanciaProcesoId))
            {
                var archivoInconsistencias = archivoErrorCarga(dto.InstanciaActividadId, dto.InstanciaProcesoId);
                _db.Archivos.Remove(archivoInconsistencias);
                _db.SaveChanges();
            }


            var copyStream = new MemoryStream();
            dto.Archivo.InputStream.CopyTo(copyStream);
            dto.Archivo.InputStream.Position = 0;
            var dt = ObtenerDataTable(dto.Archivo.InputStream, dto.InstanciaProcesoId,dto.InstanciaActividadId);
            if (!errorCarga(dto.InstanciaActividadId, dto.InstanciaProcesoId))
            {

                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
                {
                    conn.Open();
                    using (var tr = conn.BeginTransaction())
                    {
                        using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
                        {
                            foreach (DataColumn col in dt.Columns)
                            {
                                bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                            }
                            bulkCopy.DestinationTableName = "dbo.NoCliente";
                            bulkCopy.WriteToServer(dt);
                        }
                        tr.Commit();
                    }
                }

                var nombre = Path.GetFileName(dto.Archivo.FileName);
                var tipo = dto.Archivo.ContentType;
                var documentBytes = copyStream.ToArray();


                var archivoCargado = new Archivo
                {
                    Nombre = nombre,
                    Contenido = documentBytes,
                    Type = tipo,
                    Tamano = documentBytes.Length,
                    InstanciaActividadId = dto.InstanciaActividadId,
                    InstanciaProcesoId = dto.InstanciaProcesoId
                };
                _db.Archivos.Add(archivoCargado);
                _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
            }
        }

        /// <summary>
        /// Retorna el Dto de entrada para la Carga de No Clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarCargaNoClientes GetAprobarCargaNoClientes(int idProceso, int idActividad)
        {
            var tamanoArchivo = int.Parse(ConfigurationManager.AppSettings["TamanoMaxArchivo"]);
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorEnvioNoClientes").Valor;
            separador = separador == '\t'.ToString() ? "TAB" : separador;

            var extension = _db.Parametros.First(x => x.Nombre == "ExtensionArchivoNoClientes").Valor;
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoNoClientes").Valor;
            var archivoId = 0;
            var nombreArchivo = "";

            var tieneInconsistencia = errorCarga(idActividad, idProceso);
            if (tieneInconsistencia)
            {
                Archivo inconsistenciasArchivo = archivoErrorCarga(idActividad, idProceso);
                archivoId = inconsistenciasArchivo.ArchivoId;
                nombreArchivo = inconsistenciasArchivo.Nombre;
            }
            var dto = new AprobarCargaNoClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                SeparadorArchivoEntrada = separador,
                Extension = extension,
                TamanoMaximoArchivo = tamanoArchivo / (1024 * 1024),
                Encabezado = encabezado,
                TieneInconsistencias = tieneInconsistencia,
                ArchivoId = archivoId,
                NombreArchivo = nombreArchivo
            };
            return dto;
        }

        /// <summary>
        /// Retorna el Dto de salida para la carga de No Clientes
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoCargaNoClientes GetResultadoCargaNoClientes(int idProceso, int idActividad)
        {
            var archivo = _db.Archivos
                .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                .First(a => a.InstanciaActividadId == idActividad);            

            var dto = new ResultadoCargaNoClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                NoClientesCargados = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso).Count(),
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre,
            };
            return dto;
        }

        private DataTable ObtenerDataTable(Stream stream, int idProceso,int idActividad)
        {
            var dt = new DataTable();
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorEnvioNoClientes").Valor.ToCharArray()[0];

            using (var sr = new StreamReader(stream))
            {
                var colInstanciaProcesoId = new DataColumn();
                colInstanciaProcesoId.DataType = System.Type.GetType("System.Int32");
                colInstanciaProcesoId.ColumnName = "InstanciaProcesoId";
                dt.Columns.Add(colInstanciaProcesoId);

                var colTipoDocumento = new DataColumn();
                colTipoDocumento.DataType = System.Type.GetType("System.Int32");
                colTipoDocumento.ColumnName = "TipoDocumento";
                dt.Columns.Add(colTipoDocumento);

                dt.Columns.Add("Documento");


                var colApruebaFosyga = new DataColumn();
                colApruebaFosyga.DataType = System.Type.GetType("System.Boolean");
                colApruebaFosyga.ColumnName = "ApruebaFosyga";
                dt.Columns.Add(colApruebaFosyga);

                var colApruebaMotor = new DataColumn();
                colApruebaMotor.DataType = System.Type.GetType("System.Boolean");
                colApruebaMotor.ColumnName = "ApruebaMotor";
                dt.Columns.Add(colApruebaMotor);

                var colApruebaReconocer = new DataColumn();
                colApruebaReconocer.DataType = System.Type.GetType("System.Boolean");
                colApruebaReconocer.ColumnName = "ApruebaReconocer";
                dt.Columns.Add(colApruebaReconocer);

                int count = 0;
                int numLinea = 0;
                sr.ReadLine(); // Descartar encabezado
                Boolean tieneInconsistencias = false;
                Byte[] documentBytes;
                var sb = new StringBuilder();
                while (!sr.EndOfStream)
                {
                    int tipoDocumento;
                    bool es_valido=true;
                    var linea = sr.ReadLine();
                    numLinea++;
                    var data = linea.Split(separador);                    
                    if (data.Count() != 2)
                    {
                        es_valido = false;                        
                    }
                    else if (!int.TryParse(data[0], out tipoDocumento))
                    {
                        es_valido = false;
                    }
                    else if (data[1].ToString().Equals(""))
                    {
                        es_valido = false;
                    }
                    if (es_valido)
                    {
                        var row = dt.NewRow();
                        row["InstanciaProcesoId"] = idProceso;
                        row["TipoDocumento"] = int.Parse(data[0]);
                        row["Documento"] = data[1];
                        row["ApruebaFosyga"] = false;
                        row["ApruebaMotor"] = false;
                        row["ApruebaReconocer"] = false;
                        dt.Rows.Add(row);
                        count++;
                    }
                    else
                    {
                        tieneInconsistencias = true;
                        Logger = (ILogger)(new Logger());
                        Logger.Warning(String.Format(Resources.Mensajes.ErrorValidacionLinea, numLinea), "CargaNoClientesService", "ObtenerDataTable");
                        sb.AppendLine(String.Format(Resources.Mensajes.ErrorValidacionLinea, numLinea));
                    }
                    
                }
                if (tieneInconsistencias)
                {
                    documentBytes = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                    var archivo = new Archivo
                    {
                        Nombre = String.Format("INCONSISTENCIA_CARGA_NOCLIENTES_" + idProceso.ToString() + ".txt"),
                        Contenido = documentBytes,
                        Type = "text/plain",
                        Tamano = documentBytes.Length,
                        InstanciaActividadId = idActividad,
                        InstanciaProcesoId = idProceso
                    };
                    _db.Archivos.Add(archivo);
                    _db.SaveChanges();
                }
            }
            return dt;
        }

        public Boolean errorCarga(int idActividad, int idProceso)
        {
            var narchivo = _db.Archivos
                           .Where(x => x.InstanciaActividadId == idActividad)
                           .Where(x => x.Nombre.Equals("INCONSISTENCIA_CARGA_NOCLIENTES_" + idProceso.ToString() + ".txt")).Count();
            if (narchivo > 0)
                return true;
            else
                return false;
        }
        public Archivo archivoErrorCarga(int idActividad, int idProceso)
        {
            var archivo = _db.Archivos.Where(x => x.InstanciaProcesoId == idProceso)
                           .Where(x => x.InstanciaActividadId == idActividad)
                           .Where(x => x.InstanciaActividadId == idActividad)
                           .Where(x => x.Nombre.Contains("INCONSISTENCIA_CARGA_NOCLIENTES_" + idProceso.ToString() + ".txt")).First();
            return archivo;
        }
    }
}
