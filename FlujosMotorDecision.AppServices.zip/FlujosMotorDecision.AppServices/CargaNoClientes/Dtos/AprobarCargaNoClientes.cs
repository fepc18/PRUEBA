﻿using FlujosMotorDecision.AppServices.Validations;
using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarCargaNoClientes : AprobarActividadBase
    {        
        [Required(ErrorMessage = "Por favor seleccione un archivo.")]
        [ValidateInputFile]
        public HttpPostedFileBase Archivo { get; set; }
        public string SeparadorArchivoEntrada { get; set; }
        public string Extension { get; set; }

        public int TamanoMaximoArchivo { get; set; }

        public string Encabezado { get; set; }
        public IList<NoCliente> NoClientes { get; set; }
        public Boolean TieneInconsistencias { get; set; }
        public int ArchivoId { get; set; }
        public string NombreArchivo { get; set; }
    }
}
