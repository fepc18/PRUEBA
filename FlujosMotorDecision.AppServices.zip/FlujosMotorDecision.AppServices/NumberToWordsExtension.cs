﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace FlujosMotorDecision.AppServices
{
    public static class ToWordsConverter
    {
        private static readonly string[] UnitsMap = { "cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", 
                                                        "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve", "veinte", "veintiuno",
                                                        "veintidós", "veintitrés", "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve"};
        
        private static readonly string[] TensMap = { "cero", "diez", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa" };
        private static readonly string[] HundredsMap = { "cero", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos" };        

        private static readonly Dictionary<long, string> Ordinals = new Dictionary<long, string>
        {
            {1, "primero"},
            {2, "segundo"},
            {3, "tercero"},
            {4, "quarto"},
            {5, "quinto"},
            {6, "sexto"},
            {7, "séptimo"},
            {8, "octavo"},
            {9, "noveno"},
            {10, "décimo"}
        };

        public static string Convert(long number)
        {
            if (number == 0)
                return "cero";

            if (number < 0)
                return string.Format("menos {0}", Convert(Math.Abs(number)));

            var parts = new List<string>();

            if ((number / 1000000000000) > 0)
            {
                parts.Add(number / 1000000000000 == 1
                    ? "un billón"
                    : string.Format("{0} billones", Convert(number / 1000000000000)));

                number %= 1000000000000;
            }
            if ((number / 1000000000) > 0)
            {
                parts.Add(number / 1000000000 == 1
                    ? "mil millones"
                    : string.Format("{0} mil millones", Convert(number / 1000000000)));

                number %= 1000000000;
            }

            if ((number / 1000000) > 0)
            {
                parts.Add(number / 1000000 == 1
                    ? "un millón"
                    : string.Format("{0} millones", Convert(number / 1000000)));

                number %= 1000000;
            }

            if ((number / 1000) > 0)
            {
                parts.Add(number / 1000 == 1
                    ? "mil"
                    : string.Format("{0} mil", Convert(number / 1000)));

                number %= 1000;
            }

            if ((number / 100) > 0)
            {
                parts.Add(number == 100
                    ? "cien" : HundredsMap[(number / 100)]);
                number %= 100;
            }

            if (number > 0)
            {
                if (number < 30)
                {                                                      
                    parts.Add(UnitsMap[number]);
                }
                else
                {
                    var lastPart = TensMap[number / 10];
                    int units = (int)number % 10;                    
                    if (units > 0)
                    {
                        lastPart += string.Format(" y {0}", UnitsMap[number % 10]);
                    }
                    parts.Add(lastPart);
                }
            }

            return string.Join(" ", parts.ToArray());
        }

        public static string ConvertToOrdinal(this long number)
        {
            string towords;
            if (!Ordinals.TryGetValue(number, out towords))
                towords = Convert(number);
            
            if (number % 10 == 1 || number % 10 == 3)
                towords = towords.TrimEnd('o');

            int count = new Regex(Regex.Escape("millones")).Matches(towords).Count;
            while (count > 1)
            {
                int pos = towords.IndexOf("millones");
                towords = towords.Substring(0, pos) + "" + towords.Substring(pos + "millones".Length);
                count = new Regex(Regex.Escape("millones")).Matches(towords).Count;
            }                
            return towords;
        }
    }
}