﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public interface IActividadService
    {
        Actividad GetActividadInstancia(int idInstanciaAtividad);

        InstanciaActividad GetInstancia(int idActividad);
        InstanciaActividad GetActividadActualProceso(int idProceso);

        IEnumerable<Actividad> GetActividades(TipoProceso tipoProceso);
        IEnumerable<InstanciaActividad> GetActividadesInstancia(int idProceso);
    }
}
