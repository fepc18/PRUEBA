﻿using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace FlujosMotorDecision.AppServices
{
    public class ActividadService : IActividadService
    {
        private readonly IAppContext _db;

        public ActividadService(IAppContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Retorna la InstancaActividadProceso dado su llave primaria.        
        /// </summary>
        /// <param name="idActividad">Llave primaria de la InstanciaActividadProceso a retornar</param>
        /// <returns></returns>
        public Actividad GetActividadInstancia(int idInstanciaAtividad)
        {
            return _db.InstanciasActividad.Find(idInstanciaAtividad).ActividadProceso.Actividad;
        }

        /// <summary>
        /// Retorna la InstancaActividadProceso dado su llave primaria.        
        /// </summary>
        /// <param name="idActividad">Llave primaria de la InstanciaActividadProceso a retornar</param>
        /// <returns></returns>
        public InstanciaActividad GetInstancia(int idActividad)
        {
            return _db.InstanciasActividad.Find(idActividad);
        }
        /// <summary>
        /// Retorna la Actividad iniciada del idProceso recibido.
        /// La ActividadActual se determina como la unica ActividadProcesoClientes en estado Iniciado
        /// </summary>
        /// <param name="idProceso"></param>
        /// <returns></returns>
        public InstanciaActividad GetActividadActualProceso(int idProceso)
        {
            var instanciaActividad = _db.InstanciasActividad                
                .Include(x => x.ActividadProceso.Actividad)                
                .Where(a => a.InstanciaProcesoId == idProceso && (a.Estado == EstadoActividad.Iniciada || a.Estado == EstadoActividad.Ejecucion))
                .Single();

            return instanciaActividad;            
        }

        /// <summary>
        /// Retorna las InstanciasActividad pertenecientes a la InstaciaProceso con el idProceso recibido
        /// </summary>
        /// <param name="idProceso"></param>
        /// <returns></returns>
        public IEnumerable<InstanciaActividad> GetActividadesInstancia(int idProceso)
        {
            var instancias = _db.InstanciasActividad
                .Include(i => i.ActividadProceso.Actividad)
                .Include(i => i.InstanciaProceso)
                .Where(i => i.InstanciaProcesoId == idProceso).ToList();

            var actividadesOrdenadas = new List<InstanciaActividad>();

            var iterador = instancias
                .Where(y => y.ActividadProceso.Tipo == TiposActividad.Inicial)
                .Single();

            actividadesOrdenadas.Add(iterador);
            while (iterador.ActividadSiguienteId != null)
            {
                iterador = instancias
                    .Where(a => a.InstanciaActividadId == iterador.ActividadSiguienteId)
                    .Single();
                actividadesOrdenadas.Add(iterador);
            }
            
            return actividadesOrdenadas;
        }

        /// <summary>
        /// Retorna todas las actividades según el tipo proceso
        /// </summary>
        /// <param name="tipoProceso"></param>
        /// <returns></returns>
        public IEnumerable<Actividad> GetActividades(TipoProceso tipoProceso)
        {
            var proceso = _db.Procesos.First(x => x.Tipo == tipoProceso);

            var actividadesProceso = _db.ActividadesProceso
                .Include(a => a.Actividad)
                .Where(x => x.ProcesoId == proceso.ProcesoId).ToList();

            var iterador = actividadesProceso.Where(a => a.Tipo == TiposActividad.Inicial).First();
            var actividadesOrdenadas = new List<Actividad>();

            actividadesOrdenadas.Add(iterador.Actividad);

            while (iterador.ActividadSiguienteId != null)
            {
                iterador = actividadesProceso
                    .Where(a => a.ActividadId == iterador.ActividadSiguienteId)
                    .Single();
                actividadesOrdenadas.Add(iterador.Actividad);
            }
            return actividadesOrdenadas;
        }
    }
}
