﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarEnvioFosygaClientes : AprobarActividadBase
    {
        public int CargadosRiesgo { get; set; }
        public int AprobadosMotor { get; set; }
        public bool DescargarRespuesta { get; set; }
        public bool EnviarClientes { get; set; }
        public int AprobadosFosyga { get; set; }
        public string NombreArchivoEntrada { get; set; }
        public int ArchivoEntradaId { get; set; }
        public string NombreArchivoSalida { get; set; }
        public int ArchivoSalidaId { get; set; }
        public string RutaCompartidaEntrada { get; set; }
        public string RutaCompartidaSalida { get; set; }
    }
}
