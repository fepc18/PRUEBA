﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class ResultadoEnvioFosygaClientes
    {
        public int InstanciaProcesoId { get; set; }
        public int InstanciaActividadId { get; set; }
        public int CargadosRiesgo { get; set; }
        public int AprobadosMotor { get; set; }
        public int AprobadosFosyga { get; set; }
        public int ArchivoEnviadoId { get; set; }
        public string NombreArchivoEnviado { get; set; }
        public int ArchivoRecibidoId { get; set; }
        public string NombreArchivoRecibido { get; set; }
    }
}
