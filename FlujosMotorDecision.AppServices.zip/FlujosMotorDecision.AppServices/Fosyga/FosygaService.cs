﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.EntityFramework;
using Ionic.Zip;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using FastMember;
namespace FlujosMotorDecision.AppServices
{
    public class FosygaService : IFosygaService
    {
        private readonly IAppContext _db;
        //private readonly IFosygaDAL _dal;
        private readonly IProcesoService _procesoService;

        public FosygaService(IAppContext db, IProcesoService procesoService)
        {
            _db = db;
            _procesoService = procesoService;
        }
        /// <summary>
        /// Retorna el dto de entrada para el envio a fosyga
        /// Valida que exista una respuesta del servicio fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarEnvioFosygaClientes GetAprobarEnvioFosygaClientes(int idProceso, int idActividad)
        {
            var dto = new AprobarEnvioFosygaClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                CargadosRiesgo = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso).Count(),
                AprobadosMotor = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count(),
                RutaCompartidaEntrada = _db.Parametros.First(x => x.Nombre == "FOSYGA_COMPARTIDA_ENTRADA").Valor,
                RutaCompartidaSalida = _db.Parametros.First(x => x.Nombre == "FOSYGA_COMPARTIDA_SALIDA").Valor
            };

            var archivoEnviado = _db.Archivos
                                    .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                    .FirstOrDefault(a => a.InstanciaActividadId == idActividad);

            if (archivoEnviado == null)
            {
                dto.EnviarClientes = true;
            }
            else
            {
                dto.NombreArchivoEntrada = archivoEnviado.Nombre;
                dto.ArchivoEntradaId = archivoEnviado.ArchivoId;
                var nomArchivoSalida = archivoEnviado.Nombre.Replace("_E", "_S").Replace(".zip", ".txt");
                var archivoRecibido = _db.Archivos.Where(a => a.Nombre == nomArchivoSalida).FirstOrDefault();
                if (archivoRecibido == null)
                {
                    dto.DescargarRespuesta = true;
                }
                else
                {
                    dto.NombreArchivoSalida = archivoRecibido.Nombre;
                    dto.ArchivoSalidaId = archivoRecibido.ArchivoId;
                }
            }
            return dto;
        }
        /// <summary>
        /// Retorna el resultado del envio a fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoEnvioFosygaClientes GetResultadoEnvioFosygaClientes(int idProceso, int idActividad)
        {
            var enviado = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                      .FirstOrDefault(a => a.InstanciaActividadId == idActividad);
            var recibido = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                       .FirstOrDefault(a => a.Nombre == enviado.Nombre.Replace("_E", "_S").Replace(".zip", ".txt"));

            var dto = new ResultadoEnvioFosygaClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                AprobadosFosyga = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga).Count(),
                ArchivoEnviadoId = enviado.ArchivoId,
                NombreArchivoEnviado = enviado.Nombre,
                ArchivoRecibidoId = recibido.ArchivoId,
                NombreArchivoRecibido = recibido.Nombre
            };
            return dto;
        }

        /// <summary>
        /// Retorna el dto para el envio de no clientes a fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>

        public AprobarEnvioFosygaNoClientes GetAprobarEnvioFosygaNoClientes(int idProceso, int idActividad)
        {
            var dto = new AprobarEnvioFosygaNoClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                CargadosRiesgo = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso).Count(),
                RutaCompartidaEntrada = _db.Parametros.First(x => x.Nombre == "FOSYGA_COMPARTIDA_ENTRADA").Valor,
                RutaCompartidaSalida = _db.Parametros.First(x => x.Nombre == "FOSYGA_COMPARTIDA_SALIDA").Valor
            };

            var archivoEnviado = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                             .FirstOrDefault(a => a.InstanciaActividadId == idActividad);
            if (archivoEnviado == null)
            {
                dto.Enviar = true;
            }
            else
            {
                dto.NombreArchivoEntrada = archivoEnviado.Nombre;
                dto.ArchivoEntradaId = archivoEnviado.ArchivoId;

                var nomArchivoSalida = archivoEnviado.Nombre.Replace("_E", "_S").Replace(".zip", ".txt");
                var archivoRecibido = _db.Archivos
                                         .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                         .FirstOrDefault(a => a.Nombre == nomArchivoSalida);

                if (archivoRecibido == null)
                {
                    dto.DescargarRespuesta = true;
                }
                else
                {
                    dto.NombreArchivoSalida = archivoRecibido.Nombre;
                    dto.ArchivoSalidaId = archivoRecibido.ArchivoId;
                }
            }
            return dto;
        }
        /// <summary>
        /// Retorna el resultado del envio de no clientes a fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoEnvioFosygaNoClientes GetResultadoEnvioFosygaNoClientes(int idProceso, int idActividad)
        {
            var enviado = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                      .FirstOrDefault(a => a.InstanciaActividadId == idActividad);
            var recibido = _db.Archivos.Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                       .FirstOrDefault(a => a.Nombre == enviado.Nombre.Replace("_E", "_S").Replace(".zip", ".txt"));

            var dto = new ResultadoEnvioFosygaNoClientes
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                AprobadosFosyga = _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaFosyga).Count(),
                ArchivoEnviadoId = enviado.ArchivoId,
                NombreArchivoEnviado = enviado.Nombre,
                ArchivoRecibidoId = recibido.ArchivoId,
                NombreArchivoRecibido = recibido.Nombre
            };
            return dto;
        }

        /// <summary>
        /// Envia la informacion de clientes  a fosyga
        /// </summary>
        /// <param name="dto"></param>
        public void EnviarClientes(AprobarEnvioFosygaClientes dto)
        {
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoFosyga").Valor;
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoFosyga").Valor;
            var clientes = _db.Clientes.Where(c => c.ApruebaMotor && c.InstanciaProcesoId == dto.InstanciaProcesoId).ToList();

            var sb = new StringBuilder();
            sb.AppendLine(encabezado);
            clientes.ForEach(c => sb.AppendLine(c.Documento + separador + c.TipoDocumento.ToString().PadLeft(2, '0')));

            EnviarArchivoZip(sb.ToString(), dto.InstanciaProcesoId, dto.InstanciaActividadId);

        }


        /// <summary>
        /// Envia la informacion de NoClientes a fosyga
        /// </summary>
        /// <param name="dto"></param>
        public void EnviarNoClientes(AprobarEnvioFosygaNoClientes dto)
        {
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoFosyga").Valor;
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoFosyga").Valor;
            var noClientes = _db.NoClientes.Where(c => c.InstanciaProcesoId == dto.InstanciaProcesoId).ToList();

            var sb = new StringBuilder();
            sb.AppendLine(encabezado);
            noClientes.ForEach(c => sb.AppendLine(c.Documento + separador + c.TipoDocumento.ToString().PadLeft(2, '0')));

            EnviarArchivoZip(sb.ToString(), dto.InstanciaProcesoId, dto.InstanciaActividadId);

        }

        /// <summary>
        /// Actualiza la tabla de Clientes con aquellos que aprobaron el filtro de fosyga
        /// </summary>
        /// <param name="dto"></param>
        public void ProcesarSalida(int idProceso, int idActividad, string usuario)
        {            
            var tipoProceso = _db.InstanciasProceso.Find(idProceso).Proceso.Tipo;
            string tabla = tipoProceso == TipoProceso.Clientes ? "Cliente" : "NoCliente";
            var archivoEnviado = _db.Archivos
                                    .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                    .FirstOrDefault(a => a.InstanciaActividadId == idActividad);

            var nomArchivoSalida = archivoEnviado.Nombre.Replace("_E", "_S").Replace(".zip", ".txt");
            var archivo = _db.Archivos.Where(a => a.Nombre == nomArchivoSalida).FirstOrDefault();

            if (archivo != null && archivo.Contenido.Length > 0)
            {
                var clientes = new List<Cliente>();
                using (var stream = new MemoryStream(archivo.Contenido))
                {
                    stream.Position = 0;

                    using (var sr = new StreamReader(stream))
                    {
                        sr.ReadLine();
                        while (!sr.EndOfStream)
                        {
                            var linea = sr.ReadLine();
                            var data = linea.Split(';');

                            int tipoDocumento = int.Parse(data[0].Trim('"'));
                            string documento = data[1].Trim('"');
                            string tipoAfiliacion = data[4].Trim('"');
                            string estado = data[7].Trim('"');

                            if (estado.Equals("Activo", StringComparison.InvariantCultureIgnoreCase) && tipoAfiliacion.Equals("Cotizante Principal", StringComparison.InvariantCultureIgnoreCase))
                            {
                                clientes.Add(new Cliente { Documento = documento, TipoDocumento = tipoDocumento });
                            }
                        }
                    }
                }
                //Usar conexion directa a BD por motivos de performance
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
                {
                    conn.Open();
                    conn.Execute("IF OBJECT_ID('tempdb.dbo.#TEMP_CLIENTES', 'U') IS NOT NULL  DROP TABLE #TEMP_CLIENTES");
                    conn.Execute("CREATE TABLE #TEMP_CLIENTES(Documento nvarchar(max), TipoDocumento integer)");

                    var dt = new DataTable();
                    using (var reader = ObjectReader.Create(clientes, "Documento", "TipoDocumento"))
                    {
                        dt.Load(reader);
                    }
                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                    {
                        foreach (DataColumn col in dt.Columns)
                        {
                            bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        }
                        bulkCopy.DestinationTableName = "#TEMP_CLIENTES";
                        bulkCopy.WriteToServer(dt);
                    }

                    var command = @"UPDATE C SET ApruebaFosyga = 1 
FROM " + tabla + @" C INNER JOIN #TEMP_CLIENTES Temp 
ON C.TipoDocumento = Temp.TipoDocumento 
AND C.Documento = Temp.Documento
WHERE C.InstanciaProcesoId = @IdProceso 
";
                    conn.Execute(command, commandTimeout: 3600, param: new { IdProceso = idProceso });
                    conn.Execute("DROP TABLE #TEMP_CLIENTES");
                }
                //-------CREAR ARCHIVO No_Clientes.txt

                if (tabla.Equals("NoCliente"))
                {
                    //crear archivo en 
                    var nombreArchivo = _db.Parametros.First(x => x.Nombre == "NombreArchivoNoClientesFosyga").Valor;
                    var archivoOdsFosyga = _db.Archivos.Where(a => a.Nombre == nombreArchivo && a.InstanciaProcesoId == idProceso).FirstOrDefault();
                    if (archivoOdsFosyga == null)
                    {

                        var sb = new StringBuilder();
                        var noClientesFosyga = _db.NoClientes.Where(c => c.ApruebaFosyga && c.InstanciaProcesoId == idProceso).ToList();
                       
                        String charsTipoDocumento = "  ";
                        String charsDocumento = "                    ";
                        noClientesFosyga.ForEach(c =>
                             sb.Append(charsTipoDocumento.Substring(0,charsTipoDocumento.Length-c.TipoDocumento.ToString().Length)
                                           + c.TipoDocumento
                                           + charsDocumento.Substring(0, charsDocumento.Length-c.Documento.ToString().Length)
                                           + c.Documento+"\n")); //Registros
                        var contenido = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
                        archivo = new Archivo
                        {
                            Nombre = nombreArchivo,
                            Contenido = contenido,
                            Type = "text/plain",
                            Tamano = contenido.Length,
                            InstanciaActividadId = idActividad,
                            InstanciaProcesoId = idProceso
                        };
                        _db.Archivos.Add(archivo);
                        _db.SaveChanges();
                        //registrar en compartida
                        int idArchivoNoClientesODSFosyga = archivo.ArchivoId;
                        
                        var rutaNoClientesODSFosyga = _db.Parametros.First(x => x.Nombre == "rutaNoClientesODSFosyga").Valor;

                        EnviarArchivoRutaCompartida(rutaNoClientesODSFosyga, usuario, idArchivoNoClientesODSFosyga);


                    }
                }
                //
                _procesoService.CompletarActividadActual(idProceso, idActividad, usuario);
            }            
            _db.SaveChanges();
        }

        /// <summary>
        /// Realiza la descarga del archivo reconocer
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public Archivo DescargaCompartida(int idProceso, int idActividad, string usuario)
        {
            Archivo archivo = null;

            var archivoEnviado = _db.Archivos
                                    .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId })
                                    .FirstOrDefault(a => a.InstanciaActividadId == idActividad );
            var rutaCompartida = _db.Parametros.First(x => x.Nombre == "FOSYGA_COMPARTIDA_SALIDA").Valor;

            //locales
            var nombreArchivoOK = archivoEnviado.Nombre.Replace("zip", "OK").Replace("_E", "_S");

            var nombreArchivoSalida = archivoEnviado.Nombre.Replace("zip", "txt").Replace("_E", "_S");

            var files = Directory.EnumerateFiles(rutaCompartida);

            bool existeArchivoOK = false;
            bool existeArchivoSalida = false;

            foreach (var f in files)
            {
                if (f.Contains(nombreArchivoOK))
                {
                    existeArchivoOK = true;
                }
                else if (f.Contains(nombreArchivoSalida))
                {
                    existeArchivoSalida = true;
                }
            }

            if (existeArchivoOK && existeArchivoSalida)
            {
                var salida = files.Where(s => s.Contains(nombreArchivoSalida)).Single();
                var contenido = File.ReadAllBytes(salida);
                //Guardar en BD
                archivo = new Archivo
                {
                    Contenido = contenido,
                    InstanciaActividadId = idActividad,
                    InstanciaProcesoId = idProceso,
                    Nombre = Path.GetFileName(salida),
                    Type = "text/plain",
                    Tamano = contenido.Length
                };
                _db.Archivos.Add(archivo);
            }
            return archivo;
        }

        /// <summary>
        /// Envia los registros recibidos como un comprimido zip a la ruta compartida parametrizada
        /// </summary>
        /// <param name="registros"></param>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        private void EnviarArchivoZip(string registros, int idProceso, int idActividad)
        {
            //params
            var formato = _db.Parametros.First(x => x.Nombre == "FormatoArchivoFosyga").Valor;
            var ruta = _db.Parametros.First(x => x.Nombre == "FOSYGA_COMPARTIDA_ENTRADA").Valor;
            var consecutivo = _db.Parametros.First(x => x.Nombre == "ConsecutivoArchivoFosyga");
            //locales
            var nombre = String.Format(formato, consecutivo.Valor.PadLeft(5, '0'), DateTime.Today.ToString("yyyyMMdd"));
            var contenido = Encoding.Default.GetBytes(registros);

            using (var zipStream = new MemoryStream())
            {
                using (ZipFile zip = new ZipFile())
                {
                    zip.AddEntry(nombre + ".txt", new MemoryStream(contenido));
                    zip.Save(zipStream);
                }
                File.WriteAllBytes(ruta + Path.DirectorySeparatorChar + nombre + ".zip", zipStream.ToArray());
                //Se adiciona escritura de "OK" en el archivo
                //File.Create(ruta + Path.DirectorySeparatorChar + nombre + ".OK");
                File.WriteAllBytes(ruta + Path.DirectorySeparatorChar + nombre + ".OK", Encoding.Default.GetBytes("OK"));
                consecutivo.Valor = (int.Parse(consecutivo.Valor) + 1).ToString();

                var archivo = new Archivo
                {
                    Contenido = zipStream.ToArray(),
                    Nombre = nombre + ".zip",
                    InstanciaProcesoId = idProceso,
                    InstanciaActividadId = idActividad,
                    Tamano = zipStream.ToArray().Length,
                    Type = "application/zip"
                };
                _db.Archivos.Add(archivo);
            }
        }

        /// <summary>
        /// Envia los registros NoClientes aprobados por Fosyga
        /// </summary>
        /// <param name="ruta"></param>
        /// <param name="usuario"></param>
        /// <param name="idArchivo"></param>
        public void EnviarArchivoRutaCompartida(string ruta, string usuario, int idArchivo)
        {
            var archivo = _db.Archivos.Find(idArchivo);

            //-> Generar Archivo
            File.WriteAllBytes(ruta + Path.DirectorySeparatorChar + archivo.Nombre, archivo.Contenido);
            InstanciaActividad actividadCarga = _db.InstanciasActividad.Where(x => x.InstanciaActividadId == archivo.InstanciaActividadId).Single();
            ActividadProceso actividadProceso = _db.ActividadesProceso.Where(x => x.ActividadProcesoId == actividadCarga.ActividadProcesoId).Single();
            Actividad actividad = _db.Actividades.Where(x => x.ActividadId == actividadProceso.ActividadId).Single();
            _procesoService.CompletarActividadActual(archivo.InstanciaProcesoId, actividadCarga.InstanciaActividadId, usuario);
            
        }
      
        
    }
}
