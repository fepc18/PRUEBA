﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices
{
    public interface IFosygaService
    {
        /// <summary>
        /// Retorna el dto de entrada para el envio a fosyga
        /// Valida que exista una respuesta del servicio fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarEnvioFosygaClientes GetAprobarEnvioFosygaClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el resultado del envio a fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        AprobarEnvioFosygaNoClientes GetAprobarEnvioFosygaNoClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el dto para el envio de no clientes a fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoEnvioFosygaClientes GetResultadoEnvioFosygaClientes(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el resultado del envio de no clientes a fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoEnvioFosygaNoClientes GetResultadoEnvioFosygaNoClientes(int idProceso, int idActividad);

        /// <summary>
        /// Envia la informacion de clientes  a fosyga
        /// </summary>
        /// <param name="dto"></param>
        void EnviarClientes(AprobarEnvioFosygaClientes dto);

        /// <summary>
        /// Envia la informacion de NoClientes a fosyga
        /// </summary>
        /// <param name="dto"></param>
        void EnviarNoClientes(AprobarEnvioFosygaNoClientes dto);

        /// <summary>
        /// Actualiza la tabla de Clientes con aquellos que aprobaron el filtro de fosyga
        /// </summary>
        /// <param name="dto"></param>
        void ProcesarSalida(int idProceso, int idActividad, string usuario);
        
        /// <summary>
        /// Descargar la respuesta de fosyga
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        Archivo DescargaCompartida(int idProceso, int idActividad, string usuario);
    }
}
