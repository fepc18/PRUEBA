﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.EntityFramework;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using FastMember;
using System;
using System.IO;

namespace FlujosMotorDecision.AppServices
{
    public class LogObjetoService : ILogObjetoService
    {
       private readonly IAppContext _db;

       public LogObjetoService(IAppContext db)
        {
            _db = db;
        }
       public void RegisterLog(String User, Object PreviousObject, Object CurrentObject, Actions action, String _IpAddress)
       {
            LogObjeto log = new LogObjeto();
            log.Action = action;
            log.ObjectId = getObjectId(CurrentObject);
            log.PreviousObject = ""; 
            if (action == Actions.Update) {
                log.PreviousObject = SerializarXMl(PreviousObject);                 
            }
            log.CurrentObject = SerializarXMl(CurrentObject);   
            log.UserName = User;
            log.IpAddress = _IpAddress;
            log.TimeStamp = DateTime.Now;
            _db.LogObjeto.Add(log);
            _db.SaveChanges();
        }
        public String SerializarXMl(Object objeto) {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(objeto.GetType());
            StringWriter textWriter = new StringWriter();
            x.Serialize(textWriter, objeto);
            return textWriter.ToString();
        }
        public Objeto getObjectId(object CurrentObject){
            var typeCurrentObject =CurrentObject.GetType().Name;
            if (typeCurrentObject.Equals("TarifaTasaConsumo"))
                return Objeto.TarifaTasaConsumo;
            else if (typeCurrentObject.Equals("TasaConsumoMaestro"))
                return Objeto.TasaConsumo;
            else
                return Objeto.TarifaTasaConsumo; 
        }
    }
}
