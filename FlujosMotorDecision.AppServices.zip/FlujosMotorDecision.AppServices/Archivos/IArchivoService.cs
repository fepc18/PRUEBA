﻿using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Web;

namespace FlujosMotorDecision.AppServices
{
    public interface IArchivoService
    {
        /// <summary>
        /// Retorna un archivo dado su llave primaria
        /// </summary>
        /// <param name="idArchivo"></param>
        /// <returns></returns>
        Archivo Get(int idArchivo);
    }
}
