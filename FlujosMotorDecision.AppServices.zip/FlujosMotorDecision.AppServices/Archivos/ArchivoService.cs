﻿using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace FlujosMotorDecision.AppServices
{
    public class ArchivoService : IArchivoService
    {
        /// <summary>
        /// Retorna el Arhivo con el idArchivo recibido
        /// </summary>
        /// <param name="idArchivo"></param>
        /// <returns></returns>
        public Archivo Get(int idArchivo)
        {
            using (var db = new FlujosMotorDecisionContext())
            {
                return db.Archivos.Find(idArchivo);
            }
        }
    }
}
