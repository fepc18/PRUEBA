﻿using FastMember;
using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace FlujosMotorDecision.AppServices
{
    public class CargaEmpleadosService : ICargaEmpleadosService
    {
        private readonly IProcesoService _procesoService;
        private readonly IAppContext _db;

        public CargaEmpleadosService(IProcesoService procesoService, IAppContext db)
        {
            _procesoService = procesoService;
            _db = db;
        }

        /// <summary>
        /// Retorna el dto de en trada para la carga de empleados
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public AprobarCargaEmpleados GetAprobarCargaEmpleados(int idProceso, int idActividad)
        {
            var tamanoArchivo = int.Parse(ConfigurationManager.AppSettings["TamanoMaxArchivo"]);
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoEmpleados").Valor;
            var extension = _db.Parametros.First(x => x.Nombre == "ExtensionArchivoEmpleados").Valor;
            var encabezado = _db.Parametros.First(x => x.Nombre == "EncabezadoArchivoEmpleados").Valor;

            var dto = new AprobarCargaEmpleados
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                SeparadorArchivoEntrada = separador,
                Extension = extension,
                TamanoMaximoArchivo = tamanoArchivo / (1024 * 1024),
                Encabezado = encabezado
            };
            return dto;
        }

        /// <summary>
        /// Retorna el dto de salida para la carga de empleados
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoCargaEmpleados GetResultadoCargaEmpleados(int idProceso, int idActividad)
        {
            var archivo = _db.Archivos
                            .Select(a => new { a.ArchivoId, a.Nombre, a.InstanciaActividadId})
                            .First(a => a.InstanciaActividadId == idActividad);
            var dto = new ResultadoCargaEmpleados
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                EmpleadosCargados = _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.Empleado).Count(),
                ArchivoId = archivo.ArchivoId,
                NombreArchivo = archivo.Nombre,
            };
            return dto;
        }

        /// <summary>
        /// Carga a la base de datos la información de empleados
        /// </summary>
        /// <param name="dto"></param>
        public void CargarArchivoEmpleados(AprobarCargaEmpleados dto)
        {
            var copyStream = new MemoryStream();
            dto.Archivo.InputStream.CopyTo(copyStream);
            dto.Archivo.InputStream.Position = 0;

            var dt = new DataTable();
            var separador = _db.Parametros.First(x => x.Nombre == "SeparadorArchivoEmpleados").Valor.ToCharArray()[0];
            var listaDetalles = new List<RegistroArchivoEmpleados>();

            using (var sr = new StreamReader(dto.Archivo.InputStream))
            {
                sr.ReadLine(); // Descartar el titulo
                while (!sr.EndOfStream)
                {
                    bool es_valido = true;
                    var linea = sr.ReadLine();
                    var data = linea.Split(separador);
                    int _tipoDocumento;
                    decimal _CupoCC;
                    decimal _CupoTDC;
                    if (data.Count() != 5)
                    {
                        es_valido = false;
                    }
                    else if (!int.TryParse(data[1], out _tipoDocumento))
                    {
                        es_valido = false;
                    }                    
                    else if (!decimal.TryParse(data[3], out _CupoCC))
                    {
                        es_valido = false;
                    }
                    else if (!decimal.TryParse(data[4], out _CupoTDC))
                    {
                        es_valido = false;
                    }
                    if (es_valido)
                    {
                        var detalle = new RegistroArchivoEmpleados
                        {
                            TipoDocumento = int.Parse(data[1]),
                            Documento = data[2],
                            CupoCC = decimal.Parse(data[3]),
                            CupoTDC = decimal.Parse(data[4])
                        };
                        listaDetalles.Add(detalle);
                    }
                  
                }
            }
            //Poblar DataTable con FastMember
            using (var reader = ObjectReader.Create(listaDetalles))
            {
                dt.Load(reader);
            }
            // Conexion con Dapper a la BD por motivos de performance
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    conn.Execute("IF OBJECT_ID('tempdb.dbo.#TEMP_DET_EMPLEADOS', 'U') IS NOT NULL  DROP TABLE #TEMP_DET_EMPLEADOS", transaction: tr);
                    conn.Execute("CREATE TABLE #TEMP_DET_EMPLEADOS(TipoDocumento int, Documento nvarchar(max), CupoCC decimal, CupoTDC decimal)", transaction: tr);

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
                    {
                        foreach (DataColumn col in dt.Columns)
                        {
                            bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        }
                        bulkCopy.DestinationTableName = "#TEMP_DET_EMPLEADOS";
                        bulkCopy.WriteToServer(dt);
                    }

                    conn.Execute(@"INSERT INTO dbo.DetalleEmpleado(DetalleEmpleadoId, CupoCC, CupoTDC)
   SELECT C.ClienteId, Temp.CupoCC, Temp.CupoTDC
   FROM Cliente C
   INNER JOIN #TEMP_DET_EMPLEADOS Temp 
   ON C.Documento = Temp.Documento
   AND C.TipoDocumento = Temp.TipoDocumento
   WHERE C.InstanciaProcesoId = @IdProceso
   AND C.ApruebaFosyga = 1
   AND C.ApruebaMotor = 1",
                    commandTimeout: 3600,
                    param: new { IdProceso = dto.InstanciaProcesoId },
                    transaction: tr);

                    conn.Execute(@"UPDATE C SET Empleado = 1 
   FROM  Cliente C
   INNER JOIN #TEMP_DET_EMPLEADOS Temp 
   ON C.Documento = Temp.Documento
   AND C.TipoDocumento = Temp.TipoDocumento
   WHERE C.InstanciaProcesoId = @IdProceso
   AND C.ApruebaFosyga = 1
   AND C.ApruebaMotor = 1",
                    commandTimeout: 3600,
                    param: new { IdProceso = dto.InstanciaProcesoId },
                    transaction: tr);

                    tr.Commit();
                }
            }

            // Cargar archivo plano
            var formatoNombre = _db.Parametros.First(p => p.Nombre == "NombreArchivoEmpleados").Valor;
            var tipo = dto.Archivo.ContentType;
            var documentBytes = copyStream.ToArray();            

            var archivoCargado = new Archivo
            {
                Nombre = String.Format(formatoNombre, DateTime.Today.ToString("yyyyMMdd")),
                Contenido = documentBytes,
                Type = tipo,
                Tamano = copyStream.Length,
                InstanciaActividadId = dto.InstanciaActividadId,
                InstanciaProcesoId = dto.InstanciaProcesoId
            };
            _db.Archivos.Add(archivoCargado);
            _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
        }
    }
}
