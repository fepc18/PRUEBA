﻿using FlujosMotorDecision.AppServices.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarCargaEmpleados : AprobarActividadBase
    {        
        [Required(ErrorMessage = "Por favor seleccione un archivo.")]
        [ValidateInputFile]
        public HttpPostedFileBase Archivo { get; set; }

        public string SeparadorArchivoEntrada { get; set; }

        public int TamanoMaximoArchivo { get; set; }

        public string Encabezado { get; set; }

        public IList<RegistroArchivoEmpleados> Registros { get; set; }

        public string Extension { get; set; }        
    }
}
