﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class RegistroArchivoEmpleados
    {                
        public int TipoDocumento { get; set; }
        
        public string Documento { get; set; }
                
        public decimal CupoTDC { get; set; }
        
        public decimal CupoCC { get; set; }
    }
}
