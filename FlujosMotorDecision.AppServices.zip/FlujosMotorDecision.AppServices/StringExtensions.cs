﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.AppServices
{
    public static class StringExtensions
    {
        public static string Indent(int count, char pad)
        {
            return String.Empty.PadLeft(count, pad);
        }

        public static string Repeat(int count, string str)
        {
            return String.Concat(Enumerable.Repeat(str, count));
        }

        public static string Truncate(this string value, int maxLength)
        {
            if (String.IsNullOrEmpty(value)) return value;
            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }

        public static string ReplaceFirst(this string text, string search, string replace)
        {
            int pos = text.IndexOf(search);
            if (pos < 0)
            {
                return text;
            }
            return text.Substring(0, pos) + replace + text.Substring(pos + search.Length);
        }
    }
}
