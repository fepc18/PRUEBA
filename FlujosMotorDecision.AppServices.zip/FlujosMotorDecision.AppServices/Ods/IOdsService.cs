﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices
{
    public interface IOdsService
    {
        /// <summary>
        /// Retorna el dto con la información necesaria para ejecutar la actividad
        /// de insertar eventos en el ods
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        Task<AprobarInsertarEventosOds> GetAprobarInsertarEventosOds(int idProceso, int idActividad);

        /// <summary>
        /// Retorna el dto con el resultado de la ejecucion de la carga de eventos en el Ods
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        ResultadoInsertarEventosOds GetResultadoInsertarEventosOds(int idProceso, int idActividad);
        
        /// <summary>
        /// Carga en el ODS los eventos asociados a la actividad enviada
        /// </summary>
        /// <param name="dto"></param>
        void CrearEventosActividad(AprobarInsertarEventosOds dto);        

        /// <summary>
        /// Reenvia el evento especificado
        /// </summary>
        /// <param name="model"></param>
        void ReenviarEvento(LogEventoOds model);

        /// <summary>
        /// Descarga la informacion del Ods y marca a los clientes que pasaron
        /// el filtro del motor
        /// </summary>
        /// <param name="dto"></param>
        void CargarClientesAprobadosMotor(AprobarInsertarEventosOds dto);

        /// <summary>
        /// Descarga la informacion del ods y marca a los no clientes que pasaron
        /// el filtro del motor
        /// </summary>
        /// <param name="dto"></param>
        void CargarNoClientesAprobadosMotor(AprobarInsertarEventosOds dto);
    }
}
