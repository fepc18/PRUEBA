﻿using FlujosMotorDecision.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.AppServices.Dtos
{
    public class AprobarInsertarEventosOds : AprobarActividadBase
    {
        public string Terminal { get; set; }
        public bool InsertarEventos { get; set; }        
        public IEnumerable<LogEventoOds> Eventos { get; set; }
        public bool AprobarActividad { get; set; }
    }
}
