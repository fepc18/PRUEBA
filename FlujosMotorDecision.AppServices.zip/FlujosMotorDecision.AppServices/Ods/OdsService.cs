﻿using FlujosMotorDecision.AppServices.Dtos;
using FlujosMotorDecision.Core.Entities;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.EntityFramework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using FastMember;

namespace FlujosMotorDecision.AppServices
{
    public class OdsService : IOdsService
    {
        private readonly IOdsDAL _dal;
        private readonly IAppContext _db;
        private readonly IProcesoService _procesoService;

        public OdsService(IOdsDAL dal, IAppContext db, IProcesoService procesoService)
        {
            _db = db;
            _dal = dal;
            _procesoService = procesoService;
        }

        /// <summary>
        /// Reenvia el evento recibido al ODS
        /// </summary>
        /// <param name="model"></param>
        public void ReenviarEvento(LogEventoOds model)
        {
            var fechaInicio = DateTime.Now;
            var fechaFin = DateTime.Today.AddDays(1).AddHours(5).AddMinutes(59);

            var empresa = _db.Parametros.First(p => p.Nombre == "EmpresaOds").Valor;
            var estado = "PR";
            _dal.InsertarEvento(empresa, estado, model.Usuario, model.Terminal, model.Evento, fechaInicio, fechaFin);

            var logEvento = _db.LogEventosOds.Find(model.LogEventoOdsId);
            logEvento.Usuario = model.Usuario;
            logEvento.Terminal = model.Terminal;
            logEvento.FechaInicio = fechaInicio;
            logEvento.FechaFin = fechaFin;

        }

        /// <summary>
        /// Retorna el dto de entrada para el envio de enventos al Ods
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public async Task<AprobarInsertarEventosOds> GetAprobarInsertarEventosOds(int idProceso, int idActividad)
        {
            var eventos = await _db.LogEventosOds.Where(e => e.InstanciaActividadId == idActividad).ToListAsync();

            foreach (var evento in eventos)
            {
                var nuevoEstado = _dal.GetEventStatus(evento.Empresa, evento.FechaInicio, evento.Evento, evento.Terminal);
                evento.Estado = nuevoEstado;
                if (evento.Estado == "EX" || evento.Estado == "PR")
                {
                    evento.Reenviable = false;
                }
                else
                {
                    evento.Reenviable = true;
                }

            }
            var dto = new AprobarInsertarEventosOds
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                Eventos = eventos
            };
            if (!eventos.Any())
            {
                dto.InsertarEventos = true;
            }
            if (eventos.Any() && eventos.All(x => x.Estado == "EX"))
            {
                dto.AprobarActividad = true;
            }
            return dto;
        }

        /// <summary>
        /// Retorna el resultado del envio de eventos al ods
        /// </summary>
        /// <param name="idProceso"></param>
        /// <param name="idActividad"></param>
        /// <returns></returns>
        public ResultadoInsertarEventosOds GetResultadoInsertarEventosOds(int idProceso, int idActividad)
        {
            var tipoProceso = _db.InstanciasProceso.Find(idProceso).Proceso.Tipo;
            var aprobadosMotor = tipoProceso == TipoProceso.Clientes ? _db.Clientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count()
                : _db.NoClientes.Where(c => c.InstanciaProcesoId == idProceso && c.ApruebaMotor).Count();

            var dto = new ResultadoInsertarEventosOds
            {
                InstanciaProcesoId = idProceso,
                InstanciaActividadId = idActividad,
                Eventos = _db.LogEventosOds.Where(e => e.InstanciaActividadId == idActividad),
                AprobadosMotor = aprobadosMotor,
            };
            return dto;
        }

        /// <summary>
        /// Crea los eventos asociados a la actividad actual en el ODS
        /// </summary>
        /// <param name="dto"></param>
        public void CrearEventosActividad(AprobarInsertarEventosOds dto)
        {
            var fechaInicio = DateTime.Now;
            var fechaFin = DateTime.Today.AddDays(1).AddHours(5).AddMinutes(59);

            var empresa = _db.Parametros.First(p => p.Nombre == "EmpresaOds").Valor;
            var estado = _db.Parametros.First(p => p.Nombre == "EstadoInicialEventos").Valor;

            var actividad = _db.InstanciasActividad.Find(dto.InstanciaActividadId).ActividadProceso.Actividad;
            var eventosOds = _db.EventosOds.Where(e => e.ActividadId == actividad.ActividadId).Select(x => x.Nombre).ToList();
            foreach (var evento in eventosOds)
            {
                _dal.InsertarEvento(empresa, estado, dto.Usuario, dto.Terminal, evento, fechaInicio, fechaFin);

                var logEvento = _db.LogEventosOds
                    .SingleOrDefault(e => e.InstanciaActividadId == dto.InstanciaActividadId &&
                                          e.Evento == evento);

                _db.LogEventosOds.Add(
                new LogEventoOds
                {
                    Empresa = empresa,
                    Usuario = dto.Usuario,
                    Terminal = dto.Terminal,
                    Evento = evento,
                    FechaInicio = fechaInicio,
                    FechaFin = fechaFin,
                    Estado = estado,
                    InstanciaActividadId = dto.InstanciaActividadId,
                    InstanciaProcesoId = dto.InstanciaProcesoId,
                });

            }
            var instActividad = _db.InstanciasActividad.Find(dto.InstanciaActividadId);
            instActividad.ModificadaPor = dto.Usuario;
        }

        /// <summary>
        /// Actualiza la tabla clientes para aquellos que aprobaron el filtro del motor de decision
        /// </summary>
        /// <param name="dto"></param>
        public void CargarClientesAprobadosMotor(AprobarInsertarEventosOds dto)
        {
            var tipoProceso = _db.Parametros.First(p => p.Nombre == "TipoProcesoClientes").Valor;
            var clientesAprobados = _dal.GetNodoCliente(tipoProceso);

            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
            {
                conn.Open();
                conn.Execute("IF OBJECT_ID('tempdb.dbo.#TEMP_CLIENTES', 'U') IS NOT NULL  DROP TABLE #TEMP_CLIENTES");
                conn.Execute("CREATE TABLE #TEMP_CLIENTES(CLI_TIPO_DOC nvarchar(3), CLI_NUM_DOC nvarchar(max))");

                var dt = new DataTable();
                using (var reader = ObjectReader.Create(clientesAprobados, "CLI_TIPO_DOC", "CLI_NUM_DOC"))
                {
                    dt.Load(reader);
                }
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                {
                    foreach (DataColumn col in dt.Columns)
                    {
                        bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    }
                    bulkCopy.DestinationTableName = "#TEMP_CLIENTES";
                    bulkCopy.WriteToServer(dt);
                }

                var command = @"UPDATE C SET ApruebaMotor = 1 
FROM Cliente C INNER JOIN #TEMP_CLIENTES Temp 
ON C.TipoDocumento = CAST(Temp.CLI_TIPO_DOC AS int) 
AND C.Documento = Temp.CLI_NUM_DOC
WHERE C.InstanciaProcesoId = @IdProceso 
";
                conn.Execute(command, commandTimeout: 3600, param: new { IdProceso = dto.InstanciaProcesoId });
                conn.Execute("DROP TABLE #TEMP_CLIENTES");
            }
            _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
            _db.SaveChanges();
        }

        /// <summary>
        /// Actualiza la tabla NoCLientes para aquellos que aprobaron el filtro del motor de decision
        /// </summary>
        /// <param name="dto"></param>
        public void CargarNoClientesAprobadosMotor(AprobarInsertarEventosOds dto)
        {
            var tipoProceso = _db.Parametros.First(p => p.Nombre == "TipoProcesoNoClientes").Valor;
            var noClientesAprobados = _dal.GetNodoCliente(tipoProceso);

            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
            {
                conn.Open();
                conn.Execute("IF OBJECT_ID('tempdb.dbo.#TEMP_NO_CLIENTES', 'U') IS NOT NULL  DROP TABLE #TEMP_NO_CLIENTES");
                conn.Execute("CREATE TABLE #TEMP_NO_CLIENTES(CLI_TIPO_DOC nvarchar(3), CLI_NUM_DOC nvarchar(max))");

                var dt = new DataTable();
                using (var reader = ObjectReader.Create(noClientesAprobados, "CLI_TIPO_DOC", "CLI_NUM_DOC"))
                {
                    dt.Load(reader);
                }
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn))
                {
                    foreach (DataColumn col in dt.Columns)
                    {
                        bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    }
                    bulkCopy.DestinationTableName = "#TEMP_NO_CLIENTES";
                    bulkCopy.WriteToServer(dt);
                }

                var command = @"UPDATE C SET ApruebaMotor = 1 
FROM NoCliente C INNER JOIN #TEMP_NO_CLIENTES Temp 
ON C.TipoDocumento = CAST(Temp.CLI_TIPO_DOC AS int) 
AND C.Documento = Temp.CLI_NUM_DOC
WHERE C.InstanciaProcesoId = @IdProceso 
";
                conn.Execute(command, commandTimeout: 3600, param: new { IdProceso = dto.InstanciaProcesoId });
                conn.Execute("DROP TABLE #TEMP_NO_CLIENTES");
            }
            _procesoService.CompletarActividadActual(dto.InstanciaProcesoId, dto.InstanciaActividadId, dto.Usuario);
            _db.SaveChanges();
        }
    }
}
