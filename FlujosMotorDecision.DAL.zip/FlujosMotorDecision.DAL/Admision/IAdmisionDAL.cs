﻿using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL
{
    public interface IAdmisionDAL
    {
        /// <summary>
        /// Trunca la tabla TBL_MAESTRO_ASIGNACION_EMPLEADOS y la vuelve a poblar con
        /// el contenido de la tabla TBL_MAESTRO_ASIGNACION_EMPLEADOS_TMP 
        /// </summary>
        void cargarTablaMaestroAsignacionEmpleados();
        
        /// <summary>
        /// Inserta en las tablas de Clientes Preaprobados la informacion del archivo reconocer
        /// </summary>
        /// <param name="registros"></param>
        void insertarDatosReconocer(IList<CliPreaProbDto> registros);

        /// <summary>
        /// Inserta en la tabla Maestro Asignacion la informacion retoranda del ODS
        /// </summary>
        /// <param name="registros"></param>
        void insertarRegistrosMaestroAsignacion(IList<RegistroMaestroAsignacion> registros);

        /// <summary>
        /// Inserta en la tabla TBL_MAESTRO_ASIGNACION_EMPLEADOS_TMP la informacion cargada por el area de riesgo
        /// </summary>
        /// <param name="registros"></param>
        void insRegistrosMaestroAsignacionEmpleadosTmp(IList<RegistroMaestroAsignacionEmpleados> registros);
    }
}
