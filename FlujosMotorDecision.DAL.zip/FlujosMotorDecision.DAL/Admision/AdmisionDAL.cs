﻿using Dapper;
using FastMember;
using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL
{
    public class AdmisionDAL : IAdmisionDAL
    {
        /// <summary>
        /// Agrega los registros recibidos a la tabla TB_MAESTRO_ASIGNACION
        /// </summary>
        /// <param name="registros"></param>
        public void insertarRegistrosMaestroAsignacion(IList<RegistroMaestroAsignacion> registros)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connAdmision"].ConnectionString))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    conn.Execute("TRUNCATE TABLE TB_MAESTRO_ASIGNACION", transaction: tr);

                    var dt = new DataTable();
                    using (var reader = ObjectReader.Create(registros))
                    {
                        dt.Load(reader);
                    }

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
                    {
                        foreach (DataColumn col in dt.Columns)
                        {
                            bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        }
                        bulkCopy.DestinationTableName = "dbo.TB_MAESTRO_ASIGNACION";
                        bulkCopy.WriteToServer(dt);
                    }
                    tr.Commit();
                }
            }
        }


        /// <summary>
        /// Insertar la lista de registros recibida en la tabla TB_MAESTRO_ASIGNACION_EMPLEADOS_TMP
        /// </summary>
        /// <param name="registros"></param>
        public void insRegistrosMaestroAsignacionEmpleadosTmp(IList<RegistroMaestroAsignacionEmpleados> registros)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connAdmision"].ConnectionString))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    conn.Execute("TRUNCATE TABLE TB_MAESTRO_ASIGNACION_EMPLEADOS_TMP", transaction: tr);

                    var sql = @"FMD_INS_TB_MAESTRO_ASIGNACION_EMPLEADOS_TMP";
                    foreach (var r in registros)
                    {
                        conn.Execute(sql,
                             new
                             {
                                 CUENTA_TDC = r.CUENTA_TDC,
                                 FECHA_ASIGNACION = r.FECHA_ASIGNACION,
                                 TIPO_DOCUMENTO = r.TIPO_DOCUMENTO,
                                 NUMERO_DOCUMENTO = r.NUMERO_DOCUMENTO,
                                 FECHA_ACTUALIZACION_CENTRALES = r.FECHA_ACTUALIZACION_CENTRALES,
                                 CLASIFICACION_CENTRALES = r.CLASIFICACION_CENTRALES,
                                 SCORE_CENTRALES = r.SCORE_CENTRALES,
                                 NODO = r.NODO,
                                 CUOTAS_CREDITO = r.CUOTAS_CREDITO,
                                 CONTINGENTES = r.CONTINGENTES,
                                 SCORE_BEHAVIOUR = r.SCORE_BEHAVIOUR,
                                 HABITO_PAGO_PROMEDIO = r.HABITO_PAGO_PROMEDIO,
                                 ESTRATO = r.ESTRATO,
                                 ASIGNA_CONSUMO = r.ASIGNA_CONSUMO,
                                 LINEA_ACTUAL_CONSUMO = r.LINEA_ACTUAL_CONSUMO,
                                 SOPORTE_DOCUMENTOS = r.SOPORTE_DOCUMENTOS,
                                 MONTO_PREAPROBADO_CONSUMO = r.MONTO_PREAPROBADO_CONSUMO,
                                 FILTROS = r.FILTROS,
                                 RESPUESTA = r.RESPUESTA,
                             },
                             commandType: CommandType.StoredProcedure,
                             transaction: tr);
                    }
                    tr.Commit();
                }
            }
        }


        /// <summary>
        /// Insertar un registro en la tabla CliPreaprobOtrosCampos
        /// </summary>
        /// <param name="registro"></param>
        /// <param name="conn"></param>
        /// <param name="tr"></param>
        public void cargarTablaMaestroAsignacionEmpleados()
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connAdmision"].ConnectionString))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    conn.Execute("TRUNCATE TABLE TB_MAESTRO_ASIGNACION_EMPLEADOS_TMP",
                         transaction: tr);

                    conn.Execute("INSERT INTO TB_MAESTRO_ASIGNACION_EMPLEADOS_TMP SELECT * FROM TB_MAESTRO_ASIGNACION_EMPLEADOS",
                         transaction: tr);
                }
            }
        }
        /// <summary>
        /// Insertar en admisiones la informacion de preaprobados
        /// </summary>
        /// <param name="registros"></param>
        public void insertarDatosReconocer(IList<CliPreaProbDto> registros)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connAdmision"].ConnectionString))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                                        
                    insCliPreaprobOtrosCampos(registros, conn, tr);
                    insCliPreaprobOtrosCamposDet(registros, conn, tr);
                    insCliPreaprob(registros, conn, tr);                    
                    tr.Commit();
                }
            }
        }

        /// <summary>
        /// Insertar un registro en la tabla CliPreaprobOtrosCampos
        /// </summary>
        /// <param name="registros"></param>
        /// <param name="conn"></param>
        /// <param name="tr"></param>
        private void insCliPreaprobOtrosCampos(IList<CliPreaProbDto> registros, SqlConnection conn, SqlTransaction tr)
        {
            var dt = new DataTable();
            using (var reader = ObjectReader.Create(registros, 
                "tipoId",
                "numeroId",
                "primerApellido",
                "segundoApellido",
                "primerNombre",
                "segundoNombre",
                "nombreCompleto",
                "fechaExpedicion",
                "ciudadExpedicion",
                "dptoExpedicion",
                "genero",
                "rangoEdad",
                "ciiu",
                "actividadEconomica"))
            {
                dt.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                foreach (DataColumn col in dt.Columns)
                {
                    bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                }
                bulkCopy.DestinationTableName = "CliPreaprobOtrosCampos";
                bulkCopy.WriteToServer(dt);
            }
        }

        /// <summary>
        /// Insertar un registro en la tabla CliPreaprobOtrosCampos
        /// </summary>
        /// <param name="registros"></param>
        /// <param name="conn"></param>
        /// <param name="tr"></param>
        private void insCliPreaprobOtrosCamposDet(IList<CliPreaProbDto> registros, SqlConnection conn, SqlTransaction tr)
        {
            // Registro 1
            var dtReg1 = new DataTable();
            using (var reader = ObjectReader.Create(registros,
                "tipoId",
                "numeroId",                
                "ciudadTelefono",
                "codCiudadTelefono",
                "codDANEdptoTelefono",
                "numeroTelefono",
                "tipoTelefono",
                "fechaUltimaActualizacionTelefono",
                "numDeEntidadesReportanTelefono",
                "ciudadDireccion",
                "codCiudadDireccion",
                "codDANEdptoDireccion",
                "direccion",
                "tipoDireccion",
                "zona",
                "estratoDireccion",
                "fechaUltimaActualizacionDireccion",
                "numDeEntidadesReportanDireccion"))
            {
                dtReg1.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                foreach (DataColumn col in dtReg1.Columns)
                {
                    bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                }
                bulkCopy.DestinationTableName = "CliPreaprobDetOtrosCampos";
                bulkCopy.WriteToServer(dtReg1);
            }

            // Registro 2
            var dtReg2 = new DataTable();
            using (var reader = ObjectReader.Create(registros,
                "tipoId",
                "numeroId",
                "ciudadTelefono2",
                "codCiudadTelefono2",
                "codDANEdptoTelefono2",
                "numeroTelefono2",
                "tipoTelefono2",
                "fechaUltimaActualizacionTelefono2",
                "numDeEntidadesReportanTelefono2",
                "ciudadDireccion2",
                "codCiudadDireccion2",
                "codDANEdptoDireccion2",
                "direccion2",
                "tipoDireccion2",
                "zona2",
                "estratoDireccion2",
                "fechaUltimaActualizacionDireccion2",
                "numDeEntidadesReportanDireccion2"))
            {
                dtReg2.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                bulkCopy.ColumnMappings.Add("tipoId", "tipoId");
                bulkCopy.ColumnMappings.Add("numeroId", "numeroId");
                bulkCopy.ColumnMappings.Add("ciudadTelefono2", "ciudadTelefono");
                bulkCopy.ColumnMappings.Add("codCiudadTelefono2", "codCiudadTelefono");
                bulkCopy.ColumnMappings.Add("codDANEdptoTelefono2", "codDANEdptoTelefono");
                bulkCopy.ColumnMappings.Add("numeroTelefono2", "numeroTelefono");
                bulkCopy.ColumnMappings.Add("tipoTelefono2", "tipoTelefono");
                bulkCopy.ColumnMappings.Add("fechaUltimaActualizacionTelefono2", "fechaUltimaActualizacionTelefono");
                bulkCopy.ColumnMappings.Add("numDeEntidadesReportanTelefono2", "numDeEntidadesReportanTelefono");
                bulkCopy.ColumnMappings.Add("ciudadDireccion2", "ciudadDireccion");
                bulkCopy.ColumnMappings.Add("codCiudadDireccion2", "codCiudadDireccion");
                bulkCopy.ColumnMappings.Add("codDANEdptoDireccion2", "codDANEdptoDireccion");
                bulkCopy.ColumnMappings.Add("direccion2", "direccion");
                bulkCopy.ColumnMappings.Add("tipoDireccion2", "tipoDireccion");
                bulkCopy.ColumnMappings.Add("zona2", "zona");
                bulkCopy.ColumnMappings.Add("estratoDireccion2", "estratoDireccion");
                bulkCopy.ColumnMappings.Add("fechaUltimaActualizacionDireccion2", "fechaUltimaActualizacionDireccion");
                bulkCopy.ColumnMappings.Add("numDeEntidadesReportanDireccion2", "numDeEntidadesReportanDireccion");
                bulkCopy.DestinationTableName = "CliPreaprobDetOtrosCampos";
                bulkCopy.WriteToServer(dtReg2);
            }

            // Registro 3
            var dtReg3 = new DataTable();
            using (var reader = ObjectReader.Create(registros,
                "tipoId",
                "numeroId",
                "ciudadTelefono3",
                "codCiudadTelefono3",
                "codDANEdptoTelefono3",
                "numeroTelefono3",
                "tipoTelefono3",
                "fechaUltimaActualizacionTelefono3",
                "numDeEntidadesReportanTelefono3",
                "ciudadDireccion3",
                "codCiudadDireccion3",
                "codDANEdptoDireccion3",
                "direccion3",
                "tipoDireccion3",
                "zona3",
                "estratoDireccion3",
                "fechaUltimaActualizacionDireccion3",
                "numDeEntidadesReportanDireccion3"))
            {
                dtReg3.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                bulkCopy.ColumnMappings.Add("tipoId", "tipoId");
                bulkCopy.ColumnMappings.Add("numeroId", "numeroId");
                bulkCopy.ColumnMappings.Add("ciudadTelefono3", "ciudadTelefono");
                bulkCopy.ColumnMappings.Add("codCiudadTelefono3", "codCiudadTelefono");
                bulkCopy.ColumnMappings.Add("codDANEdptoTelefono3", "codDANEdptoTelefono");
                bulkCopy.ColumnMappings.Add("numeroTelefono3", "numeroTelefono");
                bulkCopy.ColumnMappings.Add("tipoTelefono3", "tipoTelefono");
                bulkCopy.ColumnMappings.Add("fechaUltimaActualizacionTelefono3", "fechaUltimaActualizacionTelefono");
                bulkCopy.ColumnMappings.Add("numDeEntidadesReportanTelefono3", "numDeEntidadesReportanTelefono");
                bulkCopy.ColumnMappings.Add("ciudadDireccion3", "ciudadDireccion");
                bulkCopy.ColumnMappings.Add("codCiudadDireccion3", "codCiudadDireccion");
                bulkCopy.ColumnMappings.Add("codDANEdptoDireccion3", "codDANEdptoDireccion");
                bulkCopy.ColumnMappings.Add("direccion3", "direccion");
                bulkCopy.ColumnMappings.Add("tipoDireccion3", "tipoDireccion");
                bulkCopy.ColumnMappings.Add("zona3", "zona");
                bulkCopy.ColumnMappings.Add("estratoDireccion3", "estratoDireccion");
                bulkCopy.ColumnMappings.Add("fechaUltimaActualizacionDireccion3", "fechaUltimaActualizacionDireccion");
                bulkCopy.ColumnMappings.Add("numDeEntidadesReportanDireccion3", "numDeEntidadesReportanDireccion");

                bulkCopy.DestinationTableName = "CliPreaprobDetOtrosCampos";
                bulkCopy.WriteToServer(dtReg3);
            }

            //Celular 1
            var dtCelular = new DataTable();
            using (var reader = ObjectReader.Create(registros,
                "tipoId",
                "numeroId",
                "celular"))
            {
                dtCelular.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                bulkCopy.ColumnMappings.Add("tipoId", "tipoId");
                bulkCopy.ColumnMappings.Add("numeroId", "numeroId");
                bulkCopy.ColumnMappings.Add("celular", "numeroTelefono");
                
                bulkCopy.DestinationTableName = "CliPreaprobDetOtrosCampos";
                bulkCopy.WriteToServer(dtCelular);
            }


            //Celular 2
            var dtCelular2 = new DataTable();
            using (var reader = ObjectReader.Create(registros,
                "tipoId",
                "numeroId",
                "celular2"))
            {
                dtCelular2.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                bulkCopy.ColumnMappings.Add("tipoId", "tipoId");
                bulkCopy.ColumnMappings.Add("numeroId", "numeroId");
                bulkCopy.ColumnMappings.Add("celular2", "numeroTelefono");

                bulkCopy.DestinationTableName = "CliPreaprobDetOtrosCampos";
                bulkCopy.WriteToServer(dtCelular2);
            }

        }

        /// <summary>
        /// Insertar un registro en la tabla CliPreaprobOtrosCampos
        /// </summary>
        /// <param name="registros"></param>
        /// <param name="conn"></param>
        /// <param name="tr"></param>
        private void insCliPreaprob(IList<CliPreaProbDto> registros, SqlConnection conn, SqlTransaction tr)
        {
            var dt = new DataTable();
            using (var reader = ObjectReader.Create(registros,
                "tipoId",
                "numeroId",
                "ciudadExpedicion",
                "nombreCompleto",
                "ingreso",
                "cuotasCredito",
                "cuotasContingentes",
                "cupo",
                "producto",
                "actividad"))
            {
                dt.Load(reader);
            }
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.TableLock, tr))
            {
                bulkCopy.ColumnMappings.Add("tipoId", "tipoDocumento");
                bulkCopy.ColumnMappings.Add("numeroId", "numDocumento");
                bulkCopy.ColumnMappings.Add("ciudadExpedicion", "ciudadExpedicion");
                bulkCopy.ColumnMappings.Add("nombreCompleto", "nombre");
                bulkCopy.ColumnMappings.Add("ingreso", "ingreso");
                bulkCopy.ColumnMappings.Add("cuotasCredito", "cuotasCredito");
                bulkCopy.ColumnMappings.Add("cuotasContingentes", "cuotasContingentes");
                bulkCopy.ColumnMappings.Add("cupo", "cupo");
                bulkCopy.ColumnMappings.Add("producto", "producto");
                bulkCopy.ColumnMappings.Add("actividad", "actividad");

                bulkCopy.DestinationTableName = "CliPreaprob";
                bulkCopy.WriteToServer(dt);
            }
        }
    }
}
