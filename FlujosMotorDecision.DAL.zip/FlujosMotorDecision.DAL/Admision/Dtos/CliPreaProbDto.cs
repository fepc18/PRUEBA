﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL.Dtos
{
    public class CliPreaProbDto
    {
        // CliPreaProbOtrosCampos
        public int? tipoId { get; set; }
        public int? numeroId { get; set; }
        public string primerApellido { get; set; }
        public string segundoApellido { get; set; }
        public string primerNombre { get; set; }
        public string segundoNombre { get; set; }
        public string nombreCompleto { get; set; }
        public DateTime? fechaExpedicion { get; set; }
        public string ciudadExpedicion { get; set; }
        public string dptoExpedicion { get; set; }
        public string genero { get; set; }
        public string rangoEdad { get; set; }
        public int? ciiu { get; set; }
        public string actividadEconomica { get; set; }

        // CliPreaProbDetOtrosCampos
        public string ciudadTelefono { get; set; }
        public string dptoTelefono { get; set; }
        public int? codCiudadTelefono { get; set; }
        public int? codDANEdptoTelefono { get; set; }
        public decimal?  numeroTelefono { get; set; }
        public string tipoTelefono { get; set; }
        public DateTime? fechaUltimaActualizacionTelefono { get; set; }
        public int? numDeEntidadesReportanTelefono { get; set; }

        public string ciudadTelefono2 { get; set; }
        public string dptoTelefono2 { get; set; }
        public int? codCiudadTelefono2 { get; set; }
        public int? codDANEdptoTelefono2 { get; set; }
        public decimal?  numeroTelefono2 { get; set; }
        public string tipoTelefono2 { get; set; }
        public DateTime? fechaUltimaActualizacionTelefono2 { get; set; }
        public int? numDeEntidadesReportanTelefono2 { get; set; }

        public string ciudadTelefono3 { get; set; }
        public string dptoTelefono3 { get; set; }
        public int? codCiudadTelefono3 { get; set; }
        public int? codDANEdptoTelefono3 { get; set; }
        public decimal?  numeroTelefono3 { get; set; }
        public string tipoTelefono3 { get; set; }
        public DateTime? fechaUltimaActualizacionTelefono3 { get; set; }
        public int? numDeEntidadesReportanTelefono3 { get; set; }

        public string ciudadDireccion { get; set; }
        public string dptoDireccion { get; set; }
        public int? codCiudadDireccion { get; set; }
        public int? codDANEdptoDireccion { get; set; }
        public string direccion { get; set; }
        public string tipoDireccion { get; set; }
        public string zona { get; set; }
        public int? estratoDireccion { get; set; }
        public DateTime? fechaUltimaActualizacionDireccion { get; set; }
        public int? numDeEntidadesReportanDireccion { get; set; }

        public string ciudadDireccion2 { get; set; }
        public string dptoDireccion2 { get; set; }
        public int? codCiudadDireccion2 { get; set; }
        public int? codDANEdptoDireccion2 { get; set; }
        public string direccion2 { get; set; }
        public string tipoDireccion2 { get; set; }
        public string zona2 { get; set; }
        public int? estratoDireccion2 { get; set; }
        public DateTime? fechaUltimaActualizacionDireccion2 { get; set; }
        public int? numDeEntidadesReportanDireccion2 { get; set; }

        public string ciudadDireccion3 { get; set; }
        public string dptoDireccion3 { get; set; }
        public int? codCiudadDireccion3 { get; set; }
        public int? codDANEdptoDireccion3 { get; set; }
        public string direccion3 { get; set; }
        public string tipoDireccion3 { get; set; }
        public string zona3 { get; set; }
        public int? estratoDireccion3 { get; set; }
        public DateTime? fechaUltimaActualizacionDireccion3 { get; set; }
        public int? numDeEntidadesReportanDireccion3 { get; set; }

        public decimal?  celular { get; set; }
        public decimal?  celular2 { get; set; }

        // CliPreaProb
        public DateTime? fechaEvaluacion { get; set; }
        public decimal?  ingreso {get;set;}
        public int? cuotasCredito { get; set; }
        public decimal?  cuotasContingentes {get; set;}
        public decimal?  cupo { get; set; }
        public int? producto { get; set; }
        public int? actividad { get; set; }

        public string email { get; set; }

        public string email2 { get; set; }
    }
}
