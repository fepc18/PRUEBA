﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL.Dtos
{
    public class RegistroMaestroAsignacionEmpleados
    {
        public string CUENTA_TDC { get; set; }

        public DateTime FECHA_ASIGNACION  { get; set; }
        public int TIPO_DOCUMENTO { get; set; }

        public string NUMERO_DOCUMENTO { get; set; }

        public DateTime FECHA_ACTUALIZACION_CENTRALES{ get; set; }

        public string CLASIFICACION_CENTRALES { get; set; }

        public decimal SCORE_CENTRALES{ get; set; }

        public decimal NODO{ get; set; }

        public decimal CUOTAS_CREDITO { get; set; }

        public decimal CONTINGENTES{ get; set; }

        public decimal SCORE_BEHAVIOUR{ get; set; }

        public  string HABITO_PAGO_PROMEDIO{ get; set; }

        public int ESTRATO { get; set; }

        public decimal ASIGNA_CONSUMO{ get; set; }

        public float LINEA_ACTUAL_CONSUMO{ get; set; }

        public decimal SOPORTE_DOCUMENTOS{ get; set; }
        
        public float MONTO_PREAPROBADO_CONSUMO { get; set; }

        public string FILTROS{ get; set; }

        public string RESPUESTA { get; set; }
    }
}
