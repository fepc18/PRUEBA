﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL.Dtos
{
    public class ResultadoEjecucionJob
    {
        public string Nombre { get; set; }
        public int UltimaFechaEjecucion { get; set; }
        public int UltimaHoraEjecucion { get; set; }
        public int TiempoEjecucion { get; set; }
        public EstadoJob Estado { get; set; }
    }
    public enum EstadoJob
    {
        Fallido = 0, 
        Exitoso = 1, 
        Cancelado = 3, 
        Progreso = 4
    }
}
