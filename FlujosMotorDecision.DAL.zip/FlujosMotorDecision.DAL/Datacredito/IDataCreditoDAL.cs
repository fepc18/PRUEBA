﻿using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL.Contratos
{
    public interface IDataCreditoDAL
    {
        /// <summary>
        /// Ejecuta un Job en SQL Server dado su nombre
        /// </summary>
        /// <param name="nombre"></param>
        void EjecutarJob(string nombre);

        /// <summary>
        /// Retorna la informacion relacionada a la ultima ejecucion de un job
        /// </summary>
        /// <param name="nombre"></param>
        /// <returns></returns>
        ResultadoEjecucionJob GetResultadoUltimaEjecucionJob(string nombre);

        /// <summary>
        /// Retorna true si el JOB se encuentra actualmente en ejecucion
        /// </summary>
        /// <param name="nombre"></param>
        /// <returns></returns>
        bool JobEnEjecucion(string nombre);
    }
}
