﻿using Dapper;
using FlujosMotorDecision.DAL.Contratos;
using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL.Implementaciones
{
    public class DataCreditoDAL : IDataCreditoDAL
    {
        /// <summary>
        /// Ejecuta un Job en SQL Server dado su nombre
        /// </summary>
        /// <param name="nombre"></param>
        public void EjecutarJob(string nombre)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connDataCredito"].ConnectionString))
            {
                conn.Open();
                var cmd = @"EXEC msdb.dbo.sp_start_job N'" + nombre + "'";
                conn.Execute(cmd);
            }
        }

        /// <summary>
        /// Retorna la informacion relacionada a la ultima ejecucion de un job
        /// </summary>
        /// <param name="nombre"></param>
        /// <returns></returns>
        public ResultadoEjecucionJob GetResultadoUltimaEjecucionJob(string nombre)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connDataCredito"].ConnectionString))
            {
                conn.Open();
                var query = @"SELECT DISTINCT
j.Name AS Nombre, h.run_date AS UltimaFechaEjecucion, h.run_time AS UltimaHoraEjecucion, h.run_duration AS TiempoEjecucion, h.run_status AS Estado
FROM msdb..sysJobHistory h, msdb..sysJobs j
WHERE j.job_id = h.job_id
AND h.step_id = 1
AND j.Name = @nombre
ORDER BY UltimaFechaEjecucion DESC, UltimaHoraEjecucion DESC";
                return conn.Query<ResultadoEjecucionJob>(query, new { Nombre = nombre }).FirstOrDefault();
            }
        }

        /// <summary>
        /// Retorna la informacion relacionada a la ultima ejecucion de un job
        /// </summary>
        /// <param name="nombre"></param>
        /// <returns></returns>
        public bool JobEnEjecucion(string nombre)
        {
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connDataCredito"].ConnectionString))
            {
                conn.Open();
                var query = @"SELECT sj.name   
FROM msdb.dbo.sysjobactivity AS sja
INNER JOIN msdb.dbo.sysjobs AS sj ON sja.job_id = sj.job_id
WHERE sja.start_execution_date IS NOT NULL
   AND sja.stop_execution_date IS NULL
AND sj.name = @nombre";
                return conn.Query<string>(query, new { Nombre = nombre }).Any();
            }
        }
    }
}

