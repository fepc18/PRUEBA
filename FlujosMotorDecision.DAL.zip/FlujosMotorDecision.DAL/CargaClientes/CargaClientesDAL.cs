﻿using Dapper;
using FastMember;
using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL
{
    public class CargaClientesDAL : ICargaClientesDAL         
    {
        /// <summary>
        /// Obtiene los registros a partir de la base de datos Admisiones por medio de Stored Procedure
        /// </summary>
        /// <param name="registros"></param>
        public void cargarClientes(int idProceso)
        {
            using (var conn =
                new SqlConnection(ConfigurationManager.ConnectionStrings["MotorContext"].ConnectionString))
            {
                conn.Open();
                using (var tr = conn.BeginTransaction())
                {
                    SqlCommand sqlCommand = new SqlCommand();
                    //SqlDataReader reader;
                    sqlCommand.CommandTimeout = 0;
                    sqlCommand.CommandText = "SP_CARGAR_CLIENTES";
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    SqlParameter pIdProceso = new SqlParameter("PROCESO_ID", idProceso);
                    sqlCommand.Parameters.Add(pIdProceso);
                    sqlCommand.Connection = conn;
                    sqlCommand.Transaction = tr;
                    sqlCommand.ExecuteNonQuery();                    
                    tr.Commit();
                }
            }
        }
    }
}
