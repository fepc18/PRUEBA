﻿using FlujosMotorDecision.DAL.Dtos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace FlujosMotorDecision.DAL
{
    public interface IOdsDAL
    {
        /// <summary>
        /// Retorna el estatus de un evento
        /// </summary>
        /// <param name="empresa"></param>
        /// <param name="fechaInicio"></param>
        /// <param name="evento"></param>
        /// <param name="terminal"></param>
        /// <returns></returns>
        string GetEventStatus(string empresa, DateTime fechaInicio, string evento, string terminal);

        /// <summary>
        /// Retorna una lista del nodo clientes creada a partir del cursor retornado por el ods
        /// </summary>
        /// <param name="tipoProceso"></param>
        /// <returns></returns>
        IList<RegistroNodoCliente> GetNodoCliente(string tipoProceso);

        /// <summary>
        /// Retorna una lista del nodo tarjeta creada a partir del cursor retornado por el ods
        /// </summary>
        /// <param name="tipoProceso"></param>
        /// <returns></returns>
        IList<RegistroNodoTarjeta> GetNodoTarjeta(string tipoProceso);

        /// <summary>
        /// Retorna una lista del nodo sobregiro creada a partir del cursor retornado por el ods
        /// </summary>
        /// <param name="tipoProceso"></param>
        /// <returns></returns>
        IList<RegistroNodoSobregiro> GetNodoSobregiro(string tipoProceso);
        /// <summary>
        /// Inserta un evento dado en el ods
        /// </summary>
        /// <param name="empresa"></param>
        /// <param name="status"></param>
        /// <param name="usuario"></param>
        /// <param name="terminal"></param>
        /// <param name="evento"></param>
        /// <param name="FechaInicio"></param>
        /// <param name="FechaFin"></param>
        void InsertarEvento(string empresa, string status, string usuario, string terminal, string evento, DateTime FechaInicio, DateTime FechaFin);
    }
}
