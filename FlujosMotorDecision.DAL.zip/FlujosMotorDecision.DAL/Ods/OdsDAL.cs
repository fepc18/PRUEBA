﻿using Dapper;
using FlujosMotorDecision.DAL;
using FlujosMotorDecision.DAL.Dtos;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FlujosMotorDecision.DAL
{
    public class OdsDAL : IOdsDAL
    {
        public string GetEventStatus(string empresa, DateTime fechaInicio, string evento, string terminal)
        {
            var p = new OracleDynamicParameters();
            p.Add("pi_cEmprCodi", empresa, OracleDbType.Varchar2, ParameterDirection.Input);
            p.Add("pi_cEvntCodi", evento, OracleDbType.Varchar2, ParameterDirection.Input);
            p.Add("pi_dEvntEval", fechaInicio, OracleDbType.Date, ParameterDirection.Input);
            p.Add("pi_cEvntTerm", terminal, OracleDbType.Varchar2, ParameterDirection.Input);
            using (var conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnOds"].ConnectionString))
            {
                conn.Open();
                return conn.Query<string>("SELECT USR_ODS.PKG_BF_DP_EVENGENE.Get_Status(:pi_cEmprCodi, :pi_cEvntCodi, :pi_dEvntEval, :pi_cEvntTerm) from DUAL",
                                               param: p,
                                               commandType: CommandType.Text).Single();
            }
        }

        public void InsertarEvento(string empresa, string status, string usuario, string terminal, string evento, DateTime FechaInicio, DateTime FechaFin)
        {
            var p = new OracleDynamicParameters();
            p.Add("pi_cEmprCodi", empresa, OracleDbType.Varchar2, ParameterDirection.Input);
            p.Add("pi_cEvntCodi", evento, OracleDbType.Varchar2, ParameterDirection.Input);
            p.Add("pi_cUserName", usuario, OracleDbType.Varchar2, ParameterDirection.Input);
            p.Add("pi_cUserTerm ", terminal, OracleDbType.Varchar2, ParameterDirection.Input);
            p.Add("pi_dEvntInic", FechaInicio, OracleDbType.Date, ParameterDirection.Input);
            p.Add("pi_dEvntFina", FechaFin, OracleDbType.Date, ParameterDirection.Input);
            p.Add("pi_cEvntStat", status, OracleDbType.Varchar2, ParameterDirection.Input);

            p.Add("pio_Error_Code", DBNull.Value, OracleDbType.Varchar2, ParameterDirection.Output);
            p.Add("pio_Error_Msg ", DBNull.Value, OracleDbType.Varchar2, ParameterDirection.Output);

            using (var conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnOds"].ConnectionString))
            {
                conn.Open();
                conn.Execute("USR_ODS.PKG_BF_DP_EVENGENE.Insert_Event",
                                               param: p,
                                               commandType: CommandType.StoredProcedure);
            }
            var errorCode = p.Get<OracleString>("pio_Error_Code");
        }

        public IList<RegistroNodoCliente> GetNodoCliente(string tipoProceso)
        {
            using (var conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnOds"].ConnectionString))
            {
                conn.Open();
                var p = new OracleDynamicParameters();
                p.Add("pi_Tipo_Proceso", tipoProceso, OracleDbType.Varchar2, ParameterDirection.Input, 2);

                p.Add("pio_Query", DBNull.Value, OracleDbType.RefCursor, direction: ParameterDirection.Output);
                p.Add("pio_Error_Code ", DBNull.Value, OracleDbType.Varchar2, direction: ParameterDirection.Output, size: 20);
                p.Add("pio_Error_Msg ", DBNull.Value, OracleDbType.Varchar2, direction: ParameterDirection.Output, size: 250);

                using (var multi = conn.QueryMultiple("USR_LANDING.PKG_MD_FEEDBACK.QUERY_NODO_CLIENTE", param: p, commandType: CommandType.StoredProcedure))
                {                    
                    var datos = multi.Read<RegistroNodoCliente>().ToList();
                    return datos;
                }
            }
        }

        public IList<RegistroNodoTarjeta> GetNodoTarjeta(string tipoProceso)
        {
            using (var conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnOds"].ConnectionString))
            {
                conn.Open();
                var p = new OracleDynamicParameters();
                p.Add("pi_Tipo_Proceso", tipoProceso, OracleDbType.Varchar2, ParameterDirection.Input, 2);

                p.Add("pio_Query", DBNull.Value, OracleDbType.RefCursor, direction: ParameterDirection.Output);
                p.Add("pio_Error_Code ", DBNull.Value, OracleDbType.Varchar2, direction: ParameterDirection.Output, size: 20);
                p.Add("pio_Error_Msg ", DBNull.Value, OracleDbType.Varchar2, direction: ParameterDirection.Output, size: 250);

                using (var multi = conn.QueryMultiple("USR_LANDING.PKG_MD_FEEDBACK.QUERY_NODO_TARJETA", param: p, commandType: CommandType.StoredProcedure))
                {
                    var datos = multi.Read<RegistroNodoTarjeta>().ToList();
                    return datos;
                }
            }
        }

        public IList<RegistroNodoSobregiro> GetNodoSobregiro(string tipoProceso)
        {
            using (var conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ConnOds"].ConnectionString))
            {
                conn.Open();
                var p = new OracleDynamicParameters();
                p.Add("pi_Tipo_Proceso", tipoProceso, OracleDbType.Varchar2, ParameterDirection.Input, 2);

                p.Add("pio_Query", DBNull.Value, OracleDbType.RefCursor, direction: ParameterDirection.Output);
                p.Add("pio_Error_Code ", DBNull.Value, OracleDbType.Varchar2, direction: ParameterDirection.Output, size: 20);
                p.Add("pio_Error_Msg ", DBNull.Value, OracleDbType.Varchar2, direction: ParameterDirection.Output, size: 250);

                using (var multi = conn.QueryMultiple("USR_LANDING.PKG_MD_FEEDBACK.QUERY_NODO_SOBREGIRO", param: p, commandType: CommandType.StoredProcedure))
                {
                    var datos = multi.Read<RegistroNodoSobregiro>().ToList();
                    return datos;
                }
            }
        }
    }
}
