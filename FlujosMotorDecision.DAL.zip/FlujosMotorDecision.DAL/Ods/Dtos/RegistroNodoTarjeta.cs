﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.DAL.Dtos
{
    public class RegistroNodoTarjeta
    {
        public string CLAVE_UNICA_CLIENTE { get; set; }
        public string TDC_NUMERO_PRODUCTO { get; set; }
    }
}
