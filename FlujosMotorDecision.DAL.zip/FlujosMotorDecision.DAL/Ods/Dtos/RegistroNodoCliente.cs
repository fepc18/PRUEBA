﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlujosMotorDecision.DAL.Dtos
{
    public class RegistroNodoCliente
    {
        public string CLI_TIPO_DOC { get; set; }
        public string CLI_NUM_DOC { get; set; }
        public string CMCLI_OFERPROD_CUENTA_TDC { get; set; }

        public DateTime FECHA_PROCESO { get; set; }
        public string CMCLI_OFERTAPRODUCTOS_TIPO_ID { get; set; }

        public string CMCLI_OFERTAPRODUCTOS_CEDULA { get; set; }

        //public string CMCLI_OFERPROD_FEC_ACTUA_CENTR { get; set; }

        public string CMCLI_OFERPROD_CLASI_CENTRALES { get; set; }

        public string CMCLI_OFERPROD_SCORE_CENTRALES { get; set; }

        public string CMCLI_OFERTAPRODUCTOS_NODO { get; set; }

        public string CMCLI_OFERPROD_CUOTAS_CREDITO { get; set; }

        public string CMCLI_OFERPROD_CONTINGENTES { get; set; }

        public string CMCLI_OFERPROD_SCORE_BEHAVIOUR { get; set; }

        public string CMCLI_OFERPROD_ANTIGUEDAD { get; set; }

        public string CMCLI_OFERPROD_HABI_PAGO_PROM { get; set; }

        public string CMCLI_OFERTAPRODUCTOS_ESTRATO { get; set; }

        public string CMCLI_OFERPROD_ASIGNA_AUMENTO { get; set; }

        public string CAMPCLIENTES_CF_ASIGNA_CONSUMO { get; set; }

        public string CMCLI_CF_ASIGNA_SOBREGIRO { get; set; }

        public string CMCLI_CF_LINEA_ACTUAL_CONSUMO { get; set; }

        public string CMCLI_CF_LINEA_ACT_SOBREGIRO { get; set; }

        public string CLI_CUPOTOTALACTUALTDC { get; set; }

        public string CMCLI_OFERPROD_REQU_SOPOR_INGR { get; set; }        

        public string CMCLI_CF_CAPITAL_ACT_CONSUMO { get; set; }

        public string CMCLI_OFERPROD_PREAPROBAUMCUPO { get; set; }

        public string CMCLI_OFERPROD_PREAPROBCONSU { get; set; }

        public string CMCLI_OFERPROD_PREAPROBSOBREGI { get; set; }

        public string RSTNOCLI_OFERPROD_INGRESO { get; set; }
        public string RSTNOCLI_OFERPROD_CUOTAS { get; set; }
        public string RSTNOCLI_OFERPROD_CONTINGENTES { get; set; }
        public string RSTNOCLI_OFERTAPRODUCTOS_CUPO { get; set; }
    }
}
