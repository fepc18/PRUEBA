﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlujosMotorDecision.DAL.Dtos
{
    public class RegistroNodoSobregiro
    {
        public string CLAVE_UNICA_CLIENTE { get; set; }
        public string PRE_SALDO{ get; set; }
        public string SGB_SALDO { get; set; }
    }
}
