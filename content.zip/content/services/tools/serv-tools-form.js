﻿app.factory('toolsResources', ['$resource', function ($resource) {
    return {
        getGeolocalizationAddress: $resource('api/tools/getGeolicalizationAddress', { address: "@address", cityCode: "@cityCode" }, { "get": { method: "GET", isArray: false } }),
    }
}]);