﻿app.factory('biometricsService', ['$resource', function ($resource) {
    return {
        getValidationHelp: $resource('api/Biometrics/getvalidationhelp', {}, { "post": { method: "POST" } }),
    }
}]);