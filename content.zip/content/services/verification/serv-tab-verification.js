﻿app.factory('tabVerificationResources', ['$resource', function ($resource) {
    return {
        //Mensajes de Usuario
        getUserMessages: $resource('api/TabsVerification/getusermessagetabverification', {}, { "post": { method: "POST" } }),
        //Base de información
        getCities: $resource('api/TabsVerification/GetCitiesBaseInformation', {}, { "post": { method: "POST" } }),
        getSanAndresitos: $resource('api/TabsVerification/GetSanAndresitosBaseInformation', {}, { "post": { method: "POST" } }),
        GetCooperatives: $resource('api/TabsVerification/GetCooperativesBaseInformation', {}, { "post": { method: "POST" } }),
        GetQuotas: $resource('api/TabsVerification/GetQuotasBaseInformation', {}, { "post": { method: "POST" } }),
        GetEmployees: $resource('api/TabsVerification/GetEmployeesBaseInformation', {}, { "post": { method: "POST" } }),
        GetTeacherScales: $resource('api/TabsVerification/GetTeacherScalesBaseInformation', {}, { "post": { method: "POST" } }),
        GetLinks: $resource('api/TabsVerification/GetLinksBaseInformation', {}, { "post": { method: "POST" } }),
        GetONG: $resource('api/TabsVerification/GetONGBaseInformation', {}, { "post": { method: "POST" } }),
        GetCreditPolicy: $resource('api/TabsVerification/GetCreditPolicyBaseInformation', {}, { "post": { method: "POST" } }),
        GetArmedForcesRanks: $resource('api/TabsVerification/GetArmedForcesRanksBaseInformation', {}, { "post": { method: "POST" } }),
        GetStores: $resource('api/TabsVerification/GetStoresBaseInformation', {}, { "post": { method: "POST" } }),
        GetPublicTransport: $resource('api/TabsVerification/GetPublicTransportBaseInformation', {}, { "post": { method: "POST" } }),
        
        FileUploadBaseInformation: $resource('api/TabsVerification/FileUploadBaseInformation', {}, { "post": { method: "POST" } }),
        GetDataReportedRequisition: $resource('api/TabsVerification/GetDataReportedRequisition', {}, { "post": { method: "POST" } }),
        GetParametersPaymentCapacity: $resource('api/TabsVerification/GetParametersPaymentCapacity', {}, { "post": { method: "POST" } }),
        SavePaymentCapacity: $resource('api/TabsVerification/SavePaymentCapacity', {}, { "post": { method: "POST" } }),
      //  GetResponseFieldForm: $resource('api/TabsVerification/GetResponseFieldForm', {}, { "post": { method: "POST" } }),
        



    }
}]);