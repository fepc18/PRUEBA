﻿app.factory('dynamicFormService', ['$resource', function ($resource) {
    return {
        getAllByModule: $resource('api/DynamicForm/getallbymodule', {}, { "post": { method: "POST" } }),
    }
}]);