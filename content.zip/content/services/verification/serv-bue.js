﻿app.factory('bueResources', ['$resource', function ($resource) {
    return {
        
        getMasterBue: $resource('api/Bue/getmasterbue', {}, { "post": { method: "POST" } }),
        //getBueDetail: $resource('api/Bue/getbuedetail', {}, { "post": { method: "POST" } }),
        getDetailBue: $resource('api/Bue/getdetailbue', { Document: "@Document" }, { "get": { method: "GET", isArray: false } }),
        getDocumentTypes: $resource('api/Bue/getdoctypes', {}, { "get": { method: "GET", isArray: false } }),
        createInternalFraudBue: $resource('api/Bue/createinternalfraudBue', {}, { "post": { method: "POST" } }),
    }
}]);