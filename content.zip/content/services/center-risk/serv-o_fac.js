﻿app.factory('oFacResources', ['$resource', function ($resource) {
    return {
        // obtiene la lista de empresas con sanciones
        getListOfac: $resource('api/Ofac/listquery', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
    }
}]);