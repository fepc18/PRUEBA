﻿app.factory('recognizeResources', ['$resource', function ($resource) {
    return {
        // obtiene la lista de empresas con sanciones
        getRecognize: $resource('api/reconocer/getdata', { typeId: "@typeId", identity: "@identity", lastName : "@lastName" }, { "get": { method: "GET", isArray: false } }),
    }
}]);