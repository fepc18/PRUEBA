﻿app.factory('centerRiskResources', ['$resource', function ($resource) {
    return {
        getShortFrame: $resource('api/CentralRisk/shortFrame', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),

        //getHeader: $resource('api/CentralRisk/header', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getVigency: $resource('api/CentralRisk/vigency', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getNoVigency: $resource('api/CentralRisk/noVigency', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getBalance: $resource('api/CentralRisk/balance', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getIndebtedness: $resource('api/CentralRisk/indebtedness', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getReclaims: $resource('api/CentralRisk/reclaims', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getAlerts: $resource('api/CentralRisk/alerts', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getQueryes: $resource('api/CentralRisk/queryes', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        //getResume: $resource('api/CentralRisk/resume', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),

        getHeader: $resource('api/CentralRisk/header', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getCalification: $resource('api/CentralRisk/calification', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getVigency: $resource('api/CentralRisk/vigency', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getNoVigency: $resource('api/CentralRisk/noVigency', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getBalance: $resource('api/CentralRisk/balance', { idConsulta: "@idConsulta"  }, { "get": { method: "GET", isArray: false } }),
        getIndebtedness: $resource('api/CentralRisk/indebtedness', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getReclaims: $resource('api/CentralRisk/reclaims', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getAlerts: $resource('api/CentralRisk/alerts', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getQueryes: $resource('api/CentralRisk/queryes', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),
        getResume: $resource('api/CentralRisk/resume', { idConsulta: "@idConsulta" }, { "get": { method: "GET", isArray: false } }),


        getHistory: $resource('api/Client/history', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),


        // determina si el usuario tiene o no una consulta vigente en la base de datos
        requireWebService: $resource('api/Client/requireWebService', { typeId: "@typeId", identity: "@identity", lastName : "@lastName" }, { "get": { method: "GET", isArray: false } }),

        // obtiene el ultimo id consulta para un usuario con tipo de identificacion y tipo de identificacion
        getLastQuery: $resource('api/Client/lastquery', { typeId: "@typeId", identity: "@identity" }, { "get": { method: "GET", isArray: false } }),
        


        validateDataCredit: $resource('api/CentralRisk/validateDataCredit', { data: "@data"}, { "get": { method: "GET", isArray: false } }),
    }
}]);