﻿app.factory('userResources', ['$resource', function ($resource) {
    return {
        getInfoBasic: $resource('api/user/getInfoBasic', null, { "get": { method: "GET", isArray: false } }),
        AuthenticateUser: $resource('api/AuthenticateUser/AuthenticateUser', null, { "post": { method: "POST" } }),
    }
}]);