﻿app.factory('reqConsultResources', ['$resource', function ($resource) {
    return {
        //getRequisitions: $resource('api/requisition/getRequisitions',
        //    {
        //        numero_solicitud: "@numero_solicitud",
        //        id_documento: "@id_documento",
        //        numero_documento: "@numero_documento",
        //        estado: "@estado",
        //        tiendas: "@tiendas",
        //        apellidos: "@apellidos",
        //        nombre_usuario: "@nombre_usuario",
        //        tipo_tramite: "@tipo_tramite",
        //        fecha1: "@fecha1",
        //        fecha2: "@fecha2",
        //        perfil: "@perfil",
        //    },
        //    { "get": { method: "GET", isArray: false } }),

        getRequisitions: $resource('api/requisition/getRequisitions', {}, { "post": { method: "POST" } }),
        getRequisitionStatus: $resource('api/requisition/getRequisitionStatus', {}, { "get": { method: "GET", isArray: false } }),
        getRequisitionDetail: $resource('api/requisition/getRequisitionDetail', { id_admision: "@id_admision", }, { "get": { method: "GET", isArray: false } }),
    }
}]);