﻿app.factory('reqProductResources', ['$resource', function ($resource) {
    return {
        //getCodeOtp: $resource('api/otp/getcode', { phoneNumber: "@phoneNumber"}, { "get": { method: "GET", isArray: false } }),
        //validateCodeOtp: $resource('api/otp/validate', { phoneNumber: "@phoneNumber", otpCode: "@otpCode" }, { "get": { method: "GET", isArray: false } }),
        //getTerminalOtp: $resource('api/otp/getTerminal', {}, { "get": { method: "GET", isArray: false } }),
        //getParametrics: $resource('api/parametrics/getparams', { version: "@version", method: "@method" }, { "get": { method: "GET", isArray: false } }),
        //getOffice: $resource('api/parametrics/getoffices', { version: "@version", method: "@method" }, { "get": { method: "GET", isArray: false } }),
        //customerProfiling: $resource('api/profiling/getProfiling', { data: "@data" }, { "get": { method: "GET", isArray: false } }),
        //prevRequestProfiling: $resource('api/profiling/getPrevRequest', { data: "@data" }, { "get": { method: "GET", isArray: false } }),
        //evidentGetAsks: $resource('api/evident/getAsks', { data: "@data" }, { "get": { method: "GET", isArray: false } }),
        //evidentValidationAsks: $resource('api/evident/validationAsks', { data: "@data" }, { "get": { method: "GET", isArray: false } }),
        //getInfoBasic: $resource('api/infobasicdata/getInfo', { data: "@data" }, { "get": { method: "GET", isArray: false } }),
        //validateRestrictiveList: $resource('api/restrictive/validateIfList', { data: "@data" }, { "get": { method: "GET", isArray: false } }),
        //validateFraud: $resource('api/fraud/validate', { data: "@data" }, { "get": { method: "GET", isArray: false } }),

        getCodeOtp: $resource('api/otp/getcode', { phoneNumber: "@phoneNumber" }, { "get": { method: "GET", isArray: false } }),
        validateCodeOtp: $resource('api/otp/validate', { phoneNumber: "@phoneNumber", otpCode: "@otpCode" }, { "get": { method: "GET", isArray: false } }),
        getTerminalOtp: $resource('api/otp/getTerminal', {}, { "get": { method: "GET", isArray: false } }),
        getParametrics: $resource('api/parametrics/getparams', { version: "@version", method: "@method" }, { "get": { method: "GET", isArray: false } }),
        getOffice: $resource('api/parametrics/getoffices', { version: "@version", method: "@method" }, { "get": { method: "GET", isArray: false } }),
        
        evidentGetAsks: $resource('api/evident/getAsks', {}, { "post": { method: "POST" } }),
        evidentValidationAsks: $resource('api/evident/validationAsks', {}, { "post": { method: "POST" } }),
        validateFraud: $resource('api/fraud/validate', {}, { "post": { method: "POST" } }),
        getInfoBasic: $resource('api/infobasicdata/getInfo', {}, { "post": { method: "POST" } }),
        prevRequestProfiling: $resource('api/profiling/getPrevRequest', {}, { "post": { method: "POST" } }),
        customerProfiling: $resource('api/profiling/getProfiling', {}, { "post": { method: "POST" } }),
        validateRestrictiveList: $resource('api/restrictive/validateIfList', {}, { "post": { method: "POST" } }),
    }
}]);