﻿app.factory('reqInsertResources', ['$resource', function ($resource) {
    return {
        //insertRequisition: $resource('api/requisition/insertRequisition', {}, { "post": { method: "POST" } }),
        //insertRequisitionXml: $resource('api/requisition/insertRequisitionXml', {}, { "post": { method: "POST" } }),

        insertRequisitionJson: $resource("api/requisition/insertRequisitionJson", {}, { "post": { method: "POST" } }),

        fingerCentralRiskAuth: $resource("api/finger/genCentralRiskAuth", {}, { "post": { method: "POST" } }),

        fingerValidate: $resource("api/finger/validateFinger", {}, { "post": { method: "POST" } }),
        fingerGetImage: $resource("api/finger/getFingerImage", {}, { "post": { method: "POST" } }),

        docScanValidate: $resource("api/docscan/validateDocScan", {}, { "post": { method: "POST" } })
        
        //insertSpouse: $resource('api/requisition/insertRequisitionSpouse', {}, { "post": { method: "POST" } }),
        //insertActivityEconomic: $resource('api/requisition/insertRequisitionActivityEconomic', {}, { "post": { method: "POST" } }),
        //insertAdditional: $resource('api/requisition/insertRequisitionAdditional', {}, { "post": { method: "POST" } }),
        //insertProduct: $resource('api/requisition/insertRequisitionProduct', {}, { "post": { method: "POST" } }),
        //insertRequisition: $resource('api/requisition/insertRequisition', {}, { "post": { method: "POST" } }),
        //insertClient: $resource('api/requisition/insertRequisitionClient', {}, { "post": { method: "POST" } }),
        //insertFinancial: $resource('api/requisition/insertRequisitionFinancial', {}, { "post": { method: "POST" } }),
        //insertLabor: $resource('api/requisition/insertRequisitionLabor', {}, { "post": { method: "POST" } }),
        //insertReference: $resource('api/requisition/insertRequisitionReference', {}, { "post": { method: "POST" } }),
        //insertAddress: $resource('api/requisition/insertRequisitionAddress', {}, { "post": { method: "POST" } }),
        //insertEmail: $resource('api/requisition/insertRequisitionEmail', {}, { "post": { method: "POST" } }),
        //insertFlags: $resource('api/requisition/insertRequisitionFlags', {}, { "post": { method: "POST" } }),
        //insertPeps: $resource('api/requisition/insertRequisitionPeps', {}, { "post": { method: "POST" } }),
        //insertIncrease: $resource('api/requisition/insertRequisitionIncrease', {}, { "post": { method: "POST" } }),
        //insertCalculate: $resource('api/requisition/insertRequisitionCalculate', {}, { "post": { method: "POST" } }),
        //insertReconsider: $resource('api/requisition/insertRequisitionReconsider', {}, { "post": { method: "POST" } }),
    }
}]);