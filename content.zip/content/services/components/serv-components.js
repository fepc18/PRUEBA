﻿app.factory('componentsResources', ['$resource', function ($resource) {
    return {
        getComponents: $resource('api/components', { id: "@id" }, { "get": { method: "GET", isArray: false } }),
    }
}]);