﻿app.factory('componentsPromise', ['$timeout', '$q', 'componentsResources', '$log',
    function ($timeout, $q, componentsResources, $log) {

        var components = {
            status: 'empty'
        };

        var interfaz = {
            getComponents: function () {
                if (components.status === 'empty') {
                    return componentsResources.getComponents.get({})
                        .$promise.then(function (data_) {
                        if (data_.state) {
                            components.data = data_.info || [];
                            components.status = 'loaded';
                            components.lastLoaded = new Date();
                            components.enabled = true;                                                   
                            
                            if (components.data.length == 0) {
                                components.enabled = false;
                                $log.warn("200 Componentes de Security Deshabilitados.");
                            } else {
                                $log.info("200 Componentes de Security Habilitados.");
                            }

                        } else {
                            components.data = [];
                            components.enabled = false;

                            $log.warn(data_.message);
                        }                        

                        return components;
                    });
                } else {
                    return $timeout(function () {
                        return components;
                    }, 0);
                }
            }
        }

        return interfaz;
    }]);