﻿app.factory('paramsPromise', ['$timeout', '$q', 'reqProductResources', '$log',
    function ($timeout, $q, reqProductResources, $log) {

        var params = {
            status: 'empty'
        };

        var offices = {
            status: 'empty'
        };

        var advisers = {
            status: 'empty'
        };

        var interfaz = {
            getParametrics: function (version_, method_) {
                if (params.status === 'empty') {
                    return reqProductResources.getParametrics.get(
                        {
                            version: version_,
                            method: method_
                        })
                        .$promise.then(function (data_) {
                            if (data_.state) {
                                params.data = data_.info;
                                params.status = 'loaded';
                                params.lastLoaded = new Date();
                                                
                                $log.info("200 Paramétricos Cargados.");
                            } else {
                                params.data = null;

                                $log.error(data_.message);
                            }

                            return params;
                        });
                } else {
                    return $timeout(function () {
                        return params;
                    }, 0);
                }
            },
            getOffice: function (version_, method_) {
                if (offices.status === 'empty') {
                    return reqProductResources.getOffice.get(
                        {
                            version: version_,
                            method: method_
                        })
                        .$promise.then(function (dataOffice_) {
                            if (dataOffice_.state) {
                                offices.data = dataOffice_.info;
                                offices.status = 'loaded';
                                offices.lastLoaded = new Date();

                                $log.info("200 Oficinas Cargadas.");
                            } else {
                                offices.data = null;

                                $log.error(dataOffice_.message);
                            }

                            return offices;
                        });
                } else {
                    return $timeout(function () {
                        return offices;
                    }, 0);
                }
            },
            getAdviser: function (version_, method_) {
                if (advisers.status === 'empty') {
                    return reqProductResources.getOffice.get(
                        {
                            version: version_,
                            method: method_
                        })
                        .$promise.then(function (data_) {
                            if (data_.state) {
                                advisers.data = data_.info;
                                advisers.status = 'loaded';
                                advisers.lastLoaded = new Date();

                                $log.info("200 Asesores Cargados.");
                            } else {
                                advisers.data = null;

                                $log.error(data_.message);
                            }

                            return advisers;
                        });
                } else {
                    return $timeout(function () {
                        return advisers;
                    }, 0);
                }
            }
        }

        return interfaz;
    }]);