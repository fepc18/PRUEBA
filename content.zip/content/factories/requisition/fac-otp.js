﻿app.factory('otpSource', ['reqProductResources', '$log',
    function (reqProductResources, $log) {

        var otpCode = {};
        var validateCode = {};
        var terminal = {};

        var interfaz = {
            getOtp: function (phoneNumber_) {
                return reqProductResources.getCodeOtp.get(
                    {
                        phoneNumber: phoneNumber_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            otpCode.status = true;
                            otpCode.data = data_.info;
                        } else {
                            otpCode.status = false;
                            otpCode.data = data_.message;

                            $log.error(data_.message);
                        }

                        return otpCode;
                    });
            },
            validateOtp: function (phoneNumber_, otpCode_) {
                return reqProductResources.validateCodeOtp.get(
                    {
                        phoneNumber: phoneNumber_,
                        otpCode: otpCode_

                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            validateCode.status = true;
                            validateCode.data = data_.info;
                        } else {

                            validateCode.status = false;
                            validateCode.data = data_.message;

                            $log.error(data_.message);
                        }

                        return validateCode;
                    });
            },
            getTerminal: function () {
                return reqProductResources.getTerminalOtp.get({}).$promise.then(function (data_) {
                    if (data_.state) {
                        terminal.status = true;
                        terminal.data = data_.info;
                    } else {
                        terminal.status = false;
                        terminal.data = data_.message;

                        $log.error(data_.message);
                    }                                       

                    return terminal;
                });
            }
        }

        return interfaz;
    }]);