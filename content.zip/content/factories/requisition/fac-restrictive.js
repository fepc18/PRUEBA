﻿app.factory('restrictiveSource', ['reqProductResources', '$log',
    function (reqProductResources, $log) {

        var validation = {};

        var interfaz = {           
            validationList: function (data_) {
                return reqProductResources.validateRestrictiveList.post(data_).$promise.then(function (data_) {
                        if (data_.state) {
                            validation.status = true;
                            validation.data = data_.info;
                        } else {
                            validation.status = false;
                            validation.data = data_.message;

                            $log.error(data_.message);
                        }
                   
                        return validation;
                    });
            }
        }

        return interfaz;
    }]);