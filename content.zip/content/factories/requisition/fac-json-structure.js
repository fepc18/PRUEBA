﻿app.factory('jsonStructure', ['$log', '$filter', 'memory', 'userResources', '$rootScope', 'toolsget',
    function ($log, $filter, memory, userResources, $rootScope, toolsget) {

        var idRequisition = 0;

        var local = {
            formatDate: function (date) {
                if (date) {
                    var fdate = $filter("date")(date, "dd/MM/yyyy");
                    return fdate;
                } else {
                    return "";
                }
            },
            formatLocaliz: function (localization) {
                if (localization) {
                    return localization.idPais + "|" + localization.idDepartamento + "|" + localization.idCiudad;
                } else {
                    return "";
                }
            },
            dataProducts: function () {
                var prods = memory.storage.get("products_finally");
                var nprods = [];
                var i = 0;

                angular.forEach(prods, function (item, index) {
                    nprods.push({
                        idSolicitud: idRequisition,
                        /*-------------------------------------*/
                        edadMinEmpFal: 18,
                        abreviacionProducto: item.abreviation,
                        idProducto: parseInt(item.idProd || "0"),
                        nombreProducto: item.description,
                        estadoFinalProducto: item.finalState,
                        tempAdmisionesId: parseInt(item.id || "0"),
                        edadMinima: parseInt(item.minAge || "0"),
                    });
                })

                return nprods;
                //return [
                //        {
                //            edadMinEmpFal: 18,
                //            abreviacionProducto: "TC",
                //            idProducto: 2,
                //            nombreProducto: "TARJETA CREDITO",
                //            estadoFinalProducto: "F",
                //            tempAdmisionesId: 0,
                //            idSolicitud: "92017217154853",
                //            edadMinima: 25
                //        },
                //        {
                //            edadMinEmpFal: 18,
                //            abreviacionProducto: "CA",
                //            idProducto: 3,
                //            nombreProducto: "CUENTA DE AHORRO",
                //            estadoFinalProducto: "F",
                //            tempAdmisionesId: 21,
                //            idSolicitud: "92017217154853",
                //            edadMinima: 6
                //        }
                //];
            },
            dataForm: {
                basicData: function () {
                    var data = memory.storage.get("form_basic_data");
                    //console.log(data.expeditionLocalization);
                    return {
                        idSolicitud: idRequisition,
                        idFormulario: 2,
                        nombre: "Datos básicos del cliente",
                        DATO_BAS_FECH_NACI: local.formatDate(data && data.birthDate),
                        DATO_BAS_GENERO: data && data.gender || "",
                        DATO_BAS_NACION: data && data.nationality || "",
                        ACT_ECO_MES_ACT: data && data.activityAge || "",
                        DATO_BAS_TEL_CEL: data && data.cellphone || "",
                        DATO_BAS_DPTO_RESID: local.formatLocaliz(data && data.residenceLocalization || ""),
                        ING_CLI_NUM_ID_CLIE: data && data.documentId || "",
                        ACT_ECO_FUE_MIL: data && data.militaryForce || "",
                        DATO_BAS_PRI_APE_CLI: data && data.surname1 || "",
                        DATO_BAS_OCUP: data && data.activity,
                        ACT_ECO_FEC_RET: data && data.prevCompanyDate || "",
                        DATO_BAS_SEG_NOM_CLI: data && data.name2 || "",
                        CED_REF_ONLINE: data && data.documentIdRef || "",
                        DATO_BAS_PRI_NOM_CLI: data && data.name1 || "",
                        DATO_BAS_CIU_NACI: local.formatLocaliz(data && data.birthLocalization || ""),
                        DATO_BAS_TIEMPO_PAIS: data && data.residenceTime || "",
                        ING_CLI_TIP_DOC: data && data.documentType || "",
                        DATO_BAS_EMPL_FALA: data && data.faEmployee || "",
                        ACT_ECO_NOM_ANTI_ACT: data && data.prevCompanyDuration || "",
                        ACT_ECO_RAN_MIL: data && data.militaryRank || "",
                        DATO_BAS_ANTI_EMPRES: data && data.activityAgeSpouce || "",
                        DATO_BAS_SEG_APE_CLI: data && data.surname2 || "",
                        DATO_BAS_FECH_EXP_DOC: local.formatDate(data && data.documentExpDate || ""),
                        DATO_BAS_CORREO_SEG: data && data.email || "",
                        //_ciudad_exp: data.expeditionLocalization ? data.expeditionLocalization.idCiudad : "",
                        //_departamento_exp: data.expeditionLocalization ? data.expeditionLocalization.idDepartamento : "",
                        DATO_BAS_FAILED_STEPS: ""
                    }
                },
                basicData2: function () {
                    var data = memory.storage.get("form_basic_data");

                    return {
                        nombre: "Datos básicos del cliente2",
                        idFormulario: 3,
                        idSolicitud: idRequisition,

                        DATO_BAS_TOTAL_ACT: data && data.totalAssets || "0",
                        DATO_BAS_ING_ACT_PRI: data && data.mainActivityIncome || "0",
                        DATO_BAS_OTR_ING: data && data.otherIncome || "0",
                        INF_FIN_TOT_EGR: data && data.totalExpend || "0",
                        DATO_BAS_TOTAL_PATR: data && data.totalHeritage || "0",
                        DATO_BAS_COS_GAST_ACT_PRI: data && data.CEActivityIncome || "0",
                        DATO_BAS_OTR_EGRE: data && data.otherExpend || "0",
                        INF_FIN_TOT_ING: data && data.totalIncome || "0",
                        DATO_BAS_EST_CIVIL: data && data.civilStatus || "",
                        INF_FIN_DESC_OTR_ING: data && data.otherIncomeDescription || "",
                        INF_FIN_DESC_OTR_EGR: data && data.otherExpendDescription || "",
                        DATO_BAS_PRI_NOM_CONY: data && data.nameSpouce || "",
                        DATO_BAS_TIP_DOC_CONY: data && data.documentTypeSpouce || "",
                        DATO_BAS_NUM_ID_CONY: data && data.documentIdSpouce || "",
                        DATO_BAS_TEL_CEL_CONY: data && data.cellphoneSpouce || "",
                        DATO_BAS_TOTAL_PAS: data && data.totalLiabilities || "0",
                        ING_PRI_CYG: data && data.mainActivityIncomeSpouce || "0",
                        DATO_BAS_OCUP_CONY: data && data.activitySpouce || "",
                        DATO_BAS_PRI_APE_CONY: data && data.surnameSpouce || ""
                    }
                },
                econoActivity: function () {
                    var data = memory.storage.get("form_economic_activity");

                    return {
                        idFormulario: 4,
                        idSolicitud: idRequisition,
                        nombre: "Actividad económica",

                        ACT_ECO_DIR_EMP: data && data.companyAddress || "",
                        ACT_ECO_DESC_ANT_AC: data && data.activityDescription || "",
                        ACT_ECO_AUTO_RETENEDOR: "", //? PENDIENTE
                        TIP_INV_REN_CAP: data && data.investmentType || "",
                        ACT_ECO_NOM_EMP: data && data.companyName || "",

                        PREGUNTA_RENT_CAP: data && data.capitalRentier || "",
                        ACT_ECO_TIP_CONTRA: data && data.contractType || "",
                        MONT_RENT_CAP: data && data.mount || "",
                        ENT_RENT_CAP: data && data.entity || "",
                        ACT_ECO_TIP_CONTRA_CYG: "",  //? PENDIENTE **
                        ACT_ECO_NOM_NIT: data && data.nit || "",
                        ACT_ECO_PLACA: data && data.licensePlate || "",
                        ACT_ECO_TEL_EMP: data && data.phoneCompany || "",
                        ACT_ECO_EXT_EMP: data && data.extensionCompany || "",
                        ACT_ECO_DESC_ACT: "", //? PENDIENTE
                        ACT_ECO_TIP_VEH: data && data.vehicleType || "",
                        ACT_ECO_DPTO_EMP: (data && data.companyLocalization) && data.companyLocalization.idDepartamento || "",
                        ACT_ECO_CARG: data && data.actualCharge || "",

                        ACT_ECO_NOM_PROVEE: data && data.provider || "",
                        ACT_ECO_TEL_PROVEE: data && data.phoneProvider || "",
                        ACT_ECO_EXT_PTOVEE: data && data.extensionProvider || "",
                        ACT_ECO_CIU_PROVEE: local.formatLocaliz(data && data.providerLocalization || null),

                        ACT_ECO_ARRENDA: data && data.lessee || "",
                        ACT_ECO_CIU_ARRENDA: local.formatLocaliz(data && data.lesseeLocalization || null),
                        ACT_ECO_DIR_INMUE: data && data.realEstateManagement || "",
                        ACT_ECO_TEL_ARRENDA: data && data.phoneLessee || "",
                        ACT_ECO_EXT_ARRENDA: data && data.extensionLessee || "",
                        ACT_ECO_VLR_COMER: data && data.commercialValue || "",

                        ACT_ECO_ARRENDA2: data && data.lessee2 || "",
                        ACT_ECO_CIU_ARRENDA2: local.formatLocaliz(data && data.lesseeLocalization2 || null),
                        ACT_ECO_DIR_INMUE2: data && data.realEstateManagement2 || "",
                        ACT_ECO_TEL_ARRENDA2: data && data.phoneLessee2 || "",
                        ACT_ECO_EXT_ARRENDA2: data && data.extensionLessee2 || "",
                        ACT_ECO_VLR_COMER2: data && data.commercialValue2 || "",

                        ACT_ECO_ARRENDA3: data && data.lessee3 || "",
                        ACT_ECO_CIU_ARRENDA3: local.formatLocaliz(data && data.lesseeLocalization3 || null),
                        ACT_ECO_DIR_INMUE3: data && data.realEstateManagement3 || "",
                        ACT_ECO_TEL_ARRENDA3: data && data.phoneLessee3 || "",
                        ACT_ECO_EXT_ARRENDA3: data && data.extensionLessee3 || "",
                        ACT_ECO_VLR_COMER3: data && data.commercialValue3 || "",
                    }
                },
                references: function () {
                    var data = memory.storage.get("form_references");

                    return {
                        nombre: "Referencia",
                        idFormulario: 5,
                        idSolicitud: idRequisition,

                        REF_PAR_FAM: data && data.kinship || "",
                        REF_NOM_FAM: data && data.nameReference || "",
                        REF_TEL_FAM: data && data.phone || "",
                        REF_CIU_FAM: local.formatLocaliz(data && data.residenceLocalization || null),
                        REF_BARRIO_FAM: "", //? PENDIENTE **
                        REF_CEL_FAM: data && data.cellphone || "" 
                    }
                },
                basicDataAdic: function () {
                    var data = memory.storage.get("form_basic_data_additional");

                    return {
                        nombre: "Datos Básicos Adicionales",
                        idSolicitud: idRequisition,
                        idFormulario: 6,

                        DATO_ADI_DIR_RESI_ADI: "", //? PENDIENTE **
                        DATO_BAS_TEL_FIJ: data && data.residencePhone || "",
                        EXC_GMF: data && data.exemptGMFAccount || "",
                        COND_MET_CORR: data && data.sendingCorresp || "",
                        DATO_ADI_NOM_EPS: data && data.eps.nombre || "",
                        DATO_BAS_DIR_RESI: data && data.address || "",
                        DATO_BAS_BARRIO: data && data.district || "",
                        COND_MET_DIA_PAG: data && data.payday || "",
                        ACT_ECO_CUE_NOM: data && data.payrollAccount || ""
                    }
                },
                normativeData: function () {
                    var data = memory.storage.get("form_normative_data");

                    return {
                        nombre: "Datos para extranjeros y normativos",
                        idSolicitud: idRequisition,
                        idFormulario: 8,

                        DAT_EXTRANJ_TIN: data && data.numberTIN || "",
                        ACT_ECO_ESPACIO_BLANCO: "", //? PENDIENTE
                        DAT_NORM_FECH_INI_PRE_DOS: local.formatDate(data && data.startDatePEP || null),
                        DATO_BAS_NACION2: data && data.otherNationality || "",
                        PREGUNTA: data && data.isOtherNationality || "",
                        PREGUNTA2: data && data.isPoliticPerson || "",
                        DAT_EXT_NOR_RES_FIS: data && data.isTaxResidenceOtherCountry || "",
                        DAT_NORM_FECH_FIN_PRE_DOS: local.formatDate(data && data.endDatePEP || null),
                        DAT_EXT_NOR_PAI: data && data.otherCountry || "",

                        DAT_EXT_ACT_PEP: "", //? PENDIENTE **
                        DAT_EXT_ACT_PEP_RELA: "", //? PENDIENTE **
                        DAT_EXT_CARGO: data && data.relActualCharge || "",
                        DAT_EXT_TIPO_RELA: data && data.relTypes || "",
                        DAT_NORM_FECH_FIN_PRE_SIETE: local.formatDate(data && data.relEndDatePEP || null),
                        DAT_NORM_FECH_INI_PRE_SIETE: local.formatDate(data && data.relStartDatePEP || null),
                        PREGUNTA7: "No" //? PENDIENTE
                    }
                },
                addCard: function () {
                    var data = memory.storage.get("form_additional_card");
                    return {
                        nombre: "Solicitud tarjeta adicional",
                        idFormulario: 9,
                        idSolicitud: idRequisition,

                        SOL_TC_ADIC_PRI_APE: data && data.additionalSurname1 || "",
                        SOL_TC_ADIC_TIP_DOC: data && data.additionalDocumentType || "",
                        SOL_TC_ADIC_FECH_NACI: local.formatDate(data && data.additionalBirthDate || null),
                        SOL_TC_ADIC_GENERO: data && data.additionalGender || "",
                        SOL_TC_ADIC_SEG_NOM: data && data.additionalName2 || "",
                        SOL_TC_ADIC_FECH_EXP: local.formatDate(data && data.additionalDocumentExpDate || null),
                        SOL_TC_ADIC_SEG_APE: data && data.additionalSurname2 || "",
                        SOL_TC_ADIC_DIR_RES: data && data.additionalResidenceAddress || "",
                        SOL_TC_ADIC_TEL: data && data.additionalCellphone || "",
                        PREGUNTA13: data && data.isAdditionalCard || "",
                        SOL_TC_ADIC_PAREN_PRIN: data && data.kinshipPrincipal || "",
                        SOL_TC_ADIC_NUM_ID_CLIE: data && data.additionalDocumentId || "",
                        SOL_TAR_ADI_PRE: data && data.isAdditionalPresent || "",
                        SOL_TC_ADIC_PRI_NOM_CLI: data && data.additionalName1 || "",
                    }
                },
                foreignCurr: function () {
                    var data = memory.storage.get("form_foreign_currency");

                    return {
                        nombre: "Transacción en moneda extranjera",
                        idFormulario: 7,
                        idSolicitud: idRequisition,

                        TME_MONEDA: data && data.currency || "",
                        TME_BANC: data && data.bank || "",
                        TME_CIU: data && data.city || "",
                        PREGUNTA4: data && data.foreignCurrencyTransact || "",
                        TME_PAIS: data && data.country || "",
                        TME_TIP_MON_EXT: data && data.operationType || "",
                        PREGUNTA5: data && data.hasAccountForeignCurrency || "",
                        TME_MONT_PROM: data && data.averageAmount || "",
                        TME_CUENT: data && data.account || "",
                        PREGUNTA6: data && data.accountCurrencyType || "",
                    }
                },
                documents: function () {
                    return {
                        idSolicitud: idRequisition,
                        nombre: "Anexar documentos",

                        CONT_ARR: "true", //? PENDIENTE
                        CAR_SER_MEDICO: "", //? PENDIENTE **
                        CAM_COM: "", //? PENDIENTE
                        PREGUNTA14: "Si", //? PENDIENTE
                        EXT_BAN: "", //? PENDIENTE
                        idFormulario: 10, //? PENDIENTE
                        DECL_RENTA: "", //? PENDIENTE **
                        DES_PEN: "", //? PENDIENTE
                        AFI_EMP_TRANS: "", //? PENDIENTE
                        DES_PAG: "", //? PENDIENTE
                        TAR_PRO_VEH: "", //? PENDIENTE
                        TIT_VAL: "true", //? PENDIENTE
                        CED_MILITAR: "", //? PENDIENTE **
                        CER_TRA_LIB: "true", //? PENDIENTE
                        CON_SER: "", //? PENDIENTE
                        ANEX_DOC_FAILED_STEPS: "" //? PENDIENTE
                    }
                }
            },
            dataClient: function (state) {
                var d = $rootScope.userData;
                var c = (state == "C") ? memory.storage.get("form_cancel_requisition") : "";

                return {
                    idSolicitud: idRequisition || "0",
                    idCancelacion: c && c.id || "",
                    //usuario: "ext_jaguilarc",
                    //canal: "Web",
                    //terminal: "Web",
                    /*--------------------------------*/
                    estado: state,
                    descripcionCancelacion: c && c.reason ? c.reason + "|" + c.description : "",
                    idOficina: d && d.store || "",
                    idAsesor: d && d.userId || "",
                    ipOrigen: d && d.ip || "",
                    uuid: "Admisiones Web",
                    fechaSolicitud: new Date(),
                }
            }
        };
        return {

            create: function (state) {
                idRequisition = $rootScope.storage.get("form_id_solicitud") || 0;
                if (idRequisition == 0) {
                    var id = toolsget.getRandomKey();

                    $rootScope.storage.set("form_id_solicitud", id);
                    idRequisition = id;
                }

                var data = {
                    Cliente: local.dataClient(state),
                    Productos: local.dataProducts(),
                    Formularios: [
                      local.dataForm.basicData(),
                      local.dataForm.basicData2(),
                      local.dataForm.econoActivity(),
                      local.dataForm.references(),
                      local.dataForm.basicDataAdic(),
                      local.dataForm.foreignCurr(),
                      local.dataForm.normativeData(),
                      local.dataForm.addCard(),
                      local.dataForm.documents(),
                    ],
                    ServiciosIntegracion: []
                };

                return data;
            }
        }
    }]);