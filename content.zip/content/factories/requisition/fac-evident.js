﻿app.factory('evidentSource', ['reqProductResources', '$log',
    function (reqProductResources, $log) {

        var asks = {};
        var validation = {};

        var interfaz = {
            getAsks: function (data_) {
                return reqProductResources.evidentGetAsks.post(data_).$promise.then(function (data_) {
                        if (data_.state) {
                            asks.status = true;
                            asks.data = data_.info;
                        } else {
                            asks.status = false;
                            asks.data = data_.message;

                            $log.error(data_.message);
                        }                        

                        return asks;
                    });
            },
            validationAsks: function (data_) {
                return reqProductResources.evidentValidationAsks.post(data_).$promise.then(function (data_) {
                        if (data_.state) {
                            validation.status = true;
                            validation.data = data_.info;
                        } else {
                            validation.status = false;
                            validation.data = data_.message;

                            $log.error(data_.message);
                        }
                   
                        return validation;
                    });
            }
        }

        return interfaz;
    }]);