﻿app.factory('reqInsertSource', ['reqInsertResources', '$log',
    function (reqInsertResources, $log) {
        //var requisition = {};
        //var requisitionXml = {};
        var requisitionJson = {};
        var fingerCentralRisk = {};
        var fingerVal = {};
        var fingerImage = {};
        var docScanVal = {};

        var interfaz = {
            insertRequisitionJson: function(data){
                return reqInsertResources.insertRequisitionJson.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        requisitionJson.status = true;
                        requisitionJson.data = data_.info;
                    } else {
                        requisitionJson.status = false;
                        requisitionJson.data = data_.message;

                        $log.error(data_.message);
                    }

                    return requisitionJson;
                });
            },
            fingerCentralRiskAuth: function (data) {
                return reqInsertResources.fingerCentralRiskAuth.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        fingerCentralRisk.status = true;
                        fingerCentralRisk.data = data_.info;
                    } else {
                        fingerCentralRisk.status = false;
                        fingerCentralRisk.data = data_.message;

                        $log.error(data_.message);
                    }

                    return fingerCentralRisk;
                });
            },

            fingerValidate: function (data) {
                return reqInsertResources.fingerValidate.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        fingerVal.status = true;
                        fingerVal.data = data_.info;
                    } else {
                        fingerVal.status = false;
                        fingerVal.data = data_.message;

                        $log.error(data_.message);
                    }

                    return fingerVal;
                });
            },

            fingerGetImage: function (data) {
                return reqInsertResources.fingerGetImage.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        fingerImage.status = true;
                        fingerImage.data = data_.info;

                    } else {
                        fingerImage.status = false;
                        fingerImage.data = data_.message;

                        $log.error(data_.message);
                    }

                    return fingerImage;
                });
            },

            docScanValidate: function (data) {
                return reqInsertResources.docScanValidate.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        docScanVal.status = true;
                        docScanVal.data = data_.info;
                    } else {
                        docScanVal.status = false;
                        docScanVal.data = data_.message;

                        $log.error(data_.message);
                    }

                    return docScanVal;
                });
            }

            //insertRequisition: function (data) {
            //    return reqInsertResources.insertRequisition.post(data).$promise.then(function (data_) {
            //        if (data_.state) {
            //            requisition.status = true;
            //            requisition.data = data_.info;
            //        } else {
            //            requisition.status = false;
            //            requisition.data = data_.message;

            //            $log.error(data_.message);
            //        }

            //        return requisition;
            //    });
            //},
            //insertRequisitionXml: function (data) {
            //    return reqInsertResources.insertRequisitionXml.post(data).$promise.then(function (data_) {
            //        if (data_.state) {
            //            requisitionXml.status = true;
            //            requisitionXml.data = data_.info;
            //        } else {
            //            requisitionXml.status = false;
            //            requisitionXml.data = data_.message;

            //            $log.error(data_.message);
            //        }

            //        return requisitionXml;
            //    });
            //},
        }

        //var spouse = {};
        //var activityEconomic = {};
        //var additional = {};
        //var product = {};
        //var requisition = {};
        //var client = {};
        //var financial = {};
        //var address = {};
        //var email = {};
        //var flags = {};
        //var peps = {};
        //var increase = {};
        //var calculate = {};
        //var reconsider = {};
        //var interfaz = {
        //    insertSpouse: function (data) {
        //        return reqInsertResources.insertSpouse.post(data).$promise.then(function (data_) {
        //                if (data_.state) {
        //                    spouse.status = true;
        //                    spouse.data = data_.info;
        //                } else {
        //                    spouse.status = false;
        //                    spouse.data = data_.message;
        //                    $log.error(data_.message);
        //                }
        //                return spouse;
        //            });
        //    },
        //    insertActivityEconomic: function (data) {
        //        return reqInsertResources.insertActivityEconomic.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                activityEconomic.status = true;
        //                activityEconomic.data = data_.info;
        //            } else {
        //                activityEconomic.status = false;
        //                activityEconomic.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return activityEconomic;
        //        });
        //    },
        //    insertAdditional: function (data) {
        //        return reqInsertResources.insertAdditional.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                additional.status = true;
        //                additional.data = data_.info;
        //            } else {
        //                additional.status = false;
        //                additional.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return additional;
        //        });
        //    },
        //    insertProduct: function (data) {
        //        return reqInsertResources.insertProduct.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                product.status = true;
        //                product.data = data_.info;
        //            } else {
        //                product.status = false;
        //                product.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return product;
        //        });
        //    },
        //    insertRequisition: function (data) {
        //        return reqInsertResources.insertRequisition.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                requisition.status = true;
        //                requisition.data = data_.info;
        //            } else {
        //                requisition.status = false;
        //                requisition.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return requisition;
        //        });
        //    },
        //    insertClient: function (data) {
        //        return reqInsertResources.insertClient.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                client.status = true;
        //                client.data = data_.info;
        //            } else {
        //                client.status = false;
        //                client.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return client;
        //        });
        //    },
        //    insertFinancial: function (data) {
        //        return reqInsertResources.insertFinancial.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                financial.status = true;
        //                financial.data = data_.info;
        //            } else {
        //                financial.status = false;
        //                financial.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return financial;
        //        });
        //    },
        //    insertAddress: function (data) {
        //        return reqInsertResources.insertAddress.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                address.status = true;
        //                address.data = data_.info;
        //            } else {
        //                address.status = false;
        //                address.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return address;
        //        });
        //    },
        //    insertEmail: function (data) {
        //        return reqInsertResources.insertEmail.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                email.status = true;
        //                email.data = data_.info;
        //            } else {
        //                email.status = false;
        //                email.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return email;
        //        });
        //    },
        //    insertFlags: function (data) {
        //        return reqInsertResources.insertFlags.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                flags.status = true;
        //                flags.data = data_.info;
        //            } else {
        //                flags.status = false;
        //                flags.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return flags;
        //        });
        //    },
        //    insertPeps: function (data) {
        //        return reqInsertResources.insertPeps.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                peps.status = true;
        //                peps.data = data_.info;
        //            } else {
        //                peps.status = false;
        //                peps.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return peps;
        //        });
        //    },
        //    insertIncrease: function (data) {
        //        return reqInsertResources.insertIncrease.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                increase.status = true;
        //                increase.data = data_.info;
        //            } else {
        //                increase.status = false;
        //                increase.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return increase;
        //        });
        //    },
        //    insertCalculate: function (data) {
        //        return reqInsertResources.insertCalculate.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                calculate.status = true;
        //                calculate.data = data_.info;
        //            } else {
        //                calculate.status = false;
        //                calculate.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return calculate;
        //        });
        //    },
        //    insertReconsider: function (data) {
        //        return reqInsertResources.insertReconsider.post(data).$promise.then(function (data_) {
        //            if (data_.state) {
        //                reconsider.status = true;
        //                reconsider.data = data_.info;
        //            } else {
        //                reconsider.status = false;
        //                reconsider.data = data_.message;
        //                $log.error(data_.message);
        //            }
        //            return reconsider;
        //        });
        //    },
        //}

        return interfaz;
    }]);