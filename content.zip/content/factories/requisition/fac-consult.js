﻿app.factory('reqConsultSource', ['reqConsultResources', '$log',
    function (reqConsultResources, $log) {

        var requisitionsResponse = {};
        var requisitionStatusResponse = {};
        var requisitionDetailResponse = {};

        var interfaz = {
            getRequisitions: function (data) {
                return reqConsultResources.getRequisitions.post(data).$promise.then(function (data_) {
                        if (data_.state) {
                            requisitionsResponse.status = true;
                            requisitionsResponse.data = data_.info;
                        } else {
                            requisitionsResponse.status = false;
                            requisitionsResponse.data = data_.message;
                            $log.error(data_.message);
                        }
                        return requisitionsResponse;
                    });
            },

            getRequisitionStatus: function () {
                return reqConsultResources.getRequisitionStatus.get().$promise.then(function (data_) {
                    if (data_.state) {
                        requisitionStatusResponse.status = true;
                        requisitionStatusResponse.data = data_.info;
                    } else {
                        requisitionStatusResponse.status = false;
                        requisitionStatusResponse.data = data_.message;
                        $log.error(data_.message);
                    }
                    return requisitionStatusResponse;
                });
            },

            getRequisitionDetail: function (id_admision_) {
                return reqConsultResources.getRequisitionDetail.get({ id_admision: id_admision_ }).$promise.then(function (data_) {
                    if (data_.state) {
                        requisitionDetailResponse.status = true;
                        requisitionDetailResponse.data = data_.info;
                    } else {
                        requisitionDetailResponse.status = false;
                        requisitionDetailResponse.data = data_.message;
                        $log.error(data_.message);
                    }
                    return requisitionDetailResponse;
                });
            }

        }
        return interfaz;
    }])