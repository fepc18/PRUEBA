﻿app.factory('toolsForm', ['toolsResources', '$log', '$filter',
    function (toolsResources, $log, $filter) {

        var geoAddress = {};

        var local = {
            diffYears: function (years) {
                var date = new Date();
                var nyear = date.getFullYear() - parseInt(years);
                var nmonth = date.getMonth() + 1;
                var ndate = new Date(nyear + "-" + nmonth + "-" + date.getDate());

                return ndate;
            }
        }

        var interfaz = {
            getGeolocalizationAddress: function (address_, cityCode_) {
                return toolsResources.getGeolocalizationAddress.get(
                    {
                        address: address_,
                        cityCode: cityCode_

                    }).$promise.then(function (data_) {
                        if (data_.state) {
                            geoAddress.status = true;
                            geoAddress.data = data_.info;

                        } else {
                            geoAddress.status = false;
                            geoAddress.data = data_.message;

                            $log.error(data_.message);
                        }                        

                        return geoAddress;
                    });
            },
            nestedControlDate: {
                addYears: function (years, dateString) {
                    var date = dateString ? new Date(dateString) : new Date();
                    var nyear = date.getFullYear() + parseInt(years);
                    var nmonth = date.getMonth() + 1;
                    var ndate = new Date(nyear + "-" + nmonth + "-" + date.getDate())

                    return ndate;
                },
                dateOptionsBirth: function (age) {
                    return {
                        formatYear: 'yyyy',
                        maxDate: local.diffYears(age),
                        initDate: local.diffYears(age),
                        minDate: new Date(1900, 1, 1),
                        startingDay: 1
                    };
                },
                dateOptionsExped: function () {
                    return {
                        formatYear: 'yyyy',
                        maxDate: new Date(),
                        initDate: new Date(),
                        minDate: new Date(),
                        startingDay: 1
                    };
                }
            },
            getAgeFromProductSelected: function (p) {
                var max = undefined;
                p = angular.fromJson(p);

                for (var i = 0 ; i < p.length ; i++) {
                    if (!max || parseInt(p[i]["edadMinima"]) > parseInt(max["edadMinima"]))
                        max = p[i];
                }

                return max;
            },
            triggerValidateField: function (form, field, property) {
                form[field].$touched = true;
                form[field].$setValidity(property, false);
                form[field].$validate();
            },
            getMaxDateFromProductSelected: function (pCheckeds) {
                var p = pCheckeds;

                if (p.length > 0) {
                    var max = interfaz.getAgeFromProductSelected(p);
                    var date = new Date();
                    var newDate = new Date(date.setYear(date.getFullYear() - parseInt(max.edadMinima)));

                    return newDate;
                } else {
                    return new Date();
                }
            },
            getAge: function (dateString) {
                var today = new Date();
                var birthDate = new Date(dateString);
                var age = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();

                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                return age;
            },
            validateAge: {
                Min: function (Age, date) {
                    var d = interfaz.getAge(date);

                    return d < Age ? true : false;
                },
                Max: function (Age, date) {
                    var d = interfaz.getAge(date);

                    return d >= Age ? true : false;
                }
            },
            dateOptions: {
                maxDate: new Date(),
                formatYear: 'yyyy',
                minDate: new Date(1900, 1, 1),
                startingDay: 1
            },
            getAge: function (dateString) {
                var today = new Date();
                var birthDate = new Date(dateString);
                var age = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();

                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                return age;
            },
            validateAge: {
                Min: function (Age, date) {
                    var d = interfaz.getAge(date);

                    return d < Age ? true : false;
                },
                Max: function (Age, date) {
                    var d = interfaz.getAge(date);

                    return d >= Age ? true : false;
                }
            },
            localization: {
                getAll: function (data, country) {
                    var loc = data;
                    var res = [];

                    loc = $filter("filter")(loc, { pais: country });
                    return loc;
                },
                getCountries: function (data) {
                    var loc = data;
                    var coun = [];

                    angular.forEach(loc, function (item, index) {
                        var contains = $filter("filter")(coun, { id: item.idPais });

                        if (contains.length == 0) {
                            var d = {
                                id: item.idPais,
                                pais: item.pais
                            }
                            coun.push(d);
                        }
                    })

                    return coun;
                }
            },
            localGender: function () {
                var g = [
                    { id: "Masculino", description: "Masculino" },
                    { id: "Femenino", description: "Femenino" }
                ];

                return g;
            },
            localEmailDomains: function () {
                var d = [
                    { id: '1', description: 'HOTMAIL.COM' },
                    { id: '2', description: 'GMAIL.COM' },
                    { id: '3', description: 'YAHOO.COM' },
                    { id: '4', description: 'YAHOO.ES' },
                    { id: '5', description: 'HOTMAIL.ES' },
                    { id: '6', description: 'CORREO.COM' },
                    { id: '7', description: 'UNE.NET.CO' },
                    { id: '8', description: 'LIVE.COM' },
                    { id: '9', description: 'OUTLOOK.COM' },
                    { id: '10', description: 'CORREO.POLICIA.GOV.CO' },
                    { id: '11', description: 'MSN.COM' },
                    { id: '12', description: 'FALABELLA.COM' },
                    { id: '13', description: 'YAHOO.COM.CO' },
                    { id: '14', description: 'YAHOO.COM.MX' },
                    { id: '15', description: 'MISENA.EDU.CO' },
                    { id: '16', description: 'ETB.NET.CO' },
                    { id: '17', description: 'FALABELLA.COM.CO' },
                    { id: '18', description: 'YAHOO.COM.AR' },
                    { id: '19', description: 'UNAL.EDU.CO' },
                    { id: '20', description: 'LATINMAIL.COM' },
                    { id: '21', description: 'CABLE.NET.CO' },
                    { id: '22', description: 'HOTMAIL.COM.CO' },
                    { id: '23', description: 'OUTLOOK.ES' },
                    { id: '24', description: 'ECOPETROL.COM.CO' },
                    { id: '25', description: 'DIAN.GOV.CO' },
                    { id: '26', description: 'TIENE.COM' },
                    { id: '27', description: 'COLOMBIA.COM' },
                    { id: '28', description: 'EPM.COM.CO' },
                    { id: '29', description: 'ME.COM' },
                    { id: '30', description: 'UNE.NET.COM' },
                    { id: '31', description: 'AOL.COM' },
                    { id: '32', description: 'TELMEX.NET.CO' },
                    { id: '33', description: 'BANCOLOMBIA.COM.CO' },
                    { id: '34', description: 'ICBF.GOV.CO' },
                    { id: '35', description: 'JAVERIANA.EDU.CO' },
                    { id: '36', description: 'COOMEVA.COM.CO' },
                    { id: '37', description: 'LIVE.COM.AR' },
                    { id: '38', description: 'ICLOUD.COM' },
                    { id: '39', description: 'INGENIEROS.COM' },
                    { id: '40', description: 'SENA.EDU.CO' },
                    { id: '41', description: 'MEDELLIN.GOV.CO' },
                    { id: '42', description: 'TELECOM.COM.CO' },
                    { id: '43', description: 'TERRA.COM.CO' },
                    { id: '44', description: 'UNE.COM.CO' },
                    { id: '45', description: 'SURA.COM.CO' },
                    { id: '46', description: 'TERRA.COM' },
                    { id: '47', description: 'UTP.EDU.CO' },
                    { id: '48', description: 'UNIANDES.EDU.CO' },
                    { id: '49', description: 'BBVA.COM' },
                    { id: '50', description: 'TELEFONICA.COM' },
                    { id: '51', description: 'ETB.COM.CO' },
                    { id: '52', description: 'HOTMAIL.COM.AR' },
                    { id: '53', description: 'TUTOPIA.COM' },
                    { id: '54', description: 'EMCALI.COM.CO' },
                    { id: '55', description: 'DAVIVIENDA.COM' },
                    { id: '56', description: 'EAFIT.EDU.CO' },
                    { id: '57', description: 'ARGOS.COM.CO' },
                    { id: '58', description: 'EMCALI.NET.CO' },
                    { id: '59', description: 'CLARO.COM.CO' },
                    { id: '60', description: 'COLSANITAS.COM' },
                    { id: '61', description: 'MAIL.COM' },
                    { id: '62', description: 'BANREP.GOV.CO' },
                    { id: '63', description: 'CORONA.COM.CO' },
                    { id: '64', description: 'CARVAJAL.COM' },
                    { id: '65', description: 'COLPATRIA.COM' },
                    { id: '66', description: 'EPM.NET.CO' },
                    { id: '67', description: 'AEROCIVIL.GOV.CO' },
                    { id: '68', description: 'LIVE.COM.MX' },
                    { id: '69', description: 'TELESAT.COM.CO' },
                    { id: '70', description: 'BANCODEBOGOTA.COM.CO' },
                    { id: '71', description: 'SEGUROSBOLIVAR.COM' },
                    { id: '72', description: 'BANCOFALABELLA.COM.CO' },
                    { id: '73', description: 'STARMEDIA.COM' },
                    { id: '74', description: 'BANCOAVVILLAS.COM.CO' },
                    { id: '75', description: 'ETB.NET.COM' },
                    { id: '76', description: 'DINISSAN.COM.CO' },
                    { id: '77', description: 'BANCOFALABELLA.COM' },
                    { id: '78', description: 'EJERCITO.MIL.CO' },
                    { id: '79', description: 'HOMECENTER.COM.CO' },
                    { id: '80', description: 'TELMEX.COM' },
                    { id: '81', description: 'ASESORSURA.COM' },
                    { id: '82', description: 'ISA.COM.CO' },
                    { id: '83', description: 'UCALDAS.EDU.CO' },
                    { id: '84', description: 'HOTMAIL.IT' },
                    { id: '85', description: 'CUNDINAMARCA.GOV.CO' },
                    { id: '86', description: 'FAMILIA.COM.CO' },
                    { id: '87', description: 'UNIWEB.NET.CO' },
                    { id: '88', description: 'DANE.GOV.CO' },
                    { id: '89', description: 'ARMADA.MIL.CO' },
                    { id: '90', description: 'UPB.EDU.CO' },
                    { id: '91', description: 'POLICIA.GOV.CO' },
                    { id: '92', description: 'CASUR.GOV.CO' },
                    { id: '93', description: 'LIVE.COM.CO' },
                    { id: '94', description: 'CAFEDECOLOMBIA.COM.CO' },
                    { id: '95', description: 'UNIQUINDIO.EDU.CO' },
                    { id: '96', description: 'CORREOUNIVALLE.EDU.CO' },
                    { id: '97', description: 'ACCIONSOCIAL.GOV.CO' },
                    { id: '98', description: 'TELEFONICA.COM.CO' },
                    { id: '99', description: 'ALPINA.COM.CO' },
                    { id: '100', description: 'LEONISA.COM' },
                    { id: '101', description: 'GECOLSA.COM.CO' },
                    { id: '102', description: 'COMCEL.COM.CO' },
                    { id: '103', description: 'SIEMENS.COM' },
                    { id: '104', description: 'BANCOAGRARIO.GOV.CO' },
                    { id: '105', description: 'UCENTRAL.EDU.CO' },
                    { id: '106', description: 'BAV.SABMILLER.COM' },
                    { id: '107', description: 'SIN.MAIL.COM' },
                    { id: '108', description: 'UT.EDU.CO' },
                    { id: '109', description: 'BANCODEOCCIDENTE.COM.CO' },
                    { id: '110', description: 'UNAL.EDU.COM' },
                    { id: '111', description: 'ELECTRICARIBE.COM' },
                    { id: '112', description: 'ELTIEMPO.COM' },
                    { id: '113', description: 'YAHOO.FR' },
                    { id: '114', description: 'TECNOQUIMICAS.COM' },
                    { id: '115', description: 'CHEC.COM.CO' },
                    { id: '116', description: 'SLB.COM' },
                    { id: '117', description: 'ROCKETMAIL.COM' },
                    { id: '118', description: 'CABLENET.CO' },
                    { id: '119', description: 'DHL.COM' },
                    { id: '120', description: 'CABLE.NET.COM' },
                    { id: '121', description: 'REGISTRADURIA.GOV.CO' },
                    { id: '122', description: 'CAFAM.COM.CO' },
                    { id: '123', description: 'UNISABANA.EDU.CO' },
                    { id: '124', description: 'COLOMBINA.COM' },
                    { id: '125', description: 'PRESIDENCIA.GOV.CO' },
                    { id: '126', description: 'FISCALIA.GOV.CO' },
                    { id: '127', description: 'AVIANCA.COM' },
                    { id: '128', description: 'UNIMILITAR.EDU.CO' },
                    { id: '129', description: 'EPSA.COM.CO' },
                    { id: '130', description: 'UNICAUCA.EDU.CO' },
                    { id: '131', description: 'POSTOBON.COM.CO' },
                    { id: '132', description: 'SERVIENTREGA.COM' },
                    { id: '133', description: 'PACIFICRUBIALES.COM.CO' },
                    { id: '134', description: 'KCC.COM' },
                    { id: '135', description: 'UNIVALLE.EDU.CO' },
                    { id: '136', description: 'JAVERIANACALI.EDU.CO' },
                    { id: '137', description: 'KOF.COM.MX' },
                    { id: '138', description: 'PROTECCION.COM.CO' },
                    { id: '139', description: 'UCATOLICA.EDU.CO' },
                    { id: '140', description: 'COMFAMA.COM.CO' },
                    { id: '141', description: 'UNISALLE.EDU.CO' },
                    { id: '142', description: 'CARACOL.COM.CO' },
                    { id: '143', description: 'UDEA.EDU.CO' },
                    { id: '144', description: 'COLSEGUROS.COM' },
                    { id: '145', description: 'MIUNE.NET' },
                    { id: '146', description: 'CONCONCRETO.COM' },
                    { id: '147', description: 'OVI.COM' },
                    { id: '148', description: 'COLPAL.COM' },
                    { id: '149', description: 'ICA.GOV.CO' },
                    { id: '150', description: 'VALLEDELCAUCA.GOV.CO' },
                    { id: '151', description: 'EPM.COM' },
                    { id: '152', description: 'ACUEDUCTO.COM.CO' },
                    { id: '153', description: 'UNE.NET' },
                    { id: '154', description: 'YAHOO.IT' },
                    { id: '155', description: 'COOMEVA.COM' },
                    { id: '156', description: 'GRUPOHELM.COM' },
                    { id: '157', description: 'UTADEO.EDU.CO' },
                    { id: '158', description: 'ELPOLI.EDU.CO' },
                    { id: '159', description: 'COMPENSAR.COM' },
                    { id: '160', description: 'EDATEL.COM.CO' },
                    { id: '161', description: 'INPEC.GOV.CO' },
                    { id: '162', description: 'ALFA.COM.CO' },
                    { id: '163', description: 'ALQUERIA.COM.CO' },
                    { id: '164', description: 'MAC.COM' },
                    { id: '165', description: 'UNINORTE.EDU.CO' },
                    { id: '166', description: 'TERPEL.COM' },
                    { id: '167', description: 'UROSARIO.EDU.CO' },
                    { id: '168', description: 'GASNATURAL.COM' },
                    { id: '169', description: 'YAHOO.AR' },
                    { id: '170', description: 'MAPFRE.COM.CO' },
                    { id: '171', description: 'ELTIEMPO.COM.CO' },
                    { id: '172', description: 'HALLIBURTON.COM' },
                    { id: '173', description: 'INVIAS.GOV.CO' },
                    { id: '174', description: 'UNE.COM' },
                    { id: '175', description: 'GNBSUDAMERIS.COM.CO' },
                    { id: '176', description: 'REDP.EDU.CO' },
                    { id: '177', description: 'AUDIFARMA.COM.CO' },
                    { id: '178', description: 'PATPRIMO.COM.CO' },
                    { id: '179', description: 'YAHOO.MX' },
                    { id: '180', description: 'BAXTER.COM' },
                    { id: '181', description: 'CABLENET.COM' },
                    { id: '182', description: 'INCAUCA.COM' },
                    { id: '183', description: 'UAN.EDU.CO' },
                    { id: '184', description: 'PUBLICAR.COM' },
                    { id: '185', description: 'BANCOPOPULAR.COM.CO' },
                    { id: '186', description: 'LIBERTYCOLOMBIA.COM' },
                    { id: '187', description: 'COLANTA.COM.CO' },
                    { id: '188', description: 'MANUELITA.COM' },
                    { id: '189', description: 'SHD.GOV.CO' },
                    { id: '190', description: 'UNILEVER.COM' },
                    { id: '191', description: 'ARQUITECTO.COM' },
                    { id: '192', description: 'IMBANACO.COM.CO' },
                    { id: '193', description: 'CODENSA.COM.CO' },
                    { id: '194', description: 'ELCOLOMBIANO.COM.CO' },
                    { id: '195', description: 'FANALCA.COM.CO' },
                    { id: '196', description: 'HISPAVISTA.COM' },
                    { id: '197', description: 'SUPERFINANCIERA.GOV.CO' },
                    { id: '198', description: 'AVIATUR.COM.CO' },
                    { id: '199', description: 'CERREJONCOAL.COM' },
                    { id: '200', description: 'GRUPO-EXITO.COM' },
                    { id: '201', description: 'ALMAVIVA.COM.CO' },
                    { id: '202', description: 'CARREFOUR.COM' },
                    { id: '203', description: 'DELOITTE.COM' },
                    { id: '204', description: 'TCC.COM.CO' }
                ];

                return d;
            },
            formTouched: function (form) {
                angular.forEach(form.$error, function (field) {
                    angular.forEach(field, function (errorField) {
                        errorField.$setTouched();
                    });
                });
            },
            clearCssError: function (form, htmlField) {
                var el = form[htmlField];
                var ngel = angular.element(el);
                var item = ngel[0].$$element[0].parentNode;

                item.className = "form-group form-group-sm";              
            },
            addCssError: function (form, htmlField) {
                var el = form[htmlField];
                var ngel = angular.element(el);
                var item = ngel[0].$$element[0].parentNode;

                item.className = "form-group form-group-sm has-error";
            }
        }

        return interfaz;
    }]);



