﻿app.factory('profilingSource', ['reqProductResources', '$log',
    function (reqProductResources, $log) {

        var customerProfile = {};
        var prevRequest = {};

        var interfaz = {
            getCustomerProfile: function (data_) {
                return reqProductResources.customerProfiling.post(data_).$promise.then(function (data_) {
                       if (data_.state) {
                           customerProfile.status = true;
                           customerProfile.data = data_.info;
                       } else {
                           customerProfile.status = false;
                           customerProfile.data = data_.message;

                           $log.error(data_.message);
                       }

                       return customerProfile;
                   });
            },
            getHistoryRequest: function (data_) {
                return reqProductResources.prevRequestProfiling.post(data_).$promise.then(function (data_) {
                        if (data_.state) {
                            prevRequest.status = true;
                            prevRequest.data = data_.info;
                        } else {
                            prevRequest.status = false;
                            prevRequest.data = data_.message;

                            $log.error(data_.message);
                        }

                        return prevRequest;
                    });
            }
        }

        return interfaz;
    }]);