﻿app.factory('infoBasicDataSource', ['reqProductResources', '$log',
    function (reqProductResources, $log) {

        var info = {};
      
        var interfaz = {
            getInfoBasic: function (data_) {
                return reqProductResources.getInfoBasic.post(data_).$promise.then(function (data_) {
                        if (data_.state) {
                            info.status = true;
                            info.data = data_.info;
                        } else {
                            info.status = false;
                            info.data = data_.message;

                            $log.error(data_.message);
                        }                        

                        return info;
                    });
            }
        }

        return interfaz;
    }]);