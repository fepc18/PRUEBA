﻿app.factory('configuration', ['navigation',
    function (navigation) {       
        var r = {
            stateVerify: {
                INCOMPLETE: {
                    id: 0,
                    text: ""
                },
                DISABLED: {
                    id: 1,
                    text: ""
                },
                PENDING_OFFICE: {
                    id: 2,
                    text: "PO"
                },
                PENDING_TRANSIT: {
                    id: 3,
                    text: "PT"
                },
                COMPLETE: {
                    id: 4,
                    text: "OK"
                },
                REJECTED: {
                    id: 5,
                    text: "X"
                },
            },
            verticalmenu: [
                {
                    id: 0,
                    name: "dashboard",
                    text: "Dashboard",
                    navigate: "/",
                    icon: "tachometer",                   
                    active: true,
                    breadcrumb: false,
                },
                {
                    id: 1,
                    name: "requisition",
                    text: "Solicitudes",
                    navigate: "",
                    icon: "pencil-square-o",                   
                    submenu: [
                        {
                            id: 1,
                            name: "product",
                            authorize: "product",
                            navigate: "/requisition/product",                                                      
                            text: "Digitar Solicitud",
                            parent: "Solicitudes",
                            icon: "pencil-square-o",
                            direct: true,
                            breadcrumb: true,                            
                        },
                        {
                            id: 2,
                            name: "demand",
                            authorize: "",
                            navigate: "",                                                        
                            text: "Solicitudes pendientes",
                            parent: "Solicitudes",
                            icon: "pencil-square-o",
                            breadcrumb: true,
                        },
                        {
                            id: 3,
                            name: "consult",
                            authorize: "consult",
                            navigate: "/requisition/consult",
                            text: "Consultar Solicitudes",
                            parent: "Solicitudes",
                            icon: "pencil-square-o",
                            breadcrumb: true,
                        },
                        {
                            id: 4,
                            name: "print",
                            authorize: "print",
                            navigate: "/requisition/print",
                            text: "Imprimir Solicitudes",
                            parent: "Solicitudes",
                            icon: "pencil-square-o",
                            breadcrumb: true,
                        }
                    ],
                    active: false,
                    breadcrumb: false,
                },
                {
                    id: 2,
                    name: "verification",
                    text: "Verificar Solicitud",
                    navigate: "/verification",
                    icon: "hand-paper-o",
                    submenu: [
                        {
                            id: 1,
                            name: "special-brands",
                            authorize: "special-brands",
                            navigate: "/verification/special-brands",
                            text: "Marcas Especiales",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            // section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        },
                        {
                            id: 2,
                            name: "biometrics",
                            authorize: "biometrics",
                            navigate: "/verification/biometrics",
                            text: "Biometria",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            //section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        },
                        {
                            id: 3,
                            name: "identity",
                            authorize: "identity",
                            navigate: "/verification/identity",
                            text: "Identidad",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            //section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        },
                        {
                            id: 4,
                            name: "customer",
                            authorize: "customer",
                            navigate: "/verification/customer",
                            text: "Cliente",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            //section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        },
                        {
                            id: 5,
                            name: "activity",
                            authorize: "activity",
                            navigate: "/verification/activity",
                            text: "Actividad",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            //section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        },
                        {
                            id: 6,
                            name: "income",
                            authorize: "income",
                            navigate: "/verification/income",
                            text: "Ingresos",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            //section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        },
                        {
                            id: 7,
                            name: "google-sarlaft",
                            authorize: "google-sarlaft",
                            navigate: "/verification/google-sarlaft",
                            text: "Google Sarlaft",
                            parent: "Verificar Solicitud",
                            icon: "pencil-square-o",
                            //section: true,
                            breadcrumb: true,
                            semaphoreStatus: 0,
                        }
                    ],
                    active: false,
                    breadcrumb: true,
                },
                {
                    id: 3,
                    name: "center-risk",
                    text: "Consultas Centrales",
                    navigate: "",
                    icon: "search-plus",                    
                    submenu: [
                        {
                            id: 1,
                            name: "shortframe",
                            authorize: "",
                            navigate: "/center-risk/shortframe",
                            text: "Trama Corta Datacredito",
                            parent: "Consultas Centrales",
                            icon: "search-plus",                            
                            direct: true,
                            breadcrumb: true,
                        },
                        {
                            id: 2,
                            name: "history",
                            authorize: "",
                            navigate: "/center-risk/history",
                            text: "Historia Datacredito",
                            parent: "Consultas Centrales",
                            icon: "search-plus",
                            breadcrumb: true,
                        },
                        {
                            id: 3,
                            name: "onDemand",
                            authorize: "",
                            navigate: "/center-risk/ondemand",
                            text: "Demanda Datacredito",
                            parent: "Consultas Centrales",
                            icon: "search-plus",
                            breadcrumb: true,
                        },
                        {
                            id: 4,
                            name: "oFac",
                            authorize: "",
                            navigate: "/center-risk/ofac",
                            text: "Consulta OFAC",
                            parent: "Consultas Centrales",
                            icon: "search-plus",
                            breadcrumb: true,
                        },
                        {
                            id: 5,
                            name: "evident",
                            authorize: "",
                            navigate: "/center-risk/evident",
                            text: "Consulta Evidente",
                            parent: "Consultas Centrales",
                            icon: "search-plus",
                            breadcrumb: true,
                        },
                        {
                            id: 6,
                            name: "recognize",
                            authorize: "",
                            navigate: "/center-risk/recognize",
                            text: "Consulta Reconocer",
                            parent: "Consultas Centrales",
                            icon: "search-plus",
                            breadcrumb: true,
                        }
                    ],
                    active: false,
                    breadcrumb: false,
                }
            ],            
            activeItemVmenu: function (nav, active) {
                var path = navigation.navigate.getPath();

                if (path != "/") {
                    path = navigation.navigate.getPath().split("/");

                    var current = nav != "" ? nav.replace("/", "") : "-";
                    var contain = false;

                    for (var i = 0; i < path.length; ++i) {
                        if (current == path[i]) {
                            contain = true;
                            break;
                        }
                    }

                    return contain;
                } else {

                    return active;
                }
            },
            //dashboarditems: [
            //    {
            //        id: 1,
            //        name: "product",
            //        authorize: "product",
            //        navigate: "/requisition/product",
            //        icon: "briefcase",
            //        bcolor: "yellow",
            //        text: "Productos",
            //        description: "Descripci&oacute;n del item"
            //    },
            //    {
            //        id: 2,
            //        name: "demand",
            //        authorize: "",
            //        navigate: "",
            //        icon: "pencil-square",
            //        bcolor: "red",
            //        text: "Solicitudes pendientes",
            //        description: "Descripci&oacute;n del item"
            //    },
            //    {
            //        id: 3,
            //        name: "other",
            //        authorize: "",
            //        navigate: "",
            //        icon: "cogs",
            //        bcolor: "terques",
            //        text: "Item pendiente",
            //        description: "Descripci&oacute;n del item"
            //    }
            //],
        }

        return r;
    }]);