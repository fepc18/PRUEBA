﻿app.factory('fileUpLoadSources', ['$log', 'tabVerificationResources',
    function (file, $log, tabVerificationResources) {
        debugger;
        var interfaz = {
            uploadFileToUrl: function (file) {
                var fd = new FormData();
                fd.append('file', file);             
            },
    }
        return interfaz;
    }]);


app.factory('Post', function ($resource) {
    return $resource('api/TabsVerification/FileUploadBaseInformation', {}, {
        create: {
            method: "POST",
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        }
    });
})

