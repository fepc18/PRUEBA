﻿app.factory("toolsget", ['$interval', '$filter',
    function ($interval, $filter) {
        var local = {
            timer: {
                hs: 0,
                ms: 0,
                ss: 0,
                format: function (data) {

                    return data ? (data.toString().length == 1 ? "0" + data : data) : "00";
                },
            },
            calculateStartCurrent: function (current) {
                var _s = parseInt(current.split(":")[2]);
                var _m = parseInt(current.split(":")[1]);
                var _h = parseInt(current.split(":")[0]);

                if (_s > 0) local.timer.ss = _s;
                if (_m > 0) local.timer.ms = _m;
                if (_h > 0) local.timer.hs = _h;
            }
        }
        var r = {
            getRandomKey: function () {
                var dat = new Date().getTime();
                var ran = Math.floor(Math.random() * (9999 - 1000)) + 1000;
                var id = dat + ran;

                return id;
            },
            toFormatDate: function (date, format) {
                format = format || "dd/MM/yyyy";

                if (date && date != "undefined" && date != "null") {
                    var fdate = $filter("date")(date, format);

                    return fdate;
                } else {
                    return "";
                }
            },
            pagination: {
                listPag: [5, 10, 15, 20],
                maxItemsDefault: "5",
                countMaxPage: function (lng, maxItems) {
                    maxItems = maxItems || r.pagination.maxItemsDefault;

                    var totalPages = (lng / maxItems);
                    var noFraction = parseInt(totalPages);

                    return (totalPages - noFraction == 0) ? noFraction : (noFraction + 1);
                }
            },
            timerVerify: {
                states: {
                    DISABLED: 1,
                    STOPPED: 2,
                    STARTED: 3,
                    FINALIZED: 4
                },
                state: 1,
                max: "00:02:00",
                current: "00:00:00",
                progress: {
                    totalSec: 0,
                    current: 0,
                    currentPer: 0,
                    moment: function () {
                        var t = r.timerVerify.progress.totalSec;
                        var curr = r.timerVerify.current.split(":");

                        curr = (parseInt(curr[0]) * 3600) + (parseInt(curr[1]) * 60) + (parseInt(curr[2]));

                        r.timerVerify.progress.current = curr;
                        r.timerVerify.progress.currentPer = curr * 100 / t;
                    },
                    total: function () {
                        var max = r.timerVerify.max.split(":");

                        max = (parseInt(max[0]) * 3600) + (parseInt(max[1]) * 60) + (parseInt(max[2]));

                        r.timerVerify.progress.totalSec = max;
                    }
                },
                start: function () {
                    //if (angular.isDefined(timer)) return;

                    timer = $interval(function () {
                        if (r.timerVerify.state == r.timerVerify.states.DISABLED || r.timerVerify.state == r.timerVerify.states.STOPPED) {
                            r.timerVerify.state = r.timerVerify.states.STARTED;

                            local.calculateStartCurrent(r.timerVerify.current);
                        }

                        local.timer.ss += 1;

                        if (local.timer.ss == 60) {
                            local.timer.ms += 1;
                            local.timer.ss = 0;
                        }
                        if (local.timer.ms == 60) {
                            local.timer.hs += 1;
                            local.timer.ms = 0;
                        }

                        var time = local.timer.format(local.timer.hs) + ":" +
                                   local.timer.format(local.timer.ms) + ":" +
                                   local.timer.format(local.timer.ss);

                        if (r.timerVerify.progress.current < r.timerVerify.progress.totalSec || r.timerVerify.progress.totalSec == 0) {
                            if (r.timerVerify.progress.totalSec == 0) r.timerVerify.progress.total();
                            r.timerVerify.progress.moment();
                        }
                        r.timerVerify.current = time;

                    }, 1000);

                },
                stop: function (isFinally) {
                    isFinally = isFinally || false;

                    if (r.timerVerify.state == r.timerVerify.states.STARTED) {
                        if (angular.isDefined(timer)) {
                            $interval.cancel(timer);
                            timer = undefined;

                            r.timerVerify.state = !isFinally ? r.timerVerify.states.STOPPED : r.timerVerify.states.FINALIZED;
                        }
                    }
                },
                clear: function () {
                    if (angular.isDefined(timer)) {
                        $interval.cancel(timer);
                        timer = undefined;
                    }

                    local.timer.hs = 0;
                    local.timer.ms = 0;
                    local.timer.ss = 0;

                    r.timerVerify.state = r.timerVerify.states.DISABLED;
                    r.timerVerify.current = "00:00:00"
                }
            }
        }

        return r;
    }]);