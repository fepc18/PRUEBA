﻿app.factory('auth', ['componentsPromise', '$filter', 'userResources', '$log', '$rootScope',
    function (componentsPromise, $filter, userResources, $log, $rootScope) {

        var r = {
            components: [],
            componentsEnabled: false,
            load: function () {
                componentsPromise.getComponents({}).then(function (data_) {
                    r.components = data_.data;
                    r.componentsEnabled = data_.enabled;
                });
                userResources.getInfoBasic.get(null, function (data_) {
                    if (data_.state) {
                        $rootScope.userData = data_.info;
                    } else {
                        $log.warning("UserData: " + data_.message);
                    }
                });
            },
            authorize: function (componentName_) {
                if (r.componentsEnabled) {
                    var find = $filter("filter")(r.components, { componentName: componentName_ });

                    return find.length > 0 ? true : false;
                } else {
                    return true;
                }
            },
            //userData: function () {
            //    userResources.getInfoBasic.get(null, function (data_) {
            //        if (data_.state) {
            //            $rootScope.userData = data_.info;
            //        } else {
            //            $log.warning("UserData: " + data_.message);
            //        }
            //    });
            //}
        }

        return r;
    }]);