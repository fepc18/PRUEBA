﻿app.factory('AuthenticateUserSources', ['userResources', '$log',
    function (userResources, $log) {
        var interfaz = {
            AuthenticateUser: function (data) {
                return userResources.AuthenticateUser.post(data).$promise.then(function (data_) {
                    if (data_.state) {                       
                        var user = data_.info;
                    } else {
                        user = false;                        
                        $log.error(data_.message);
                    }
                    return user;
                });
            },
           
    }
        return interfaz;
    }]);


