﻿app.factory('routeInclude', [
    function () {

        var r = {
            requisition: {
                product: {
                    otpRegister: "content/app_views/requisition/product/order/otp/register.html",
                    otpCode: "content/app_views/requisition/product/order/otp/code.html",
                    otpFinally: "content/app_views/requisition/product/order/otp/finally.html",
                    offerList: "content/app_views/requisition/product/order/offer/list.html",
                    offerLegacy: "content/app_views/requisition/product/order/offer/legacy.html",
                    formBData: "content/app_views/requisition/product/order/form/basic-data.html",
                    formBDataAdic: "content/app_views/requisition/product/order/form/basic-data-additional.html",
                    formAddCard: "content/app_views/requisition/product/order/form/additional-card.html",
                    formEcoActivity: "content/app_views/requisition/product/order/form/economic-activity.html",
                    formEvident: "content/app_views/requisition/product/order/form/evident.html",
                    formForeignCur: "content/app_views/requisition/product/order/form/foreign-currency.html",
                    formNormData: "content/app_views/requisition/product/order/form/normative-data.html",
                    formProdOffer: "content/app_views/requisition/product/order/form/products-offer.html",
                    formReferences: "content/app_views/requisition/product/order/form/references.html",
                    cancelRequisition: "content/app_views/requisition/product/order/form/cancel-requisition.html",
                    formFinally: "content/app_views/requisition/product/order/form/finally.html",
                    docFinger: "content/app_views/requisition/product/order/document/finger.html",
                    docScan: "content/app_views/requisition/product/order/document/files.html"
                },
                catalog: {
                    show: "content/app_views/requisition/product/catalog/show.html"
                },
                adn: {
                    show: "content/app_views/requisition/product/adn/show.html"
                }
            },

            verification: {
                infoClient: "content/app_views/verification/info-client/index.html",
                specialBrands: "content/app_views/verification/special-brands/index.html",
                biometrics: "content/app_views/verification/biometrics/index.html",
                identity: "content/app_views/verification/identity/index.html",
                customer: "content/app_views/verification/customer/index.html",
                activity: "content/app_views/verification/activity/index.html",
                income: "content/app_views/verification/income/index.html",
                googleSarlaft: "content/app_views/verification/google-sarlaft/index.html",
                tabs: {
                    index: "content/app_views/verification/tabs/index.html",
                    internalFraud: "content/app_views/verification/tabs/internal-fraud/show.html",
                    searchReq: "content/app_views/verification/tabs/search-req/show.html",
                    userMsg: "content/app_views/verification/tabs/user-msg/show.html",
                    infoBase: "content/app_views/verification/tabs/info-base/show.html",
                    consultFraud: "content/app_views/verification/tabs/consult-fraud/show.html",
                    paymentCapacity: "content/app_views/verification/tabs/payment-capacity/show.html",
                    centralRisk: "content/app_views/verification/tabs/central-risk/show.html"
                }
            }
        }
        return r;
    }]);