﻿app.factory('oFacSources', ['oFacResources', '$log',
    function (oFacResources, $log) {
        var listOfac = {};

        var interfaz = {
            getListOfac: function (typeId_, identity_) {
                return oFacResources.getListOfac.get(
                    {
                        typeId: typeId_,
                        identity: identity_
                    }).$promise.then(function (data_) {
                        if (data_.state) {
                            listOfac.status = true;
                            listOfac.data = data_.info;
                        } else {
                            listOfac.status = false;
                            listOfac.data = data_.message;

                            $log.error(data_.message);
                        }
                        return listOfac;
                    });
            }
        }
        return interfaz;
    }]);