﻿app.factory('centerRiskSource', ['centerRiskResources', '$log',
    function (centerRiskResources, $log) {

        var shortFrame = {};
        var firstFrame = {};
        var calification = {};
        var vigency = {};
        var noVigency = {};
        var balance = {};
        var indebtedness = {};
        var reclaims = {};
        var alerts = {};
        var queryes = {};
        var resume = {};
        var history = {};
        var requireCenterRisk = {};
        var lastQuery = {};

        var validation = {};

        var interfaz = {
            getLastQuery: function (typeId_, identity_) {
                return centerRiskResources.getLastQuery.get(
                    {
                        typeId: typeId_,
                        identity: identity_
                    }).$promise.then(function (data_) {
                        if (data_.state) {
                            lastQuery.status = true;
                            lastQuery.data = data_.info;
                        } else {
                            lastQuery.status = false;
                            lastQuery.data = data_.message;

                            $log.error(data_.message);
                        }
                        return lastQuery;
                    });
            },
            requireWebService: function (typeId_, identity_, lastName_) {
                return centerRiskResources.requireWebService.get(
                    {
                        typeId: typeId_,
                        identity: identity_,
                        lastName: lastName_
                    }).$promise.then(function (data_) {
                        if (data_.state) {
                            requireCenterRisk.status = true;
                            requireCenterRisk.data = data_.info;
                        } else {
                            requireCenterRisk.status = false;
                            requireCenterRisk.data = data_.message;

                            $log.error(data_.message);
                        }
                        return requireCenterRisk;
                    });
            },
            getShortFrame: function (idConsulta_) {
            return centerRiskResources.getShortFrame.get(
                {
                    idConsulta: idConsulta_
                }).$promise.then(function (data_) {

                    if (data_.state) {
                        shortFrame.status = true;
                        shortFrame.data = data_.info;
                    } else {
                        shortFrame.status = false;
                        shortFrame.data = data_.message;

                        $log.error(data_.message);
                    }

                    return shortFrame;
                });
            },
            getHeader: function (idConsulta_) {
            return centerRiskResources.getHeader.get(
                {
                    idConsulta: idConsulta_
                }).$promise.then(function (data_) {

                    if (data_.state) {
                        firstFrame.status = true;
                        firstFrame.data = data_.info;
                    } else {
                        firstFrame.status = false;
                        firstFrame.data = data_.message;

                        $log.error(data_.message);
                    }

                    return firstFrame;
                });
            },
            getCalification: function (idConsulta_) {
                return centerRiskResources.getCalification.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            calification.status = true;
                            calification.data = data_.info;
                        } else {
                            calification.status = false;
                            calification.data = data_.message;

                            $log.error(data_.message);
                        }

                        return calification;
                    });
            },



            getVigency: function (idConsulta_) {
                return centerRiskResources.getVigency.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            vigency.status = true;
                            vigency.data = data_.info;
                        } else {
                            vigency.status = false;
                            vigency.data = data_.message;

                            $log.error(data_.message);
                        }

                        return vigency;
                    });
            },
            getNoVigency: function (idConsulta_) {
                return centerRiskResources.getNoVigency.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            noVigency.status = true;
                            noVigency.data = data_.info;
                        } else {
                            noVigency.status = false;
                            noVigency.data = data_.message;

                            $log.error(data_.message);
                        }

                        return noVigency;
                    });
            },
            getBalance: function (idConsulta_) {
                return centerRiskResources.getBalance.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            balance.status = true;
                            balance.data = data_.info;
                        } else {
                            balance.status = false;
                            balance.data = data_.message;

                            $log.error(data_.message);
                        }

                        return balance;
                    });
            },
            getIndebtedness: function (idConsulta_) {
                return centerRiskResources.getIndebtedness.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            indebtedness.status = true;
                            indebtedness.data = data_.info;
                        } else {
                            indebtedness.status = false;
                            indebtedness.data = data_.message;

                            $log.error(data_.message);
                        }

                        return indebtedness;
                    });
            },
            getReclaims: function (idConsulta_) {
                return centerRiskResources.getReclaims.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            reclaims.status = true;
                            reclaims.data = data_.info;
                        } else {
                            reclaims.status = false;
                            reclaims.data = data_.message;

                            $log.error(data_.message);
                        }

                        return reclaims;
                    });
            },
            getAlerts: function (idConsulta_) {
                return centerRiskResources.getAlerts.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            alerts.status = true;
                            alerts.data = data_.info;
                        } else {
                            alerts.status = false;
                            alerts.data = data_.message;

                            $log.error(data_.message);
                        }

                        return alerts;
                    });
            },
            getQueryes: function (idConsulta_) {
                return centerRiskResources.getQueryes.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            queryes.status = true;
                            queryes.data = data_.info;
                        } else {
                            queryes.status = false;
                            queryes.data = data_.message;

                            $log.error(data_.message);
                        }

                        return queryes;
                    });
            },
            getResume: function (idConsulta_) {
                return centerRiskResources.getResume.get(
                    {
                        idConsulta: idConsulta_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            resume.status = true;
                            resume.data = data_.info;
                        } else {
                            resume.status = false;
                            resume.data = data_.message;

                            $log.error(data_.message);
                        }

                        return resume;
                    });
            },
            getHistory: function (typeId_, identity_) {
                return centerRiskResources.getHistory.get(
                    {
                        typeId: typeId_,
                        identity: identity_
                    }).$promise.then(function (data_) {

                        if (data_.state) {
                            history.status = true;
                            history.data = data_.info;
                        } else {
                            history.status = false;
                            history.data = data_.message;

                            $log.error(data_.message);
                        }

                        return history;
                    });
            },
            validateDataCredit: function (data_) {
                return centerRiskResources.validateDataCredit.get({
                    data: data_
                }).$promise.then(function (data_) {
                    if (data_.state) {
                        validation.status = true;
                        validation.data = data_.info;
                    } else {
                        validation.status = false;
                        validation.data = data_.message;

                        $log.error(data_.message);
                    }

                    return validation;
                });
            }
        }
        return interfaz;
    }]);