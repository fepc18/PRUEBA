﻿app.factory('recognizeSources', ['recognizeResources', '$log',
    function (recognizeResources, $log) {
        var recognize = {};

        var interfaz = {
            getDataRecognize: function (typeId_, identity_, lastName_) {
                return recognizeResources.getRecognize.get(
                    {
                        typeId: typeId_,
                        identity: identity_,
                        lastName: lastName_
                    }).$promise.then(function (data_) {
                        if (data_.state) {
                            recognize.status = true;
                            recognize.data = data_.info;
                        } else {
                            recognize.status = false;
                            recognize.data = data_.message;

                            $log.error(data_.message);
                        }
                        return recognize;
                    });
            }
        }
        return interfaz;
    }]);