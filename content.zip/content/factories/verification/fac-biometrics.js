﻿app.factory('biometricsFactory', ['biometricsService', '$log',
    function (biometricsService, $log) {
        var DocumentFeatures = {};
        
        var interfaz = {
            getValidationHelp: function (data) {
                return biometricsService.getValidationHelp.post(data).$promise.then(function (result) {
                    if (result.state) {
                        DocumentFeatures.status = true;
                        DocumentFeatures.data = result.info;
                    } else {
                        DocumentFeatures.status = false;
                        DocumentFeatures.data = result.message;

                        $log.error(result.message);
                    }
                    return DocumentFeatures;
                });
            },
        }
        return interfaz;
    }]);