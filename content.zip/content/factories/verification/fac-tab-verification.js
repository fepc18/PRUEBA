﻿app.factory('tabVerificationSources', ['tabVerificationResources', '$log',
    function (tabVerificationResources, $log) {
        var listUserMessages = {};
        var listCities = {};
        var listSanAndresitos = {};
        var listCooperatives = {};
        var listQuotas = {};
        var listEmployees = {};
        var listTeacherScales = {};
        var listChurch = {};        
        var listLinks = {};
        var listONG = {};
        var listCreditPolicy = {};
        var listStores = {};
        var listArmedForcesRanks = {};
        var listPublicTransport = {};
        var dataReportedRequisition = {};
        var dataParametersPaymentCapacity = {};
        var dataSavePaymentCapacity = {};

        var interfaz = {
            getUserMessages: function (data) {
                return tabVerificationResources.getUserMessages.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listUserMessages.status = true;
                        listUserMessages.data = data_.info;
                    } else {
                        listUserMessages.status = false;
                        listUserMessages.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listUserMessages;
                });
            },
            getCities: function (data) {
                return tabVerificationResources.getCities.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listCities.status = true;
                        listCities.data = data_.info;
                    } else {
                        listCities.status = false;
                        listCities.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listCities;
                });
            },
            getSanAndresitos: function (data) {
                return tabVerificationResources.getSanAndresitos.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listSanAndresitos.status = true;
                        listSanAndresitos.data = data_.info;
                    } else {
                        listSanAndresitos.status = false;
                        listSanAndresitos.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listSanAndresitos;
                });
            },
            getCooperatives: function (data) {
                return tabVerificationResources.GetCooperatives.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listCooperatives.status = true;
                        listCooperatives.data = data_.info;
                    } else {
                        listCooperatives.status = false;
                        listCooperatives.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listCooperatives;
                });
            },
            getQuotas: function (data) {
                return tabVerificationResources.GetQuotas.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listQuotas.status = true;
                        listQuotas.data = data_.info;
                    } else {
                        listQuotas.status = false;
                        listQuotas.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listQuotas;
                });
            },
            getEmployees: function (data) {
                return tabVerificationResources.GetEmployees.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listEmployees.status = true;
                        listEmployees.data = data_.info;
                    } else {
                        listEmployees.status = false;
                        listEmployees.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listEmployees;
                });
            },
            getTeacherScales: function (data) {
                return tabVerificationResources.GetTeacherScales.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listTeacherScales.status = true;
                        listTeacherScales.data = data_.info;
                    } else {
                        listTeacherScales.status = false;
                        listTeacherScales.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listTeacherScales;
                });
            },
            GetChurch: function (data) {
                return tabVerificationResources.GetChurch.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listChurch.status = true;
                        listChurch.data = data_.info;
                    } else {
                        listChurch.status = false;
                        listChurch.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listChurch;
                });
            },
            getLinks: function (data) {
                return tabVerificationResources.GetLinks.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listLinks.status = true;
                        listLinks.data = data_.info;
                    } else {
                        listLinks.status = false;
                        listLinks.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listLinks;
                });
            },
           
            getONG: function (data) {
                return tabVerificationResources.GetONG.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listONG.status = true;
                        listONG.data = data_.info;
                    } else {
                        listONG.status = false;
                        listONG.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listONG;
                });
            },
            getCreditPolicy: function (data) {
                return tabVerificationResources.GetCreditPolicy.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listCreditPolicy.status = true;
                        listCreditPolicy.data = data_.info;
                    } else {
                        listCreditPolicy.status = false;
                        listCreditPolicy.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listCreditPolicy;
                });
            },
            getArmedForcesRanks: function (data) {
                return tabVerificationResources.GetArmedForcesRanks.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listArmedForcesRanks.status = true;
                        listArmedForcesRanks.data = data_.info;
                    } else {
                        listArmedForcesRanks.status = false;
                        listArmedForcesRanks.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listArmedForcesRanks;
                });
            },
           
            getStores: function (data) {
                return tabVerificationResources.GetStores.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listStores.status = true;
                        listStores.data = data_.info;
                    } else {
                        listStores.status = false;
                        listStores.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listStores;
                });
            },
            getPublicTransport: function (data) {
                return tabVerificationResources.GetPublicTransport.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listPublicTransport.status = true;
                        listPublicTransport.data = data_.info;
                    } else {
                        listPublicTransport.status = false;
                        listPublicTransport.data = data_.message;
                        $log.error(data_.message);
                    }
                    return listPublicTransport;
                });
            },

            getDataReportedRequisition: function (data) {
                
                return tabVerificationResources.GetDataReportedRequisition.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        dataReportedRequisition.status = true;
                        dataReportedRequisition.data = data_.info;
                    } else {
                        dataReportedRequisition.status = false;
                        dataReportedRequisition.data = data_.message;
                        $log.error(data_.message);
                    }
                    return dataReportedRequisition;
                });
            },
            getParametersPaymentCapacity: function () {
                return tabVerificationResources.GetParametersPaymentCapacity.post().$promise.then(function (data_) {
                    if (data_.state) {
                        dataParametersPaymentCapacity.status = true;
                        dataParametersPaymentCapacity.data = data_.info;
                    } else {
                        dataParametersPaymentCapacity.status = false;
                        dataParametersPaymentCapacity.data = data_.message;
                        $log.error(data_.message);
                    }
                    return dataParametersPaymentCapacity;
                });
            },
            savePaymentCapacity: function (data) {

                return tabVerificationResources.SavePaymentCapacity.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        dataSavePaymentCapacity.status = true;
                        dataSavePaymentCapacity.data = data_.info;
                    } else {
                        dataSavePaymentCapacity.status = false;
                        dataSavePaymentCapacity.data = data_.message;
                        $log.error(data_.message);
                    }
                    return dataSavePaymentCapacity;
                });
            },
           
    }
        return interfaz;
    }]);


