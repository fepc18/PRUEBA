﻿app.factory('bueSources', ['bueResources', '$log',
    function (bueResources, $log) {
        var listMasterBue = {};
        var listDetailBue = {};
        var listDocTypeBue = {};

        var interfaz = {
            getMasterBue: function (data) {
               return bueResources.getMasterBue.post(data).$promise.then(function (data_) {
                    if (data_.state) {
                        listMasterBue.status = true;
                        listMasterBue.data = data_.info;
                    } else {
                        listMasterBue.status = false;
                        listMasterBue.data = data_.message;

                        $log.error(data_.message);
                    }
                    return listMasterBue;
                });
            },

            getDetailBue: function (document) {
               return bueResources.getDetailBue.get({ Document: document }).$promise.then(function (data_) {
                        if (data_.state) {
                            listDetailBue.status = true;
                            listDetailBue.data = data_.info;
                        } else {
                            listDetailBue.status = false;
                            listDetailBue.data = data_.message;

                            $log.error(data_.message);
                }
                        return listDetailBue;
                });
        },

            getDocumentTypes: function () {
                return bueResources.getDocumentTypes.get({}).$promise.then(function (data_) {
                    if (data_.state) {
                        listDocTypeBue.status = true;
                        listDocTypeBue.data = data_.info;
                    } else {
                        listDocTypeBue.status = false;
                        listDocTypeBue.data = data_.message;

                        $log.error(data_.message);
                    }
                    return listDocTypeBue;
                });
            },
            createInternalFraudBue: function (data) {
                return bueResources.createInternalFraudBue.post(data).$promise.then(function (data_) {
                    debugger;
                    if (data_.state) {
                      
                        
                    } else {
                                              

                        $log.error(data_.message);
                    }
                    return data_;
                })
            },
    }
        return interfaz;
}]);