﻿app.factory('dynamicFormFactory', ['dynamicFormService', '$log',
    function (dynamicFormService, $log) {
        var dynamicForm = {};

        var interfaz = {
            getAllByModule: function (module, ecoActivity) {
                data = {
                    IdModule: module,
                    IdEconomicActivity: ecoActivity
                };

                return dynamicFormService.getAllByModule.post(data).$promise.then(function (result) {
                    if (result.state) {
                        dynamicForm.status = true;
                        dynamicForm.data = result.info;
                    } else {
                        dynamicForm.status = false;
                        dynamicForm.data = result.message;

                        $log.error(result.message);
                    }
                    return dynamicForm;
                });
            },
        }
        return interfaz;
    }]);