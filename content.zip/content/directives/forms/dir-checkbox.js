﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('checkboxDirective', [function () {
    return {
        restrict: 'E',
        scope: {
            item: '=',
            model: "=ngModel"
        },
        link: function (scope, element, attributes) {

            console.log(element);

            scope.change = function (val) {
                scope.model = val;
                console.log(scope.model);
            };

            debugger;
            var checkSize = (attributes.checksize >= 1 && attributes.checksize <= 12) ? "col-md-" + attributes.checksize : "col-md-6";
            var labelsize = (attributes.labelsize >= 1 && attributes.labelsize <= 12) ? "col-md-" + attributes.labelsize : "col-md-6";

            $(element[0].childNodes[0]).addClass(labelsize);

            $("div.check-directive").css("border") == "1px solid red";

            console.log(checkSize);
            console.log(labelsize);

        },
        templateUrl: '/content/style/templates/formControls/checkbox-directive.html',
    }
}]);
