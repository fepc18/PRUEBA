﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('textareaDirective', [function () {
    return {
        restrict: 'E',
        scope: {
            item: '=',
            model: "=ngModel"
        },
        link: function (scope, element, attributes) {
            scope.rows = attributes.rows;
            
            scope.$watch(attributes.size, function (value) {
                var size = (value >= 1 && value <= 12) ? "col-md-" + value : "col-md-6";
                $(element[0].childNodes[0]).addClass(size);
            });
        },
        templateUrl: '/content/style/templates/formControls/textarea-directive.html',
    }
}]);
