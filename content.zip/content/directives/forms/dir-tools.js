﻿app.directive('ngEnter', function() {
    return function(scope, elem, attrs) {
        elem.bind("keydown keypress", function(event) {
            // 13 represents enter button
            if (event.which === 13) {
                scope.$apply(function() {
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    };
});

app.directive('maskMaxlength', function () {
    return {
        restrict: 'A',
        require: '^form',
        scope: {
            max: "@maskMaxlength"
        },
        link: function (scope, element, attrs, formCtrl) {
            var inputNgEl = angular.element(element);

            inputNgEl.bind('keypress', function () {
                var valView = formCtrl[element[0].name].$viewValue;
                var special = 0;

                if (valView) {
                    for (var i = 0; i < valView.length; ++i) {
                        if (isNaN(valView[i]) || valView[i] == "") special += 1;
                    }
                }
                var newLength = parseInt(scope.max) + special;

                element.attr("maxlength", newLength);
            })
        }
    }
});
