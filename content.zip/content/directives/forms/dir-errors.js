﻿app.directive('showErrorsForm', function () {
    return {
        restrict: 'A',
        require: '^form',
        link: function (scope, element, attrs, formCtrl) {
            var inputNgEl = angular.element(element);

            inputNgEl.bind('submit', function () {

                angular.forEach(element[0], function (item, index) {
                    var parent = item.parentElement;

                    if (parent.className.includes("input-group")) parent = parent.parentElement;
                    if (parent.className.includes("form-group")) {
                        if (formCtrl[item.name].$invalid) {

                            var ngEl = angular.element(parent);
                            ngEl.attr("class", parent.className + " has-error");
                        }
                    }
                })
            })
        }
    }
});

app.directive('showErrors', function () {
    return {
        restrict: 'A',
        require: '^form',
        link: function (scope, element, attrs, formCtrl) {

            var inputEl = element[0].querySelector("[name]");
            var inputNgEl = angular.element(inputEl);
            var inputName = inputNgEl.attr('name');

            inputNgEl.bind('blur', function () {
                element.toggleClass('has-error', formCtrl[inputName].$invalid);
            })
        }
    }
});
