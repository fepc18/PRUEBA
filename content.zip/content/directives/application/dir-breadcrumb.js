﻿angular.module('services.breadcrumbs', []);
angular.module('services.breadcrumbs').factory('breadcrumbs', ['$filter', '$rootScope', '$location', 'configuration', function ($filter, $rootScope, $location, configuration) {

    var breadcrumbs = [];
    var breadcrumbsService = {};

    $rootScope.$on('$routeChangeSuccess', function (event, current) {

        getBreadcrumbs();
    });

    breadcrumbsService.getAll = function () {
        if (breadcrumbs.length == 0) {
            getBreadcrumbs();
        }

        return breadcrumbs;
    };

    breadcrumbsService.getFirst = function () {
        return breadcrumbs[0] || {};
    };


    function getBreadcrumbs() {
        var pathElements = $location.path().split('/'), result = [], i;
        var breadcrumbPath = function (index) {
            return '/' + (pathElements.slice(0, index + 1)).join('/');
        };

        pathElements.shift();
        for (i = 0; i < pathElements.length; i++) {
            var gpn = getPrettyName(pathElements[i]);

            if (gpn != '')
                result.push({ name: gpn, path: breadcrumbPath(i) });
        }

        breadcrumbs = result;
    }
    function getPrettyName(name_) {
        var vmenu = configuration.verticalmenu;
        var find = $filter("filter")(vmenu, { name: name_ });
        var nameReturn = "";
        var bread = undefined;
        
        if (find.length > 0) {
            nameReturn = find[0].text;
            bread = find[0].breadcrumb;
        } else {
            var xname = name_;

            angular.forEach(vmenu, function (item, index) {
                if (item.submenu) {
                    var find = $filter("filter")(item.submenu, { name: name_ });

                    if (find.length > 0) {
                        xname = find[0].text;
                        bread = find[0].breadcrumb;
                    }
                }
            });
            nameReturn = xname;
        }

        return nameReturn = (bread || bread == undefined ? nameReturn : '');
    }


    return breadcrumbsService;
}]);