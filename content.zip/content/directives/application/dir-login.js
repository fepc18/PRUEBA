﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('fbControlLogin', ['AuthenticateUserSources', function (AuthenticateUserSources) {
    return {
        scope: {
            value: "=ngModel",
            ctrl:"@ctrl",
            name: "@",
            callback: "&callback"
        },
        require: 'ngModel',
        templateUrl: '/content/style/fbControls/fb-control-login.html',
        link: function (scope, element, attr) {
                      
            scope.click= function() {
                
                var vm = {};
                
                vm.idsystem = "421";
                vm.username = scope.username;
                vm.password = scope.password;
                vm.profileid = "666";

                var dataJson = JSON.stringify(vm);
           
                AuthenticateUserSources.AuthenticateUser(dataJson).then(function (data_) {                    
                    if(data_.statusidlogin=="101"){
                        scope.value = true;                     
                        scope.callback();
                    } else {
                        scope.value = false;                       
                    }
                });


                // Verificar autenticidad de usuario
                console.log(scope.username + " - " + scope.password + ' ::: Control: '+scope.ctrl);
                //scope.value = scope.username ? true : false;

                }
            
        }
    };
}]);