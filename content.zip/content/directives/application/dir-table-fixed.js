﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('tableFixed', ['regex', '$timeout', function (regex, $timeout) {
    return function (scope, element, attr) {
        //if (scope.$last) {
        //    start();
        //} else {
        //    console.log("process...");
        //}
        //start();

        $timeout(function () {
            //var p = angular.element(angular.element(element[0].parentElement)[0].parentElement)[0].parentElement;            
            var el = angular.element(element);

            var tbl = el[0].childNodes[1];
            var tbh = angular.element(tbl)[0].childNodes[1];
            var tbd = angular.element(tbl)[0].childNodes[3];

            var tbFirst = angular.element(tbd)[0].children[0];
            tbFirst = angular.element(tbFirst)[0].children;

            var nhtml_body = "<tbody style='visibility:hidden;'>";
            angular.forEach(tbFirst, function (item, index) {
                if (item.nodeName == "TD") {
                    nhtml_body += item.outerHTML;
                }
            })
            nhtml_body += "</body>";

            thFirst = angular.element(tbh)[0].children[0];
            thFirst = angular.element(thFirst)[0].children;

            var nhtml_head = "<thead><tr>";
            angular.forEach(thFirst, function (item, index) {
                if (item.nodeName == "TH") {
                    nhtml_head += item.outerHTML;
                }
            })
            nhtml_head += "</tr></thead>";

            var ntbl = "<table class='table table-striped' style='margin-bottom:-40px;border-collapse: initial;'>" + nhtml_head + nhtml_body + "</table>";
            ntbl = angular.element(ntbl);

            angular.element(angular.element(tbl)[0].childNodes[1])[0].style.visibility = "hidden";
            angular.element(angular.element(tbl)[0].childNodes[1])[0].style.display = "table-footer-group";

            var divH = "<div class='border-table-header-style'></div>"
            var divB = "<div class='overflow-table-sm scroll-table-style'></div>";

            var dh = angular.element(divH).append(ntbl);
            var db = angular.element(divB).append(tbl);

            el.empty();
            el.append(dh);
            el.append(db);

            //console.log(scope);
        }, 0);
    };
}]);