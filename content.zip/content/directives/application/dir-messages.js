﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('messageCustom', ['$timeout', function ($timeout) {
    return {
        scope: {
            title: '@?title',
            message: '@?message',
            funct: '&?funct',
            type: "@",
            big: "@?big",
            small: "@?small"
        },
        templateUrl: function (element, attr) {
            var tp = attr.type || "info";
            var bg = attr.big ? "big-" : attr.small ? "min-" : "";

            return '/content/style/templates/' + bg + 'message-' + attr.type + '.html';
        },
        link: function (scope, element, attr) {
            
            function load(messageFromModel) {
                var isFunction = scope.funct ? true : false;

                scope.data = {
                    title: scope.title || '',
                    message: scope.message || '',
                    messageButton: '',
                    isFn: isFunction
                }
            }
            load();                      

        }
    };
}]);
