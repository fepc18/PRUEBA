﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('imgZoom', [function () {
    return {
        scope: {},
        restrict: 'EA',
        //require: 'id',
        link: function (scope, elem, attrs) {
            var id = elem[0].id;

            var paramsBlowup = {
                round: true,
                width: 220,
                height: 220,
                background: "#FFF",
                border: "4px solid #2a3542",
                cursor: true,
                scale: 2
            };


            $("#" + id).blowup(paramsBlowup);
        }
    };
}]);
