﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo
// ?            variables opcionales (Ej; @?myVar, =?myvar)

app.directive('fbTablePagination', ['$timeout', '$compile', function ($timeout, $compile) {
    return {
        scope: {
            value: "=ngModel",
            totalItems: "=totalItems",
            name: "@",
            aliasModel: "@aliasModel",
            itemsPerPage: "@?itemsPerPage",
                        
            current: "=current"
        },
        //require: 'ngModel',
        link: function (scope, element, attr) {
            var length_ = 0;
            var current = 0;
            var bypage = scope.itemsPerPage || 5;

            function init() {
                //scope.$parent.$parent[scope.aliasModel]["current_" + scope.name] = 0;
                //scope.$parent.$parent[scope.aliasModel]["bypage_" + scope.name] = bypage;
                               
                scope.current = current;

                //scope["current_" + scope.name] = 0;
                //scope["bypage_" + scope.name] = bypage;

                scope.$watch("totalItems", function (oldValue, newValue) {
                    if (oldValue != newValue) {
                        length = oldValue;

                        var ngel = angular.element(element)[0];
                        ngel = ngel.children[1];
                        ngel = angular.element(ngel);

                        var pag = "<div class='col-md-12'>" +
                        "<span class='pull-left'>Pagina 1 de 5 </span>" +
                        "<ul uib-pagination total-items='" + length + "'" +
                        "next-text='Siguiente'" +
                        "previous-text='Previa'" +
                        "first-text='Primera'" +
                        "last-text='Ultima'" +
                        "ng-model='ondemand.current_" + scope.name + "'" +
                        "items-per-page='" + bypage + "'" +
                        "class='pagination-sm no-margin pull-right'" +
                        "boundary-links='true'></ul></div>";

                        $compile(pag)(scope);
                        ngel.append(pag);
                        $compile(ngel)(scope);

                        console.log(ngel);
                    }
                })
            }

            $timeout(init, 0);
        }
    };
}]);

//DESCARTADO**