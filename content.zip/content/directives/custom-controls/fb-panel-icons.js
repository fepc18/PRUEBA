﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('fbPanelIconGroup', [function () {
    return {
        scope: {
            itemExpanded: "=?fbItemExpanded",
            colorIcons: "@?fbColorIcons"
        },
        link: function (scope, element, attr) {
            scope.itemExpanded = scope.itemExpanded == undefined ? -1 : scope.itemExpanded;
            scope.colorIcons = scope.colorIcons == undefined ? "#fff" : scope.colorIcons;

            angular.element(document).ready(function () {
                var inputEl = element[0];
                var inputNgEl = angular.element(inputEl);

                angular.forEach(inputEl.children, function (item, index) {
                    var pitem = item.children[0].children[0];
                    var pNgItem = angular.element(pitem);
                    var itemEl = angular.element('<i name="panel-icon"></i>');
                    pNgItem.append(itemEl);

                    var icon = pitem.children["panel-icon"];
                    var watch = isItemExpanded(index);

                    if (watch) {
                        icon.className = 'icon-panel-collapse fa fa-chevron-up';
                        icon.style.color = scope.colorIcons;

                        var collapse = item.children[1];
                        var clsCollapse = collapse.className + " in";

                        collapse.className = clsCollapse;
                    } else {
                        icon.className = 'icon-panel-collapse fa fa-chevron-down';
                        icon.style.color = scope.colorIcons;
                    }

                    var pNgEl = angular.element(pitem);
                    pNgEl.bind("click", function () {
                        angular.forEach(inputEl.children, function (item, index) {
                            var p = item.children[0].children[0];
                            var inClass = item.children[1].className.split(" ");
                            var i = p.children["panel-icon"];

                            if (findClass(inClass, "in")) {
                                i.className = 'icon-panel-collapse fa fa-chevron-down';
                                i.style.color = scope.colorIcons;
                            }
                        });

                        var iconClicked = pNgEl[0].children["panel-icon"];
                        var result = conditionInChevr(item, iconClicked);

                        if (result) {
                            iconClicked.className = 'icon-panel-collapse fa fa-chevron-up';
                            iconClicked.style.color = scope.colorIcons;
                        } 

                    });
                });
                function isItemExpanded(index) {
                    return scope.itemExpanded == index ? true : false;
                }
                function conditionInChevr(itemEach, iClicked) {
                    var findIn = false;
                    var inClassCollapse = itemEach.children[1].className.split(" ");

                    findIn = findClass(inClassCollapse, "in");

                    var findChevr = false;
                    var inClassIcon = iClicked.className.split(" ");

                    findChevr = findClass(inClassIcon, "fa-chevron-down");

                    return (!findIn && findChevr) ? true : false;
                }
                function findClass(classGroup, classFind) {
                    var find = false;

                    for (var x = 0 ; x < classGroup.length; ++x) {
                        if (classGroup[x].trim() == classFind) {
                            find = true; break;
                        }
                    }
                    return find;
                }
            });
        }
    };
}]);
