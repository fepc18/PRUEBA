﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('fbControlCondition', [function () {
    return {
        scope: {
            value: "=ngModel",           
            name: "@",
            valConditionYes: "@conditionYes",
            valConditionNo: "@conditionNo",
            textConditionYes: "@?textYes",
            textConditionNo: "@?textNo",
            initWithYes: "@?initWithYes",
            functionChange: "&"
        },
        require: 'ngModel',
        templateUrl: '/content/style/fbControls/fb-control-condition.html',
        link: function (scope, element, attr) {

            scope.calculate = function (val) {
                scope.functionChange();
                scope.value = val == 1 ? processIfBoolean(scope.valConditionYes) : processIfBoolean(scope.valConditionNo);
            }

            function init() {
                if (!scope.textConditionYes) scope.textConditionYes = "SI";
                if (!scope.textConditionNo) scope.textConditionNo = "NO";
                if ((scope.valConditionYes == undefined || scope.valConditionNo == undefined) ||
                    (scope.valConditionYes == null || scope.valConditionNo == null)) {

                    scope.valConditionYes = true;
                    scope.valConditionNo = false;
                }
                if (scope.initWithYes) scope.value = scope.valConditionYes;
                if (scope.value == scope.valConditionYes) {
                    scope.selected = 1;
                } else {
                    scope.selected = 0;
                    scope.value = scope.valConditionNo;
                }
            }

            function processIfBoolean(val) {
                switch (val) {
                    case "true":
                        return true;
                        break;
                    case "false":
                        return false;
                        break;
                    default:
                        return val;
                        break;
                }
            }
            init();
        }
    };
}]);