﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('fbControlTwonumeric', ['regex', function (regex) {
    return {
        scope: {
            value: "=ngModel",
            name: "@",
            form: "="
        },
        restrict: 'EA',
        require: 'ngModel',
        templateUrl: '/content/style/fbControls/fb-control-twonumeric.html',
        link: function (scope, element, attr) {
            scope.regex = regex;
            scope.years = "";
            scope.months = "";
            scope.idname = scope.name;

            if (!scope.idname) {
                scope.idname = "ID" + Math.floor((Math.random() * 9999) + 1000);
            }

            if (scope.value) {
                var val = scope.value.split(",");

                scope.years = parseInt(val[0]);
                scope.months = parseInt(val[1]);
            }

            scope.calculate = function () {
                scope.value = "";
                scope.years = scope.years || 0;
                scope.months = scope.months || 0;
                scope.value = scope.years + "," + scope.months;
            }

            scope.upCount = function (max, control) {
                var val = parseInt(scope[control]) || 0;
                if (val < max) {
                    scope[control] = parseInt(val) + 1;
                    scope.calculate();
                }
            }
            scope.downCount = function (min, control) {
                var val = parseInt(scope[control]) || 1;
                if (val > min) {
                    scope[control] = parseInt(val) - 1;
                    scope.calculate();
                }
            }

            scope.notation = function (event) {
                if (event.charCode === 101) {
                    event.preventDefault();
                }
            }
        }
    };
}]);