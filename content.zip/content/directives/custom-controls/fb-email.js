﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('fbControlEmail', ['regex', function (regex) {
    return {
        scope: {
            value: "=ngModel",
            name: "@",
            domainsList: '@',
            form: "="
        },
        require: 'ngModel',
        templateUrl: '/content/style/fbControls/fb-control-email.html',
        link: function (scope, element, attr) {
            scope.regex = regex;
            scope.domains = angular.fromJson(scope.domainsList);
            scope.name = "";
            scope.domain = "";
            scope.idname = scope.name;

            if (!scope.idname) {
                scope.idname = "ID" + Math.floor((Math.random() * 9999) + 1000);
            }

            if (scope.value) {
                var val = scope.value.split("@");
                scope.name = val[0];
                scope.domain = val[1];
            }

            scope.calculate = function () {
                scope.value = "";

                if (scope.name && scope.domain) {
                    var d = scope.domain.description ? scope.domain.description.trim() : scope.domain.trim();

                    scope.value = scope.name.trim() + "@" + d;
                }
            }
        }
    };
}]);