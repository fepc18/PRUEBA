﻿//  =           paso de variable directo
//  @           paso del valor de la variable
//  &           paso de funcion directo
// =NgModel     paso de variable (value) en ngModel directo

app.directive('fbControlAddress', ['regex', 'toolsForm', function (regex, toolsForm) {
    return {
        scope: {
            value: "=ngModel",
            name: "@",
            localization: '@',
            form: "=",
            messageProcessing: "@",
            messageRequired: "@",
            o_value: "=?object"
        },
        require: 'ngModel',
        templateUrl: '/content/style/fbControls/fb-control-address.html',
        link: function (scope, element, attr) {
            scope.regex = regex;
            scope.noMatch = false;
            scope.notFound = false;
            scope.requiredField = "";

            scope.messageProcessing = scope.messageProcessing || "validando...";
            scope.messageRequired = scope.messageRequired || "Debe ingresar primero una Ciudad y Departamento.";

            scope.calculateGeoAddress = function () {
                var address_ = scope.address;
                var city_ = scope.localization ? angular.fromJson(scope.localization) : null;
                var field = scope.name;

                if (address_ && city_) {
                    asign(scope.messageProcessing);
                    scope.noMatch = false;

                    toolsForm.getGeolocalizationAddress(address_, city_.codigoDane).then(function (data_) {
                        if (data_.status) {
                            var r = angular.fromJson(data_.data.direccionValidarResp);

                            if (r.informacionOperacion.codigoOperacion == "0000") {
                                scope.o_value = r.resultados;
                                //console.log(r.resultados);
                                asign(r.resultados.areaGeograficaGeoreferenciada.direccionGeoreferenciada);
                                scope.noMatch = false;

                                triggerCleanError(element);
                            } else {
                                toolsForm.triggerValidateField(scope.form, field, "required");

                                asign(null);
                                scope.noMatch = true;
                                scope.notFound = r.informacionOperacion.glosaOperacion;
                                scope.requiredField = "";

                                triggerHasError(element);
                            }
                        } else {
                            toolsForm.triggerValidateField(scope.form, field, "required");

                            asign(null);
                            scope.noMatch = true;
                            scope.notFound = data_.data;
                            scope.requiredField = "";

                            triggerHasError(element);
                        }
                    });

                } else {
                    toolsForm.triggerValidateField(scope.form, field, "required");
                    asign(null);
                    scope.noMatch = true;

                    if (address_) {
                        scope.requiredField = scope.messageRequired;
                    } else {
                        scope.requiredField = "Ingresa una dirección válida.";
                    }

                    triggerHasError(element);
                }
            }

            if (scope.value) {
                scope.address = scope.value;
                scope.calculateGeoAddress();
            }

            function asign(value) {
                scope.address = value;
                scope.value = value;
            }
            function triggerCleanError(el) {
                var inputEl = element[0].parentElement;
                var inputNgEl = angular.element(inputEl)[0];
                var cls = inputNgEl.className.split(" ");
                var ncls = "";

                for (var i = 0 ; i < cls.length; ++i) {
                    if (cls[i].trim() != "has-error") {
                        ncls = ncls + cls[i];
                    }
                }
                inputNgEl.className = ncls;
            }
            function triggerHasError(el) {
                var inputEl = element[0].parentElement;
                var inputNgEl = angular.element(inputEl)[0];

                inputNgEl.className = inputNgEl.className + " has-error";
            }
        }
    };
}]);