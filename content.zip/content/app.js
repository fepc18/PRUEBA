﻿var app = angular.module(
    "admisiones",
    [        
        'ngRoute',
        'ngResource',
        'ngSanitize',
        'ngAria',
        'ngAnimate',
        //'ngMessages',
        'services.breadcrumbs',
        'ui.bootstrap',
        'ui.utils.masks'        
    ]);


