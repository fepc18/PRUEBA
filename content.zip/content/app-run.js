﻿app.run(
    [
        '$rootScope',
        '$location',
        '$filter',
        'breadcrumbs',
        'regex',
        'memory',
        'navigation',
        'parametrics',
        'configuration',
        'auth',
        'userResources',
        'toolsget',
function (
    $rootScope,
    $location,
    $filter,
    breadcrumbs,
    regex,
    memory,
    navigation,
    parametrics,
    configuration,
    auth,
    userResources,
    toolsget) {

    $rootScope.titleApp = "Admisiones Web";
    $rootScope.storage = memory.storage;
    $rootScope.navigate = navigation.navigate;
    $rootScope.breadcrumbs = breadcrumbs;
    $rootScope.regex = regex;

    $rootScope.authorize = function (componentName_) {
        return auth.authorize(componentName_);
    };

    auth.load();

    $rootScope.parametrics = parametrics;
    $rootScope.parametrics.load();

    $rootScope.configuration = configuration;
    $rootScope.paginationTables = toolsget.pagination;
    $rootScope.timerVerify = toolsget.timerVerify;

    $rootScope.$on('$routeChangeStart', function (event, next, current) {
        var path = next ? next.$$route.originalPath : "";

        if (!path.match("/verification")) {
            $rootScope.timerVerify.stop();
        }

        //if (path.match("/verification")) {

        //    if ($rootScope.timerVerify.state != $rootScope.timerVerify.states.FINALIZED &&
        //        $rootScope.timerVerify.state != $rootScope.timerVerify.states.DISABLED) {
        //        //$rootScope.timerVerify.state == $rootScope.timerVerify.states.STARTED;

        //        $rootScope.timerVerify.start();
        //    }
        //} else {

        //    $rootScope.timerVerify.stop();
        //}
    });


    $rootScope.activateTimeVerifyFromMenuClick = function (sem) {
        if (sem != undefined) {
            if ($rootScope.timerVerify.state == $rootScope.timerVerify.states.FINALIZED)
                $rootScope.timerVerify.state = $rootScope.timerVerify.states.STOPPED;
        }
    }

    //temporal
    $rootScope.simulateVerify = {
        state: [
                {
                    id: 0,
                    text: "Incompleto",
                },
                {
                    id: 1,
                    text: "Deshabilitado",
                },
                {
                    id: 2,
                    text: "Pendiente Oficina",
                },
                {
                    id: 3,
                    text: "Pendiente Transito",
                },
                {
                    id: 4,
                    text: "Completo",
                },
                {
                    id: 5,
                    text: "Rechazado",
                }
        ],

        click: function (pos, state) {
            $rootScope.configuration.verticalmenu[2].submenu[pos].semaphoreStatus = state;
        }
    }

    

}]);
