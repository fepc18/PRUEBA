﻿app.controller("requisitionController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        
        console.log("requi");

    }]);