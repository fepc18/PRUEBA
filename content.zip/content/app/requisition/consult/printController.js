﻿app.controller("consultController", ['$scope', '$rootScope', 'toolsForm', 'reqConsultSource',
    function ($scope, $rootScope, toolsForm, reqConsultSource) {

        var init = function () {
            print.filtroModel = {};
        }

        var htmlLoadComponents = function () {
            print.searchTypeListOf = params.getParam("parametrics_tiposIdentificacion");         
        }
     
        init();
        htmlLoadComponents();

        print.requisitionListOf_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
        print.requisitionListOf_Current = 1;
        print.requisitionListOf_TotalItems = 0;

    }]);