﻿app.controller("consultDetailController", ['$scope', '$rootScope', 'paramsPromise', 'toolsForm', 'reqConsultSource', '$routeParams',
    function ($scope, $rootScope, paramsPromise, toolsForm, reqConsultSource, $routeParams) {

        var consultDetail = this;

        consultDetail.isInclude = $scope.fromInclude || false;
        var parentInclude = consultDetail.isInclude ? $scope.$parent.$parent.searchReq : null;
        //console.log("include=" + finc_search);

        var getRequisitionDetail = function () {
            reqConsultSource.getRequisitionDetail(consultDetail.detailModel.id_admision).then(function (data_) {
                    var data = data_.data;
                    if (data != undefined && data != null) {
                        var result = angular.fromJson(data);
                        consultDetail.detailStatus = data_.status;
                        consultDetail.detailMessage = data_.message;
                        consultDetail.detailModel = JSON.parse(JSON.stringify(result))
                    } else {
                        $log.warn("No se han podido consultar el detalle");
                    }
                })
        };

        var init = function () {
            consultDetail.detailModel = {};
            consultDetail.consultTemp = {};
            consultDetail.consultTemp = $rootScope.consultTemp;
            consultDetail.detailStatus = 'empty';
            consultDetail.detailMessage = '';
            consultDetail.detailModel.id_admision = !consultDetail.isInclude ? $routeParams.idConsulta : parentInclude.includeResultData.idConsulta;
            getRequisitionDetail();
        }

        consultDetail.goBack = function () {
            if (!consultDetail.isInclude) {
                $rootScope.navigate.go('/requisition/consult');
            } else {
                parentInclude.includeResult = "";
            }            
        };

        init();
    }]);