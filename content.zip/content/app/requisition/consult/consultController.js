﻿app.controller("consultController", ['$scope', '$rootScope', 'paramsPromise', 'toolsForm', 'reqConsultSource',
    function ($scope, $rootScope, paramsPromise, toolsForm, reqConsultSource) {
        var consult = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;


        var isInclude = $scope.fromInclude || false;       
        //console.log("include = " + isInclude);

        var getOffice = function () {
            paramsPromise.getParametrics(1, "oficinas").then(function (data_) {
                var data = data_.data;
                if (data != undefined && data != null) {
                    var result = angular.fromJson(data);
                    consult.filtroModel.statusDDLOffice = data_.status;
                    consult.officeListOf = JSON.parse(JSON.stringify(result.oficinas))
                } else {
                    $log.warn("No se han podido consultar las oficinas para listar");
                }
            })
        };

        var getRequisition = function () {
            if (consult.filtroModel.status == null || consult.filtroModel.status == 'undefined') {
                consult.filtroModel.status = "";
            }
            if (consult.filtroModel.office == null || consult.filtroModel.office == 'undefined') {
                consult.filtroModel.office = "";
            }

            consult.startSearch = true;

            var sendParams = {
                IdRequisition: consult.filtroModel.requisitionNum || -1,               
                Document: consult.filtroModel.documentNum || -1,
                DocumentType: consult.filtroModel.documentType || "",
                Status: consult.filtroModel.status.id || -1,
                Store:consult.filtroModel.office.id || -1,
                Surnames: consult.filtroModel.apellidoCliente || "",
                UserName: consult.filtroModel.nombreCliente || "",
                TransactType: -1,               
                Date1: consult.filtroModel.fechaInicial || "",
                Date2: consult.filtroModel.fechaFinal || "",                
                Profile: 'DIR',
            }

            reqConsultSource.getRequisitions(sendParams).then(function (data_) {
                    consult.startSearch = false;

                    var data = data_.data;
                    if (data != undefined && data != null) {
                        var result = angular.fromJson(data);
                        consult.filtroModel.statusRequisitionListOf = data_.status;
                        consult.requisitionListOf = JSON.parse(JSON.stringify(result))
                        consult.requisitionListOf_TotalItems = consult.requisitionListOf.length;

                        consult.searchedRequisition = true;
                    } else {
                        $log.warn("No se han podido consultar las solicitudes");
                    }
                })
        };


   /*     var getRequisitionStatus = function () {
            reqConsultSource.getRequisitionStatus().then(function (data_) {
                var data = data_.data;
                if (data != undefined && data != null) {
                    var result = angular.fromJson(data);
                    consult.filtroModel.statusRequisitionStatusListOf = data_.status;
                    consult.requisitionStatusListOf = JSON.parse(JSON.stringify(result))

                } else {
                    $log.warn("No se han podido consultar el listado de estados");
                }
            })
        };
        */
        //Funcion para inicializar Variables y campos
        var init = function () {
            consult.filtroModel = {};
            consult.filtroModel.goDetail = "/requisition/consult/";
            consult.filtroModel.statusDDLOffice = "empty"
            consult.filtroModel.statusRequisitionListOf = "empty"
            consult.filtroModel.statusRequisitionStatusListOf = "empty"
            consult.filtroModel.documentType = "1";
            consult.filtroModel.office = "";
            consult.filtroModel.status = "";
            consult.dateOptionsInit = toolsForm.dateOptions;
            consult.officeListOf = [];
            consult.documentTypeListOf = [];
            consult.requisitionListOf = [];
            consult.requisitionStatusListOf = [];
            $rootScope.consultTemp = {};
            getOffice();
            getRequisitionStatus();
        }

        var htmlLoadComponents = function () {
            consult.documentTypeListOf = params.getParam("parametrics_tiposIdentificacion");

            if (isInclude) {
                reloadFilterBefore();
            } else {
                $rootScope.paramsSearchRequisition = undefined;
            }

        }
        function reloadFilterBefore() {
            var data = $rootScope.paramsSearchRequisition;

            if (data) {
                if (data.idReq)
                    consult.filtroModel.requisitionNum = data.idReq;

                if (data.TypeDoc)
                    consult.filtroModel.documentType = data.TypeDoc;

                if (data.IdDoc)
                    consult.filtroModel.documentNum = data.IdDoc;

                if ((data.idReq || data.IdDoc) && data.TypeDoc) {
                    getRequisition();
                }
            }
        }


        consult.submitConsult = function () {
            getRequisition();
        }

        consult.goToDetail = function (idSolicitud, indice) {
            if (!isInclude) {
                $rootScope.consultTemp = consult.requisitionListOf[indice];
                //console.log("lo que tiene root", $rootScope.consultTemp)
                $rootScope.navigate.go(consult.filtroModel.goDetail + idSolicitud);
            } else {
                $rootScope.consultTemp = consult.requisitionListOf[indice];
                $scope.$parent.$parent.searchReq.includeResultData.idConsulta = idSolicitud;
                $scope.$parent.$parent.searchReq.includeResult = "/content/app_views/requisition/consult/consultDetailView.html";
            }

            $rootScope.paramsSearchRequisition = {
                idReq: consult.filtroModel.requisitionNum || undefined,
                TypeDoc: consult.filtroModel.documentType || undefined,
                IdDoc: consult.filtroModel.documentNum || undefined
            }
        }

        init();
        htmlLoadComponents();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    htmlLoadComponents();
                } else {
                    return false;
                }
            });



        consult.requisitionListOf_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
        consult.requisitionListOf_Current = 1;
        consult.requisitionListOf_TotalItems = 0;

    }]);