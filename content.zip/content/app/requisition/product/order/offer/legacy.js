﻿app.controller("offerLegacyController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;

        parent.finally.activeCancellationFlag = false;
        vm.legacyJson = [];

        vm.toggle = function () {
            vm.toggleActive = vm.toggleActive ? false : true;
        }
        vm.next = function () {
            //parent.productPath = parent.link.formBData;
            parent.productPath = parent.link.docFinger;
        }
        vm.back = function () {
            parent.productPath = parent.link.offerList;
        }



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                transformHtml: function (html) {
                    var legacyJson = [];
                    html = html && html.length > 0 ? html[1].descripcion : "";

                    if (html) {
                        var el = angular.element(html);

                        angular.forEach(el[0].children, function (item, index) {
                            var sub = angular.element(item);
                            var tit = angular.element(sub[0].children[0]);
                            var con = angular.element(sub[0].children[1]);
                            var inner = tit[0].innerHTML;

                            inner = inner.replace("&nbsp;", "");
                            tit[0].innerHTML = inner;

                            angular.element(tit[0].children[1]).remove();

                            var titleText = tit[0].innerHTML;
                            var descText = con[0].innerHTML;

                            legacyJson.push(
                                {
                                    id: index,
                                    title: titleText.replace("h3", "").replace("<", "").replace(">", ""),
                                    description: descText,
                                    collapse: index == 0 ? true : false
                                });
                        });
                    }

                    return legacyJson;
                },
            }
            return {                                                
                init: function () {
                    var txt = params.getParam("parametrics_textosJuridicos");

                    vm.legacyJson = local.transformHtml(txt);
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
