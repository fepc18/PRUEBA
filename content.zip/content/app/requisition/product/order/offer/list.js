﻿app.controller("offerListController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;

        parent.finally.activeCancellationFlag = false;
        vm.products = [];
        vm.enabledForCheckeds = false;

        vm.checked = function (id, verify) {
            verify = verify || false;

            vm.products[id].checked = !verify ? true : vm.products[id].checked ? false : true;
            vm.enabledForCheckeds = params.enableCheckedsProduct();
        }
        vm.next = function () {
            parent.productPath = parent.link.offerLegacy;
        }



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            return {
                init: function () {
                    vm.products = params.products;
                    vm.enabledForCheckeds = params.enableCheckedsProduct();
                }
            }
        }();
        base.init();

    }]);