﻿app.controller("otpFinallyController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var parent = $scope.$parent.product;

        parent.finally.activeCancellationFlag = false;

        vm.verify = parent.verifyOtp;
        vm.next = function () {  
            parent.productPath = parent.link.offerList;
        }
    }]);