﻿app.controller("otpCodeController", ['$scope', '$rootScope', 'otpSource',
    function ($scope, $rootScope, otpSource) {

        var vm = this;
        var parent = $scope.$parent.product;

        parent.finally.activeCancellationFlag = false;
        vm.otpCode = "";
        vm.status = "STOP";

        vm.back = function () {
            parent.productPath = parent.link.otpRegister;
        }
        vm.next = function () {
            vm.status = "PROCESS";

            otpSource.validateOtp(parent.productVars.phone, vm.otpCode).then(function (data_) {
                if (data_.status) {
                    var result = data_.data.result;
                    var status = data_.data.status;

                    if (status.code != "0501") {
                        if (result.MessageCode && result.MessageCode == "200") {

                            parent.productPath = parent.link.otpFinally;
                            parent.verifyOtp = true;

                            vm.status = "STOP";
                        } else {

                            vm.error = {
                                code: result.MessageCode,
                                message: result.Description,
                                invalid: true,
                                tryAgain: true
                            };
                            vm.status = "STOP";
                        }
                    } else {

                        vm.error = {
                            code: status.code,
                            message: "Hubo un error en el servicio de envío de código OTP: " + status.detail,
                            tryAgain: false
                        };
                        vm.status = "ERROR";
                    }
                } else {
                    vm.error = {
                        code: "0401",
                        message: "Hubo un error en el servicio de envío de código OTP: " + data_.data,
                        tryAgain: false
                    };
                    vm.status = "ERROR";
                }
            });          
        }
    }]);