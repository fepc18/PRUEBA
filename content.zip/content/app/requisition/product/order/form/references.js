﻿app.controller("formReferencesController", ['$scope', '$rootScope', 'toolsForm', 'fraudSource', '$log',
    function ($scope, $rootScope, toolsForm, fraudSource, $log) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formReferences";

        vm.sendForm = 0;      
        vm.kinships = [];
        vm.provinces = [];
        vm.typeReferences = [];

        vm.validateRequiredNested = function (field, fieldNested, clearCss) {
            clearCss = clearCss || false;

            if (vm[fieldNested] == '' || vm[fieldNested] == undefined || vm[fieldNested] == null) {
               
                return true;
            } else {
                toolsForm.clearCssError($scope[formName], field);

                return false;
            }            
        }
        vm.changeKinship = function () {
            var r = vm.typeReference;
            if (r != "FA") {
                vm.kinship = "10";
            } else {
                if (vm.kinship == "10") vm.kinship = null;
            }
        }

        vm.back = function () {
            parent.productPath = parent.link.formEcoActivity;
        };
        vm.submit = function () {
            if ($scope[formName].$invalid) {               
                vm.sendForm = -1;
                return false;

            } else {               
                var value = base.dataForFraud();

                vm.initFraud = true;
                fraudSource.validate(JSON.stringify(value)).then(function (data_) {
                    var result = false;

                    if (data_.status) {
                        var d = data_.data;

                        if (d.fraudeConsultarResp.informacionOperacion.codigoOperacion == "0000") {
                            if (d.fraudeConsultarResp.resultados.esFraude == false) {
                                $log.info("200 Validación de Fraude Exitosa.");

                                base.saveLocalData();
                                parent.productPath = parent.link.formNormData;
                                vm.sendForm = 1;

                                result = true;

                            } else {
                                vm.error = {
                                    status: true,
                                    message: "Cliente Rechazado por Políticas Internas."// - Validación Fraude",
                                }

                                /*******************************/
                                /*                             */
                                /*  FINALIZACION DE SOLICITUD  */
                                /*                             */
                                /*******************************/
                                parent.finally.result = "R";
                                parent.finally.message = vm.error.message;
                                parent.finally.createJson();
                            }
                        } else {
                            vm.error = {
                                status: true,                                
                                message: d.fraudeConsultarResp.informacionOperacion.glosaOperacion,
                            }
                        }

                    } else {
                        vm.error = {
                            status: true,
                            exception: true,
                            message: data_.data,
                        }
                        $log.error("500 Error en el servicio de Fraudes: " + vm.error.message);
                    }

                    vm.initFraud = false;
                
                    return result;
                })
                


                /*#############*/
                //base.saveLocalData();
                ////parent.productPath = parent.link.formNormData;
                //vm.sendForm = -1;
                //vm.error = {
                //    status: true,
                //    message: "Cliente Rechazado por Políticas Internas. - Validación Fraude",
                //}
                //return true;
                /*#############*/
            }
        };



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                valueFraud: {},
                valueFraudForDocument: function () {
                    var data = vm.data_formbasicdata;

                    if (data && data.documentId)
                        valueFraud.fraudeConsultarReq.persona.push({
                            tipoPersona: "Titular",
                            documentoIdentidad: {
                                tipoDocumento: data.documentType,
                                numeroDocumento: data.documentId
                            }
                        });

                    if (data && data.documentIdSpouce)
                        valueFraud.fraudeConsultarReq.persona.push({
                            tipoPersona: "Adicional",
                            documentoIdentidad: {
                                tipoDocumento: data.documentTypeSpouce,
                                numeroDocumento: data.documentIdSpouce
                            }
                        });
                },
                valueFraudForPhone: function (data) {
                    var data = vm.data_formbasicdata;
                    var dataAD = vm.data_formbasicdataadd;
                    var dataEC = vm.data_formeconomicactivity;

                    if (dataAD && data && dataAD.residencePhone)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: data.residenceLocalization.idCiudad,
                            numeroTelefono: dataAD.residencePhone
                        });

                    if (dataEC && dataEC.phoneProvider)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataEC.providerLocalization.idCiudad,
                            numeroTelefono: dataEC.phoneProvider
                        });

                    if (dataEC && dataEC.phoneCompany)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataEC.companyLocalization.idCiudad,
                            numeroTelefono: dataEC.phoneCompany
                        });

                    if (dataEC && dataEC.phoneLessee)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataEC.lesseeLocalization.idCiudad,
                            numeroTelefono: dataEC.phoneLessee
                        });

                    //LOCAL:
                    if (vm.phone)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: vm.residenceLocalization.idCiudad,
                            numeroTelefono: vm.phone
                        });

                    //DEFAULT:
                    if (valueFraud.fraudeConsultarReq.telefono.length <= 1) {
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: "1114",
                            numeroTelefono: "0000000"
                        });
                    }
                },
                valueFraudForCellPhone: function (data) {
                    var data = vm.data_formbasicdata;

                    if (data && data.cellphone)
                        valueFraud.fraudeConsultarReq.celular.push(data.cellphone);

                    if (data && data.cellphoneSpouce)
                        valueFraud.fraudeConsultarReq.celular.push(data.cellphoneSpouce);

                    //LOCAL:
                    if (vm.cellphone)
                        valueFraud.fraudeConsultarReq.celular.push(vm.cellphone);

                    //DEFAULT:
                    if (valueFraud.fraudeConsultarReq.celular.length <= 1) {
                        valueFraud.fraudeConsultarReq.celular.push("0000000000");
                    }
                },
                valueFraudForCompany: function (data) {
                    var data = vm.data_formeconomicactivity;

                    if (data && data.companyName)
                        valueFraud.fraudeConsultarReq.empresa.push(data.companyName);

                    //DEFAULT:
                    if (valueFraud.fraudeConsultarReq.empresa.length == 1)
                        valueFraud.fraudeConsultarReq.empresa.push(data.companyName);

                    ////DEFAULT:
                    //valueFraud.fraudeConsultarReq.empresa.push("-");
                }
            }
            return {
                dataForFraud: function () {
                    valueFraud = {
                        fraudeConsultarReq: {
                            cabecera: {
                                country: "CO",
                                channel: "Web",
                                IOsID: "4562"
                            },
                            persona: [],
                            telefono: [],
                            celular: [],
                            empresa: []
                        }
                    }
                    
                    local.valueFraudForDocument();
                    local.valueFraudForPhone();
                    local.valueFraudForCellPhone();
                    local.valueFraudForCompany();

                    return valueFraud;
                },
                saveLocalData: function () {
                    var data = {
                        nameReference: vm.nameReference || null,
                        residenceLocalization: vm.residenceLocalization || null,
                        phone: vm.phone || null,
                        kinship: vm.kinship || null,
                        cellphone: vm.cellphone || null,
                        typeReference: vm.typeReference || null,
                        documentReference: vm.documentReference || null,
                    }

                    $rootScope.storage.set("form_references", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_references"));
                    var loaded = false;

                    if (data != null) {
                        vm.nameReference = data.nameReference || undefined;
                        vm.residenceLocalization = data.residenceLocalization || undefined;                       
                        vm.phone = data.phone || undefined;
                        vm.kinship = data.kinship || undefined;
                        vm.cellphone = data.cellphone || undefined;
                        vm.typeReference = data.typeReference || undefined;
                        vm.documentReference = data.documentReference || undefined;

                        loaded = true;
                    }
                    return loaded;
                },
                getLocalization: function () {
                    var loc = params.getParam("parametrics_localizaciones");  
                    var prov = [];

                    prov = toolsForm.localization.getAll(angular.fromJson(loc), "COLOMBIA");

                    return prov;
                },

                init: function () {
                    vm.kinships = params.getParam("parametrics_parentescos");
                    vm.typeReferences = [
                            {
                                id: "FA",
                                description: "Familiar"
                            },
                            {
                                id: "PE",
                                description: "Personal"
                            }
                    ];
                    vm.provinces = base.getLocalization();

                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));
                    vm.data_formbasicdataadd = angular.fromJson($rootScope.storage.get("form_basic_data_additional"));
                    vm.data_formeconomicactivity = angular.fromJson($rootScope.storage.get("form_economic_activity"));
                    
                    var load = base.loadLocalData();
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
