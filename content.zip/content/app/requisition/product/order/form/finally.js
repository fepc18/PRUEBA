﻿app.controller("formFinallyController", ['$scope', '$rootScope', 'toolsForm', 'jsonStructure', 'reqInsertSource', '$filter', '$log', 'memory',
    function ($scope, $rootScope, toolsForm, jsonStructure, reqInsertSource, $filter, $log, memory) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formFinally";

        vm.result = {
            state: false,
            code: "",
            message: "",
            infoLast: ""
        }
        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var basic = memory.storage.get("form_basic_data");
        var badic = memory.storage.get("form_basic_data_additional");
        var econo = memory.storage.get("form_economic_activity");
        var addic = memory.storage.get("form_basic_data_additional");
        var addCard = memory.storage.get("form_additional_card");
        var refe = memory.storage.get("form_references");

        var jsonXml = {
            xmlRequisition: function () {
                var req = vm.json.Cliente;
                req.fechaSolicitud = ""; //$filter("date")(req.fechaSolicitud, "dd/MM/yyyy");

                var d = {
                    Document: basic.ING_CLI_NUM_ID_CLIE,
                    DocumentType: basic.ING_CLI_TIP_DOC,
                    XmlData: "<ROOT>" +
                                "<SLC_FECHA>" + req.fechaSolicitud + "</SLC_FECHA>" +
                                "<SLC_USUARIO>" + req.usuario + "</SLC_USUARIO>" +
                                "<SLC_CANAL>" + req.canal + "</SLC_CANAL>" +
                                "<SLC_TERMINAL>" + req.terminal + "</SLC_TERMINAL>" +
                                "<SLC_NUM_DOCUMENTO>" + (basic && basic.documentId || "") + "</SLC_NUM_DOCUMENTO>" +
                                "<SLC_TIPO_DOCUMENTO>" + (basic && basic.documentType || "") + "</SLC_TIPO_DOCUMENTO>" +
                                "<SLC_OFICINA>" + req.idOficina + "</SLC_OFICINA>" +
                                "<SLC_DIA_PAGO>" + (badic && badic.payday || "") + "</SLC_DIA_PAGO>" +
                             "</ROOT>",
                };

                return d;
            },
            xmlClient: function (id) {
                var gender = basic && basic.gender || "";
                gender = gender != "" ? basic.gender.toLowerCase() == "masculino" ? "M" : "F" : "";

                var xml = "<ROOT>" +
                                "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                                "<SLP_NUM_DOCUMENTO>" + (basic && basic.documentId || "") + "</SLP_NUM_DOCUMENTO>" +
                                "<SLP_TIPO_DOCUMENTO>" + (basic && basic.documentType || "") + "</SLP_TIPO_DOCUMENTO>" +
                                "<SLP_PRIMER_APELLIDO>" + (basic && basic.surname1 || "") + "</SLP_PRIMER_APELLIDO>" +
                                "<SLP_SEGUNDO_APELLIDO>" + (basic && basic.surname2 || "") + "</SLP_SEGUNDO_APELLIDO>" +
                                "<SLP_PRIMER_NOMBRE>" + (basic && basic.name1 || "") + "</SLP_PRIMER_NOMBRE>" +
                                "<SLP_SEGUNDO_NOMBRE>" + (basic && basic.name2 || "") + "</SLP_SEGUNDO_NOMBRE>" +
                                "<SLP_NACIMIENTO_FEC>" + base.formatDate(basic && basic.birthDate || "") + "</SLP_NACIMIENTO_FEC>" +
                                "<SLP_NACIMIENTO_DEPTO>" + base.getGeoData(basic && basic.birthLocalization || "", 2) + "</SLP_NACIMIENTO_DEPTO>" +
                                "<SLP_NACIMIENTO_MPIO>" + base.getGeoData(basic && basic.birthLocalization || "", 3) + "</SLP_NACIMIENTO_MPIO>" +
                                "<SLP_GENERO>" + gender + "</SLP_GENERO>" +
                                "<SLP_NACIONALIDAD>" + (basic && basic.nationality || "") + "</SLP_NACIONALIDAD>" +
                                "<SLP_EPS>" + (badic && badic.eps.nombre || "") + "</SLP_EPS>" +
                                "<SLP_ESTADO_CIVIL>" + (basic && basic.civilStatus || "") + "</SLP_ESTADO_CIVIL>" +
                             "</ROOT>";

                return xml;
            },
            xmlSpouse: function (id) {
                var xml = "<ROOT>" +
                                "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                                "<SLCY_NUM_DOCUMENTO_CNY>" + (basic && basic.documentIdSpouce || "") + "</SLCY_NUM_DOCUMENTO_CNY>" +
                                "<SLCY_TIPO_DOCUMENTO_CNY>" + (basic && basic.documentTypeSpouce || "") + "</SLCY_TIPO_DOCUMENTO_CNY>" +
                                "<SLCY_PRIMER_APELLIDO>" + (basic && basic.surnameSpouce || "") + "</SLCY_PRIMER_APELLIDO>" +
                                "<SLCY_SEGUNDO_APELLIDO></SLCY_SEGUNDO_APELLIDO>" +
                                "<SLCY_PRIMER_NOMBRE>" + (basic && basic.nameSpouce || "") + "</SLCY_PRIMER_NOMBRE>" +
                                "<SLCY_SEGUNDO_NOMBRE></SLCY_SEGUNDO_NOMBRE>" +
                                "<SLCY_ACTIVIDAD>" + (basic && basic.activitySpouce || "") + "</SLCY_ACTIVIDAD>" +
                                "<SLCY_INGRESOS>" + (basic && basic.totalIncome || "0") + "</SLCY_INGRESOS>" +
                                "<SLCY_EGRESOS>" + (basic && basic.totalExpend || "0") + "</SLCY_EGRESOS>" +
                             "</ROOT>";

                return xml;
            },
            xmlAdditional: function (id) {
                var req = vm.json.Cliente;

                req.fechaSolicitud = ""; // $filter("date")(req.fechaSolicitud, "dd/MM/yyyy");
                basic.gender = basic.gender.toLowerCase() == "masculino" ? "M" : "F";

                var xml = "<ROOT>" +
                                "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                                "<SDC_NUMERO_DOC>" + (basic && basic.documentId || "") + "</SDC_NUMERO_DOC>" +
                                "<SDC_TIPO_DOC>" + (basic && basic.documentType || "") + "</SDC_TIPO_DOC>" +
                                "<SDC_CIUDAD_EXP>" + base.getGeoData(basic && basic.expeditionLocalization || "", 3) + "</SDC_CIUDAD_EXP>" +
                                "<SDC_DEPTO_EXP>" + base.getGeoData(basic && basic.expeditionLocalization || "", 2) + "</SDC_DEPTO_EXP>" +
                                "<SDC_FECHA_EXP>" + base.formatDate(basic && basic.documentExpDate) + "</SDC_FECHA_EXP>" +
                                "<SDC_PRIMER_APELLIDO>" + (basic && basic.surname1 || "") + "</SDC_PRIMER_APELLIDO>" +
                                "<SDC_SEGUNDO_APELLIDO>" + (basic && basic.surname2 || "") + "</SDC_SEGUNDO_APELLIDO>" +
                                "<SDC_PRIMER_NOMBRE>" + (basic && basic.name1 || "") + "</SDC_PRIMER_NOMBRE>" +
                                "<SDC_SEGUNDO_NOMBRE>" + (basic && basic.name2 || "") + "</SDC_SEGUNDO_NOMBRE>" +
                                "<SDC_NACIONALIDAD>" + (basic && basic.nationality || "") + "</SDC_NACIONALIDAD>" +
                                "<SDC_DIRECCION>" + (addic && addic.address || "") + "</SDC_DIRECCION>" +
                                "<SDC_BARRIO>" + (addic && addic.district || "") + "</SDC_BARRIO>" +
                                "<SDC_CIUDAD>" + base.getGeoData(basic && basic.residenceLocalization || "", 3) + "</SDC_CIUDAD>" +
                                "<SDC_DEPARTAMENTO>" + base.getGeoData(basic && basic.residenceLocalization || "", 2) + "</SDC_DEPARTAMENTO>" +
                                "<SDC_TELEFONO>" + (basic && basic.cellphoneSpouce || "") + "</SDC_TELEFONO>" +
                                "<SDC_PARENTESCO>" + (addCard && addCard.kinshipPrincipal || 1) + "</SDC_PARENTESCO>" +
                                "<SDC_FECHA_NACIMIENTO>" + base.formatDate(basic && basic.birthDate || "") + "</SDC_FECHA_NACIMIENTO>" +
                                "<SDC_GENERO>" + (basic && basic.gender || "") + "</SDC_GENERO>" +
                                "<SDC_USUARIO_PROMOTOR>" + req.idAsesor + "</SDC_USUARIO_PROMOTOR>" +  //pendiente
                                "<SDC_EMPRESA_TRAB>" + (econo && econo.companyName || "") + "</SDC_EMPRESA_TRAB>" +
                                "<SDC_ACTIVIDAD_ECO>" + (basic && basic.activity || "") + "</SDC_ACTIVIDAD_ECO>" +
                                "<SDC_TEL_EMPRESA>" + (econo && econo.phoneCompany || "") + "</SDC_TEL_EMPRESA>" +
                                "<SDC_REGISTRO>" + req.fechaSolicitud + "</SDC_REGISTRO>" +  //pendiente
                                "<SDC_ESTADO>" + "0" + "</SDC_ESTADO>" +  //pendiente
                             "</ROOT>";

                return xml;
            },
            xmlFinancial: function (id) {
                var descIn = basic && basic.otherIncomeDescription || "";
                var descEg = basic && basic.otherExpendDescription || "";
                var desc = "Ingresos: " + descIn + ", Egresos: " + descEg;

                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" + //pendiente
                               "<SLFN_CAPTURA>" + "" + "</SLFN_CAPTURA>" + //pendiente
                               "<SLFN_TIPO_MOV>" + "I" + "</SLFN_TIPO_MOV>" + //pendiente
                               "<SLFN_VARIABLE>" + "" + "</SLFN_VARIABLE>" + //pendiente
                               "<SLFN_DESC_OTROS>" + desc + "</SLFN_DESC_OTROS>" +
                               "<SLFN_VALOR>" + 0 + "</SLFN_VALOR>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlLabor: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLLN_NUM_DOCUMENTO>" + (basic && basic.documentId || "") + "</SLLN_NUM_DOCUMENTO>" +
                               "<SLLN_TIPO_DOCUMENTO>" + (basic && basic.documentType || "") + "</SLLN_TIPO_DOCUMENTO>" +
                               "<SLLN_EMPRESA>" + (econo && econo.companyName || "") + "</SLLN_EMPRESA>" +
                               "<SLLN_ACTIVIDAD>" + (econo && econo.companyCIIU.codigo || "") + "</SLLN_ACTIVIDAD>" +
                               "<SLLN_OCUPACION>" + (basic && basic.activity) + "</SLLN_OCUPACION>" +
                               "<SLLN_CARGO>" + (econo && econo.actualCharge || "") + "</SLLN_CARGO>" +
                               "<SLLN_TIPO_VINCULACION>" + (econo && econo.contractType || "") + "</SLLN_TIPO_VINCULACION>" +
                               "<SLLN_FECHA_INGRESO>" + base.formatDate(econo && econo.companyStartDate || "") + "</SLLN_FECHA_INGRESO>" +
                               "<SLLN_FECHA_RETIRO>" + base.formatDate(econo && econo.companyEndDate || "") + "</SLLN_FECHA_RETIRO>" +
                               "<SLLN_PERMANENCIA>" + "" + "</SLLN_PERMANENCIA>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlReference: function (id) {
                var tel = (refe != null ? (refe.phone || refe.cellphone) : "");

                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLRN_TIPO_REFERENCIA>" + (refe && refe.typeReference || "") + "</SLRN_TIPO_REFERENCIA>" +
                               "<SLRN_NOMBRE>" + (refe && refe.nameReference || "") + "</SLRN_NOMBRE>" +
                               "<SLRN_IDENTIFICACION>" + (refe && refe.documentReference || "") + "</SLRN_IDENTIFICACION>" +
                               "<SLRN_RELACION>" + (refe && refe.kinship || "") + "</SLRN_RELACION>" +
                               "<SLRN_TELEFONO>" + tel + "</SLRN_TELEFONO>" +
                            "</ROOT>";

                return xml;
            },
            xmlAddres: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLDN_NUM_DOCUMENTO>" + (basic && basic.documentId || "") + "</SLDN_NUM_DOCUMENTO>" +
                               "<SLDN_TIPO_DOCUMENTO>" + (basic && basic.documentType || "") + "</SLDN_TIPO_DOCUMENTO>" +
                               "<SLDN_TIPO_DIRECCION>" + "0" + "</SLDN_TIPO_DIRECCION>" + //pendiente
                               "<SLDN_DEPARTAMENTO>" + base.getGeoData(basic.residenceLocalization || "", 2) + "</SLDN_DEPARTAMENTO>" +
                               "<SLDN_CIUDAD>" + base.getGeoData(basic.residenceLocalization || "", 3) + "</SLDN_CIUDAD>" +
                               "<SLDN_BARRIO>" + (badic.district || "") + "</SLDN_BARRIO>" +
                               "<SLDN_COMP_PRIMARIO_1>" + "" + "</SLDN_COMP_PRIMARIO_1>" + //pendiente
                               "<SLDN_COMP_PRIMARIO_2>" + "" + "</SLDN_COMP_PRIMARIO_2>" + //pendiente
                               "<SLDN_COMP_PRIMARIO_3>" + "" + "</SLDN_COMP_PRIMARIO_3>" + //pendiente
                               "<SLDN_COMP_SECUNDARIO_1>" + "" + "</SLDN_COMP_SECUNDARIO_1>" + //pendiente
                               "<SLDN_COMP_SECUNDARIO_2>" + "" + "</SLDN_COMP_SECUNDARIO_2>" + //pendiente
                               "<SLDN_COMPLEMENTO>" + "" + "</SLDN_COMPLEMENTO>" + //pendiente
                               "<SLDN_PUBLICIDAD>" + "" + "</SLDN_PUBLICIDAD>" + //pendiente
                               "<SLDN_NOTIFICACION>" + "" + "</SLDN_NOTIFICACION>" + //pendiente
                               "<SLDN_EXTRACTOS>" + "" + "</SLDN_EXTRACTOS>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlEmail: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLCN_TIPO_CORREO>" + "0" + "</SLCN_TIPO_CORREO>" + //pendiente
                               "<SLCN_CORREO>" + (basic && basic.email || "") + "</SLCN_CORREO>" +
                               "<SLCN_VERIFICADO>" + "" + "</SLCN_VERIFICADO>" + //pendiente
                               "<SLCN_PUBLICIDAD>" + "" + "</SLCN_PUBLICIDAD>" + //pendiente
                               "<SLCN_NOTIFICACION>" + "" + "</SLCN_NOTIFICACION>" + //pendiente
                               "<SLCN_EXTRACTOS>" + "" + "</SLCN_EXTRACTOS>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlFlags: function (id) {
                var xml = "<ROOT>" +
                               "<SLF_SOLICITUD>" + id + "</SLF_SOLICITUD>" +
                               "<SLF_TIPO_FLAG>" + "0" + "</SLF_TIPO_FLAG>" + //pendiente
                               "<SLF_ESTADO>" + "" + "</SLF_ESTADO>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlPeps: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLP_TIPO_PRODUCTO>" + "0" + "</SLP_TIPO_PRODUCTO>" + //pendiente
                               "<SLP_ASESOR>" + "Undefined" + "</SLP_ASESOR>" + //pendiente
                               "<SLP_ESTADO>" + "" + "</SLP_ESTADO>" + //pendiente
                               "<SLP_NUMERO_PRODUCTO>" + "" + "</SLP_NUMERO_PRODUCTO>" + //pendiente
                               "<SLP_CUPO_SUGERIDO>" + "0" + "</SLP_CUPO_SUGERIDO>" + //pendiente
                               "<SLP_CUPO_ASIGNADO>" + "0" + "</SLP_CUPO_ASIGNADO>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlIncrease: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SAC_TRAMA>" + "0" + "</SAC_TRAMA>" + //pendiente   
                               "<SAC_NUMERO_CUENTA>" + "" + "</SAC_NUMERO_CUENTA>" + //pendiente   
                               "<SAC_TIPO_DOC>" + "" + "</SAC_TIPO_DOC>" + //pendiente   
                               "<SAC_NUMERO_DOCUMENTO>" + "" + "</SAC_NUMERO_DOCUMENTO>" + //pendiente   
                               "<SAC_HABITO_PAGO_PROM>" + "" + "</SAC_HABITO_PAGO_PROM>" + //pendiente   
                               "<SAC_PUNTUALIDAD>" + "" + "</SAC_PUNTUALIDAD>" + //pendiente   
                               "<SAC_FECHA_APERTURA>" + base.formatDate(new Date()) + "</SAC_FECHA_APERTURA>" + //pendiente   
                               "<SAC_CUPO_ASIGNADO>" + "0" + "</SAC_CUPO_ASIGNADO>" + //pendiente   
                               "<SAC_SALDO>" + "0" + "</SAC_SALDO>" + //pendiente   
                               "<SAC_SOBRECUPO>" + "0" + "</SAC_SOBRECUPO>" + //pendiente   
                               "<SAC_CUOTA_RENUEVA>" + "0" + "</SAC_CUOTA_RENUEVA>" + //pendiente   
                               "<SAC_DIAS_MORA>" + "0" + "</SAC_DIAS_MORA>" + //pendiente   
                               "<SAC_MONTO_MORA>" + "0" + "</SAC_MONTO_MORA>" + //pendiente   
                               "<SAC_SCORE_BEHAVIOR>" + "" + "</SAC_SCORE_BEHAVIOR>" + //pendiente   
                               "<SAC_CUPO_ANTERIOR>" + "0" + "</SAC_CUPO_ANTERIOR>" + //pendiente   
                               "<SAC_MENSAJE_CONFIRMACION>" + "" + "</SAC_MENSAJE_CONFIRMACION>" + //pendiente   
                               "<SAC_CODIGO_MENSAJE>" + "" + "</SAC_CODIGO_MENSAJE>" + //pendiente   
                               "<SAC_FECHA_CREACION>" + base.formatDate(new Date()) + "</SAC_FECHA_CREACION>" + //pendiente   
                            "</ROOT>";

                return xml;
            },
            xmlCalculate: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLC_FECHA_PROCESO>" + base.formatDate(new Date()) + "</SLC_FECHA_PROCESO>" + //pendiente
                               "<SLC_INGRESO_PRINCIPAL>" + "0" + "</SLC_INGRESO_PRINCIPAL>" + //pendiente
                               "<SLC_CUPO_TARJETA>" + "0" + "</SLC_CUPO_TARJETA>" + //pendiente
                               "<SLC_CUPO_FINAL_PLUS>" + "0" + "</SLC_CUPO_FINAL_PLUS>" + //pendiente
                               "<SLC_CAPACIDAD_LIMPIA>" + "0" + "</SLC_CAPACIDAD_LIMPIA>" + //pendiente
                               "<SLC_OTRO_INGRESO_4>" + "0" + "</SLC_OTRO_INGRESO_4>" + //pendiente
                               "<SLC_OTRO_INGRESO_5>" + "0" + "</SLC_OTRO_INGRESO_5>" + //pendiente
                               "<SLC_INGRESO_NETO_BRUTO>" + "0" + "</SLC_INGRESO_NETO_BRUTO>" + //pendiente
                               "<SLC_COSTOS_ACT_PPAL>" + "0" + "</SLC_COSTOS_ACT_PPAL>" + //pendiente
                               "<SLC_INGRESO_NETO_DIRECTO>" + "0" + "</SLC_INGRESO_NETO_DIRECTO>" + //pendiente
                               "<SLC_GASTOS_PERSONALES>" + "0" + "</SLC_GASTOS_PERSONALES>" + //pendiente
                               "<SLC_GASTOS_PERSONALES_AUTO>" + "0" + "</SLC_GASTOS_PERSONALES_AUTO>" + //pendiente
                               "<SLC_GASTOS_PERSONALES_DEF>" + "0" + "</SLC_GASTOS_PERSONALES_DEF>" + //pendiente
                               "<SLC_GASTOS_ARRIENDO>" + "0" + "</SLC_GASTOS_ARRIENDO>" + //pendiente
                               "<SLC_GASTOS_CREDITO>" + "0" + "</SLC_GASTOS_CREDITO>" + //pendiente
                               "<SLC_GASTOS_NOMINA>" + "0" + "</SLC_GASTOS_NOMINA>" + //pendiente
                               "<SLC_GASTOS_OTROS>" + "0" + "</SLC_GASTOS_OTROS>" + //pendiente
                               "<SLC_TOTAL_EGRESOS>" + "0" + "</SLC_TOTAL_EGRESOS>" + //pendiente
                               "<SLC_CAPACIDAD_PAGO>" + "0" + "</SLC_CAPACIDAD_PAGO>" + //pendiente
                               "<SLC_CAPACIDAD_ENDEUDAMIENTO>" + "0" + "</SLC_CAPACIDAD_ENDEUDAMIENTO>" + //pendiente
                               "<SLC_CUPO_POLITICAS>" + "0" + "</SLC_CUPO_POLITICAS>" + //pendiente
                               "<SLC_CUPO_AUTOMATICO>" + "0" + "</SLC_CUPO_AUTOMATICO>" + //pendiente
                               "<SLC_CUPO_SUGERIDO>" + "0" + "</SLC_CUPO_SUGERIDO>" + //pendiente
                               "<SLC_SCORE>" + "0" + "</SLC_SCORE>" + //pendiente
                               "<SLC_SMLMV>" + "0" + "</SLC_SMLMV>" + //pendiente
                               "<SLC_ACT_ECONOMICA>" + "" + "</SLC_ACT_ECONOMICA>" + //pendiente
                               "<SLC_PROCESO>" + "" + "</SLC_PROCESO>" + //pendiente
                               "<SLC_EDAD>" + "0" + "</SLC_EDAD>" + //pendiente
                               "<SLC_TIPO_RESIDENCIA>" + "" + "</SLC_TIPO_RESIDENCIA>" + //pendiente
                               "<SLC_EXPERIENCIA_ACTIVIDAD>" + "0" + "</SLC_EXPERIENCIA_ACTIVIDAD>" + //pendiente
                               "<SLC_GENERO>" + "" + "</SLC_GENERO>" + //pendiente
                               "<SLC_ESTADO_CIVIL>" + "" + "</SLC_ESTADO_CIVIL>" + //pendiente
                               "<SLC_PERSONAS_CARGO>" + "0" + "</SLC_PERSONAS_CARGO>" + //pendiente
                               "<SLC_NIVEL_ESTUDIOS>" + "" + "</SLC_NIVEL_ESTUDIOS>" + //pendiente
                               "<SLC_TIPO_CONTRATO>" + "" + "</SLC_TIPO_CONTRATO>" + //pendiente
                               "<SLC_ID_TIENDA>" + "0" + "</SLC_ID_TIENDA>" + //pendiente
                               "<SLC_CUPO_CENTRALES>" + "0" + "</SLC_CUPO_CENTRALES>" + //pendiente
                               "<SLC_FACTOR_CATALOGO>" + "0" + "</SLC_FACTOR_CATALOGO>" + //pendiente
                               "<SLC_FACTOR_T1>" + "0" + "</SLC_FACTOR_T1>" + //pendiente
                               "<SLC_FACTOR_T2>" + "0" + "</SLC_FACTOR_T2>" + //pendiente
                               "<SLC_FACTOR_T3>" + "0" + "</SLC_FACTOR_T3>" + //pendiente
                               "<SLC_FACTOR_T4>" + "0" + "</SLC_FACTOR_T4>" + //pendiente
                               "<SLC_FACTOR_EDAD>" + "0" + "</SLC_FACTOR_EDAD>" + //pendiente
                               "<SLC_FACTOR_TIPO_RESIDENCIA>" + "0" + "</SLC_FACTOR_TIPO_RESIDENCIA>" + //pendiente
                               "<SLC_FACTOR_EXPERIENCIA_ACT>" + "0" + "</SLC_FACTOR_EXPERIENCIA_ACT>" + //pendiente
                               "<SLC_FACTOR_SEXO>" + "0" + "</SLC_FACTOR_SEXO>" + //pendiente
                               "<SLC_FACTOR_ESTADO_CIVIL>" + "0" + "</SLC_FACTOR_ESTADO_CIVIL>" + //pendiente
                               "<SLC_FACTOR_PERSONAS_CARGO>" + "0" + "</SLC_FACTOR_PERSONAS_CARGO>" + //pendiente
                               "<SLC_FACTOR_NIVEL_ESTUDIOS>" + "0" + "</SLC_FACTOR_NIVEL_ESTUDIOS>" + //pendiente
                               "<SLC_FACTOR_ACTIVIDAD_ECONOMICA>" + "0" + "</SLC_FACTOR_ACTIVIDAD_ECONOMICA>" + //pendiente
                               "<SLC_FACTOR_TIPO_CONTRATO>" + "0" + "</SLC_FACTOR_TIPO_CONTRATO>" + //pendiente
                               "<SLC_FACTOR_TIENDA>" + "0" + "</SLC_FACTOR_TIENDA>" + //pendiente
                               "<SLC_FLAG_CLINTON>" + "0" + "</SLC_FLAG_CLINTON>" + //pendiente
                               "<SLC_GLOSA>" + "" + "</SLC_GLOSA>" + //pendiente
                               "<SLC_ESTADO>" + "0" + "</SLC_ESTADO>" + //pendiente
                            "</ROOT>";

                return xml;
            },
            xmlReconsider: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SRC_OBSERVACIONES>" + "" + "</SRC_OBSERVACIONES>" + //pendiente  
                               "<SRC_FECHA_REGISTRO>" + "" + "</SRC_FECHA_REGISTRO>" + //pendiente  
                               "<SRC_ENVIAR_TR_DIRECTOR>" + "0" + "</SRC_ENVIAR_TR_DIRECTOR>" + //pendiente  
                               "<SLC_IDENTIFICADOR_NUEVA>" + "0" + "</SLC_IDENTIFICADOR_NUEVA>" + //pendiente  
                            "</ROOT>";

                return xml;
            },
            xmlActivity: function (id) {
                var xml = "<ROOT>" +
                               "<SLC_IDENTIFICADOR>" + id + "</SLC_IDENTIFICADOR>" +
                               "<SLEN_CIIU>" + "" + "</SLEN_CIIU>" + //pendiente  
                               "<SLEN_PERFIL>" + "" + "</SLEN_PERFIL>" + //pendiente  
                               "<SLEN_ACTIV_BANCO>" + (basic && basic.activity || "") + "</SLEN_ACTIV_BANCO>" + //pendiente  
                            "</ROOT>";

                return xml;
            },
        };

        var base = function () {
            return {
                getGeoData: function (data, section) {
                    if (data && data != "undefinde" && data != "null") {
                        switch (section) {
                            case 1:
                                return data.idPais;
                                break;
                            case 2:
                                return data.idDepartamento;
                                break;
                            case 3:
                                return data.idCiudad;
                                break;
                            default:
                                return data;
                                break;
                        }
                    } else {
                        return "";
                    }
                },
                formatDate: function (date) {
                    if (date && date != "undefined" && date != "null") {
                        var fdate = date; // $filter("date")(date, "dd/MM/yyyy");

                        return fdate;
                    } else {
                        return "";
                    }
                },
                reloadIdRequisition: function (id) {
                    $rootScope.storage.set("form_id_solicitud", id);

                    vm.json.Cliente.idSolicitud = id;
                    vm.json.Productos.idSolicitud = id;

                    //vm.json.Formularios[0].idSolicitud = id;
                    //vm.json.Formularios[1].idSolicitud = id;
                    //vm.json.Formularios[2].idSolicitud = id;
                    //vm.json.Formularios[3].idSolicitud = id;
                    //vm.json.Formularios[4].idSolicitud = id;
                    //vm.json.Formularios[5].idSolicitud = id;
                    //vm.json.Formularios[6].idSolicitud = id;
                    //vm.json.Formularios[7].idSolicitud = id;
                    //vm.json.Formularios[8].idSolicitud = id;
                },
                logInfo: function (result) {
                    switch (result) {
                        case "R":
                            $log.info("Solicitud Rechazada");
                            break;
                        case "C":
                            console.log("Solicitud Cancelada");
                            break;
                        case "F":
                            console.log("Solicitud Aprobada");
                            break;
                    }
                },
                init: function () {
                    var result = parent.finally.result;
                    if (result == "R") result = "F";

                    base.logInfo(result);

                    vm.result.infoLast = parent.finally.message || null;
                    vm.json = jsonStructure.create(result || "F");
                    vm.jsonSend = JSON.stringify(vm.json);
                    vm.jsonView = JSON.stringify(vm.json, null, 4);
                   
                    var dataJson = {
                        IdRequisition: vm.json.Cliente.idSolicitud,
                        Json: vm.jsonSend,
                    }

                    reqInsertSource.insertRequisitionJson(dataJson).then(function (data_) {
                        var code = "0";
                        var msg = "";

                        if (data_.status) {                            

                            if (data_.data.codigo == "200") {                               
                                msg = String.format("Registro de Solicitud <strong>{0}</strong><br/> Completo", dataJson.IdRequisition);

                                $log.info(msg);                
                                $rootScope.storage.clearItem("form_id_solicitud");
                            } else {                                
                                msg = String.format("Inconvenientes al registrar Solicitud <strong>{0}</strong><br/> {1}", dataJson.IdRequisition, data_.data.detalle);

                                $log.error(msg);
                            }                            
                            code = data_.data.codigo;

                            if (!vm.result.infoLast) vm.result.infoLast = msg;
                            vm.result.state = true;
                        } else {                            
                            code = "500";
                            msg = String.format("Error 500 Solicitud <strong>{1}</strong><br/> {0}", data_.data);
                            $log.error(msg);

                            vm.result.state = false;
                        }

                        vm.result.code = code;
                        vm.result.message = msg;
                    });
                    //vm.result.code = "200";
                    //vm.result.message = "Registro de Solicitud <strong>123</strong><br/> Completo";
                    //vm.result.state = true;



                    //#######################################



                    //$rootScope.storage.set("form_id_solicitud", data_.data.idRequisition)
                    //vm.jsonView = JSON.stringify(vm.json, null, 4);

                    //reqInsertSource.insertRequisition(jsonXml.xmlRequisition()).then(function (data_) {
                    //    if (data_.status) {
                    //        var msg = String.format("Registro de Solicitud # {0}", data_.data.idRequisition);
                    //        $log.info(msg);

                    //        $rootScope.storage.set("form_id_solicitud", data_.data.idRequisition)
                    //        vm.jsonView = JSON.stringify(vm.json, null, 4);

                    //        //var basic = memory.storage.get("form_basic_data");
                    //        var idreq = $rootScope.storage.get("form_id_solicitud");
                    //        var jsonXmlComplex = {
                    //            IdProduct: "",
                    //            IdRequisition: idreq,
                    //            Document: (basic && basic.documentId || ""),
                    //            DocumentType: (basic && basic.documentType || ""),
                    //            XmlClientData: jsonXml.xmlClient(idreq),
                    //            XmlSpouseData: jsonXml.xmlSpouse(idreq),
                    //            XmlAdditionalData: jsonXml.xmlAdditional(idreq),
                    //            XmlFinancialData: jsonXml.xmlFinancial(idreq),
                    //            XmlLaborData: jsonXml.xmlLabor(idreq),
                    //            XmlReferenceData: jsonXml.xmlReference(idreq),
                    //            XmlAddressData: jsonXml.xmlAddres(idreq),
                    //            XmlEmailData: jsonXml.xmlEmail(idreq),
                    //            XmlFlagsData: jsonXml.xmlFlags(idreq),
                    //            XmlPepsData: jsonXml.xmlPeps(idreq),
                    //            XmlIncreaseData: jsonXml.xmlIncrease(idreq),
                    //            XmlCalculateData: jsonXml.xmlCalculate(idreq),
                    //            XmlReconsiderData: jsonXml.xmlReconsider(idreq),
                    //            XmlActivityData: jsonXml.xmlActivity(idreq),
                    //        }

                    //        reqInsertSource.insertRequisitionXml(jsonXmlComplex).then(function (data_) {
                    //            if (data_.status) {
                    //                var msgTemp = "Adicional[OK]; " +
                    //                              "Financiera[OK]; " +
                    //                              "Laboral[OK]; " +
                    //                              "Referencia[OK]; " +
                    //                              "Direccion[OK]; " +
                    //                              "CorreoE[OK]; " +
                    //                              "Flags[OK]; " +
                    //                              "Peps[OK]; " +
                    //                              "Aumento Cupo[OK]; " +
                    //                              "Calculo Cupo[OK]; " +
                    //                              "Reconsiderar[OK]; " +
                    //                              "Actividad Eco[OK]; ";

                    //                var msg = String.format("Solicitud {0}; Cliente {1}; {2}", data_.data.idRequisition, data_.data.idClient, msgTemp);
                    //                $log.info(msg);
                    //            } else {
                    //                var msg = String.format("Error Solicitud: {0}", data_.data);
                    //                $log.error(msg);
                    //            }
                    //        });
                    //    } else {
                    //        var msg = String.format("Error al registrar y obtener Id de Solicitud: {0}", data_.data);
                    //        $log.error(msg);
                    //    }
                    //});
                }
            }
        }();
        base.init();

        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
