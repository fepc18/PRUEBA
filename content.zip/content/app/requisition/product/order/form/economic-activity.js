﻿app.controller("formEconomicActivityController", ['$scope', '$rootScope', '$filter', 'toolsForm', '$resource',
    function ($scope, $rootScope, $filter, toolsForm, $resource) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formEconomicActivity";
                
        vm.sendForm = 0;
        vm.contractTypes = [];
        vm.vehicleTypes = [];
        vm.provinces = [];
        vm.dateOptions = toolsForm.dateOptions;
        vm.dateOptionsEndDate = toolsForm.dateOptions;

        //console.log(vm.dateOptionsEndDate);

        vm.calculateDateOptionsEndDate = function () {
            vm.dateOptionsEndDate.minDate = new Date(vm.companyStartDate);
            vm.companyEndDate = "";
        }

        vm.back = function () {
            parent.productPath = parent.link.formBDataAdic;
        };
        vm.submit = function () {
            if ($scope[formName].$invalid) {
                vm.sendForm = -1;
                return false;
            } else {
                base.saveLocalData();
                parent.productPath = parent.link.formReferences;
                vm.sendForm = 1;
                return true;
            }
        };



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            return {
                saveLocalData: function () {
                    var data = {
                        companyName: vm.companyName || null,
                        companyLocalization: vm.companyLocalization || null,
                        companyAddress: vm.companyAddress || null,
                        actualCharge: vm.actualCharge || null,
                        phoneCompany: vm.phoneCompany || null,
                        contractType: vm.contractType || null,
                        provider: vm.provider || null,
                        phoneProvider: vm.phoneProvider || null,
                        extensionProvider: vm.extensionProvider || null,
                        providerLocalization: vm.providerLocalization || null,
                        capitalRentier: vm.capitalRentier || null,
                        investmentType: vm.investmentType || null,
                        mount: vm.mount || null,
                        entity: vm.entity || null,
                        companyEndDate: vm.companyEndDate || null,
                        companyStartDate: vm.companyStartDate || null,
                        companyCIIU: vm.companyCIIU || null,

                        /*-----------------------------------------*/
                        lessee: vm.lessee || null,
                        phoneLessee: vm.phoneLessee || null,
                        extensionLessee: vm.extensionLessee || null,
                        lesseeLocalization: vm.lesseeLocalization || null,
                        realEstateManagement: vm.realEstateManagement || null,
                        commercialValue: vm.commercialValue || null,

                        lessee2: vm.lessee2 || null,
                        phoneLessee2: vm.phoneLessee2 || null,
                        extensionLessee2: vm.extensionLessee2 || null,
                        lesseeLocalization2: vm.lesseeLocalization2 || null,
                        realEstateManagement2: vm.realEstateManagement2 || null,
                        commercialValue2: vm.commercialValue2 || null,

                        lessee3: vm.lessee3 || null,
                        phoneLessee3: vm.phoneLessee3 || null,
                        extensionLessee3: vm.extensionLessee3 || null,
                        lesseeLocalization3: vm.lesseeLocalization3 || null,
                        realEstateManagement3: vm.realEstateManagement3 || null,
                        commercialValue3: vm.commercialValue3 || null,
                        /*-----------------------------------------*/

                        vehicleType: vm.vehicleType || null,
                        licensePlate: vm.licensePlate || null,
                        extensionCompany: vm.extensionCompany || null,
                        nit: vm.nit || null,
                        activityDescription: vm.activityDescription || null,
                    }

                    $rootScope.storage.set("form_economic_activity", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_economic_activity"));
                    var loaded = false;
                                        
                    if (data != null) {
                        vm.companyName = data.companyName || undefined;
                        vm.companyLocalization = data.companyLocalization || undefined;
                        vm.companyAddress = data.companyAddress || undefined;
                        vm.actualCharge = data.actualCharge || undefined;
                        vm.phoneCompany = data.phoneCompany || undefined;
                        vm.contractType = data.contractType || undefined;
                        vm.provider = data.provider || undefined;
                        vm.phoneProvider = data.phoneProvider || undefined;
                        vm.extensionProvider = data.extensionProvider || undefined;
                        vm.providerLocalization = data.providerLocalization || undefined;
                        vm.capitalRentier = data.capitalRentier || undefined;
                        vm.investmentType = data.investmentType || undefined;
                        vm.mount = data.mount || undefined;
                        vm.entity = data.entity || undefined;
                        vm.companyEndDate  = data.companyEndDate ? new Date(data.companyEndDate) : undefined;
                        vm.companyStartDate = data.companyStartDate ? new Date(data.companyStartDate) : undefined;
                        vm.companyCIIU = data.companyCIIU || undefined;

                        /*-----------------------------------------*/
                        vm.lessee = data.lessee || undefined;
                        vm.phoneLessee = data.phoneLessee || undefined;
                        vm.extensionLessee = data.extensionLessee || undefined;
                        vm.lesseeLocalization = data.lesseeLocalization || undefined;
                        vm.realEstateManagement = data.realEstateManagement || undefined;
                        vm.commercialValue = data.commercialValue || undefined;

                        vm.lessee2 = data.lessee2 || undefined;
                        vm.phoneLessee2 = data.phoneLessee2 || undefined;
                        vm.extensionLessee2 = data.extensionLessee2 || undefined;
                        vm.lesseeLocalization2 = data.lesseeLocalization2 || undefined;
                        vm.realEstateManagement2 = data.realEstateManagement2 || undefined;
                        vm.commercialValue2 = data.commercialValue2 || undefined;

                        vm.lessee3 = data.lessee3 || undefined;
                        vm.phoneLessee3 = data.phoneLessee3 || undefined;
                        vm.extensionLessee3 = data.extensionLessee3 || undefined;
                        vm.lesseeLocalization3 = data.lesseeLocalization3 || undefined;
                        vm.realEstateManagement3 = data.realEstateManagement3 || undefined;
                        vm.commercialValue3 = data.commercialValue3 || undefined;
                        /*-----------------------------------------*/

                        vm.vehicleType = data.vehicleType || undefined;
                        vm.licensePlate = data.licensePlate || undefined;
                        vm.extensionCompany = data.extensionCompany || undefined;
                        vm.nit = data.nit || undefined;
                        vm.activityDescription = data.activityDescription || undefined;

                        loaded = true;
                    }
                    return loaded;
                },
                getLocalization: function () {
                    var loc = params.getParam("parametrics_localizaciones");
                    var prov = [];

                    prov = toolsForm.localization.getAll(angular.fromJson(loc), "COLOMBIA");

                    return prov;
                },
                validateActivityFields: function () {
                    var data = vm.data_formbasicdata;

                    /*#################*/
                    //data.activity = 10;
                    /*#################*/

                    var local = {
                        exist: function (ids) {
                            var d = data.activity;

                            if (d == 1) d = data.activitySpouce;
                            for (var i = 0; i < ids.length; ++i) {
                                if (ids[i] == d) {
                                    return true;
                                    break;
                                }
                            }
                            return false;                            
                        }
                    }

                    return {
                        companyName: local.exist([4, 5, 11, 8, 10, 9, 7, 13]),
                        nit: local.exist([7]),
                        companyLocalization: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        companyAddress: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        actualCharge: local.exist([4, 5, 11]),
                        phoneCompany: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        extensionCompany: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        companyStartDate: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        companyEndDate: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        companyCIIU: local.exist([4, 5, 11, 8, 10, 7, 13]),
                        contractType: local.exist([4, 5, 11]),
                        activityDescription: local.exist([7]),
                        provider: local.exist([7]),
                        phoneProvider: local.exist([7]),
                        extensionProvider: local.exist([7]),
                        providerLocalization: local.exist([7]),
                        capitalRentier: local.exist([12]),
                        investmentType: local.exist([12]),
                        mount: local.exist([12]),
                        entity: local.exist([12]),
                        lessee: local.exist([12]),
                        phoneLessee: local.exist([12]),
                        extensionLessee: local.exist([12]),
                        lesseeLocalization: local.exist([12]),
                        realEstateManagement: local.exist([12]),
                        commercialValue: local.exist([12]),
                        vehicleType: local.exist([13]),
                        licensePlate: local.exist([13]),
                    }
                },

                init: function () {
                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));
                   
                    vm.contractTypes = params.getParam("parametrics_tiposContratos");
                    vm.vehicleTypes = params.getParam("parametrics_tiposVehiculos");
                    vm.ciius = params.getParam("parametrics_ciius");
                    vm.provinces = base.getLocalization();
                    vm.visible = base.validateActivityFields();

                    var load = base.loadLocalData();                                      

                    vm.actualWork = vm.companyEndDate ? false : true;
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
