﻿app.controller("formForeignCurrencyController", ['$scope', '$rootScope', 'toolsForm',
    function ($scope, $rootScope, toolsForm) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formForeignCurrency";

        vm.sendForm = 0;
        vm.accountCurrencyTypes = [];
        vm.operationTypes = [];
        vm.currencyList = [];

        vm.back = function () {

            if (base.enableIfAdditionalCard()) {
                parent.productPath = parent.link.formAddCard;
            } else {
                parent.productPath = parent.link.formNormData;
            }  
        };
        vm.submit = function () {
            if ($scope[formName].$invalid) {
                vm.sendForm = -1;
                return false;
            } else {
                base.saveLocalData();
                parent.productPath = parent.link.formEvident;
                vm.sendForm = 1;
                return true;
            }
        };



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            return {
                enableIfAdditionalCard: function () {
                    var data = angular.fromJson($rootScope.storage.get("product_offer_checkeds"));
                    var result = false;

                    angular.forEach(data, function (item, index) {
                        if (item.id == "0" || item.description == "Tarjeta de Credito") {
                            result = true;
                        }
                    })
                    return result;
                },
                saveLocalData: function () {
                    var data = {
                        foreignCurrencyTransact: vm.foreignCurrencyTransact || null,
                        operationType: vm.operationType || null,
                        hasAccountForeignCurrency: vm.hasAccountForeignCurrency || null,
                        accountCurrencyType: vm.accountCurrencyType || null,
                        account: vm.account || null,
                        bank: vm.bank || null,
                        country: vm.country || null,
                        city: vm.city || null,
                        currency: vm.currency || null,
                        averageAmount: vm.averageAmount || null,
                    }

                    $rootScope.storage.set("form_foreign_currency", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_foreign_currency"));
                    var loaded = false;

                    if (data != null) {
                        vm.foreignCurrencyTransact = data.foreignCurrencyTransact || undefined;
                        vm.operationType = data.operationType || undefined;
                        vm.hasAccountForeignCurrency = data.hasAccountForeignCurrency || undefined;
                        vm.accountCurrencyType = data.accountCurrencyType || undefined;
                        vm.account = data.account || undefined;
                        vm.bank = data.bank || undefined;
                        vm.country = data.country || undefined;
                        vm.city = data.city || undefined;
                        vm.currency = data.currency || undefined;
                        vm.averageAmount = data.averageAmount || undefined;

                        loaded = true;
                    }
                    return loaded;
                },                             

                init: function () {
                    vm.accountCurrencyTypes = params.getParam("parametrics_tiposCuentasExtranjeras"); //params.tiposCuentasExtranjeras;
                    vm.operationTypes = params.getParam("parametrics_tiposOperacionesExtranjeras"); //params.tiposOperacionesExtranjeras;
                    vm.currencyList = params.getParam("parametrics_monedas");// params.monedas;

                    var load = base.loadLocalData();
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
