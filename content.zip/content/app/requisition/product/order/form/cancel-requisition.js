﻿app.controller("cancelRequisitionController", ['$scope', '$rootScope', 'toolsForm',
    function ($scope, $rootScope, toolsForm) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formCancelRequisition";

        vm.sendForm = 0;
        vm.back = function () {
            parent.productPath = parent.finally.backCancellationPath;
        };
        vm.submit = function () {
            if ($scope[formName].$invalid) {
                vm.sendForm = -1;

                return false;
            } else {
                base.saveLocalData();

                parent.finally.activeCancellationFlag = false;
                parent.finally.result = "C";
                parent.finally.createJson();

                return true;
            }
        };

        vm.reasons = [];

        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            return {
                generateIdCan: function () {
                    var d = new Date().getTime();
                    var r = Math.floor(Math.random() * (9999 - 5000)) + 5000;
                    var id = d + r;

                    return id;
                },
                saveLocalData: function () {
                    var data = {
                        id: base.generateIdCan(),
                        reason: vm.reason || null,
                        description: vm.description || null,
                    }

                    $rootScope.storage.set("form_cancel_requisition", data);
                },
                init: function () {
                    vm.reasons = params.getParam("parametrics_motivosCancelacion");
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
