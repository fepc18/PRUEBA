﻿app.controller("formEvidentController", ['$scope', '$rootScope', '$filter', 'toolsForm', 'evidentSource',
    function ($scope, $rootScope, $filter, toolsForm, evidentSource) {

        var vm = this;
        var parent = $scope.$parent.product;
        var formName = "formEvident";

        vm.fromLoaded = false;
        vm.sendForm = 0;
        vm.error = {
            status: true,
            message: "",
        }

        vm.back = function () {
            //parent.productPath = "content/app_views/requisition/product/order/form/additional-card.html";
        };
        vm.submit = function () {
            /*******************************/
            /*                             */
            /*  FINALIZACION DE SOLICITUD  */
            /*                             */
            /*******************************/
            if (!vm.error.status) {
                parent.finally.result = "F";
                parent.finally.message = "Solicitud finalizada correctamente!";
            } else {
                parent.finally.result = "R";
                parent.finally.message = "Evidente: " + vm.error.message;
            }
            //? PENDIENTE:?
            parent.finally.createJson();
        };
        vm.asks = [];
        vm.askResponse = [];
        vm.isCheckedAsk = false;

        vm.currentPage = 0;
        vm.totalItems = 0;
        vm.askCurrent = null;
        vm.send = false;

        vm.nextAsk = function (index) {
            vm.isCheckedAsk = false;
            vm.askCurrent = vm.asks[index];
        }
        vm.setAskChecked = function (item) {
            var index = vm.currentPage;
            base.saveAskSelected(vm.asks[index], item);
        }
        vm.validateAsks = function () {
            base.validationAsks();
        }
        vm.reset = function () {
            vm.send = false;
            vm.error.status = false;

        }

        vm.checkstyle = function (field) {
            if (vm.askResponse.length > 0 && vm.askResponse.length > vm.currentPage) {
                var find = vm.askResponse[vm.currentPage];

                if (find.idRespuestaField == field) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                formatDateFromJson: function (dateString) {
                    if (dateString != undefined || dateString != null) {
                        var iof = dateString.indexOf("-");

                        if (iof > 0) {
                            var spl = dateString.split("-");
                            return spl[2].substring(0, 2) + "/" + spl[1] + "/" + spl[0];
                        } else {
                            return dateString;
                        }
                    } else {
                        return "";
                    }
                },
                formatZeroLeft: function (val, zeroLeft) {
                    var max = parseInt(zeroLeft);

                    while (val.toString().length < max) {
                        val = "0" + val.toString();
                    }

                    return val;
                }
            }
            return {
                saveLocalData: function () {
                    var data = {

                    }

                    $rootScope.storage.set("form_evident", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_evident"));
                    var loaded = false;

                    if (data != null) {


                        loaded = true;
                    }
                    return loaded;
                },
                dataForAsks: function () {
                    var data = vm.data_formbasicdata;

                    var value = {
                        Head: {
                            country: "CO",
                            channel: "admisionWeb",
                            IOsID: ""
                        },
                        NumeroIdentificacion: data.documentId || "",
                        TipoDocumento: data.documentType || "",
                        Nombres: (data.name1 + (data.name2 ? " " + data.name2 : "")) || "",
                        PrimerApellido: data.surname1 || "",
                        SegundoApellido: data.surname2 || "",
                        FechaExpedicion: data.documentExpDate || "",

                    };
                    value.FechaExpedicion = local.formatDateFromJson(value.FechaExpedicion);

                    return value;
                },
                dataForValidation: function () {
                    var data = vm.data_formbasicdata;

                    /*#####*/
                    //data = {
                    //    documentType: "1",
                    //    documentId: "45258855"
                    //}
                    /*#####*/

                    var value = {
                        Head: {
                            country: "CO",
                            channel: "admisionWeb",
                            IOsID: ""
                        },
                        Answer: {
                            identificacionField: {
                                tipoField: data.documentType || "",
                                numeroField: data.documentId || "",
                            },
                            idCuestionarioField: vm.refAsk.id,
                            regCuestionarioField: vm.refAsk.register,
                            respuestaField: vm.askResponse
                        }
                    }

                    return value;
                },
                saveAskSelected: function (item, response) {
                    var find = $filter("filter")(vm.askResponse, { idPreguntaField: item.ordenField });

                    if (find.length == 0) {
                        vm.askResponse.push(
                            {
                                idPreguntaField: local.formatZeroLeft(item.ordenField, 2),
                                idRespuestaField: response,
                            }
                        );
                    } else {
                        var idx = 0;
                        angular.forEach(vm.askResponse, function (item, index) {
                            if (item.idPreguntaField == find[0].idPreguntaField) {
                                idx = index;
                            }
                        });
                        if (vm.askResponse[idx].idRespuestaField != response)
                            vm.askResponse[idx].idRespuestaField = response;
                    }
                    vm.isCheckedAsk = true;
                },

                getAsks: function () {
                    /*#############*/
                    //vm.loadingAsks = false;

                    //var str = '{"preguntaField":[{"respuestaField":[{"idField":"001","textoField":"SI"},{"idField":"002","textoField":"NO"}],"idField":"005003003","textoField":"USTED TIENE O HA TENIDO UNA CUENTA/CONTRATO/CREDITO CON DIRECTV","ordenField":1,"idRespuestaCorrectaField":"00","pesoField":3,"pesoFieldSpecified":true},{"respuestaField":[{"idField":"001","textoField":"6378"},{"idField":"002","textoField":"7299"},{"idField":"003","textoField":"2437"},{"idField":"004","textoField":"4666"},{"idField":"005","textoField":"NO TENGO TARJETA DE CREDITO CON LA ENTIDAD"}],"idField":"005002002","textoField":"CUALES SON LOS CUATRO ULTIMOS DIGITOS DE SU TARJETA DE CREDITO MASTERCARD ACTIVA/VIGENTE CON BANCO CORPBANCA (SANTANDER, HELM)","ordenField":2,"idRespuestaCorrectaField":"00","pesoField":1,"pesoFieldSpecified":true},{"respuestaField":[{"idField":"001","textoField":"CMR FALABELLA"},{"idField":"002","textoField":"UNIFACOOP"},{"idField":"003","textoField":"BANCO AV VILLAS (AHORRAMAS)"},{"idField":"004","textoField":"MACROFINANCIER A"},{"idField":"005","textoField":"CREDITITULOS"},{"idField":"006","textoField":"NINGUNA DE LAS ANTERIORES"}],"idField":"005003005","textoField":"CON CUAL DE LAS SIGUIENTES ENTIDADES TIENE MAYOR NUMERO DE PRODUCTOS ACTIVOS?","ordenField":3,"idRespuestaCorrectaField":"00","pesoField":3,"pesoFieldSpecified":true},{"respuestaField":[{"idField":"001","textoField":"CLASICA/ESTANDAR"},{"idField":"002","textoField":"ORO/GOLD"},{"idField":"003","textoField":"PLANTINO/PLATINUM"},{"idField":"004","textoField":"EMPRESARIAL/BUSSINES"},{"idField":"005","textoField":"NO TENGO TARJETA DE CREDITO CON LA ENTIDAD"}],"idField":"005002004","textoField":"DE QUE TIPO ES SU TARJETA DE CREDITO DE BCO COLPATRIA ?","ordenField":4,"idRespuestaCorrectaField":"00","pesoField":1,"pesoFieldSpecified":true}],"idField":"00009836","resultadoField":"01","registroField":4246270,"numIntentosAnoField":null,"numIntentosMesField":null,"numIntentosDiaField":null,"excluirClienteField":false,"alertasField":"false","respuestaAlertaField":"","codigoAlertaField":"00"}';
                    //var json = JSON.parse(str);

                    //vm.asks = [];
                    //angular.forEach(json.preguntaField, function (item, index) {
                    //    vm.asks.push(item);
                    //});
                    //vm.refAsk = {
                    //    id: json.idField,
                    //    register: json.registroField
                    //}
                    //vm.totalItems = parseInt(vm.asks.length) - 1;
                    //vm.nextAsk(0);
                    /*#############*/


                    var value = base.dataForAsks();
                    vm.loadingAsks = true;

                    evidentSource.getAsks(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;
                            if (d.status != null || d.status != undefined) {
                                if (d.status.code == "0200" && d.result.questionnaire && d.result.questionnaire.preguntaField) {
                                    var vec = d.result.questionnaire;

                                    vm.asks = [];
                                    vm.refAsk = {
                                        id: vec.idField,
                                        register: vec.registroField
                                    }

                                    angular.forEach(vec.preguntaField, function (item, index) {
                                        vm.asks.push(item);
                                    });

                                    vm.totalItems = parseInt(vm.asks.length) - 1;
                                    vm.nextAsk(0);

                                } else {
                                    vm.error = {
                                        status: true,
                                        message: d.status.detail,
                                    }
                                    vm.asks = [];
                                }
                            } else {
                                vm.error = {
                                    status: true,
                                    message: d.status.detail,
                                }
                                vm.asks = [];
                            }
                        } else {
                            vm.error = {
                                status: true,
                                message: data_.message,
                            }
                            vm.asks = [];
                        }

                        vm.loadingAsks = false;
                    });

                },
                validationAsks: function () {
                    /*#############*/
                    //var value = base.dataForValidation();
                    //vm.loadingValidation = true;
                    //vm.send = true;
                    //console.log(json);
                    //console.log(JSON.stringify(json));
                    /*#############*/

                    var value = base.dataForValidation();
                    vm.loadingValidation = true;
                    vm.send = true;

                    evidentSource.validationAsks(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;

                            if (d.status != null || d.status != undefined) {
                                if (d.status.code == "0200") {
                                    vm.error.status = false;

                                } else {
                                    vm.error.status = true;

                                    switch (d.status.code) {
                                        case "0201":
                                            vm.error.message = "El cliente no existe.";
                                            break;
                                        case "0203":
                                            vm.error.message = "Ha superado el número máximo de intentos por día.";
                                            break;
                                        case "0204":
                                            vm.error.message = "La validación NO fue exitosa.";
                                            break;
                                        default:
                                            vm.error.message = d.status.detail;
                                            break;
                                    }
                                }

                            } else {
                                vm.error.status = true;
                                vm.error.message = d.status.detail;                                
                            }
                        } else {                           
                            vm.error.status = true;
                            vm.error.message = data_.message;
                        }

                        vm.loadingValidation = false;
                    });

                },

                init: function () {
                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));

                    var load = base.loadLocalData();

                    base.getAsks();
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });


        /*#############*/
        //vm.send = true;
        //vm.loadingAsks = false;
        //vm.error = {
        //    status: true,
        //    message: "Error en el procesamiento de evidente."
        //}
        /*#############*/
    }]);
