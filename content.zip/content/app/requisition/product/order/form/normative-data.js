﻿app.controller("formNormativeDataController", ['$scope', '$rootScope', 'toolsForm',
    function ($scope, $rootScope, toolsForm) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formNormativeData";
                
        vm.sendForm = 0;
        vm.tools = toolsForm;
        vm.dateOptionsEndDate = toolsForm.dateOptions;
        vm.dateOptions = toolsForm.dateOptions;
        vm.relDateOptionsEndDate = toolsForm.dateOptions;
        vm.relDateOptions = toolsForm.dateOptions;
        vm.countries = [];
        vm.relTypes = [];

        vm.calculateDateOptionsEndDate = function () {
            vm.dateOptionsEndDate.minDate = new Date(vm.startDatePEP);
            vm.endDatePEP = null;
        }
           
        vm.calculateRelDateOptionsEndDate = function () {
            vm.relDateOptionsEndDate.minDate = new Date(vm.relStartDatePEP);
            vm.relEndDatePEP = null;
        }

        vm.back = function () {
            parent.productPath = parent.link.formReferences;
        };
        vm.submit = function () {
            if ($scope[formName].$invalid) {                
                vm.sendForm = -1;
                return false;
            } else {
                base.saveLocalData();

                if (base.enableIfAdditionalCard()) {
                    parent.productPath = parent.link.formAddCard;
                } else {
                    parent.productPath = parent.link.formForeignCur;
                }
                                
                vm.sendForm = 1;
                return true;
            }
        };
        vm.validateTIN = function () {
            //**DEPRECATED**

            //var d = vm.data_formbasicdata;
            //var eeuu = 332;

            //if (d && d.nationality == eeuu || d && d.residenceLocalization.idPais == eeuu || d && d.birthLocalization.idPais == eeuu) {
            //    return true;
            //} else {
            //    return false;
            //}
        }


        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            return {
                enableIfAdditionalCard: function(){
                    var data = angular.fromJson($rootScope.storage.get("product_offer_checkeds"));
                    var result = false;

                    angular.forEach(data, function (item, index) {
                        if (item.id == "0" || item.description == "Tarjeta de Credito") {
                            result = true;
                        }
                    })
                    return result;
                },
                saveLocalData: function () {
                    var data = {
                        isPoliticPerson: vm.isPoliticPerson || null,
                        nowPoliticPerson: vm.nowPoliticPerson || null,
                        startDatePEP: vm.startDatePEP || null,
                        endDatePEP: vm.endDatePEP || null,

                        relPoliticPerson: vm.relPoliticPerson || null,
                        relType: vm.relType || null,
                        relActualCharge: vm.relActualCharge || null,
                        nowRelPoliticPerson: vm.nowRelPoliticPerson || null,
                        relStartDatePEP: vm.relStartDatePEP || null,
                        relEndDatePEP: vm.relEndDatePEP || null,


                        isOtherNationality: vm.isOtherNationality || null,
                        otherNationality: vm.otherNationality || null,
                        isTaxResidenceOtherCountry: vm.isTaxResidenceOtherCountry || null,
                        otherCountry: vm.otherCountry || null,
                        numberTIN: vm.numberTIN || null,
                    }

                    $rootScope.storage.set("form_normative_data", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_normative_data"));
                    var loaded = false;

                    if (data != null) {
                        vm.isPoliticPerson = data.isPoliticPerson || undefined;
                        vm.nowPoliticPerson = data.nowPoliticPerson || undefined;
                        vm.startDatePEP = new Date(data.startDatePEP) || undefined;
                        vm.endDatePEP = new Date(data.endDatePEP) || undefined;

                        vm.relPoliticPerson = data.relPoliticPerson || undefined,
                        vm.relType = data.relType || undefined,
                        vm.relActualCharge = data.relActualCharge || undefined,
                        vm.nowRelPoliticPerson = data.nowRelPoliticPerson || undefined,
                        vm.relStartDatePEP = new Date(data.relStartDatePEP) || undefined,
                        vm.relEndDatePEP = new Date(data.relEndDatePEP) || undefined,

                        vm.isOtherNationality = data.isOtherNationality || undefined;
                        vm.otherNationality = data.otherNationality || undefined;
                        vm.isTaxResidenceOtherCountry = data.isTaxResidenceOtherCountry || undefined;
                        vm.otherCountry = data.otherCountry || undefined;
                        vm.numberTIN = data.numberTIN || undefined;

                        loaded = true;
                    }
                    return loaded;
                },
                getCountries: function () {                    
                    var loc = params.getParam("parametrics_paises");

                    return loc;
                },
                getRelTypes: function(){
                    var loc = params.getParam("parametrics_moRelacion");

                    return loc;
                },

                init: function () {
                    vm.countries = base.getCountries();
                    vm.relTypes = base.getRelTypes();

                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));

                    var load = base.loadLocalData();

                    if (vm.startDatePEP) vm.dateOptionsEndDate.minDate = new Date(vm.startDatePEP);
                    if (vm.relStartDatePEP) vm.relDateOptionsEndDate.minDate = new Date(vm.relStartDatePEP);
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
