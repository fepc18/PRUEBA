﻿app.controller("formBasicDataController", ['$scope', '$rootScope', '$filter', 'toolsForm',
    'infoBasicDataSource', 'restrictiveSource', 'toolsget', 'userResources', 'reqInsertSource', '$log',
    function ($scope, $rootScope, $filter, toolsForm,
        infoBasicDataSource, restrictiveSource, toolsget, userResources, reqInsertSource, $log) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formBasicData";
        var userData = {};

        parent.finally.activeCancellationFlag = false;

        vm.fromLoaded = false;
        vm.sendForm = 0;
        vm.tools = toolsForm;
        vm.basicDataLoaded = false;
        vm.initDataLoaded = false;
        vm.initRestrictive = false;
        vm.oldDataLoaded = "";
        vm.provinces = [];
        vm.genders = [];
        vm.countries = [];
        vm.emailDomains = [];
        vm.documentTypes = [];
        vm.jobs = [];
        vm.militariesForce = [];
        vm.militariesRank = [];
        vm.civilStatusL = [];
        vm.dateOptionsBirth = {};
        vm.dateOptionsExped = {};
        vm.dateOptions = toolsForm.dateOptions;

        vm.calculateSummaryAge = {
            months: function (valueControl) {
                valueControl = valueControl || "0,0";

                var aag = valueControl.split(",");
                var y = aag[0] * 12;
                var m = aag[1];

                return parseInt(y) + parseInt(m);
            },
            years: function (valueControl) {
                valueControl = valueControl || "0,0";

                var aag = valueControl.split(",");
                return aag[0];
            }
        }
        vm.calculateTotalIncome = function () {
            vm.totalIncome = parseFloat(vm.mainActivityIncome || 0) + parseFloat(vm.otherIncome || 0);
        };
        vm.calculateExpend = function () {
            vm.totalExpend = parseFloat(vm.otherExpend || 0) + parseFloat(vm.CEActivityIncome || 0);
        };
        vm.filterActivity = function (i) {
            return i.id == '2' || i.id == '5';
        };
        vm.filterJobsSpouce = function (i) {
            return i.id != '1';
        }
        vm.calculateHeritage = function () {
            var assets = vm.totalAssets || 0;
            var liabi = vm.totalLiabilities || 0;

            vm.totalHeritage = parseFloat(assets) - parseFloat(liabi);
        }
        vm.validateDescription = function (field, description) {
            if (!vm[field] || parseFloat(vm[field]) == 0) {
                vm[description] = '';

                toolsForm.clearCssError($scope[formName], description);
            } else {
                if (vm[description] == '') {
                    toolsForm.addCssError($scope[formName], description);
                }
            }
        }
        vm.changeExpDate = function (dateString) {
            var age = 18; //base.getAgeFromProd();

            vm.dateOptionsExped.initDate = toolsForm.nestedControlDate.addYears(age, dateString);
            vm.dateOptionsExped.minDate = toolsForm.nestedControlDate.addYears(age, dateString);
        }

        vm.setMilitariesRankFromForce = function (master, listSlave) {
            var ranks = params.getParam("parametrics_rangosFuerzas");
            ranks = angular.fromJson(ranks);

            var ob = vm[master];
            var find = $filter("filter")(vm.militariesForce, { id: ob });

            vm[listSlave] = $filter("filter")(ranks, { idFuerzaMilitar: find[0].id });
        };
        vm.hideIfNotConditionMaster = function (array, masterName, slaveName, propertyMaster, valueMaster) {
            var ob = vm[masterName];
            var find = $filter("filter")(array, { [propertyMaster]: ob });

            if (find[0][propertyMaster] == valueMaster) {
                vm["sh_" + slaveName] = false;
                vm[slaveName] = null;
            } else {
                vm["sh_" + slaveName] = true;
            }
        };
        vm.hideIfNotConditionMasterMultiple = function (array, masterName, slaveNames, propertyMaster, valueMasters) {
            var ob = vm[masterName];
            var find = $filter("filter")(array, { [propertyMaster]: ob });

            for (var i = 0; i < slaveNames.length; ++i) {
                var isvalue = function () {
                    for (var x = 0; x < valueMasters.length; ++x) {
                        if (find[0][propertyMaster] == valueMasters[x]) {
                            return true;
                        }
                    }
                };
                if (!isvalue()) {
                    vm["sh_" + slaveNames[i]] = false;
                    vm[slaveNames[i]] = null;
                } else {
                    vm["sh_" + slaveNames[i]] = true;
                }
            }
        };
        vm.setPropertyDocumentFromTypeDoc = function (itemName, slave, property, persist) {
            var ob = vm[itemName];
            var find = $filter("filter")(vm.documentTypes, { id: ob });

            vm[slave] = !persist ? null : vm[slave] || null;
            vm[itemName + "_" + property] = find[0][property];
        };
        vm.loadInfoBasicData = function () {
            if (vm.documentId != undefined && vm.documentId != "" && vm.documentId != null) {
                if (vm.oldDataLoaded != vm.documentId && vm.documentId.trim() != "") {
                    var value = base.dataForInfoBasic();

                    vm.initDataLoaded = true;
                    vm.warningLoadData = false;

                    infoBasicDataSource.getInfoBasic(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;

                            if (d.clienteInformacionGeneralObtenerResp.informacionOperacion.codigoOperacion == "00") {
                                //console.log(d);

                                base.reloadFromService(d.clienteInformacionGeneralObtenerResp.resultados);

                            } else {
                                vm.warningLoadData = true;
                                vm.warningText = d.clienteInformacionGeneralObtenerResp.informacionOperacion.glosaOperacion;
                            }

                        } else {
                            vm.warningLoadData = true;
                            vm.warningText = "no se pudieron precargar los datos para Información Básica";
                        }
                        vm.basicDataLoaded = true;
                        vm.initDataLoaded = false;
                    })
                    vm.oldDataLoaded = vm.documentId;
                }
            }
        }

        vm.back = function () {
            parent.productPath = parent.link.offerList;
        };
        vm.errorException = function () {
            parent.finally.result = "R";
            parent.finally.createJson();
        }
        vm.submit = function () {
            if ($scope[formName].$invalid) {
                vm.sendForm = -1;
                return false;
            } else {
                //######################
                //base.saveLocalData();
                ////parent.productPath = parent.link.formProdOffer;

                //vm.sendForm = 1;
                //vm.initRestrictive = true;

                //vm.error = {
                //    status: true,
                //    exception: false,
                //    message: "Cliente Rechazado por Políticas Internas. - Validación Listas Restrictivas"
                //}
                //parent.finally.result = "R";
                //vm.initRestrictive = false;

                ////return true;
                //######################


                if (vm.basicDataLoaded) {

                    var value = base.dataForRestrictive();
                    vm.initRestrictive = true;

                    base.fingerAuth();
                    base.restrictiveList(value);

                } else {
                    return false;
                }
            }
        };



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                formatDate: function (date) {
                    var d = date.split("-");
                    return d[0] + "-" + d[1] + "-" + d[2];
                }
            }
            return {
                generateIdSol: function () {
                    var storage = $rootScope.storage.get("form_id_solicitud");

                    if (!storage) {
                        //var d = new Date().getTime();
                        //var r = Math.floor(Math.random() * (9999 - 1000)) + 1000;
                        var id = toolsget.getRandomKey(); // d + r;

                        $rootScope.storage.set("form_id_solicitud", id);
                    }
                },
                reloadFromService: function (d) {
                    var data = d.cliente;

                    vm.surname1 = data.apellidoPaterno;
                    vm.birthDate = new Date(local.formatDate(data.fechaNacimiento));

                    var names = data.nombres.split(" ");
                    if (names.length > 1) {
                        vm.name1 = names[0];
                        vm.name2 = names[1];
                    } else {
                        vm.name1 = names[0];
                    }
                    vm.email = data.informacionContacto.correoElectronico.direccionCorreoElectronico;

                    parent.productVars.basicData_address = data.informacionContacto.direccion[0].direccionCompleta;
                    parent.productVars.basicData_phone = data.informacionContacto.telefono[0].numeroTelefono;
                },
                dataForInfoBasic: function () {
                    var value = {
                        clienteInformacionGeneralObtenerExpReq: {
                            cabecera: {
                                country: "CO",
                                channel: "Web",
                                IOsID: "0"
                            },
                            documentoIdentidad: {
                                tipoDocumento: vm.documentType,
                                numeroDocumento: vm.documentId
                            }
                        }
                    }

                    return value;
                },
                dataForRestrictive: function () {
                    var value = {
                        listasRestrictivasConsultarReq: {
                            cabecera: {
                                country: "CO",
                                channel: "Web",
                                IOsID: "0"
                            },
                            listaDocumentosIdentidad: {
                                documentoIdentidad: [
                                    {
                                        tipoDocumento: vm.documentType,
                                        numeroDocumento: vm.documentId
                                    }
                                ]
                            },
                            listaNombres: {
                                nombrePersona: [
                                  {
                                      apellidoPaterno: vm.surname1,
                                      nombres: (vm.name1 + " " + vm.name2).trim()
                                  }
                                ]
                            }
                        }
                    }

                    return value;
                },
                saveLocalData: function () {
                    var data = {
                        documentType: vm.documentType || null,
                        documentId: vm.documentId || null,
                        surname1: vm.surname1 || null,
                        surname2: vm.surname2 || null,
                        name1: vm.name1 || null,
                        name2: vm.name2 || null,
                        birthDate: vm.birthDate || null,
                        birthLocalization: vm.birthLocalization || null,
                        documentExpDate: vm.documentExpDate || null,
                        gender: vm.gender || null,
                        residenceLocalization: vm.residenceLocalization || null,
                        residenceTime: vm.residenceTime || null,
                        cellphone: vm.cellphone || null,
                        nationality: vm.nationality || null,
                        residenceTime: vm.residenceTime || null,
                        email: vm.email || null,
                        activity: vm.activity || null,
                        activityAge: vm.activityAge || null,
                        prevCompanyDuration: vm.prevCompanyDuration || null,
                        prevCompanyDate: vm.prevCompanyDate || null,
                        documentIdRef: vm.documentIdRef || null,
                        militaryForce: vm.militaryForce || null,
                        militaryRank: vm.militaryRank || null,
                        mainActivityIncome: vm.mainActivityIncome || null,
                        otherIncome: vm.otherIncome || null,
                        CEActivityIncome: vm.CEActivityIncome || null,
                        otherIncomeDescription: vm.otherIncomeDescription || null,
                        otherExpend: vm.otherExpend || null,
                        otherExpendDescription: vm.otherExpendDescription || null,
                        totalIncome: vm.totalIncome || null,
                        totalExpend: vm.totalExpend || null,
                        totalAssets: vm.totalAssets || null,
                        totalLiabilities: vm.totalLiabilities || null,
                        totalHeritage: vm.totalHeritage || null,
                        civilStatus: vm.civilStatus || null,
                        documentTypeSpouce: vm.documentTypeSpouce || null,
                        documentIdSpouce: vm.documentIdSpouce || null,
                        surnameSpouce: vm.surnameSpouce || null,
                        nameSpouce: vm.nameSpouce || null,
                        activitySpouce: vm.activitySpouce || null,
                        militaryForceSpouce: vm.militaryForceSpouce || null,
                        militaryRankSpouce: vm.militaryRankSpouce || null,
                        cellphoneSpouce: vm.cellphoneSpouce || null,
                        mainActivityIncomeSpouce: vm.mainActivityIncomeSpouce || null,
                        faEmployee: vm.faEmployee || null,
                        expeditionLocalization: vm.expeditionLocalization || null,
                        activityAgeSpouce: vm.activityAgeSpouce || null,
                    }

                    $rootScope.storage.set("form_basic_data", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_basic_data"));
                    var loaded = false;

                    if (data != null) {
                        vm.documentType = data.documentType || undefined;
                        vm.documentId = data.documentId || undefined;
                        vm.surname1 = data.surname1 || undefined;
                        vm.surname2 = data.surname2 || undefined;
                        vm.name1 = data.name1 || undefined;
                        vm.name2 = data.name2 || undefined;
                        vm.birthDate = data.birthDate ? new Date(data.birthDate) : undefined;
                        vm.birthLocalization = data.birthLocalization || undefined;
                        vm.documentExpDate = data.documentExpDate ? new Date(data.documentExpDate) : undefined;
                        vm.gender = data.gender || undefined;
                        vm.residenceLocalization = data.residenceLocalization || undefined;
                        vm.cellphone = data.cellphone || undefined;
                        vm.nationality = data.nationality || undefined;
                        vm.residenceTime = data.residenceTime || undefined;
                        vm.email = data.email || undefined;
                        vm.activity = data.activity || undefined;
                        vm.activityAge = data.activityAge || undefined;
                        vm.prevCompanyDuration = data.prevCompanyDuration || undefined;
                        vm.prevCompanyDate = data.prevCompanyDate ? new Date(data.prevCompanyDate) : undefined;
                        vm.documentIdRef = data.documentIdRef || undefined;
                        vm.militaryForce = data.militaryForce || undefined;
                        vm.militaryRank = data.militaryRank || undefined;
                        vm.mainActivityIncome = data.mainActivityIncome || undefined;
                        vm.otherIncome = data.otherIncome || undefined;
                        vm.CEActivityIncome = data.CEActivityIncome || undefined;
                        vm.otherIncomeDescription = data.otherIncomeDescription || undefined;
                        vm.otherExpend = data.otherExpend || undefined;
                        vm.otherExpendDescription = data.otherExpendDescription || undefined;
                        vm.totalIncome = data.totalIncome || undefined;
                        vm.totalExpend = data.totalExpend || undefined;
                        vm.totalAssets = data.totalAssets || undefined;
                        vm.totalLiabilities = data.totalLiabilities || undefined;
                        vm.totalHeritage = data.totalHeritage || undefined;
                        vm.civilStatus = data.civilStatus || undefined;
                        vm.documentTypeSpouce = data.documentTypeSpouce || undefined;
                        vm.documentIdSpouce = data.documentIdSpouce || undefined;
                        vm.surnameSpouce = data.surnameSpouce || undefined;
                        vm.nameSpouce = data.nameSpouce || undefined;
                        vm.activitySpouce = data.activitySpouce || undefined;
                        vm.militaryForceSpouce = data.militaryForceSpouce || undefined;
                        vm.militaryRankSpouce = data.militaryRankSpouce || undefined;
                        vm.cellphoneSpouce = data.cellphoneSpouce || undefined;
                        vm.mainActivityIncomeSpouce = data.mainActivityIncomeSpouce || undefined;
                        vm.faEmployee = data.faEmployee || "no";
                        vm.expeditionLocalization = data.expeditionLocalization || "";
                        vm.activityAgeSpouce = data.activityAgeSpouce || "";

                        vm.basicDataLoaded = true;
                        vm.oldDataLoaded = vm.documentId;

                        loaded = true;
                    }
                    return loaded;
                },
                getLocalization: function () {
                    var loc = params.getParam("parametrics_localizaciones");
                    var prov = [];

                    prov = toolsForm.localization.getAll(angular.fromJson(loc), "COLOMBIA");

                    return prov;
                },
                getGenders: function () {
                    return toolsForm.localGender();
                },
                getEmailDomains: function () {
                    return toolsForm.localEmailDomains();
                },
                getCountries: function () {
                    var loc = params.getParam("parametrics_paises");

                    return loc;
                },
                getAgeFromProd: function () {
                    var p = params.getParam("product_available_checkeds");

                    if (p) {
                        var age = vm.tools.getAgeFromProductSelected(p);

                        return age ? age.edadMinima : 18;
                    } else {
                        return 18;
                    }
                },
                getUserInfo: function () {
                    userResources.getInfoBasic.get(null, function (data_) {
                        if (data_.state) {
                            //console.log(data_.info);
                            userData = data_.info;
                        } else {
                            $log.warning("UserData: " + data_.message);
                            userData = null;
                        }
                    });
                },
                restrictiveList: function (value) {
                    restrictiveSource.validationList(JSON.stringify(value)).then(function (data_) {
                        var result = false;

                        if (data_.status) {
                            var d = data_.data;

                            if (d.listasRestrictivasConsultarResp.informacionOperacion.codigoOperacion == "0000") {

                                if (d.listasRestrictivasConsultarResp.resultados.encontradoEnListas == false) {
                                    base.saveLocalData();
                                    base.generateIdSol();

                                    parent.productPath = parent.link.formProdOffer;
                                    vm.sendForm = 1;

                                    result = true;
                                } else {
                                    vm.error = {
                                        status: true,
                                        message:
                                            "Cliente Rechazado por Políticas Internas." // - Validación Listas Restrictivas"
                                    }

                                    /*******************************/
                                    /*                             */
                                    /*  FINALIZACION DE SOLICITUD  */
                                    /*                             */
                                    /*******************************/
                                    parent.finally.result = "R";
                                    parent.finally.message = vm.error.message;
                                    parent.finally.createJson();

                                }

                            } else {
                                vm.error = {
                                    status: true,
                                    message: d.listasRestrictivasConsultarResp.informacionOperacion.glosaOperacion
                                }
                            }

                        } else {
                            vm.error = {
                                status: true,
                                exception: true,
                                message: data_.data
                            }
                        }

                        vm.initRestrictive = false;

                        return result;
                    });
                },
                fingerAuth: function () {
                    var finger = $rootScope.storage.get("form_finger");

                    var jsonFinger = {
                        Head: {
                            country: "CO",
                            channel: "Web",
                            User: userData.userName,
                            IdStore: userData.store
                        },
                        ClientIdentification: {
                            TipoIdentificacion: vm.documentType == "1" ? "CC" : "CE",
                            Identificacion: vm.documentId
                        },
                        Document: {
                            Fecha: toolsget.toFormatDate(new Date()), // "15/01/2017",
                            Oficina: userData.storeName, //"Calle 120",
                            Ciudad: userData.cityName, //"BOGOTÁ",
                            EsTramiteNormal: "True",
                            EsTramiteOptimo: "False",
                            EsTramiteRechazado: "False",

                            NombreFuncionario: userData.names, // "Jesus Aguilar",
                            CodigoFuncionario: userData.numberUser, //"1895822",
                            CargoFuncionario: userData.profileName,

                            NombreCliente: vm.name1 + (vm.name2 || "") + " " + vm.surname1 + (vm.surname2 || ""),
                            EsCedulaCiudadania: vm.documentType == "1" ? "True" : "False",
                            EsCedulaExtranjeria: vm.documentType == "2" ? "True" : "False",
                            IdentificacionCliente: vm.documentId,
                            LugarExpedicion: vm.expeditionLocalization.ciudadDepartamento,
                            Huella: finger.imageMin, // "Qk02sgAAAAAAADYAAAAoAAAAdgAAAIAAAAABABgAAAAAAAAAAADEDgAAxA4AAAAAAAAAAAAA/////////////////////////////////v7++fn5////Y2NjgYGBwMDA5+fn6urq4+Pj9vb2+/v76Ojo8vLy8vLy6urq8/Pz9/f38/Pz4+Pj3Nzc7+/v9fX1/f397Ozs7u7u2tra8PDw+/v78/Pz7e3t8vLy4eHh5OTk19fX5eXl8/Pz+vr69/f39vb2+vr6+Pj46enp39/f39/f6urq9vb2+Pj4+Pj48fHx+vr67+/v8vLy8vLy8/Pz8vLy8fHx+vr69PT0/Pz83Nzcz8/P19fX4+Pj7Ozs9PT0+vr68vLy9PT09fX19PT09/f36urq7Ozs9PT0+Pj4+Pj44+PjtLS08vLy9/f39fX17+/v+fn5+fn59vb28PDw+vr69vb26Ojo6+vr9vb26Ojo7u7u+Pj49vb2+fn58/Pz3d3doKCgvLy85OTkxMTEwMDA7u7u+/v78fHx7Ozs/Pz89vb29/f3///////////////////////////////////8/Pz9/f3///9ycnKQkJDg4ODq6ura2tro6Oj29vbo6Ojq6urz8/Pq6urs7Oz09PT29vbv7+/v7+/i4uLf39/h4eH19fXy8vLp6emqqqrm5ub09PTj4+PPz8/d3d3R0dHc3Nze3t7U1NTv7+/19fX19fX09PTk5OTa2trV1dXq6ury8vL7+/v6+vrz8/P4+Pjr6+vu7u74+Pj19fX4+Pj4+Pj8/Pz09PTr6+vk5OTk5OTh4eHo6Ojy8vL4+Pj4+Pj19fX29vb39/fq6urz8/P19fXy8vLq6urx8fHv7+/29vbu7u7AwMCwsLD29vb39/fo6Ojd3d3l5eX7+/v5+fnp6enu7u739/fx8fHl5eX29vbt7e3k5OT29vb7+/v09PT4+Pjk5OS5ubmcnJzb29ve3t7Ozs7l5eX5+fnx8fHj4+Pz8/P19fX5+fn///////////////////////////////////39/f7+/v///6KiotPT0/b29t3d3eTk5Pz8/PPz8+Dg4O3t7eXl5fLy8vHx8fPz8/f39+7u7vLy8uHh4dHR0dvb2/Dw8Orq6uLi4qSkpOTk5P39/fn5+fLy8vf39/j4+Pr6+vz8/Pb29vf39/X19fv7++3t7c7Ozufn5/n5+f39/fr6+vT09ODg4NLS0tDQ0NjY2PDw8Pf39/j4+Pf39/T09Obm5tbW1tTU1Nzc3PT09Pv7+/z8/Pv7+/b29vf39/r6+vHx8e3t7f39/fX19fj4+O3t7eHh4eTk5Orq6v39/f///8HBwcbGxvr6+vj4+PLy8uTk5OHh4fj4+PPz8/T09PPz8/b29vb29vLy8uXl5e7u7uvr6/Ly8vf39/Pz8/n5+fb29uvr66+vr7q6uuHh4ePj4+fn5/Ly8vr6+vDw8Ofn5/Pz8/n5+f///////////////////////////////////f39/v7+/v7+3d3d5OTk7u7u5OTk9fX19fX14+Pj7e3t7u7u8PDw9fX19PT09PT0+vr68PDw7u7u4ODgzs7Ozs7O7+/v7Ozs5+fnmpqa0NDQ/////v7+9/f39fX1+/v7+/v739/fy8vLubm539/f/Pz8+vr6+vr6+/v7/f397u7u0tLSxMTEwsLC1tbW7+/v9/f3/f39+/v7////1tbWzMzM09PT4ODg0dHR7Ozs+vr6+Pj4+/v7/f398/Pz7u7u7+/v39/f4eHh8/Pz8vLy4eHh4eHh6+vr7+/v+Pj48PDw/v7+xMTE2dnZ+vr69PT06urq5OTk5eXl/v7+9fX1+Pj4+vr67+/v5eXl9fX14+Pj5eXl9vb26urq8fHx8PDw+vr6+/v78vLyzs7OjY2N4ODg5eXl3Nzc39/f9/f38vLy9vb29/f3+/v7///////////////////////////////////9/f3+/v7+/v7s7Ozu7u729vbx8fH29vby8vLj4+Pr6+vp6en39/f19fXw8PDz8/P39/f4+Pj09PTn5+fV1dXf39/z8/Py8vLr6+vDw8PExMTQ0NDh4eHg4ODMzMzNzc3T09PPz8/S0tLW1tbz8/P7+/v19fXu7u7d3d3h4eHPz8/FxcXQ0NDt7e309PTw8PDk5OTm5ubt7e3q6urc3NzY2Njj4+P29vb19fX4+Pj39/fx8fHp6enk5OTj4+Pa2trq6urz8/Pu7u709PTm5ubt7e319fXz8/Pz8/P6+vr19fX9/f3MzMzp6eny8vLs7Ozm5ubf39/m5ub8/Pz29vb6+vr4+Pjy8vLZ2dnt7e34+Pjp6enw8PDu7u7t7e319fX39/f5+fn9/f3y8vKcnJy2trbf39+srKzOzs709PT39/fy8vLo6Oj5+fn///////////////////////////////////39/f39/f7+/vr6+vHx8fX19fj4+Orq6ufn5+rq6uHh4fLy8vf39/Pz8+/v7+7u7vj4+Pj4+Pn5+erq6tDQ0OLi4vf39/f39+rq6rW1tbW1tcfHx9XV1ejo6N/f3+bm5vDw8Pb29vX19fv7+/39/d3d3cXFxb+/v8bGxszMzN/f3+vr6/z8/P7+/tTU1MfHx8vLy9DQ0M/Pz/z8/PT09Pj4+Pf39/j4+Pr6+vz8/OLi4t/f39nZ2ebm5u3t7eXl5f39/f39/ebm5szMzObm5vX19f39/e/v7+3t7f7+/unp6fn5+cTExNzc3N3d3fPz8+3t7ePj4+Xl5f7+/vr6+vv7+/f39/f398TExOXl5fn5+ff39+/v7/X19evr6/T09Pn5+fj4+Pv7+/39/c7OznFxcc7OzqysrMbGxvPz8/n5+fn5+ebm5vDw8P///////////////////////////////////v7+/Pz8/v7++vr68PDw9vb2+/v75+fn6+vr6enp6enp9vb29vb28vLy7u7u8fHx9fX1+fn5+vr65+fny8vL4eHh9/f3+Pj49PT0xMTEv7+//f39+vr6+Pj49vb2/Pz89vb2+/v79fX12dnZu7u7xcXFyMjI4ODg9/f3+/v79/f39vb26enp09PTxMTEzMzM7+/v9PT08fHx8/PzwcHB5eXl8fHxycnJy8vLzMzM1NTU5+fn+vr6/Pz89fX18vLy4+Pjx8fHzMzM7u7u9/f38/Pz7u7uz8/Pzc3N1tbW3d3d5+fn1NTU6Ojo9vb29/f39PT04uLi39/f8vLy9PT08/Pz8vLy9/f35eXl2dnZ+vr6/Pz88PDw5ubm8PDw7u7u9/f39/f3/Pz8/v7+/f39lpaWlJSUq6urrq6uzc3N8/Pz+fn57e3t9/f3///////////////////////////////////////7+/v+/v76+vrf39/19fX39/fi4uLr6+vh4eHm5ub5+fn4+Pj19fXv7+/6+vr6+vr6+vr4+Pjp6ena2trh4eHx8fHz8/Pv7+/CwsK5ubn+/v739/f29vbk5OTl5eXj4+POzs7FxcW3t7fFxcXz8/P7+/v+/v729vbf39/FxcXHx8fOzs7f39/x8fH29vby8vLT09PBwcHKysrCwsLr6+vx8fG/v7+5ubnf39/29vb+/v79/f3t7e3MzMzOzs67u7va2trx8fH+/v7l5eXJycnNzc3CwsLV1dXk5OT39/f5+fnV1dXp6enx8fHu7u7m5ubFxcXExMTKysrV1dXY2Njn5+f39/fx8fHt7e35+fn4+Pj5+fnf39/y8vLp6env7+/w8PD19fX7+/v+/v7Ly8tubm64uLi0tLTExMTw8PD4+Pjv7+/7+/v///////////////////////////////////////z8/P39/ff399LS0vX19e3t7eXl5ePj4+Xl5fb29vn5+fb29vn5+fHx8fz8/Pj4+Pz8/PHx8eTk5N3d3eTk5N7e3ry8vL29vaioqLW1tcXFxbu7u7m5uaurq7i4uMnJydTU1N/f3+Xl5fb29u7u7u3t7dnZ2be3t6ioqK+vr9bW1vf39/7+/uvr69DQ0MHBwc/Pz9zc3O7u7vT09O3t7fX19efn5+np6fr6+vPz89XV1dPT09TU1M3NzdPT0+fn5/r6+vj4+OLi4ra2tsTExN3d3fT09Pv7+/v7+/v7+/j4+Lm5ub6+vr6+vsXFxdra2tra2tDQ0NLS0ufn5/v7+/j4+Pv7+/T09PX19fv7+/v7+/j4+Ozs7O3t7evr6+np6ejo6O3t7fn5+fv7+/b29n5+fqKiori4uLu7u+Dg4PT09Pn5+f///////////////////////////////////////////v7+/f39/v7+zMzM+Pj44+Pj7e3t5ubm+Pj49/f39/f3+Pj49vb29PT0/Pz8+Pj4+vr65OTk4ODg4eHh4ODg8PDw8/Pz3t7eubm5tLS0u7u7ubm5wsLC29vb7Ozs/Pz8/f39+Pj4/f39x8fHubm5pqamsbGxy8vL4eHh+Pj4+/v7zc3NxsbGurq6vb296urq/Pz8+/v77e3ttra2p6en6urq+/v7+fn57u7uu7u7urq6yMjI7Ozs9vb2+fn57u7uzMzMr6+vurq61dXV9/f3/Pz8+vr67Ozs09PTwsLCrq6uxMTEycnJ8vLy9fX1/Pz89vb2+fn59fX18vLy+/v7+vr6+fn58fHx8PDw9vb2+fn5+vr6+Pj48fHx6+vr6enp4ODg6enp+Pj4+/v7////0tLSb29voqKioKCgrq6u8fHx+fn5/Pz8///////////////////////////////////////+/v79/f39/f3f39/y8vLr6+vs7Ozx8fH5+fn19fXz8/P5+fn5+fn39/f9/f309PTz8/Pu7u7i4uLg4ODa2tru7u7t7e319fXv7+/X19f39/f09PT4+Pj8/Pz39/f19fX39/fb29vf39/n5+fNzc3Q0NDq6ur39/f+/v7W1tbS0tKurq66urrn5+f09PT39/fl5eXExMTKysq6urrY2Nj+/v7m5ubR0dG/v7/BwcHp6en5+fn9/f3y8vLa2tqysrKwsLDT09Ps7Oz29vb9/f3q6urIyMiwsLC1tbW8vLzBwcHr6+v29vb8/Pz6+vr5+fnx8fH39/fp6enh4eHU1NTT09PDw8PY2Njo6Oj39/fz8/P4+Pj6+vrx8fHq6urq6urj4+Pu7u7v7+/19fX8/Pz09PSHh4d3d3eIiIiFhYXr6+v39/f+/v7///////////////////////////////////////7+/v39/f///+jo6OHh4ebm5uPj4/j4+Pf39/T09Pb29vr6+vr6+vPz8/j4+PX19ff39/j4+O/v7+fn59nZ2bOzs7y8vMXFxeHh4b+/v+fn5+/v7+rq6tLS0sDAwLKysrm5uaWlpbS0tPX19fv7+/7+/u7u7uLi4sPDw6Ojo8fHx+np6fr6+vr6+uLi4sHBwbq6utPT0/Ly8vb29uTk5MPDw8TExNnZ2ejo6Pr6+vr6+unp6ejo6L+/v7Ozs9zc3PT09P7+/vHx8c/Pz83NzbGxsb+/v+Pj4/b29vj4+Pj4+NXV1d3d3dLS0r6+vq6urrCwsLm5ub29vdbW1tPT09ra2uXl5fv7+/7+/vn5+fT09Pv7+/n5+ff39+7u7u3t7eDg4Ofn5+7u7vj4+Pn5+f///7GxsVFRUYKCgpCQkNbW1vj4+P///////////////////////////////////////////v7+/Pz8////5+fn3Nzc4+Pj4ODg9/f37e3t7+/v9vb29fX1+Pj49PT08vLy7e3t9PT07+/v5+fn4uLi39/fyMjIrKysoqKivb29paWlqqqqzc3NsLCwkpKSoqKitra2zs7OzMzM1dXV/f39+fn519fXrq6upaWlra2tycnJ7+/v+Pj49fX10tLSrKysv7+/5ubm+fn55ubmvb29pqams7Oz39/f+Pj49/f35OTkz8/PsrKywcHByMjI5+fn+vr66+vrycnJtLS0o6OjxMTE09PT8/Pz/f399PT01dXVwcHBnJyctra2nZ2dpaWlrq6uwMDA3Nzc6enp8PDw+Pj4/f39+/v79fX18vLy+vr6+Pj49/f3+Pj49vb27u7u4+Pj5ubm4ODg6urq+fn5+fn5/v7+39/fISEhbm5ufn5+ra2t8PDw///////////////////////////////////////////+/v78/Pz////o6Ojd3d3Ozs709PT19fXw8PDx8fH09PT6+vr5+fn4+Pjz8/Py8vLs7Ozr6+vo6OjR0dHl5eX4+Pj6+vr19fX7+/vf39/u7u7x8fGVlZWWlpbt7e339/f7+/v09PTq6uq+vr6np6eoqKiwsLDg4OD4+Pj9/f3y8vK4uLilpaW1tbXU1NT29vbs7Oy8vLy0tLSurq7b29v8/Pzs7OzLy8u/v7/BwcGioqLOzs75+fnn5+f19fXCwsKhoaGXl5e7u7vv7+/6+vr////09PTPz8+lpaWGhoa5ubna2trq6urw8PD29vb7+/v5+fnx8fHs7Ozp6enW1tbExMS7u7vAwMC+vr79/f35+fn6+vr4+Pj4+Pj39/f09PTt7e3j4+Pv7+/u7u76+vr9/f3+/v5cXFxRUVFwcHCHh4fp6en///////////////////////////////////////////7+/vv7+/7+/uzs7NjY2ODg4Pb29vb29vPz8/b29vT09Pf39/Hx8fj4+PHx8ezs7PT09Ozs7Ovr69DQ0LOzs+Tk5Pr6+v7+/s7Ozq6urr29vZGRka+vr+rq6v////n5+dXV1aWlpaqqqp2dnaioqN3d3fn5+f7+/u3t7cfHx7u7u7m5ucHBwe3t7f7+/uvr66ampqCgoOHh4fT09Pv7+9XV1bW1tbOzs8nJydzc3PX19fv7++Li4sTExLOzs66ursTExOjo6Pv7+/7+/urq6sTExKenp4yMjMDAwN/f3/7+/vn5+f7+/unp6enp6fPz887OzpaWlomJiYeHh5iYmKampqmpqczMzO3t7f39/fr6+vj4+Pr6+vr6+vf39/X19e7u7ufn5+Hh4enp6fT09Pr6+v///7a2tjg4OGVlZWRkZOXl5f///////////////////////////////////////////v7++/v7/f397+/v3Nzc+Pj49/f39vb2+/v7+Pj4+/v78vLy8fHx9vb29PT09/f3+/v76urqw8PD9fX16+vre3t7eXl50NDQioqKW1tba2trx8fH////+Pj41dXVlpaWiIiIwsLC7e3t7+/v+fn5+/v7+/v7wMDAmpqasrKy+Pj48/Pz+Pj4/Pz8y8vLlpaWqqqq9PT0////2traoKCgo6Oj5+fn/////v7+6enpzc3NnJycl5eX39/f/f39+vr6+Pj44ODgxMTEpKSkeHh4goKCoqKi+Pj4/v7++/v7rq6uiIiIoqKiiYmJjY2Njo6OiIiIpKSk7u7u6urq/v7+/////v7+9vb28fHx2tra4ODg6enp8fHx8fHx8vLy9fX18/Pz5ubm2tra5eXl6enp9/f3+/v75eXlPDw8QEBANTU109PT///////////////////////////////////////////+/v77+/v9/f3z8/Pm5ub39/f29vb5+fn5+fn7+/v4+Pj29vbz8/Py8vL5+fn6+vr6+vr29vaWlpbBwcH+/v7S0tJ0dHSbm5vl5eWKioqurq78/Pz39/eoqKhsbGypqanm5ubq6uqsrKzQ0ND+/v7Y2Nijo6Orq6vY2Nj8/Pzq6uqwsLDw8PDg4OCZmZm9vb3u7u78/Pzc3NyqqqrHx8f09PT9/f3z8/PBwcGZmZmmpqa2trb29vb5+fnY2Njd3d2ioqKGhoaKioqJiYmbm5ve3t7z8/P8/PzExMSfn5+IiIiVlZXMzMz39/fT09PExMTv7+/6+vr39/f4+Pj4+Pjz8/Pf39/d3d2urq6RkZHAwMDl5eX19fX19fX39/f5+fn4+Pjm5ubc3Nzl5eXl5eX39/f7+/vu7u5+fn4ZGRkaGhrl5eX///////////////////////////////////////////7+/vz8/P7+/vT09PDw8PDw8Pb29vT09N/f39XV1fb29vb29vLy8vf39/T09Pn5+fLy8v7+/sXFxZiYmNzc3P///8DAwGBgYLGxsff39/39/fLy8pWVlWJiYpubm/b29v///5eXl2lpacjIyO7u7o2NjaOjo+zs7P////Dw8JGRkZ6envv7+7W1tba2tvn5+fHx8bm5uZaWlunp6f////Dw8NLS0p6enpiYmMfHx/b29v///////5mZmZCQkNLS0vb29tTU1Ojo6OTk5Pv7+/////X19a+vr2BgYL+/v/T09Pv7+/7+/tDQ0JCQkP////////7+/vv7+87OzrGxsW9vb2ZmZoODg5ycnN/f3/f39/X19f39/fT09Pb29vn5+fX19ebm5t3d3dbW1ubm5vPz8/f39+/v77y8vBoaGicnJ/Hx8f///////////////////////////////////////////v7+/Pz8/v7++fn59vb2+/v7+fn5+/v79PT08vLy8fHx9/f39vb29vb2+Pj46enpu7u7mpqa+/v7z8/Penp6u7u7////r6+vh4eH9PT05ubmY2NjYmJiw8PD////6OjokZGRk5OT0dHR////p6enh4eH9PT0+Pj4vr6+j4+PwcHB9fX1ubm5oKCg////09PTkZGRmZmZ+vr6/Pz8zc3Nl5eXtra22dnZ/v7+8fHx3d3dsbGx1NTUy8vL8/Pz+fn5l5eXf39/09PT/f390NDQj4+Pg4ODm5ub4uLi////8fHxrq6uZmZmd3d3wsLC9fX1p6enW1tbTU1NdXV1c3Nzs7Oz4uLi9/f3+fn5/f393Nzcy8vL4eHh+vr6+Pj49/f3+fn58PDw2NjY0NDQ39/f7u7u9vb29vb24uLibGxsKioq/v7+///////////////////////////////////////////+/v76+vr+/v78/Pz19fX5+fn4+Pj8/Pz39/f5+fn39/f7+/v09PT29vb09PT5+fne3t6Dg4P39/f+/v6vr69tbW39/f26urp2dnb+/v6enp5RUVF/f3/29vb09PSBgYF2dnbBwcH+/v7R0dFqamrT09P////IyMh/f3/AwMD////l5eWXl5fq6urz8/OKioqPj4/x8fHw8PC8vLycnJzS0tL6+vr9/f339/evr6+Wlpavr6/9/f339/fY2NikpKSRkZHJycn////BwcFwcHCTk5Pw8PD29vb////IyMhsbGxoaGiSkpL19fXw8PB7e3tRUVFhYWFJSUmNjY3m5ub7+/v9/f3s7Ozg4OC8vLyNjY2xsbHr6+v4+Pj4+Pjz8/P5+fn5+fni4uLX19fe3t7v7+/29vb29vbv7++Dg4MqKir///////////////////////////////////////////////7+/vz8/P7+/v39/fX19fj4+Pf39/j4+Pb29vn5+ff39/T09PLy8ujo6Pn5+f39/f39/dXV1aCgoO3t7ezs7E9PT9PT05ycnJKSkv///4+Pj1tbW9PT0////52dnWJiYsPDw/39/cnJyXp6eqKiovr6+sPDw39/f8DAwP7+/t7e3qOjo+Xl5evr66ysrJaWlu/v7+Dg4JGRkbS0tPT09Ovr66CgoPj4+LS0tJ+fn9zc3Pv7+7u7u3x8fK+vr/f399ra2ufn5/Dw8IGBgZWVlezs7P///+Hh4YODg11dXbCwsOTk5P7+/ry8vGNjY0FBQYGBgcXFxePj4/39/e7u7r29vYeHh2lpaaqqqtfX1+fn5/z8/P7+/v39/fr6+vb29vLy8vn5+fHx8dzc3OPj4/T09Pv7+/j4+Pf399/f301NTf///////////////////////////////////////////////////Pz8/v7+/f396Ojo7e3t+/v79/f38PDw+Pj47u7u8fHx9/f39PT0+fn5vLy8/f398vLyVlZWjo6O+vr6iYmJoKCga2trm5ub+Pj4dHR0Tk5O7u7u8fHxU1NTWlpa9/f36+vrbm5uc3Nz7u7u+fn5hISEoKCg/Pz8zs7OgoKCycnJ7Ozsl5eXlJSU5+fn8fHxiIiIuLi4+/v79PT0kZGRvLy8wsLCiYmJ6urq////srKyf39/zc3N8/PzsbGxgoKC5+fnsrKynJyc8fHx+/v7lpaWbm5ud3d3xMTE////19fXb29vRUVFXV1dpqam/Pz8////9fX1pqamYWFhSkpKmpqazMzM/Pz8/f395eXl3d3d09PTzs7O9PT0+vr69vb2+fn59fX12dnZ2NjY7e3t9vb2+fn5+Pj47u7uw8PD///////////////////////////////////////////////////+/v79/f39/f3v7+/t7e34+Pjz8/Pw8PD39/fw8PD19fX39/f5+fn19fVnZ2fT09P8/PyUlJRRUVHExMTy8vLMzMw8PDy5ubn19fVNTU1ZWVn5+fnNzc0zMzNqamr7+/vm5uZlZWWPj4/////f39+AgIDy8vLo6OiBgYGgoKD////ExMSFhYWzs7P+/v6oqKiVlZX6+vra2tqqqqrCwsL19fV3d3fExMT8/PzQ0NB+fn7IyMj///+qqqqDg4OysrLT09OIiIj6+vrx8fGhoaFfX1+wsLD09PT9/f3S0tJqampJSUmAgIDh4eH7+/vy8vK1tbVvb29SUlJgYGCgoKD////29vbj4+OioqKJiYmnp6eurq7S0tL7+/vz8/P09PT5+fn6+vri4uLNzc3b29vq6ur7+/v4+Pjt7e3x8fH///////////////////////////////////////////////////////z8/P39/ejo6Pf39/j4+O7u7vn5+fX19e3t7fn5+fPz8/X19fv7+7GxsVpaWv////Ly8k1NTWVlZfz8/Nvb22xsbOzs7MXFxTAwMLKysvr6+o6OjkRERLOzs/7+/m5ubk5OTt3d3ejo6GhoaMDAwPLy8nJycnt7e/X19eXl5X9/f6urq////8bGxp+fn////7m5uYGBgerq6ujo6JSUlNzc3Pr6+qqqqpaWlu3t7f///62trZOTk/z8/Nzc3J+fn/z8/LKysldXV5ubm/b29vn5+dfX16GhoU9PT5SUlOfn5/n5+fX19aamplFRUV1dXXJyctPT0/n5+fv7++Tk5GlpaWxsbK6urs/Pz/n5+fz8/P7+/vz8/Pb29vr6+u/v7/b29vLy8tvb29DQ0Ofn5/v7+/v7+/X19fr6+v///////////////////////////////////////////////////////Pz8+vr68vLy8vLy8fHx6enp+Pj47u7u5eXl7u7u7+/v8fHx+vr6xsbGQ0NDq6ur////kJCQQEBA9/f35+fnSkpK7OzslJSUKSkpvLy8oqKik5OTPDw81tbW39/fSUlJXFxc+vr6wcHBdHR04+Pj1NTUW1tbt7e3/Pz8iYmJeXl53t7e4ODgdnZ2zc3N6Ojof39/2NjY4+PjfHx8wcHB////vr6+iIiI9fX19vb2nZ2dqamp+vr6xsbGjIyM8vLytra2SUlJra2t/f396Ojoi4uLZ2dnpKSkr6+v8PDw////6enpioqKPDw8LCwsj4+P7+/v////7u7uw8PDXl5ej4+P3d3d+Pj4////5eXl6urq4+Pj/f399/f39vb25+fn8vLy8vLy4ODgy8vL1tbW+fn5+fn59fX1+/v7///////////////////////////////////////////////////////9/f37+/v5+fnz8/Py8vL29vb4+Pj19fX4+Pj39/f19fXu7u77+/v4+PiQkJB1dXX6+vrNzc03Nzfm5ubz8/M9PT25ubna2tqmpqaCgoJnZ2e7u7teXl7t7e2cnJxOTk6zs7P+/v5nZ2dycnL9/f15eXmbm5v///+MjIx0dHTt7e339/eHh4eSkpLo6Ohvb2/h4eHX19d+fn7CwsL///+WlpaQkJD7+/vc3NyNjY22trb8/PyioqKioqL5+fmDg4NiYmLa2tr7+/vY2NhYWFienp7w8PCJiYmoqKj///+6urpISEg6OjqPj4/e3t7////k5ORiYmJhYWFvb2/p6en////t7e2kpKSJiYmCgoKkpKTp6eny8vL6+vr7+/v7+/vw8PD6+vrs7OzLy8vExMTz8/P5+fn4+Pj9/f3///////////////////////////////////////////////////////39/fv7+/r6+vX19fPz8/n5+fb29vj4+PPz8+/v7/r6+vv7+9ra2vv7+7e3t2lpaeXl5eHh4SwsLJOTk/r6+lFRUWdnZ/n5+fLy8oWFhfHx8aCgoDs7O/f393BwcFRUVO7u7sjIyFVVVZCQkNbW1mtra+7u7ry8vH5+ftPT0/7+/rq6unBwcN3d3bu7u6Kiounp6Y2NjdHR0fj4+Jubm5ubm/Pz89ra2oGBgaWlpfb29o2NjZOTk/7+/p2dnYCAgO/v7/b29oeHh2RkZMDAwNPT00VFRV5eXsXFxa6urjw8PGNjY8fHx////9/f342NjUlJST8/P6CgoPv7++jo6I6OjmdnZ1ZWVq2trfj4+Pn5+cHBwY+Pj+vr6/j4+Pv7+/X19ff39+jo6MvLy8fHx+7u7vv7+/n5+fz8/P///////////////////////////////////////////////////////Pz8+/v78/Pz9vb28PDw9PT07Ozs8fHx9PT09vb2/Pz819fXh4eH8vLy1dXVMzMzzs7O+Pj4VFRUODg4+vr6YmJiSUlJ9fX14eHhICAg19fXfn5+NDQ07+/vh4eHaWlp/f39h4eHSEhI0NDQ1dXVzc3N5ubmZmZmpKSk////1tbWe3t7lZWV9vb28PDw0NDQhISEzc3N+Pj4qKiobGxs4+Pj5eXleHh4qamp+/v7oKCgb29v8vLyzMzMYWFh4eHh+/v7h4eHQkJCyMjI1NTUR0dHUlJS09PTzMzMNzc3X19f0tLS////0dHRUVFRJCQkU1NT0dHR+/v7u7u7a2trVlZWfX19xcXF/v7+6enptra2f39/ubm59/f3+Pj4+fn59/f39fX18fHx29vbysrK9PT09/f3+vr6/f39///////////////////////////////////////////////////////9/f36+vr29vb4+Pj5+fnv7+/t7e329vb4+Pjz8/P6+vq1tbVLS0ve3t7x8fE+Pj6IiIj///+SkpIZGRnf39+Hh4dpaWnHx8fh4eFSUlLj4+NoaGhHR0fl5eVXV1ehoaH///9lZWVvb2/4+Pj////Q0NBmZmZ3d3fy8vLMzMx6enp7e3vNzc3////Ly8tycnKenp7///+vr697e3vY2Njn5+eBgYGXl5f5+fm8vLxkZGTR0dHX19dWVlazs7P9/f2mpqZGRkaamprz8/NNTU1RUVHj4+Pf3983Nzdra2vw8PDc3NyUlJQ0NDRJSUmLi4v8/Pzl5eVubm5FRUVpaWnT09P////e3t6UlJR0dHSxsbH39/f09PT+/v739/f7+/v8/Pzz8/Pu7u7n5+fNzc3p6en39/f4+Pj+/v7///////////////////////////////////////////////////////z8/P7+/vv7+/Ly8vT09PLy8vX19f39/fv7+/X19fT09MXFxVBQUG1tbfb29ltbW8bGxvz8/FxcXCAgINnZ2Y6Ojh4eHrm5ufb29jU1NcXFxYmJiXFxcezs7Kqqqvb29srKynl5eZubm////6qqqkxMTIuLi/z8/MvLy2xsbPj4+H5+furq6tbW1n5+foGBgf///6ampmdnZ8fHx/Pz82JiYq6urv///6ioqG5ubt3d3d/f32hoaK6urv///6ioqEpKSrW1tf///21tbWVlZe/v77+/v0ZGRoGBgf///+fn51paWlhYWHx8fPz8/Pz8/LGxsTQ0NDg4OMTExP///+Pj45KSkkZGRoyMjPr6+v39/ebm5rq6uuLi4vX19fv7+/f39/f39/X19fPz89bW1tnZ2fv7+/z8/P///////////////////////////////////////////////////////////Pz8/f39+fn5+Pj49PT06enp9fX19/f39/f38vLysrKy6Ojozc3NxsbG6enpwsLCoqKiqampgICAOzs76OjojY2NHR0df39/////SEhIpKSkz8/P2NjYY2NjSEhI+fn5q6urR0dHuLi4////fHx8bm5u5ubm+vr6bGxsv7+/yMjIampq8vLykJCQkJCQ7Ozs4uLieXl5m5ub/v7+iYmJe3t7////y8vLXl5elpaW////c3NzdnZ2+/v7y8vLVlZWeXl5+/v7s7OzQkJC5eXl7e3tQEBAU1NT9/f34ODgX19fRUVF2dnZ+Pj4////pqamIyMjYGBgzc3N/f39/f39ZmZmIiIinp6e9vb29fX1tLS0e3t7Z2dn7e3t+/v7+Pj49vb2+fn5+/v78vLy3t7e1dXV9PT0+vr6/v7+///////////////////////////////////////////////////////+/v75+fn7+/v6+vr19fXx8fH29vb29vbt7e28vLy7u7vn5+f+/v7c3Nytra1QUFBra2swMDCIiIju7u7m5uZ2dnZXV1eUlJTx8fEnJyddXV3///+goKAkJCSRkZH5+fllZWVXV1f7+/vGxsZVVVWxsbH8/Px7e3uioqL7+/tsbGyWlpbk5ORaWlrMzMzq6up0dHRsbGzu7u6SkpJgYGDj4+PKyspdXV2tra3z8/OZmZl4eHjt7e3U1NRYWFiJiYn39/e2trZDQ0Pg4ODv7+9fX19qamrx8fHFxcVBQUFISEjq6urv7++lpaV/f389PT2YmJjz8/Pq6uq9vb1qampeXl7CwsL////U1NRbW1tHR0eGhobk5OT8/Pzy8vL6+vr29vb19fX19fXu7u7n5+fQ0NDv7+/7+/v///////////////////////////////////////////////////////////7+/vz8/Pv7+/X19fPz8+jo6Pb29vj4+PT09Ojo6Pz8/OHh4f///5mZmX5+fvPz8/39/e/v7/Dw8P///729vVNTU9HR0UJCQuDg4GBgYFVVVf///46OjkhISN3d3dTU1ENDQ4mJif///3t7e2hoaP///7q6ul1dXefn57a2tnd3d+Pj45+fn3h4ePz8/H5+fmtra9PT09zc3FxcXK2tre/v725ubqWlpf39/ZKSklpaWuHh4dfX109PT3FxcfLy8sbGxklJSbS0tPb29nR0dEJCQu7u7sLCwjIyMktLS/X19czMzF9fXz09PX5+ftXV1f////Pz811dXSIiIl1dXdra2v39/bi4uFtbW1JSUrW1tfv7+/r6+rS0tKmpqff39/n5+fPz8/Pz8+/v7+rq6s/Pz+Tk5P39/f//////////////////////////////////////////////////////////////+/v7/f39+Pj48/Pz7e3t+Pj4/Pz8/f39/Pz87e3tYGBg6enp////bW1tm5ubx8fHWlpa9vb2/v7+h4eHsrKy7OzsPj4+3NzchISEJycn5eXl9vb22dnZ////jIyMdnZ2x8fH7e3tZ2dne3t78vLyWFhYkZGR+vr6YGBgrKys5+fnW1tb29vbwMDAaGhop6en1NTUXl5ekJCQ////dHR0iIiI+/v7tbW1Z2dnu7u7/f39f39/VlZW4uLiy8vLPj4+kpKS6OjoYGBgSUlJ3Nzc9fX1UVFRVlZW8/Pz1dXVPT09VFRUUFBQ9/f36OjoZGRkTExMJSUlgYGB+/v7////0tLSQUFBhoaG7u7u+fn5q6urZ2dna2tr6urq8vLy+/v79fX1+fn5+fn59/f32tra3Nzc///////////////////////////////////////////////////////////////////8/Pz5+fnq6ur5+fn09PTy8vL4+Pjz8/P19fXi4uI5OTlra2v///+cnJwyMjKnp6eampqcnJx+fn7n5+cwMDDw8PA8PDyfn5/GxsYTExOysrLKyso2Njbx8fFycnIxMTHMzMzPz89ISEi9vb3W1tZWVla+vr7R0dFfX1/t7e2amppjY2P///90dHRlZWX19fV5eXlcXFzIyMjo6OhDQ0Oqqqr+/v54eHiRkZH+/v6wsLBERESbm5vr6+tmZmZbW1v29vaCgoJLS0vZ2dng4OBoaGg0NDTIyMj4+PhNTU0iIiJ6enry8vLZ2dltbW1JSUlVVVWsrKz5+fnOzs56enpgYGCMjIz39/f+/v6bm5tISEhhYWHe3t729vb8/Pz+/v7z8/P39/fu7u77+/vc3NzS0tL///////////////////////////////////////////////////////////////////z8/Pz8/Ofn5/f39/f39/j4+PHx8fDw8Pv7+/39/aqqqjIyMuLi4uzs7CIiIpOTk////4iIiB8fH/f3921tbYyMjJCQkCoqKv7+/jo6OoqKit/f3ywsLOHh4Y6OjikpKdzc3JqamlZWVtjY2JmZmWBgYPX19Xd3d4ODg93d3VFRUcfHx4yMjHt7e+Li4tra2oGBgYGBgf7+/nBwcHx8fP///3Z2doqKiv///8/Pz1dXV7Ozs/7+/pubm0ZGRunp6bGxsTo6Ourq6vn5+VtbW05OTubm5vb29lZWVj8/P7m5uf///7y8vCcnJ1VVVc3Nzff39////7i4uDs7O0RERJGRkf///9PT01ZWVj4+PoWFhfX19f39/c7Ozrm5ufj4+PDw8PPz8+np6e/v7+Tk5NHR0f///////////////////////////////////////////////////////////////////Pz8+/v78fHx8vLy+vr68/Pz8PDw5eXl39/f/f395OTkFhYWdHR0////jIyMkpKS////wsLCBwcHysrK6+vrLCwsr6+vJSUlwcHBWVlZPj4++/v7Pj4+qKiosLCwJCQk1NTUoKCgS0tL+fn5jo6OY2Nj////eXl55+fnhoaGeHh49vb2W1tbx8fHh4eHpKSkUFBQ09PT2dnZU1NT09PT2traX19f7e3t6enphISEjo6O/v7+wsLCb29v1NTU9/f3SUlJlpaW9/f3bW1tODg4ycnJ////W1tbVVVVu7u7////lpaWTU1NMzMz29vb/f395eXle3t7Pj4+ODg429vb/Pz8vr6+TU1NUVFRq6ur5eXl6urqnJycra2t5eXl+Pj47u7u8fHx8fHx8PDw6+vr2tra///////////////////////////////////////////////////////////////////8/Pz9/f37+/v09PT7+/v09PT09PT7+/vBwcGpqan+/v59fX0ICAjJycna2toNDQ3f39/v7+8lJSV3d3f///8iIiK0tLQ7OztoaGilpaUxMTH///8jIyOXl5ehoaEeHh7v7+9xcXFCQkL39/eIiIiTk5Pd3d1WVlb///9cXFzGxsanp6djY2PS0tKRkZFvb2+IiIj09PR9fX19fX3///+Li4uhoaH///9zc3N2dnb5+fnd3d1fX1/o6Oj///95eXl9fX3///9xcXFJSUmvr6/e3t5xcXEjIyO3t7f9/f2Li4t/f39RUVHv7+/q6upcXFw7OztaWlqxsbHz8/P///+ysrIzMzMvLy/c3Nz///+8vLxcXFx8fHzu7u79/f38/Pzv7+/v7+/y8vL4+Pjx8fHo6Oj///////////////////////////////////////////////////////////////////v7+/n5+ff39/T09Pj4+PHx8fPz8+fn58nJyVNTU/v7+8jIyAAAAFJSUv7+/mlpaXR0dP///4iIiDIyMtra2rOzs4yMjJubmzExMfn5+SoqKunp6TU1Naurq56eniQkJPPz83FxcYSEhO/v7zc3N8TExJqamnt7e9PT02BgYOnp6UxMTMHBwYGBgbS0tFFRUevr64uLi3R0dO7u7rGxsXZ2dv39/YODg19fX9nZ2c3NzUZGRru7u/7+/qCgoGlpafr6+pmZmUBAQJWVleHh4SMjIyAgIMvLy/X19WRkZBISEoCAgPf396mpqUNDQyIiIpKSkvT09M3Nzf39/dLS0i4uLlZWVtra2vz8/IKCgikpKYGBgfv7+/r6+t7e3vn5+fDw8Onp6fPz8/j4+PX19fHx8f///////////////////////////////////////////////////////////////////Pz8/f39+vr6+fn5+fn56+vr+/v74ODg3t7eS0tL+/v77+/vRUVFRUVF////ampqLy8v////7u7uHBwclZWV9fX1Kysr1tbWHR0d4+PjGxsbz8/PNzc3kZGRxMTEQUFB////c3Nzenp6yMjIUVFR8vLygYGBkpKSvLy8jY2NvLy8VVVV/v7+ZWVlampqpqam5ubmUVFRmJiY+/v7UFBQtLS02NjYQUFBoaGh/f39gICAfX19/v7+goKCS0tL6urq4eHhUFBQPDw88fHxZ2dnJiYmqKio9fX1PDw8NDQ0QkJC6enp1dXVIyMjMDAwra2t/Pz8ioqKLi4u/v7+ampqOTk52dnZ+Pj4goKCNTU1ZGRk/f39+Pj4ubm5iYmJ9vb27+/v7Ozs8/Pz8vLy7Ozs9vb2///////////////////////////////////////////////////////////////////8/Pz8/Pz6+vr7+/v39/fu7u74+Pjp6en19fVra2tmZmb9/f25ublpaWn////Nzc0PDw+pqan4+PhISEh4eHj///9DQ0MhISGGhoaNjY1ERER4eHhPT09cXFzU1NRDQ0P///9zc3OGhoaurq5OTk77+/tKSkrg4OBoaGjNzc2CgoKLi4vk5ORgYGBoaGj9/f2Hh4ddXV3t7e2WlpZLS0vt7e17e3uNjY34+PiEhIRNTU3r6+umpqZFRUWzs7P19fVFRUVQUFDr6+uioqIfHx9ra2v///90dHQVFRV5eXnu7u7j4+NtbW0dHR2urq729vZoaGgYGBi2traysrI3NzfGxsbw8PBeXl4nJyeTk5Pz8/P39/eDg4NnZ2eBgYHu7u7q6urr6+vp6ens7Ozz8/P5+fn///////////////////////////////////////////////////////////////////39/fv7+/n5+ff39/n5+fn5+fPz85ubm/Dw8K2trQcHB+Pj4/b29i8vL8TExP///zIyMjY2Nv///2xsbCoqKvz8/ODg4JSUlPz8/KSkpIiIiFlZWXV1dVtbW9PT0yoqKvz8/ERERJycnKampldXV93d3To6Ounp6U9PT7m5uUZGRu3t7Y+Pj0FBQdPT0+zs7E9PT7u7u+7u7mhoaK6ursrKylVVVfPz87S0tF1dXdDQ0Ofn50dHR4mJif///39/fzQ0NL29vdvb20NDQ2FhYf///29vbzAwMMPDw+Hh4f///2pqahISEpeXl////3FxcTQ0NMzMzO7u7hcXF6ampvv7+0BAQAwMDJ+fn////8fHx2RkZEpKSq+vr+vr6/Hx8e7u7vDw8Obm5vj4+Pj4+Pz8/P///////////////////////////////////////////////////////////////////v7++vr6+fn59vb26+vr8fHx4ODgCAgItLS04uLiBwcHSUlJ////Pz8/JCQk5OTkdHR0FhYW5+fnlpaWAAAA09PTv7+/BAQEenp6////6+vrioqKgYGBNDQ04+PjHx8f8vLyKSkppaWlbGxsjIyMt7e3b29v8PDwUFBQlJSUmJiY6enpSUlJhYWF////dHR0UFBQ+fn5eXl5TExM+vr6e3t71dXVz8/PUlJSqqqq////cnJyYmJi8PDwtra2KSkpnJyc+vr6REREQUFB8/PzhYWFFxcX0NDQrq6uKCgoxsbGCgoKbGxs////e3t7MDAw6Ojoy8vLSEhIVFRU/Pz8kZGRCwsLj4+P////enp6WFhYX19fv7+/8fHx////9vb27u7u8vLy7e3t+vr69/f3+/v7///////////////////////////////////////////////////////////////////////7+/v5+fn4+Pj6+vrr6+vx8fFNTU2lpaX9/f1AQEAODg7U1NR9fX0CAgLg4OCEhIQBAQHIyMi2trYAAACMjIzg4OALCwteXl7f399cXFzl5eXAwMARERHf398JCQnh4eFJSUnCwsJ1dXW3t7dYWFinp6fHx8czMzNhYWH4+PiKiopfX1/JycnMzMxCQkKKiorx8fE9PT2WlpbHx8djY2P19fVYWFh5eXn///+Pj49BQUGpqanm5uZycnJlZWX6+vqQkJAcHByzs7Ofn58sLCxBQUHj4+MUFBSNjY16enoQEBDo6Oibm5sjIyPd3d37+/s2NjY0NDTs7OzV1dUVFRVZWVn6+vqtra0+Pj4wMDDm5ub09PTm5ubJycns7Ozz8/P09PTw8PD9/f3x8fH6+vr///////////////////////////////////////////////////////////////////7+/vz8/Pn5+fn5+fr6+vj4+P///5ycnHR0dP///4eHhwAAALu7u6KiogAAAMrKyvn5+TY2Nq+vr+np6QsLC0dHR/r6+jAwMHJycltbWw8PD+jo6P///8/Pz+fn5wcHB9zc3Hp6eoKCgubm5qurq0JCQt3d3Y6OjlBQUOHh4b6+vj4+PlxcXP39/VtbW1FRUcLCwsvLy1NTU/z8/Hh4ePHx8V5eXlpaWvr6+re3t1tbW6enp/7+/nl5eUtLS////8rKyhEREaenp/Hx8UBAQBYWFvz8/FJSUkRERPv7+x8fH5OTk/T09BQUFIqKivX19Tw8PDk5Odzc3Pn5+SQkJHFxcfv7+6ysrA0NDVJSUtvb2////7e3t05OTnR0dO3t7ezs7PHx8evr6/Pz8/b29v39/f///////////////////////////////////////////////////////////////////v7++vr6/f399vb2+/v7rKys////xcXFGxsbtbW15ubmHR0dvr6+7OzsEBAQT09P////Ly8vODg4////HR0dWFhY9vb2GBgYXV1dd3d3pKSkiIiIOzs77+/v+vr6TU1Np6enkZGRSEhI7+/vLi4uTk5O+/v7Tk5OXV1d+/v7ZWVlS0tLxcXFxMTER0dHZWVl19fXTU1Nh4eH7u7ukpKSy8vLRERE4ODg19fXSEhIf39/////vLy8WlpasLCw6enpQUFBbW1t////h4eHMTExtbW1j4+PBwcH1dXVW1tbY2Nj4eHhfX19YGBg9fX1V1dXBwcHurq66+vrUFBQRUVF6+vr5eXlPz8/SEhI5+fn8/PztLS0PT09dnZ27Ozs+/v75ubm7Ozs7e3t8fHx+fn5/v7+///////////////////////////////////////////////////////////////////////6+vr8/Pzx8fH39/ednZ3u7u7Ozs4VFRVFRUX///8gICBLS0v///9fX18yMjL///9xcXEAAAD7+/skJCQKCgrr6+smJiZjY2P///+2trYVFRUoKCjt7e3x8fHo6Oj4+Pi0tLQjIyPJyclCQkKkpKTLy8tISEihoaHIyMh+fn5BQUH6+vqMjIw9PT24uLienp5AQEC7u7uxsbGenp5TU1OlpaX19fVQUFBDQ0PZ2dnq6upSUlJ+fn739/dgYGA+Pj7q6urMzMwmJiaCgoLs7OwLCwuKioq7u7t6enrt7e1sbGwYGBjm5ua4uLgNDQ18fHz///95eXkcHBzs7Ozo6OhQUFAfHx/Gxsb4+PhiYmJaWlp9fX3h4eH////h4eHe3t7y8vL39/fz8/P4+Pj+/v7///////////////////////////////////////////////////////////////////////z8/Pn5+e/v7/T09MfHx9PT0/Dw8FFRUSIiIuvr65iYmAAAAMfHx7q6ugcHB////6ampgMDA/b29oODgwYGBvb29iwsLIqKioODgwAAABYWFtPT0zk5OTs7O/r6+vn5+fj4+L29vcvLyzw8PP///15eXlZWVv///3FxcTc3N4aGhv///2FhYWxsbP///2xsbFdXV/r6+lNTU0ZGRnR0dP39/ZSUlF9fX9DQ0Pn5+V1dXVZWVvPz84mJiSEhId3d3bi4uEdHR4ODg/7+/qCgoD4+Pvj4+AsLC76+vpKSkhgYGKysrKioqAUFBT09Pf7+/mdnZwEBAZKSkvb29jU1NScnJ+np6e7u7n19fS4uLo2Njfr6+ra2tsvLy2xsbN/f3+7u7urq6vDw8PX19f//////////////////////////////////////////////////////////////////////////+/v7/Pz88fHx3t7e+vr6z8/P1NTU4uLiHBwcwcHB39/fCwsLjIyM5eXlGhoak5OT3d3dAAAA2trazc3NFBQU5ubmNjY2o6OjnZ2dBQUFj4+PuLi4FRUVR0dH3t7eQUFBq6ur7+/vyMjI0dHR6OjoLCwsampq/f39R0dHNTU10dHRq6urNTU1vLy8zMzMZ2dnnZ2dwsLCOTk5h4eH////xsbGTU1Nb29v/v7+kpKSLi4uzMzM3d3dMjIyjY2N5eXlOjo6VFRU/f39lpaWQkJC5eXlWVlZPj4++/v7JycnYWFh9fX1S0tLMjIy19fXv7+/Dw8PcXFx////cXFxGxsbpqam////enp6RkZGkpKS+/v79fX1p6enZ2dngoKC8fHx9PT09PT0/Pz8+/v7///////////////////////////////////////////////////////////////////////////6+vr8/Pz6+vr4+Pj///91dXWFhYXz8/NNTU14eHjx8fEbGxtSUlL19fUQEBBlZWXx8fEDAwOqqqrZ2dkRERH4+Pg7OzuGhobBwcEAAADKysqqqqoAAACXl5eUlJQhISG/v79OTk6/v7/////Q0NAeHh6lpaXw8PBAQEBUVFT///9nZ2dCQkL19fVSUlJNTU3e3t6GhoZYWFirq6v4+PhZWVlVVVXp6enb29tYWFhtbW3///+dnZ1TU1P9/f2NjY1KSkrAwMC8vLwyMjKbm5v4+PgaGhqgoKCwsLA4ODjo6OiMjIwHBwefn5/u7u5EREQgICDk5OSsrKwcHBxra2v29vajo6MbGxszMzPt7e35+fmnp6dcXFyioqLOzs7w8PDz8/Px8fH39/f4+Pj///////////////////////////////////////////////////////////////////////////z8/Pz8/Pj4+PT09P///4KCghkZGejo6F5eXicnJ/v7+2pqahwcHP///zU1NWNjY/Ly8gkJCUdHR+Dg4AQEBPf39z4+PltbW7q6ugAAAJ6enmFhYQAAAOLi4lFRURwcHNjY2BwcHHd3d/////7+/tnZ2f///3FxcSoqKqioqOnp6Tw8PISEhODg4FdXV25ubujo6Do6OkRERP///8fHx09PT7Ozs+7u7khISDw8PO3t7e3t7YmJif///7+/vy0tLcPDw+7u7j8/P1xcXP7+/jc3N7S0tMPDwycnJ+bm5qenpy4uLqKiov///29vbwICAqysrNPT0z09PSsrK/z8/NPT0zY2NjY2Nt3d3f///4+Pjzg4OMnJyfLy8vb29vz8/Ofn5+7u7vHx8fv7+////////////////////////////////////////////////////////////////////////////Pz8+/v7+/v74+PjysrK39/fDg4O6urqu7u7ZGRkv7+/paWlAAAA4ODgUlJSNDQ0+fn5DAwMT09P4uLiAAAAx8fHSkpKXFxcy8vLAAAAxsbGQUFBCwsL8PDwPT09S0tL6enpHx8flpaWsrKyqqqq/f39////aWlpXFxc6urqhISESEhIuLi4wMDAR0dH0dHRoKCgUFBQvr6+8/PzaWlpQUFB8vLylJSUNDQ0xcXF/f39qamp5eXl6+vrgICArKys////ioqKODg44ODgra2tgYGB9PT0UFBQe3t7+fn5HBwcRkZG/Pz8oaGhBAQEbGxs7e3tlpaWICAgnp6e9vb2VVVVDg4OtLS0+Pj4UlJSPDw8bm5u/Pz8vb29pqam+Pj46urq7+/v9fX1+vr6///////////////////////////////////////////////////////////////////////////6+vr7+/v7+/vDw8Ps7Oz7+/sPDw+ZmZn///9YWFjv7+/j4+MAAABcXFx9fX0ZGRn///8RERFubm7k5OQCAgKpqalycnIrKyubm5sAAACCgoJaWloTExP29vYqKipmZmbNzc0hISGxsbF/f39kZGT///+tra2ysrL+/v719fVJSUlNTU3j4+M7OztycnL+/v5dXV1OTk77+/uCgoI5OTnKysrX19cvLy9qamr///+lpaXGxsb+/v7IyMhMTEz+/v6zs7NCQkLHx8f///8/Pz/W1tasrKwdHR3///9xcXEUFBTl5eWUlJQ0NDS8vLz///+4uLgpKSlWVlbz8/PFxcU4ODiMjIz4+PhsbGwoKChRUVH////b29tXV1eEhIT5+fno6Ojh4eH8/Pz+/v7///////////////////////////////////////////////////////////////////////////v7+/r6+v///5qamp+fn////5aWlhwcHOzs7C4uLgMDA////x4eHltbW5+fnwUFBfn5+S8vLzw8PPb29gQEBMDAwI2NjRAQEIaGhgAAAJOTk1paWgcHB+Tk5AwMDGFhYbq6ug4ODsrKynFxcVdXV+Xl5TMzM3V1dfT09P////v7+/39/Y+Pj1JSUvv7+1ZWVktLS+Pj4+jo6DMzM25ubv///3Z2djs7O/Hx8cnJyWJiYvf399/f3zg4OO3t7dvb2zU1NU9PT/7+/lxcXHJycv///xISEpaWlrS0tDw8PK2trcPDwwwMDLm5uX5+fvr6+iUlJSkpKcbGxuTk5CwsLImJif7+/qSkpB0dHXBwcPv7+8LCwmVlZZeXl/v7++Xl5fj4+Pb29vv7+/7+/v///////////////////////////////////////////////////////////////////////////v7++/v7////e3t7TU1N////0tLSAAAA3NzcRUVFAAAA9PT0NTU1NjY25ubmAAAAs7OzV1dXKysr8fHxBAQElpaWfX19CAgIw8PDAAAAkZGRgoKCAAAA3d3dEhISa2trt7e3GBgY0tLSQ0NDMjIy/Pz8Z2dnNzc34ODgmJiYmpqa+Pj43t7evb29cXFxODg4UVFR/Pz8dHR0Tk5O4ODg1tbWQEBAfn5+////a2trn5+f/Pz89vb2nZ2d/Pz8hoaGGxsbtLS019fXJCQk6+vro6OjLS0t9/f3UFBQWlpa9fX1iIiIYGBgNDQ0cXFxgICAAAAAtra2xcXFU1NTPT093NzcqqqqWFhYh4eH5+fntra2SEhIVVVV5OTk8vLy5eXl9/f39PT08fHx/v7+///////////////////////////////////////////////////////////////////////////+/v78/Pz///+mpqYXFxfNzc3d3d0JCQljY2PR0dECAgKcnJySkpIFBQXv7+8EBARWVlZRUVE1NTXj4+MBAQF8fHyJiYkNDQ3Pz88AAACHh4dpaWkAAADh4eEaGhpvb2+pqakRERHj4+NTU1M/Pz////9bW1s7OzvLy8txcXFCQkLt7e2tra3+/v5oaGhPT0/GxsbT09MzMzOmpqb6+vpNTU1kZGT6+vq8vLxhYWH////ExMSxsbH////Y2NhERES0tLT4+PhWVla4uLjX19cAAADDw8OOjo4mJib09PRVVVVPT0+NjY1QUFDm5uYnJydjY2P8/PwmJiYRERHj4+OKioomJiZ+fn7///+VlZUhISGGhob09PTMzMz7+/v19fX5+fns7Ozz8/P+/v7///////////////////////////////////////////////////////////////////////////////v7+/39/eTk5B0dHX5+fvLy8gwMDBISEv///xwcHDIyMuvr6woKCu/v7wkJCWRkZD4+PisrK+jo6AICAnh4eLKysgEBAfX19QAAAIaGhpaWlgAAAOnp6SYmJnR0dMjIyAAAAOzs7EpKSkVFRf///1VVVWFhYfr6+mZmZoODg9fX1ywsLNHR0cvLy8rKyv///6SkpB0dHeTk5MrKynJycri4uPf391dXV3Fxcf///2lpaenp6fz8/EpKSl5eXv///7KysldXV////15eXlxcXP///zY2Np2dnZCQkEVFRd/f3xUVFevr61NTUxsbG9DQ0Ly8vBYWFpOTk+Tk5F9fXzIyMvDw8N7e3iwsLHNzc////6ysrKioqP////n5+e3t7erq6vHx8f///////////////////////////////////////////////////////////////////////////////////Pz8/Pz8/v7+aWlpWVlZ////YGBgEhIS5ubmfn5+AAAA39/fsbGxPz8/XV1dVFRUEhISW1tb7e3tBQUFQ0NDycnJAAAA9vb2AAAAW1tbsrKyAAAA5ubmT09PZGRk8/PzVlZW2dnZAAAAlJSU+vr6KioqQ0ND/f39PT09UVFR6OjoS0tL5OTkU1NTPj4+z8/P/f396enp9fX1ODg4V1dX8PDw0NDQWlpa39/f1tbWfX19/f39y8vLU1NT7u7uurq6a2tr4+Pjurq6RkZG7OzsVlZWQUFB/v7+ISEhoqKienp6mpqa39/fAAAAjY2N8fHxIyMjTk5O/v7+cnJyEhISw8PD6enpQUFBX19f////lJSUPz8/09PT+/v76+vr7Ozs+fn5/v7+///////////////////////////////////////////////////////////////////////////////////8/Pz6+vr19fXOzs6Pj4/6+vqysrIbGxvn5+ecnJwAAADT09PT09MDAwNvb2/MzMwEBAR7e3vf398CAgI+Pj7i4uIAAADQ0NAKCgogICDFxcUAAABsbGyfn58MDAz19fVYWFinp6cAAADKysrh4eEiIiI9PT3y8vI1NTVJSUnX19clJSXj4+NKSkpCQkLd3d1eXl66urri4uIsLCxZWVn39/dxcXFsbGz///9aWlq8vLz4+PiIiIi1tbX6+vpdXV2SkpL9/f07Oztzc3Pk5OQTExO7u7tpaWlWVlbV1dUPDw/Y2NhSUlIZGRnz8/NcXFwYGBjb29vU1NQHBwdhYWH7+/t3d3dgYGDNzc2+vr4+Pj6enp7////k5OTe3t7j4+P19fX7+/v+/v7///////////////////////////////////////////////////////////////////////////////z8/Pv7+/v7++zs7AMDA7KystnZ2SAgIP7+/r29vQAAAKenp/T09BISEjIyMvPz8wUFBYeHh8fHxwEBAVZWVtXV1QAAAMjIyFFRUQkJCeXl5Q4ODjg4OMLCwgAAAGlpaf7+/mxsbBkZGfb29rS0tB0dHUFBQenp6UdHR01NTcXFxS4uLufn5zk5OTc3N+3t7SMjI4aGhr6+vqSkpPX19b29vWNjY729vdnZ2VdXV+Pj45+fnz4+Pv///7KysjIyMv///5mZmT8/P+zs7F1dXUxMTMrKygAAAOvr6y8vLxgYGLm5uQAAAGdnZ5qamgkJCX5+fvr6+oGBgTAwMPLy8pCQkA0NDZ2dnf7+/kdHR4iIiP7+/qWlpa6uru/v7+3t7fb29vv7+////////////////////////////////////////////////////////////////////////////////////Pz8+fn5+/v7////PDw8Q0ND////LCwswsLC0NDQAwMDVFRU+vr6ISEhAQEB5ubmFhYWhYWFmpqaMzMzQkJCvr6+AAAA5+fnPz8/AgICxsbGAAAAExMT9fX1FxcXExMTvb29lZWVi4uL////o6OjKSkpMDAw+vr6JycncnJyt7e3Pj4+/f39ODg4YmJi2dnZWVlZ1dXVYmJiMTEx8fHxjIyMXFxc7OzsXl5eZ2dn/Pz8UFBQsbGx9PT0IyMjpqam+fn5Li4uQEBAxcXFCQkJ+/v7ISEhlZWVs7OzDg4Op6enODg4Ojo63NzcLS0tT09Px8fHe3t7BwcHvb293d3dGRkZODg49vb2a2trfn5+8fHxo6OjY2Nj0dHR9/f36+vr8vLy/Pz8///////////////////////////////////////////////////////////////////////////////////9/f38/Pz8/Pz///9VVVUNDQ34+PhCQkJeXl6tra0cHBwvLy/q6upsbGwHBwe2trYnJydYWFinp6chISEXFxdHR0dOTk7AwMAZGRkAAAC4uLgpKSkKCgqRkZGdnZ0AAAA8PDxbW1v///9vb28vLy80NDQ5OTn+/v4pKSlubm61tbVdXV3r6+sjIyOfn5+5ublzc3Pj4+NAQEAxMTHz8/NMTExKSkrl5eUtLS27u7vBwcEbGxvs7Oxra2sjIyP5+fmKiooqKirLy8tXV1d0dHSWlpaLi4vZ2dkGBgaTk5OWlpYjIyP39/dKSkoZGRn8/PyYmJhDQ0OTk5P19fUwMDBKSkr///99fX1fX1////+srKxNTU3Kysrn5+f7+/vu7u74+Pj///////////////////////////////////////////////////////////////////////////////////////7+/vv7+/r6+vf396ioqAAAAMnJyXx8fD4+PvHx8VFRUQkJCfj4+EJCQgAAALCwsCoqKhkZGbu7uwMDAwAAAEtLSwAAAKWlpWBgYDU1NY2NjSoqKgAAAHBwcGdnZzAwMGFhYQYGBr6+vmJiYktLSz8/PzQ0NP7+/icnJ42NjXNzczIyMufn5xsbG8TExISEhB8fH+vr67+/vzg4OO7u7jg4OHNzc/b29nFxcd/f31NTU35+ftTU1B8fH3h4ePb29khISFFRUf///zk5OYCAgGtra+/v70tLSz8/P+Li4hgYGHNzc76+vgYGBo6Ojr+/vxcXFzQ0NMfHx3FxcQoKCry8vHNzc0RERM/Pz9jY2EBAQJSUlObm5v39/d/f3/T09Pf39///////////////////////////////////////////////////////////////////////////////////////////+/v7/f393d3d4ODgAAAAxcXFnp6eEhIS+vr6eHh4CwsL////aWlpAAAAysrKTExMAAAAurq6Y2NjfX19r6+vAAAAg4ODgYGBAAAAra2tQUFBAAAAsrKyc3NzoKCgExMTAAAAsrKyOTk5S0tLcnJyNDQ0+Pj4Ly8vkJCQXFxcTk5O4+PjHR0d5OTkXl5eKSkp7e3tKioqRUVF0tLSMjIy3d3dvr6+nJyc8fHxX19f29vbh4eHICAg4eHhWFhYJiYm4+Pjy8vLCQkJMTEx9vb2eXl5ERER2dnZZWVlBwcHvr6+T09PGxsb6urqMDAwCAgI0dHRjIyMAwMDb29veXl5HBwcy8vL/f39bm5ufHx8x8fH3Nzc1tbWxcXF8/Pz9PT0///////////////////////////////////////////////////////////////////////////////////////9/f37+/v8/PzKysru7u4bGxuvr6/AwMAAAADh4eFkZGQAAACysrKZmZkAAAChoaGxsbEAAACCgoJqamohISG7u7sCAgIHBwd9fX0AAADFxcUjIyMGBgb19fU3NzcYGBgXFxcQEBDg4OAAAAAAAACysrIZGRn09PRAQECmpqZUVFRAQEDCwsI6Ojrx8fE2NjZDQ0Pl5eURERGcnJxzc3Nqamr////FxcXj4+PGxsYzMzPu7u4iIiJRUVHKysoiIiJZWVn///8iIiIdHR3f39+dnZ0ICAjDw8O6urpVVVVra2uTk5MAAACioqKDg4MAAABOTk7e3t4sLCx8fHzr6+sYGBiIiIj7+/t9fX1dXV3m5ub///+Pj4+IiIjc3Nzz8/P4+Pj///////////////////////////////////////////////////////////////////////////////////////////r6+vz8/Ht7e9/f3wsLC11dXf///y4uLkFBQYmJiQAAAN7e3mdnZwAAAHh4eKenpwAAAH5+fkhISAAAAIyMjAAAAFxcXHV1dQMDA9TU1A4ODhEREeHh4QMDAwwMDCkpKZubm7a2tgAAACEhIYSEhAwMDNbW1kVFRZWVlV5eXnd3d5ubm0RERM7OzhwcHFhYWLa2thkZGeXl5TIyMoWFhff39zk5OfDw8G9vb5+fn5+fnxwcHNbW1lxcXAICAuLi4ktLSy0tLXFxcf///x0dHSgoKP7+/ikpKTExMfz8/A8PDyQkJOvr6w8PDwAAANnZ2Tg4OCwsLP///2JiYj8/P+Hh4ba2toODg9/f3/Hx8a+vr3Nzc8jIyPv7+/f39/v7+////////////////////////////////////////////////////////////////////////////////////////Pz8+/v7/f39k5OT7+/vJiYmJCQk/v7+enp6AAAAn5+fAAAAsLCwy8vLAAAAeXl5sLCwAAAAb29vra2tBQUFbGxszc3N5eXlNjY2BQUF4+PjGxsbHBwcmZmZAAAAfX19aWlpysrK3d3dEhISAQEBr6+vLCwsrq6ubW1tlZWVKSkpjIyMcnJyLS0tra2tCQkJqKioY2NjJycn3d3dHR0dvb296urqS0tL5+fnFRUV4+PjPj4+enp68vLyCwsLeXl5vLy8ERERDw8P/Pz8bW1tAAAAtra2goKCAAAAqqqqs7OzAAAAs7OzoaGhAAAAiYmJ29vbAAAApqam29vbCwsLycnJu7u7SEhIx8fH+vr6wMDAjY2Npqam8/Pz/Pz89fX1+Pj4///////////////////////////////////////////////////////////////////////////////////////+/v77+/v+/v6Ojo7v7+9FRUUDAwPV1dVycnIAAADY2NgAAAB2dnbq6uoGBgYqKirt7e0AAAAeHh7///8eHh4oKCitra0HBwcNDQ0FBQXt7e0wMDAZGRmGhoYAAAD19fUDAwN8fHyWlpY2NjYEBATCwsIFBQWUlJRVVVVvb28MDAy4uLgrKys3NzeVlZUMDAy6urozMzOGhoaFhYUmJibd3d2kpKTQ0NCIiIhcXFyvr68yMjL7+/toaGgWFhbX19crKysGBgbFxcWkpKQJCQlsbGzV1dUAAAAUFBTV1dUICAgdHR38/PwMDAw2Njbv7+9HR0dgYGDv7+84ODh9fX3Z2dlWVlaEhIT7+/vj4+OOjo6VlZX19fXu7u7Ozs7r6+v7+/v///////////////////////////////////////////////////////////////////////////////////////////v7+/39/ZaWlqqqqkxMTAcHB+Hh4ZGRkQAAAPT09BMTE0xMTNXV1SQkJA8PD////ykpKQgICPPz8yIiIjw8PKCgoAMDAy8vLwMDA97e3jExMTIyMn5+fjk5OdHR0QEBAZeXl8/Pz0dHRwAAAMzMzBYWFpGRkXV1dUBAQBsbG8vLyxEREUdHR3R0dAoKCtra2icnJ5OTk2FhYS4uLt7e3jMzM5WVlZiYmLq6ujg4OJKSkrq6ugkJCZaWlqurqykpKTc3N9jY2EVFRRISEtLS0nl5eQEBAba2tmBgYAYGBpqamq6urgAAAJCQkJaWlgAAALS0tGRkZCcnJ7a2tqWlpTU1Nc7Ozv39/Y+Pj4GBgdnZ2erq6rq6usjIyPb29vn5+f///////////////////////////////////////////////////////////////////////////////////////////v7+/Pz8sbGxwsLCVVVVAAAAvLy8v7+/AAAA3t7eHR0dDg4O09PTNTU1BgYG1dXVREREAQEB4eHhMTExMjIy5OTkHx8fvb29W1tb3t7eGxsbSEhIOjo6SEhIk5OTAAAAqKioIiIilJSUFhYWmJiYRUVFZmZmt7e3MjIyLy8v4ODgDw8PbW1tdXV1FxcX8fHxGRkZoaGhLS0tkJCQiIiIGxsbkZGRycnJKioqKysr9vb2NTU1HR0d8/PzUFBQFBQU29vbampqDg4OX19f0tLSAAAAXFxcrq6uAAAAODg4////V1dXVVVVpaWlHBwcPT0939/fCwsLt7e3zMzMMDAwampq5ubmwMDAPj4+mZmZ+Pj4vb29m5ub4uLi/f39/f39///////////////////////////////////////////////////////////////////////////////////////////+/v78/PzBwcHBwcGXl5cAAACOjo7g4OAAAACzs7M3NzcEBATq6uppaWkAAADLy8t0dHQAAACNjY1QUFAICAj///8RERFmZmb+/v7j4+MSEhJ4eHhQUFAuLi6SkpIAAACmpqYBAQGvr68KCgpUVFRmZmYhISG5ubkAAAARERHd3d0AAABsbGyGhoYBAQGenp4AAACgoKAHBwfo6Og7OztJSUn8/PwkJCQ5OTmnp6e3t7cMDAxqamrFxcUAAABSUlLLy8tMTEwhISHk5ORqamoAAADq6uo6OjoDAwPLy8ve3t4nJyf8/PwzMzMAAADJycllZWULCwv8/PxiYmInJye4uLjs7OxXV1d8fHz9/f3n5+eJiYm5ubn7+/v5+fn8/Pz///////////////////////////////////////////////////////////////////////////////////////////7+/vv7++Dg4EVFRf///z09PUdHR+Dg4AYGBrCwsJeXlwAAAKmpqbe3twAAAGdnZ9vb2wAAAK6urlpaWgICAri4uC4uLklJSaamphUVFTs7O39/f0dHRw0NDevr6wAAAM3NzRYWFunp6RQUFHV1dVpaWhcXF7m5uQAAAFlZWdTU1AAAAHR0dHh4eAwMDL29vQ0NDXp6el1dXZmZmQICAmdnZ3Z2dhkZGU9PT9TU1CEhIVdXV9ra2iIiIjw8PO7u7kFBQQUFBcfHx11dXQICAouLi8DAwAEBAXd3d9fX1w4ODp6enmRkZBQUFJ6ens3NzQwMDMjIyISEhCgoKJWVlfPz85iYmFVVVd3d3fHx8WhoaIqKiujo6P39/fn5+f///////////////////////////////////////////////////////////////////////////////////////////////f39/Pz89PT0MzMz////T09PGRkZ/Pz8FhYWd3d3i4uLAAAAiYmJv7+/AAAAFhYW5ubmCgoKlZWVhoaGAAAAzs7OJSUlKCgo1NTUAQEBJSUlPT09ZWVlEhIS5+fnAAAA1NTUHR0d6urqHx8feXl5d3d3CQkJwMDAAAAARUVF2NjYAAAAYWFhh4eHBgYG3t7eFhYWMjIymJiYR0dHFhYW09PTHh4eEBAQu7u7Xl5eAAAAqqqqk5OTAQEBmpqasbGxEBAQXFxc6enpIiIiFxcX8fHxU1NTDg4O29vbYGBgGRkZ5ubmDg4OCAgI3t7eZmZmKioq5+fnKysrKioqlZWVysrKSkpKl5eX/v7+vb29UlJSs7Oz8/Pz8PDw9vb2/v7+///////////////////////////////////////////////////////////////////////////////////////////9/f39/f3///9XV1f///9JSUkICAjs7OxHR0c7Ozv///8AAAA/Pz/8/PwhISEQEBDU1NQkJCQiIiKpqakAAAC9vb0/Pz8vLy/g4OAAAACBgYEAAAAHBwctLS3U1NQAAADOzs41NTXk5OQsLCxqamqlpaUAAADc3NwAAAA3Nze+vr4AAABycnKdnZ0AAADCwsI9PT0AAADPz89SUlLa2tpRUVEAAACioqLNzc0AAABRUVGkpKQGBgYaGhrq6uoAAAADAwPS0tIVFRUjIyOqqqqZmZkAAACRkZGnp6cAAAB5eXmLi4sAAADAwMCLi4sMDAzHx8dsbGwcHBxubm7b29tra2tBQUH6+vrT09M3NzeWlpb5+fnU1NTz8/P5+fn///////////////////////////////////////////////////////////////////////////////////////////////7+/vn5+f///2lpacTExJKSkiMjI////zg4OAAAANnZ2Y2NjQAAAPj4+FZWVgAAAPr6+i8vLwAAAKysrAEBATY2Nm9vbx0dHfLy8gEBAcPDwxAQEBoaGgcHB/X19QEBAc3NzSMjI9XV1SUlJVdXV4uLiwAAANbW1hYWFhwcHLS0tAAAABISEtXV1QAAAISEhLKysgQEBLm5uf///5OTkwQEBAUFBf39/UBAQAEBAebm5jc3NwUFBdTU1FZWVgAAAIqKiq2trQAAADg4OPz8/CEhIQMDA9HR0RcXFwoKCunp6RsbG09PT/f39y4uLjIyMt/f3zAwMH9/f/X19aenpyMjI9/f39nZ2URERFxcXPDw8Pj4+J+fn+zs7Pf39///////////////////////////////////////////////////////////////////////////////////////////////////+/v7////cnJyeHh439/fIiIixcXFv7+/AAAAc3NzwcHBAAAAi4uLfn5+AAAAj4+Pc3NzAAAA4+PjKSkpJSUlurq6CwsL9/f3DAwMoaGhJSUlExMTKysrpKSkEBAQpKSkQ0NDfHx8Nzc3NTU1y8vLAAAAp6enbGxsAAAA4uLiBwcHCAgI9PT0MjIyHh4eqKioAwMDYmJieXl5CQkJBwcHu7u7c3NzAQEBcXFxsLCwAAAAJiYmtra2AwMDERER+fn5bGxsCAgIwMDAZGRkAAAASEhIZGRkAAAAR0dHqampMzMz8fHxMzMzERERtra2jY2NODg49/f32dnZS0tLd3d3////bW1tQEBA3d3d////xMTEt7e39vb2+/v7///////////////////////////////////////////////////////////////////////////////////////////////////6+vr+/v6jo6MyMjL09PRXV1djY2P///8yMjIvLy/9/f0YGBiEhITk5OQBAQGLi4txcXEAAADJycl5eXkaGhrIyMgAAADDw8MdHR1jY2OhoaEDAwNgYGAWFhYcHByRkZEgICBcXFxWVlYLCwvl5eUHBweQkJB5eXkAAADLy8tcXFwAAACxsbGtra0ODg4iIiIlJSUZGRkKCgoMDAxSUlL39/cjIyMeHh76+vojIyMxMTHf3989PT0AAACoqKh8fHwAAAB+fn6JiYkAAAAlJSXw8PArKysfHx/S0tIODg62trabm5sICAhcXFzg4OA7OzuioqL29vZHR0cvLy/f39/19fVYWFiYmJj////S0tKLi4vc3Nz5+fn7+/v///////////////////////////////////////////////////////////////////////////////////////////////////z8/Pv7++fn5xQUFKysrIGBgRYWFvn5+XFxcRISEvX19TExMU5OTr+/vwAAAKysrJycnAAAAHl5ea6urgAAANjY2AwMDH19fSEhIRUVFeHh4QQEBJeXlwAAADs7O9zc3AAAADIyMl9fXwAAAMzMzBUVFWdnZ5ubmw8PD0FBQeLi4gAAABMTE9nZ2Y+PjwICAgAAAAQEBB8fH8nJyeXl5R4eHjo6Ov///2FhYQAAAGZmZq2trQAAAGNjY8LCwgICAicnJ/j4+BEREQMDA9fX14yMjAAAANDQ0F1dXREREeXl5R4eHjo6Ou/v72VlZUREROjo6H19fS0tLXt7e+zs7JOTk1BQUPb29vj4+IWFhZWVlezs7Pr6+vv7+////////////////////////////////////////////////////////////////////////////////////////////////////v7++/v7/v7+dHR0OTk57e3tQkJC8fHxuLi4MzMz7u7uMTExExMT9fX1EhISTExM9vb2CAgIWVlZu7u7AAAAs7OzKioqcnJyZGRkAQEB3d3dBAQEdnZ2AQEBfHx8ysrKGBgYGRkZnp6eAAAAmpqaODg4JSUl+Pj4CwsLAAAAx8fHKysrBwcHIyMj////vLy8ioqKtra29vb29/f3Ojo6AAAAmJiYxsbGAAAAJSUl7OzsFRUVCgoK5eXlEhISAQEB0NDQPj4+AAAAqqqqp6enBAQEh4eHx8fHExMT2NjYQkJCCwsL6urqkJCQRkZGsrKy0NDQVFRUSEhI9PT02NjYMTExsLCw/Pz8wcHBcXFx09PT9fX1+fn5+/v7///////////////////////////////////////////////////////////////////////////////////////////////////+/v77+/v9/f3KysoqKirx8fF7e3uamprn5+ceHh7a2tp1dXUAAACmpqZCQkJISEj4+PgSEhINDQ3i4uIAAACNjY1kZGRTU1Onp6cAAADJyckVFRVFRUU6OjoHBwfx8fFgYGAXFxfj4+MAAABJSUl0dHQBAQHY2NhEREQAAABmZmbc3NwMDAwPDw9UVFTr6+v////m5uZ1dXUpKSkvLy8zMzP29vY0NDQCAgK6urqKiooAAACioqKampoSEhKKioqtra0AAAA7OzvR0dEDAwMNDQ3w8PBoaGhNTU2UlJQLCwuRkZG9vb1HR0d4eHj09PRvb28hISG9vb3u7u5OTk5ERET6+vru7u5iYmKKiorz8/P4+Pj6+vr9/f3///////////////////////////////////////////////////////////////////////////////////////////////////39/fv7+/z8/NbW1kRERNjY2LW1tSMjI+fn50VFRXx8fOjo6AAAAKioqNLS0hcXF9fX10tLSwAAANfX1wAAADQ0NM7OzgYGBtjY2BERESkpKZ2dnRMTE8HBwQAAAMXFxaqqqiEhId3d3QgICCAgIPDw8AUFBUVFRfPz8wEBAQQEBL6+vuHh4RkZGQICAhcXFz8/PxAQECYmJgUFBXd3d////0FBQQAAAK2trYGBgQAAADw8PP7+/hcXFykpKc/PzwICAhISEvT09FRUVAICAsnJyZ6engEBAbe3tz4+PtjY2J2dnQ8PD5CQkOrq6snJyR4eHnNzc/7+/mJiYjIyMt7e3v///3Nzc1lZWdTU1Pv7+/r6+vv7+/7+/v//////////////////////////////////////////////////////////////////////////////////////////////////+/v79/f3+vr68PDwNjY2bm5u8/PzICAgkZGRdnZ2FxcX9fX1JSUlKysr/Pz8HBwcsLCwrKysAAAAvb29RERERUVFxsbGAAAAzc3NREREDw8PwsLCAAAAvr6+BwcHNjY29PT0Dg4Ot7e3XFxcAgIC1tbWMTExAQEBra2tsLCwAAAACwsLTU1Nzs7OZmZmCgoKAAAABAQEEBAQuLi45eXlKSkpAAAAdHR02NjYHh4eEhIS6OjoMzMzICAg6+vrJSUlAAAAzc3NR0dHAAAAfn5+4uLiDw8PJSUl/f39m5ubLS0tFhYWkpKSzMzMycnJLCwsNjY29PT0X19fICAgy8vL9PT0o6OjR0dHsbGx/f394+Pj4+Pj+Pj4/v7+///////////////////////////////////////////////////////////////////////////////////////////////////+/v739/fw8PDu7u5WVlYmJibt7e1TU1M6OjrT09MFBQXKysp9fX0FBQXLy8s6OjpfX1/n5+cUFBRUVFR3d3dBQUHf398AAACnp6d4eHgKCgrW1tYAAACTk5M1NTUFBQXe3t5OTk5ERES/v78AAACbm5uWlpYAAAAVFRXw8PBMTEwFBQUGBgYpKSnLy8uysrJcXFyQkJDo6OjDw8MeHh4aGhobGxvQ0NAcHBwAAACPj4/Q0NAGBgaRkZFra2sCAgJ8fHzOzs4DAwMhISHr6+taWloCAgKRkZHT09MICAgLCwuIiIiOjo6tra1KSkoYGBjNzc3Ly8sfHx9NTU38/PzFxcVbW1uMjIz29vb7+/vJycnn5+f5+fn///////////////////////////////////////////////////////////////////////////////////////////////////////7+/vr6+vf394qKitbW1jY2NsHBwebm5hcXF6Ojoz09PYaGhurq6hMTE5CQkKampgsLC/j4+D09PSQkJMDAwAAAAO/v7wICApaWlqWlpQoKCvX19RYWFl9fX6GhoQAAAKmpqV5eXisrK+np6QAAACQkJP///1JSUgAAAFNTU////2RkZAICAgkJCQUFBeTk5P///+Hh4T4+PgkJCQkJCRMTE+zs7FlZWQAAAHl5edjY2BYWFpCQkLCwsAAAABUVFfb29icnJwcHB9XV1ZSUlAAAAKioqPPz8z8/PwsLC93d3a6urgYGBsnJyTo6OpycnP///1tbWzo6OuHh4d7e3mVlZWhoaPr6+vDw8MrKysbGxvPz8/39/f///////////////////////////////////////////////////////////////////////////////////////////////////////v7+/Pz8////QUFB7Ozsk5OTPT09////LS0tgYGB1dXVEBAQuLi4Ozs7MTEx7e3tBQUFfHx8qqqqERER7OzsAAAAt7e3Pj4+CgoK19fXEhIS9fX1Pj4+CgoK8PDwJycnMTEx4eHhAAAAqqqqeXl5AAAAd3d36enpBgYGAAAAMjIy////2dnZPz8/SUlJlpaWXl5eAAAADw8PFxcXTU1N/v7+YGBgAAAALi4ux8fHAAAACQkJ/Pz8Hx8fCgoK0NDQgYGBAAAAe3t7r6+vAAAAIyMj////Tk5OGRkZ7OzseHh4JSUl1NTUQ0NDbW1t/v7+UFBQBgYGzMzMwsLCNDQ0YGBg9PT05ubmhoaGgYGB1NTU9/f3/Pz8///////////////////////////////////////////////////////////////////////////////////////////////////////+/v76+vr///9BQUGnp6f19fU2NjaioqKMjIxhYWH8/PwlJSWHh4daWloUFBTv7+8sLCwODg7p6ekgICDl5eUsLCxmZmaRkZEAAADLy8s0NDRycnKfn58AAACpqalxcXETExP4+Pg9PT1VVVX4+PgiIiIICAivr6+qqqolJSUAAABaWlqBgYGsrKyGhoYQEBAJCQkJCQlFRUWhoaH8/PyIiIgDAwMeHh7Y2NgaGhoFBQVlZWWLi4sDAwOCgoK+vr4WFhYjIyP39/cnJycZGRnLy8tpaWkfHx/S0tKlpaUEBASYmJjMzMwYGBjd3d2bm5sYGBhhYWH6+vpQUFBKSkrX19f7+/uBgYFtbW3c3Nz39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////7+/vv7+////3FxcVdXV/39/YaGhjQ0NMLCwjY2NsrKym1tbX9/f7m5uQoKCrq6up2dnQAAANra2nd3d4qKipCQkBkZGe/v7wMDA5eXl4+Pjzw8PO/v7xQUFGhoaMHBwQAAALu7u83NzQAAAJmZmcnJySEhIR4eHt/f3+fn539/fy0tLRMTEwYGBgEBASoqKllZWYuLi/39/cvLyzs7OwICAiwsLLy8vHBwcAAAAEFBQZSUlAEBAUBAQPX19SEhIQUFBcXFxX5+fgAAAImJiaOjowAAAKioqM3NzQwMDHV1dfX19T4+Pm5ubv7+/isrKycnJ8fHx4mJiTAwMKOjo////8/Pz0FBQcLCwv7+/vv7+/r6+v39/f///////////////////////////////////////////////////////////////////////////////////////////////////////v7++/v7////xcXFKSkp0NDQycnJICAg0dHRhYWFjY2N8fHxWFhY////Ozs7T09P09PTAgIChISEqqqqAAAA6+vrQUFBxcXFMzMzEhIS5eXlDQ0NhYWFv7+/AAAA4+PjUFBQFBQU/v7+Pz8/CgoKt7e36OjoJSUlDg4OkJCQ/Pz8+fn53d3dyMjIwMDA9/f3////tbW1UVFRBQUFGxsbLS0t+fn5dHR0AAAAjo6O6+vrBQUFNDQ07e3taGhoAQEBpKSkpqamBwcHUVFR7e3tFBQUcHBwzs7OJCQkTExM9fX1TExMIiIi1dXVzMzMGxsbnJyc5eXlGRkZdHR0////vb29UFBQeXl5/////Pz8/v7+8/Pz/Pz8///////////////////////////////////////////////////////////////////////////////////////////////////////////9/f36+vrr6+tGRkaCgoL29vY1NTV3d3fd3d0rKyvp6elXV1eKiorp6ekpKSmQkJBqampOTk7c3NwICAimpqbCwsJGRkaysrIMDAz5+fl0dHQNDQ3z8/NAQEB9fX29vb0AAAB8fHzR0dEAAAAXFxfh4eHn5+cyMjIAAAAzMzPT09PKysqCgoLr6+vLy8uFhYUZGRkAAAARERGwsLD///9NTU0AAAB4eHj8/PwtLS0BAQHJyclhYWEAAAC2trbs7OwFBQUSEhL29vZMTEwjIyPz8/MoKCgICAjo6OiTk5MAAAChoaHs7OwXFxcXFxf6+vpLS0tBQUG4uLjl5eU+Pj4mJibk5OT7+/vn5+e4uLj19fX9/f3///////////////////////////////////////////////////////////////////////////////////////////////////////////39/f39/fn5+YaGhjs7O+Dg4HBwcEJCQvT09BwcHMPDw5mZmSIiIvr6+kZGRjY2NvLy8g0NDX5+fhgYGAYGBvv7+zs7O/n5+X5+fm9vb+Hh4QgICGhoaLm5uQcHB+np6VVVVQAAANnZ2cPDwxERESsrK93d3fj4+K6urhISEggICBsbGycnJwsLCxERERgYGD8/P4uLi+7u7tDQ0BkZGQAAAFZWVufn5y0tLQAAAE9PT3d3dwAAAFVVVfT09DY2NhAQEOHh4Xd3dwICAqWlpXd3dwAAAHt7e9nZ2UdHR19fX////3Z2dgICArq6upaWlhwcHLOzs/39/XNzczc3N7Ozs/////n5+djY2NTU1Pv7+////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7++vr6+vr66urqZGRki4uL5+fnHh4ezMzMiIiIMjIyx8fHHh4elJSUwcHBAAAA+Pj4NjY2QUFB19fXCgoKpqamenp6QEBA8fHxIiIi9vb2ioqKExMT/Pz8Y2NjNjY27OzsHBwcOTk5/Pz8xsbGJycnJCQkdHR0////7Ozso6Oja2trTk5OkZGRiIiIvb299/f3+fn5Pz8/ERERGxsbioqK5ubmDg4OY2NjEhISiYmJAQEBPDw8////Pz8/AAAAl5eXy8vLPDw8cnJy5OTkDw8POzs7+/v7LS0tGBgY1tbW0tLSDw8PVFRU9vb2MTExS0tL////fX19ICAg2NjY/v7+/f390dHRiYmJ9vb29PT0///////////////////////////////////////////////////////////////////////////////////////////////////////////////+/v77+/v19fX+/v6pqalBQUHm5uYlJSVwcHDu7u4cHBykpKSampo0NDT+/v5YWFheXl64uLgSEhKlpaVeXl4vLy/v7+8UFBSYmJiOjo4iIiLu7u7ExMRsbGzp6ekQEBBsbGz///9cXFwoKCjk5OTs7OxnZ2cAAABOTk7Z2dn////////////7+/vh4eHS0tKQkJA6OjoRERFISEjExMTw8PAqKioAAAAICAi7u7sbGxtJSUn///93d3cFBQWDg4P7+/sgICAUFBT6+vpPT08iIiLs7Ox2dnYAAAC8vLzOzs4LCwscHBzj4+OKiooICAjOzs7X19crKyuAgIDz8/Pf3996enqLi4vR0dH////z8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////39/f7+/t3d3dfX1/7+/kNDQ6GhocDAwEFBQe3t7W1tbU1NTfn5+RkZGbGxscrKyhMTE+vr61RUVDw8PPT09CMjI+jo6E5OTkpKSrOzs1NTU2VlZfX19UtLS7i4uMvLyxEREaWlpd7e3g0NDR4eHunp6fv7+8XFxVNTU1tbW3Jycj8/Pz8/PywsLBMTEyYmJjk5OS4uLpaWlvb29vHx8TExMQICAlVVVfb29tLS0oaGhv7+/l1dXQAAAJeXl+Hh4ScnJw8PD93d3cDAwAMDA8LCwpiYmAAAAIGBgfr6+jMzMywsLM7Ozs3NzSEhIYuLi/7+/nJych0dHd3d3eDg4ENDQzAwMNLS0v7+/vn5+fb29v///////////////////////////////////////////////////////////////////////////////////////////////////////////////v7++vr66OjonJyc////t7e3ICAg7+/vY2NjSEhI/f39ISEhu7u7xMTEGRkZ6OjoTExMR0dH5+fnAwMDpKSkycnJHh4e9PT0Dw8PNTU1/f39MDAwampqysrKExMTu7u75+fnKioqdnZ2+Pj4dXV1GRkZUlJSurq69fX17u7u+/v7mZmZSUlJVVVVdnZ2jY2N2NjY////1dXVl5eXAAAAWlpa5OTk+fn5WFhYCQkJNjY2WFhYAAAAeXl5////IyMjFRUV5+fnwsLCAAAAdnZ25OTkHBwcExMT7u7uZmZmAgICenp67+/vGxsbAQEB2trat7e3SEhI5+fn////VVVVZWVly8vL////+Pj49/f3+Pj4///////////////////////////////////////////////////////////////////////////////////////////////////////////////////7+/v09PQpKSna2try8vJqamrg4ODPz88WFha1tbW3t7cvLy/7+/s/Pz9VVVW+vr4ICAi2trZ+fn4ICAjz8/MpKSl4eHiampoVFRWUlJTU1NQgICDPz8+Xl5cODg6np6f4+PgtLS0wMDDb29vU1NSmpqaRkZFpaWlNTU1VVVX7+/vx8fHj4+P9/f329vbT09NgYGAtLS0ICAjCwsL9/f2RkZFAQEAAAAA9PT1NTU1FRUVwcHD29vYoKCgAAADDw8Ph4eEYGBgmJib39/czMzMSEhLGxsZtbW0AAAAbGxvz8/Nubm4AAACXl5f///8sLCyysrLj4+N7e3stLS3q6ur8/Pzu7u7s7Oz19fX8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+////3V1dVBQUPz8/OLi4kZGRvf391VVVUVFRfr6+jMzM3Nzc7i4uAQEBOPj42lpaScnJ////0pKSsLCwqSkpAYGBs7OzlVVVS0tLeLi4j09PTMzM/39/YWFhTExMbW1tefn52FhYUlJSdDQ0IeHh8PDw/r6+vPz893d3fz8/NHR0cDAwEVFRRkZGR8fHyQkJImJieXl5f///6OjowAAAFFRUdnZ2fPz80hISLKysv///1BQUAYGBqGhoezs7BkZGQAAAMjIyG9vbxwcHFRUVPj4+BwcHBEREeXl5a2trQAAAGtra+vr62ZmZpiYmP///46OjhQUFK6urv7+/tPT02RkZMjIyPT09Pv7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////+fn5+/v74eHhOjo6sbGx/v7+fX19eXl55+fnOjo6rq6uoqKiDQ0N6enpPDw8kJCQ3t7eDw8Ptra2ubm5Gxsb6OjoYGBgS0tL5OTkPj4+j4+P1dXVJCQkhYWF+fn5paWlLy8vdHR06urq6enp6+vrU1NT19fX4ODgsLCw8PDwioqKPT09o6OjpqamdHR0wsLC8PDw9PT0sLCwNzc3QkJCsrKy////vb29JycnExMT8PDwgoKCAAAAdHR0+fn5Tk5OBwcHfX196OjoBwcHDg4O5ubmkpKSAAAAnZ2d3NzcBAQEUlJS39/fPz8/RUVF/v7+sLCwPj4+j4+P////3t7eKysrenp69PT0+/v7/Pz8///////////////////////////////////////////////////////////////////////////////////////////////////////////////////8/Pz7+/v+/v7IyMhHR0fd3d3p6elKSkrQ0NB5eXk6Ojr7+/tqamq5ubne3t43Nzfk5OSZmZkyMjL///9KSko6Ojro6OgCAgKKiorh4eE5OTm+vr7r6+tFRUV2dnb39/fl5eWKiopOTk719fXh4eH9/f36+vr+/v7m5ub////+/v79/f3+/v7+/v76+vrh4eGGhoY8PDweHh5nZ2f5+fnx8fFjY2MvLy8ZGRno6OiSkpIAAACwsLDt7e0oKCgAAACGhob///8wMDAVFRWnp6fCwsIAAABzc3Pz8/MmJiYRERHz8/NoaGgBAQHk5OStra0LCwtfX1/n5+f6+vpeXl5iYmL39/f8/Pz6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////z8/Pj4+Pv7+/v7+1dXV4iIiP///6CgoCwsLPT09EZGRmFhYfv7+zc3N97e3nd3d1paWvHx8UVFRaOjo9nZ2RwcHKioqKKiohMTE7m5ueHh4S0tLcTExPT09IuLi2JiYtHR0fPz8/f39/Ly8paWlr29vV9fX5GRkcvLy2VlZUxMTG1tbb6+vvb29mdnZx8fHzQ0NJmZmdLS0urq6pqamiYmJiEhIWRkZO/v75eXlxsbG6mpqfX19ScnJwcHB4ODg////1JSUgEBAWBgYN/f3y0tLSwsLPv7+3BwcAUFBbW1tb6+vhAQEJWVlenp6RwcHCYmJujo6PT09JmZmV1dXfDw8P39/fHx8fX19f39/f///////////////////////////////////////////////////////////////////////////////////////////////////////////////////Pz8/Pz84eHh/f39vb29bW1t1tbW+Pj4QUFBVVVV09PTJCQki4uLkZGRNzc31NTUXFxcYWFh3NzcMjIyxcXFysrKRkZGxcXFmZmZVlZW1tbWzs7OOzs7np6e////29vbSUlJsbGxhYWFxcXFxsbGpqamsbGxvb29uLi4lpaWlJSUqKio+Pj4////19fXs7Oz9vb2////r6+vT09PHh4eUlJS5OTk7u7ufX19CQkJra2twcHBODg4Dg4OgICA////dHR0AAAAXFxc/Pz8KCgoCwsL4uLii4uLAAAAcXFx+fn5HR0dVFRU/v7+NTU1JSUl2tra+fn5dHR0SEhI7u7u////v7+/6enp+fn5/f39///////////////////////////////////////////////////////////////////////////////////////////////////////////////////8/Pz9/f2Pj4/ExMTu7u5PT092dnb////Hx8cYGBipqamampoODg6/v78ODg6Kiorx8fEpKSmIiIilpaUcHBzu7u7e3t4fHx+wsLCtra0hISHf39+UlJQ1NTVycnL8/Pzz8/Pz8/OBgYFeXl5hYWFBQUFvb2/Dw8PY2Nja2trU1NTS0tLBwcGVlZXGxsbx8fGxsbFxcXEoKCg0NDSpqan8/Py8vLwrKyscHBx4eHizs7NQUFADAwO6urrk5ORZWVkAAAAVFRXk5OSBgYEAAAB6enrt7e0REREoKCj///9ra2svLy/r6+uIiIgAAADCwsLh4eFZWVkkJCTQ0ND4+Pjf39/j4+P9/f38/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7+/vv7+7m5uXBwcP///9vb20xMTJ+fn////4SEhCQkJI+Pj8TExO/v73t7ezIyMujo6MHBwQICAu/v71xcXCsrK/T09NHR0SIiIouLi8HBwaSkpP7+/p6enhsbG3R0dI2Njbi4uPHx8f39/f///+Li4qmpqZ2dnW9vb4SEhJeXl7S0tM/Pz8rKysrKyunp6Tk5OaampuDg4P///6qqqj8/PwkJCXZ2dujo6PPz8wgICCYmJvDw8Hh4eB0dHQICAgAAAM3NzYmJiQAAADU1Nf///0hISAAAAKurq+Li4kRERNPT08bGxgAAAImJie3t7TAwMBEREcTExP7+/m1tbYWFhf7+/uXl5fPz8////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////f39/f396enpOTk539/f/Pz8bW1tIyMj4ODg////VlZWLCwsZGRk7Ozs+Pj4T09PKysr2travLy8MDAw/f39YGBgOTk56urq/f39hoaGZWVl29vb/v7+////zs7OGxsbR0dHUFBQOzs7KSkpPj4+cnJyoKCgrKysysrK1NTU0tLSzMzMWFhYNjY2hYWF/////v7+/v7+19fXT09PDAwMTk5O5ubm////a2trGhoa39/f9/f3NjY2X19f1NTUAAAAzc3NpaWlAAAADw8P7OzsvLy8AAAAV1dX////FxcXY2Nj0NDQAAAAdHR0////o6OjCQkJxMTE////dHR0NjY27e3t8fHx8PDw+Pj4///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+/v75+fn///9jY2NnZ2f7+/vj4+MqKipJSUn6+vr4+PiOjo4bGxs3Nzfz8/PPz887OztfX1////+NjY1fX1/7+/uOjo48PDxjY2P7+/t0dHQbGxtycnL19fX///+8vLwyMjLJycnw8PDS0tLGxsadnZ1ycnJlZWVfX19fX1+JiYmDg4OdnZ3X19e7u7vj4+PS0tJKSkokJCShoaHm5ub8/Pzv7+9YWFgZGRm7u7u3t7cHBwdOTk7v7+8XFxdISEjr6+sJCQkICAjQ0NDn5+cQEBAPDw/09PR4eHgFBQXa2tovLy9SUlL7+/t5eXlFRUXi4uL7+/udnZ1iYmLf39/7+/vu7u75+fn39/f///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////r6+vr6+sLCwjIyMra2tvz8/Lm5uTExMebm5oyMjOPj4/b29mlpaVBQUOLi4tTU1ExMTIGBgfv7+7S0tJqamv///729vXp6elZWVvr6+qOjo3R0dG1tbZubm////8nJyYCAgI+Pj4eHh6GhocfHx9vb27q6urW1tdra2vX19erq6tvb29/f32VlZT8/P7W1tYuLi9/f3/39/bS0tEVFRRwcHDU1NeDg4Nvb2wcHB21tbfDw8BAQEBoaGvn5+SQkJAAAAKGhofHx8RcXFwAAAKOjo+bm5hAQEBYWFvf394SEhOTk5DQ0NAAAAMfHx/z8/GBgYDw8PPLy8v///7a2trKysvr6+vv7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+/v7+Pj4+Pj4mpqaNDQ039/f9vb2hoaGjIyMhISETU1Nz8/P3t7eOzs7SkpK4uLi3t7eU1NTPDw8urq6vb29PDw8tra29vb2tra2qqqqvb298vLy29vbWlpae3t7ysrK9fX18PDwqampgYGBZ2dnVFRUmJiYdnZ2ZWVlZmZmXFxchoaG0NDQy8vL2NjY8/Pz5ubm2NjYTExMISEhPDw8p6en6urqubm5HBwcV1dX3t7eHh4eMDAw39/fkJCQAQEBmJiY9fX1IyMjAAAAbW1t/f39SUlJFxcXUVFR/f39+vr6VFRUAgICqKio/Pz8XV1dMjIy5OTk/v7+zMzMgoKC5ubm9fX1/f39///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7+/v7+/v19fXv7+88PDxKSkr09PTi4uIvLy+xsbF2dnY8PDzIyMjt7e1/f39QUFDe3t7+/v5YWFhISEj///+8vLyJiYnw8PDx8fH7+/uNjY1MTEzV1dX29vaTk5NiYmJdXV3Kysrp6en4+Pj////////4+Pju7u7////l5eXz8/Px8fHQ0NCSkpJPT09jY2NPT0+goKBfX1+enp729vbX19dAQEAQEBAzMzP19fVhYWE9PT3z8/NycnIAAACamprw8PA4ODg2NjZkZGT///+UlJQAAAAJCQnLy8vq6upaWloAAACSkpL8/PyWlpYLCwvb29v////T09NERETp6eny8vL5+fn9/f3///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////j4+P///7Gxsf///7Ozsx8fH5aWlv///4ODg2xsbP7+/q6uroGBgaysrOzs7FxcXDY2NtLS0vb29paWloiIiOvr6/z8/NjY2GJiYrGxsf///2BgYERERK+vr/39/bi4uHl5eVVVVVtbW2lpaYuLi3t7e3JycoGBgZCQkJqamnV1dXZ2dmdnZ4CAgH9/f8vLy+Tk5Pz8/O/v7/39/Z+fnxgYGBoaGpSUlPX19XV1dVJSUv///29vbwAAAFhYWP///zAwMCEhITg4OP39/Z2dnRUVFRISEsPDw/b29kdHRxYWFnt7e////3x8fAQEBK6urv7+/svLyx8fH29vb/v7+/z8/PPz8/7+/v///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Pz8////fHx82NjY8fHxm5ubIyMjurq6+Pj4lZWVurq6////g4ODMDAwx8fH9PT0fX19WFhYlJSU6urqq6urcHBw3d3d9PT0wMDALS0tubm59/f3mZmZYGBgt7e309PT+/v73d3dpqamn5+fqampsbGxnp6eqampq6ururq619fX7Ozs/v7+/////v7+4eHhw8PDrKysdnZ2UVFROzs7oKCg8/PzyMjIR0dHYmJi39/fIiIiHx8flZWV+Pj4eXl5AAAATk5O9vb2goKCAAAACgoK39/f39/fREREAAAAr6+v9vb2dHR0BQUFu7u7////pKSkFxcXc3Nz+Pj4+fn5+Pj49/f3/v7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8/Pz9/f2mpqZOTk7f39/v7+93d3czMzPm5ubx8fFCQkJwcHDo6Ohra2stLS3MzMz9/f29vb09PT2IiIj+/v6vr69PT09/f3/v7+/c3NzPz8+2trbs7Ozw8PChoaFGRkZaWlrAwMDs7Oz5+fnw8PDt7e3l5eXz8/P19fXs7Oy3t7d8fHyKiopsbGxJSUlOTk5DQ0OGhoZKSkqJiYnr6+vo6OhOTk4TExNlZWX4+PjT09OKiorl5eX8/PxYWFgAAAAtLS39/f2MjIwaGhokJCSYmJju7u4xMTEDAwOWlpb39/dKSkoAAACLi4v///+1tbUEBARra2v+/v77+/v8/Pz19fX29vb+/v7///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////39/fj4+Pj4+EFBQTw8PN/f3+/v762trV1dXcjIyOXl5TY2Nmtra/v7+4+Pj15eXr6+vu/v78jIyDU1NbCwsPv7++fn55mZmUhISIuLi+zs7NTU1HV1daampvT09Pf395+fn42NjXh4eG9vb1BQUEZGRkZGRlJSUn9/f1RUVEpKSlBQUHl5eZCQkI6Ojre3t/X19f///////+/v75iYmCMjI3Z2dsnJyf7+/t7e3qqqqpCQkMXFxU5OTicnJ5qamvDw8HZ2dgsLCzIyMuPj4+7u7jg4OA0NDaysrP///3Z2dikpKTU1NfPz85+fnwAAADU1NeHh4fr6+szMzOzs7O3t7ff39/7+/v///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////f39/Pz8/v7+2traRERESkpKvb29/v7+u7u7QUFBtbW15+fnVVVVVlZW29vbzc3NNTU1QUFB8PDw6+vrZ2dnXV1dycnJ/v7+r6+vMzMzWlpa3t7e/v7+mZmZXl5ebm5uycnJ+fn5+vr66+vr2tra3t7e3d3d2dnZ6+vr7Ozs7Ozs7Ozs6enp////////+vr6nZ2dZWVleXl5Y2NjvLy829vb7+/vk5OTUlJSGxsbCwsLbm5uj4+PKSkp19fX////S0tLHh4eWlpa/Pz8uLi4ERERHx8fpqam////QEBAAQEBR0dH9PT0+/v7EhISTExM4uLi////ysrKu7u79PT09vb2/v7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////9/f37+/v39/f9/f3c3Nw2NjZFRUW0tLT///+NjY06Ojre3t7s7OxmZmZDQ0PX19fQ0NBfX19vb2+/v7/4+Ph2dnYwMDCZmZn+/v7i4uKWlpZZWVmFhYXf39/g4OCamppdXV1paWmNjY3MzMy+vr7CwsLV1dXQ0NDb29vU1NSnp6evr6/GxsaOjo5oaGhmZmZhYWG+vr79/f3h4eHf39++vr4wMDA9PT1oaGinp6fh4eG6urqhoaHs7OzZ2dleXl4DAwOurq7s7OxeXl4TExM2Njbg4OD9/f2EhIQBAQE+Pj7r6+vs7OxkZGQuLi7r6+v9/f3GxsY4ODjp6enz8/Pz8/P6+vr///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////39/fv7+9ra2pycnPPz86GhoUJCQmNjY/f39+Dg4ENDQ0xMTOTk5Onp6UBAQElJSb+/v+7u7lVVVT4+PqWlpevr67W1tV9fX4GBgfj4+P///56enlRUVICAgOnp6enp6evr66urq4WFhY6OjmhoaFVVVVVVVWBgYFRUVGRkZIqKisvLy+Li4re3t7e3t/Dw8Pr6+vHx8ZycnGVlZXh4eObm5p6entvb2/z8/M/Pzx4eHlFRUff39+Pj4yoqKldXV8zMzP///15eXg0NDQ8PD9zc3Pz8/FdXVwsLCxQUFMbGxtPT0y8vLygoKOTk5P7+/sTExB8fH2RkZPX19fj4+PX19fv7+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Pz8/Pz87OzsTk5O8PDw4eHh39/fU1NTbm5u+fn52dnZbm5uYGBg4eHh+vr6V1dXYmJi0tLS/Pz8ra2tUFBQZWVl3d3d+/v7oqKiYmJioaGh/v7++Pj4q6uraWlppKSk/Pz8/////v7++/v78PDw4+Pj7Ozs6urq5ubm+vr6/////v7+9fX19fX16OjosrKyZ2dnV1dXY2NjfX193d3d/v7+3t7e5ubmpaWlHR0dg4OD/v7+hYWFISEhPz8/9fX19fX1Li4uQ0NDAAAAnJyc+vr6TExMAAAAEBAQ7+/v5+fnLS0tAAAAxcXF////oKCgJCQkJycnyMjI9/f3+Pj4+fn5/Pz8///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////9/f37+/v+/v6AgIBdXV2xsbH////v7+9fX19kZGTn5+f///+Xl5dERES5ubny8vJ7e3s5OTmNjY34+PjY2Nhubm5BQUGqqqr+/v7Dw8NdXV1ycnKYmJjh4eHKysqLi4tra2uKioqioqL29vb09PTn5+f4+PjX19fOzs7FxcWampqIiIh5eXlbW1taWlp0dHSdnZ3d3d339/f////f399qampCQkIqKiptbW3t7e329vaMjIweHh6BgYHa2tr5+flRUVEGBgZCQkLAwMD39/djY2MODg4bGxvV1dX29vZFRUUMDAy9vb3////Ly8tXV1cwMDDg4OD8/Pz19fX4+Pjs7Oz+/v7///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7+/vz8/Pv7+/Pz82RkZD8/P5+fn/j4+O/v71VVVVBQUOrq6v39/XZ2dkBAQMjIyP///5mZmTo6Onx8fPPz8////6urq0FBQW9vb+Pj4/z8/NXV1djY2L6+vpCQkJqampSUlI+Pj5SUlKamppGRkYqKir29vb+/v35+fp6enoeHh5+fn56ens7OzuDg4Pj4+P////Ly8snJyZycnEZGRllZWZGRkcnJyf///6enpzIyMiIiItXV1f///7u7uzIyMhsbG76+vv7+/qWlpTs7OwQEBBsbG62trf///1lZWRsbG66urv///8XFxSAgIBsbG6ioqPn5+fn5+fr6+vf39/Pz8/7+/v///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+/Pz8/Pz8+vr64+Pji4uLQ0NDVFRU4eHh39/fX19fR0dH09PT/f39pqamSEhIe3t7+vr629vbRkZGQkJCc3Nz0tLS9/f3tLS0QUFBlpaWsbGxqamp8vLy/////////////////////Pz84ODg3d3d8vLy9vb2/v7+/f39/Pz8////////+fn5x8fHo6OjioqKRkZGZWVlpKSkvr6+8/Pz/f394eHhWFhYSUlJhoaG7e3t////YWFhAgICc3Nz/f39xsbGNTU1TExMubm5ycnJ2NjY8/PzlpaWCQkJy8vL////r6+vNTU1SEhI3Nzc9PT08fHx8fHx7e3t+Pj4+fn5/v7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8/Pz////Y2Nj+/v7p6emioqJNTU1zc3Pv7+/u7u6RkZFfX1/AwMD////ExMRaWlpwcHD29vbr6+uRkZFMTExXV1eLi4v+/v7v7+/z8/Pa2tqIiIiJiYmBgYF0dHR7e3uDg4OBgYF+fn6tra3m5ua7u7vBwcHBwcHb29vAwMCEhISBgYG4uLh+fn57e3uwsLDLy8vt7e319fXz8/O7u7tycnKIiIhycnLg4OD19fXw8PBkZGQzMzOZmZn+/v6zs7MWFhZKSkr09PSQkJCIiIj///88PDwYGBizs7P4+Phvb28ZGRlOTk7o6Oj09PT5+fm8vLz39/f39/f5+fn4+Pj+/v7///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7+////6Ghoaenp/r6+v7+/tra2oaGhlxcXMjIyP39/eXl5Y+Pj6Ojo+jo6Orq6n19fVxcXLq6uv////Hx8cHBwYyMjJqamp2dnbq6uvPz8/////v7++np6cnJybm5ub6+vp6enqqqqqmpqaSkpJKSkoSEhKKiorS0tLCwsMDAwNra2vz8/O3t7eLi4v///+bm5s7Oznh4eFFRUUVFRXZ2duHh4f7+/sXFxW1tbVhYWGxsbOXl5fPz84uLixQUFGxsbPHx8XV1dQ4ODtnZ2VlZWQsLC66urvv7+5GRkRcXF0lJSe/v7/r6+vPz88rKyurq6uzs7Pj4+PX19ff39/7+/v///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////f39/f391dXVUVFRbm5u5eXl/f399vb2l5eXVFRUjo6O+Pj4+/v7fn5+ZWVl39/f9/f3pKSkR0dHdnZ2srKy5+fn////8fHx4ODguLi4eHh4k5OTtLS03Nzc+fn56enp4+Pj/Pz8/f39/Pz8/Pz8/v7+9/f3/Pz8/Pz8/v7++vr67u7u8/Pz2NjYy8vLioqKcHBwWlpabGxssbGx8vLy/v7+8PDwgYGBQkJCNDQ0xcXF+/v7wsLCLS0tRkZGxcXF+/v7TU1NBgYGwcHBoKCgAAAAsrKy/Pz8t7e3FRUVQEBA/v7+9vb24+PjVFRUra2t+vr6+/v7+/v7+fn5/Pz8/v7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8/Pz8/Pzy8vLT09OHh4dgYGCzs7Pz8/Py8vLGxsZPT09/f3/Z2dn7+/vY2Nhqamq1tbX////g4OCbm5teXl5jY2OkpKTMzMzn5+f6+vrw8PC7u7uurq6Ojo6fn5+Li4twcHCMjIyKioqMjIyVlZXKysrX19eHh4eNjY27u7uHh4dycnJ1dXWDg4N2dnaLi4vHx8fy8vL8/Pz////29vaioqJSUlJbW1tnZ2fV1dX+/v6WlpZUVFRtbW34+Pjt7e1VVVUWFhaOjo7k5OQwMDC7u7v///9ra2sVFRVubm7c3Nz8/Pzw8PBQUFDCwsL09PTs7Oz39/f39/f19fX7+/v+/v7///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7+/v39/e3t7ejo6P///76+vnZ2dmlpaenp6f7+/uDg4Hd3d05OTsnJyf///97e3mBgYIODg7+/v/j4+PX19cvLy4+Pj2xsbGZmZqOjo8/Pz/f39/////////Ly8uDg4MbGxp+fn7+/v8fHx9TU1MfHx6ioqKWlpZWVlZ2dnaysrOnp6d/f3+fn5/7+/v39/eTk5Nra2qGhoYSEhHNzc3FxcYyMjOvr6////8zMzG1tbTc3N7W1tfj4+J2dnRMTE3Jycurq6sDAwBkZGXd3d/X19W5ubgsLC3Fxcezs7ODg4GNjY1dXV6Kiov////b29vj4+Pj4+PT09Pn5+fv7+////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////v7++/v76urqnp6e0tLS////7+/vh4eHgYGB5ubm+/v77+/vubm5kZGRzs7O////5ubm1tbWjIyMmZmZ5OTk/Pz8+Pj44eHhxcXFycnJzc3N19fX4+Pj7Ozs/f39/f39/f39/////Pz8/v7++Pj4/v7++fn59PT0+vr6/f39/Pz8+Pj4+/v7/Pz8/v7+39/fuLi4xcXFwsLCvr6+6urq7+/v+/v7+vr6ycnJbm5uYWFh2tra////dnZ2KCgokZGR////sLCwKioqnZ2d7OzsX19fJCQkwcHB+vr67e3tbGxsSUlJwcHB+vr69PT0+/v78/Pz/f39+Pj49/f3/v7+///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////9/f39/f38/Pz8/Pz+/v7////9/f37+/v8/Pz+/v7////+/v78/Pz8/Pz+/v7////////+/v77+/v8/Pz+/v7+/v7////////////////9/f3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v79/f3+/v7+/v7+/v7+/v7+/v7+/v79/f3+/v7////////////////////9/f38/Pz7+/v9/f3////+/v75+fn5+fn+/v7+/v76+vr6+vr+/v7+/v75+fn7+/v////////7+/v6+vr8/Pz+/v7+/v7+/v7+/v7+/v7+/v7////9/f3//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////w==",
                            FingerHuella: finger.finger[0].toUpperCase() + finger.finger.slice(1) + " Mano " + finger.hand, // "Indice Derecho",
                            TelefonoCliente: vm.cellphone,
                            CorreoCliente: vm.email
                        }
                    };
                    //console.log(JSON.stringify(jsonFinger));

                    reqInsertSource.fingerCentralRiskAuth(jsonFinger).then(function (data_) {
                        var code = "0";
                        var msg = "";

                        if (data_.status) {
                            if (data_.data.status.code == "0200") {
                                msg = String.format("Documento de Autorizaci&oacute;n Centrales de Riesgo # <strong>{0}</strong>",data_.data.result.result);

                                $log.info("Documento de Autorización Centrales de Riesgo #" + data_.data.result.result);
                            } else {
                                msg = String.format("Inconvenientes al Documento de Autorizaci&oacute;n Centrales de Riesgo. Error {0}<br/> {1}", data_.data.status.code, data_.data.status.detail);

                                $log.warn(String.format("Inconvenientes al Documento de Autorización Centrales de Riesgo. Error {0}: {1}", data_.data.status.code, data_.data.status.detail));
                            }
                        } else {
                            code = "500";
                            msg = String.format("Error 500. Documento de Autorizaci&oacute;n Centrales de Riesgo {0}", data_.data);
                            $log.warn("Error 500 Documento de Autorización Centrales de Riesgo");

                            vm.result.state = false;
                        }
                        //vm.result.code = code;
                        //vm.result.message = msg;

                        vm.result = {
                            code: code,
                            message: msg
                        }
                    });
                },

                init: function () {
                    base.getUserInfo();

                    vm.documentType = "1";
                    vm.documentTypeSpouce = "1";
                    vm.gender = "Femenino";

                    vm.provinces = base.getLocalization();
                    vm.countries = base.getCountries();
                    vm.emailDomains = base.getEmailDomains();
                    vm.genders = base.getGenders();

                    vm.documentTypes = params.getParam("parametrics_tiposIdentificacion");
                    vm.jobs = params.getParam("parametrics_ocupaciones");
                    vm.militariesForce = params.getParam("parametrics_fuerzasMilitares");
                    vm.civilStatusL = params.getParam("parametrics_estadosCiviles");

                    vm.dateOptionsBirth = toolsForm.nestedControlDate.dateOptionsBirth(18);
                    vm.dateOptionsExped = toolsForm.nestedControlDate.dateOptionsExped();

                    var load = base.loadLocalData();

                    if (load) {
                        vm.fromLoaded = true;

                        //Disparo para código en NgChange,NgInit del HTML
                        vm.hideIfNotConditionMaster(vm.countries, 'nationality', 'residenceTime', 'id', '170');
                        vm.hideIfNotConditionMasterMultiple(vm.civilStatusL, 'civilStatus', ['documentTypeSpouce', 'documentIdSpouce', 'surnameSpouce', 'nameSpouce', 'activityAgeSpouce', 'activitySpouce', 'cellphoneSpouce', 'mainActivityIncomeSpouce'], 'id', ['2', '5']);
                        vm.hideIfNotConditionMasterMultiple(vm.jobs, 'activity', ['militaryForce', 'militaryRank'], 'id', ['8', '10']);
                        vm.hideIfNotConditionMasterMultiple(vm.jobs, 'activitySpouce', ['militaryForceSpouce', 'militaryRankSpouce'], 'id', ['8', '10']);
                        vm.changeExpDate(vm.birthDate);
                        vm.nationality = "170";
                    }
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });





        /*###########################################################################*/
        vm.preload = function () {
            vm.documentType = "1";
            vm.documentId = "79886653";
            vm.surname1 = "perez";
            vm.name1 = "pedro";
            vm.birthDate = new Date("1978-01-10T05:00:00.000Z");
            vm.birthLocalization = { "ciudadDepartamento": "BOGOTÁ, D.C. - BOGOTÁ D.C.", "idCiudad": "1114", "idDepartamento": "164", "idPais": "170", "indicativoCiudad": "1", "pais": "COLOMBIA", "codigoDane": "11001" };
            vm.documentExpDate = new Date("1996-02-23T05:00:00.000Z");
            vm.gender = "Masculino";
            vm.residenceTime = "2,1";
            vm.cellphone = "3107873562";
            vm.nationality = "141";
            vm.email = "cpinzon@FALABELLA.COM.CO";
            vm.activity = "1";
            vm.activityAge = "1,0";
            vm.documentIdRef = "0";
            vm.militaryForce = null;
            vm.militaryRank = null;
            vm.mainActivityIncome = 2675765;
            vm.otherIncome = 348238;
            vm.CEActivityIncome = 21323;
            vm.otherIncomeDescription = "sasas";
            vm.otherExpend = 252555;
            vm.otherExpendDescription = "asasas";
            vm.totalIncome = 1024003;
            vm.totalExpend = 231232;
            vm.totalAssets = 7789797;
            vm.totalLiabilities = 897897;
            vm.totalHeritage = 6891900;
            vm.civilStatus = "2";
            vm.documentTypeSpouce = "1";
            vm.documentIdSpouce = "897987";
            vm.surnameSpouce = "ROBLES";
            vm.nameSpouce = "MARIA";
            vm.activitySpouce = "4";
            vm.militaryForceSpouce = null;
            vm.militaryRankSpouce = null;
            vm.cellphoneSpouce = "3107873562";
            vm.mainActivityIncomeSpouce = 6757650;
            vm.faEmployee = "no";
            vm.expeditionLocalization = { "ciudadDepartamento": "BOGOTÁ, D.C. - BOGOTÁ D.C.", "idCiudad": "1114", "idDepartamento": "164", "idPais": "170", "indicativoCiudad": "1", "pais": "COLOMBIA", "codigoDane": "11001" };
            vm.residenceLocalization = { "ciudadDepartamento": "BOGOTÁ, D.C. - BOGOTÁ D.C.", "idCiudad": "1114", "idDepartamento": "164", "idPais": "170", "indicativoCiudad": "1", "pais": "COLOMBIA", "codigoDane": "11001" };
            vm.prevCompanyDate = null;
            vm.prevCompanyDuration = "0,0";
            vm.hideIfNotConditionMaster(vm.countries, 'nationality', 'residenceTime', 'id', '170');
            vm.hideIfNotConditionMasterMultiple(vm.civilStatusL, 'civilStatus', ['documentTypeSpouce', 'documentIdSpouce', 'surnameSpouce', 'nameSpouce', 'activitySpouce', 'cellphoneSpouce', 'mainActivityIncomeSpouce'], 'id', ['2', '5']);
            vm.hideIfNotConditionMasterMultiple(vm.jobs, 'activity', ['militaryForce', 'militaryRank'], 'id', ['8', '10']);
            vm.hideIfNotConditionMasterMultiple(vm.jobs, 'activitySpouce', ['militaryForceSpouce', 'militaryRankSpouce'], 'id', ['8', '10']);

            var prd = [
                {
                    "abreviacion": "TC",
                    "anioMaximo": "2017",
                    "anioMinimo": "1992",
                    "descripcion": "Tarjeta de crédito CMR Falabella",
                    "edadMinima": "25",
                    "id": 1,
                    "idOcupacion": "1",
                    "estado": "1",
                    "tempAdmisionesId": "0",
                    "idName": true,
                    "checked": true,
                    "image": "card-empty.png",
                    "$$hashKey": "object:80"
                }
            ];
            $rootScope.storage.set("product_available_checkeds", prd);

        }
    }]);
