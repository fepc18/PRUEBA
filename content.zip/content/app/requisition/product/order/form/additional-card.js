﻿app.controller("formAdditionalCardController", ['$scope', '$rootScope', '$filter', 'toolsForm', 'fraudSource','$log',
    function ($scope, $rootScope, $filter, toolsForm, fraudSource, $log) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formAdditionalCard";
               
        vm.fromLoaded = false;
        vm.sendForm = 0;
        vm.documentTypes = [];
        vm.genders = [];        
        vm.dateOptionsBirth = {};
        vm.dateOptionsExped = {};
        vm.kinships = [];

        vm.setPropertyDocumentFromTypeDoc = function (itemName, slave, property, persist) {
            var ob = vm[itemName];
            var find = $filter("filter")(vm.documentTypes, { id: ob });

            vm[slave] = !persist ? null : vm[slave] || null;
            vm[itemName + "_" + property] = find[0][property];
        };
        vm.changeExpDate = function (dateString) {
            vm.dateOptionsExped.initDate = toolsForm.nestedControlDate.addYears(18, dateString);
            vm.dateOptionsExped.minDate = toolsForm.nestedControlDate.addYears(18, dateString);
        }

        vm.back = function () {
            parent.productPath = parent.link.formNormData;
        };
        vm.submit = function () {
            if ($scope[formName].$invalid) {                
                vm.sendForm = -1;
                return false;

            } else {
                /*##################*/
                //vm.error = {
                //    status: true,
                //    message: "Cliente Rechazado por Políticas Internas. - Validación Fraude",
                //}
                /*##################*/


                var value = base.dataForFraud();

                vm.initFraud = true;
                fraudSource.validate(JSON.stringify(value)).then(function (data_) {
                    var result = false;

                    if (data_.status) {
                        var d = data_.data;

                        if (d.fraudeConsultarResp.informacionOperacion.codigoOperacion == "0000") {
                            if (d.fraudeConsultarResp.resultados.esFraude == false) {
                                $log.info("200 Validación de Fraude Exitosa - Tarjeta Adicional.");

                                base.saveLocalData();
                                parent.productPath = parent.link.formForeignCur;
                                vm.sendForm = 1;

                                result = true;

                            } else {
                                vm.error = {
                                    status: true,
                                    message: "Cliente Rechazado por Políticas Internas." // - Validación Fraude",
                                }

                                /*******************************/
                                /*                             */
                                /*  FINALIZACION DE SOLICITUD  */
                                /*                             */
                                /*******************************/
                                parent.finally.result = "R";
                                parent.finally.message = vm.error.message;
                                parent.finally.createJson();
                            }
                        } else {
                            vm.error = {
                                status: true,                                
                                message: d.fraudeConsultarResp.informacionOperacion.glosaOperacion,
                            }                           
                        }

                    } else {
                        vm.error = {
                            status: true,
                            exception: true,
                            message: data_.data,
                        }
                        $log.error("500 Error en el servicio de Fraudes: " + vm.error.message);
                    }

                    vm.initFraud = false;

                    return result;
                })
            }
        };



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                valueFraud: {},
                valueFraudForDocument: function () {
                    var data = vm.data_formbasicdata;

                    if (data && data.documentId)
                        valueFraud.fraudeConsultarReq.persona.push({
                            tipoPersona: "Titular",
                            documentoIdentidad: {
                                tipoDocumento: data.documentType,
                                numeroDocumento: data.documentId
                            }
                        });

                    if (data && data.documentIdSpouce)
                        valueFraud.fraudeConsultarReq.persona.push({
                            tipoPersona: "Adicional",
                            documentoIdentidad: {
                                tipoDocumento: data.documentTypeSpouce,
                                numeroDocumento: data.documentIdSpouce
                            }
                        });
                },
                valueFraudForPhone: function (data) {
                    var dataAD = vm.data_formbasicdataadd;
                    var dataEC = vm.data_formeconomicactivity;
                    var data = vm.data_formbasicdata;
                    var dataRE = vm.data_formReferences;

                    if (dataAD && data && dataAD.residencePhone)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: data.residenceLocalization.idCiudad,
                            numeroTelefono: dataAD.residencePhone
                        });

                    if (dataEC && dataEC.phoneProvider)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataEC.providerLocalization.idCiudad,
                            numeroTelefono: dataEC.phoneProvider
                        });

                    if (dataEC && dataEC.phoneCompany)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataEC.companyLocalization.idCiudad,
                            numeroTelefono: dataEC.phoneCompany
                        });

                    if (dataEC && dataEC.phoneLessee)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataEC.lesseeLocalization.idCiudad,
                            numeroTelefono: dataEC.phoneLessee
                        });


                    if (dataRE && dataRE.phone)
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: dataRE.residenceLocalization.idCiudad,
                            numeroTelefono: dataRE.phone
                        });

                    //DEFAULT:
                    if (valueFraud.fraudeConsultarReq.telefono.length <= 1) {
                        valueFraud.fraudeConsultarReq.telefono.push({
                            codigoCiudad: "1114",
                            numeroTelefono: "0000000"
                        });
                    }
                },
                valueFraudForCellPhone: function (data) {
                    var data = vm.data_formbasicdata;
                    var dataRE = vm.data_formReferences;

                    if (data && data.cellphone)
                        valueFraud.fraudeConsultarReq.celular.push(data.cellphone);

                    if (data && data.cellphoneSpouce)
                        valueFraud.fraudeConsultarReq.celular.push(data.cellphoneSpouce);

                    if (dataRE && dataRE.cellphone)
                        valueFraud.fraudeConsultarReq.celular.push(data.cellphone);

                    //DEFAULT:
                    if (valueFraud.fraudeConsultarReq.celular.length <= 1) {
                        valueFraud.fraudeConsultarReq.celular.push("0000000000");
                    }
                },
                valueFraudForCompany: function (data) {
                    var data = vm.data_formeconomicactivity;

                    if (data && data.companyName)
                        valueFraud.fraudeConsultarReq.empresa.push(data.companyName);

                    //DEFAULT:
                    if (valueFraud.fraudeConsultarReq.empresa.length == 1)
                        valueFraud.fraudeConsultarReq.empresa.push(data.companyName);
                }
            }
            return {
                dataForFraud: function () {
                    valueFraud = {
                        fraudeConsultarReq: {
                            cabecera: {
                                country: "CO",
                                channel: "Web",
                                IOsID: "4562"
                            },
                            persona: [],
                            telefono: [],
                            celular: [],
                            empresa: []
                        }
                    }

                    local.valueFraudForDocument();
                    local.valueFraudForPhone();
                    local.valueFraudForCellPhone();
                    local.valueFraudForCompany();

                    return valueFraud;
                },
                saveLocalData: function () {
                    var data = {
                        isAdditionalCard: vm.isAdditionalCard || null,
                        isAdditionalPresent: vm.isAdditionalPresent || null,
                        additionalDocumentType: vm.additionalDocumentType || null,
                        additionalDocumentId: vm.additionalDocumentId || null,
                        additionalName1: vm.additionalName1 || null,
                        additionalName2: vm.additionalName2 || null,
                        additionalSurname1: vm.additionalSurname1 || null,
                        additionalSurname2: vm.additionalSurname2 || null,
                        additionalBirthDate: vm.additionalBirthDate || null,
                        additionalDocumentExpDate: vm.additionalDocumentExpDate || null,
                        additionalGender: vm.additionalGender || null,
                        additionalCellphone: vm.additionalCellphone || null,
                        additionalResidenceAddress: vm.additionalResidenceAddress || null,
                        kinshipPrincipal: vm.kinshipPrincipal || null,
                    }

                    $rootScope.storage.set("form_additional_card", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_additional_card"));
                    var loaded = false;

                    if (data != null) {
                        vm.isAdditionalCard = data.isAdditionalCard || undefined;
                        vm.isAdditionalPresent = data.isAdditionalPresent || undefined;
                        vm.additionalDocumentType = data.additionalDocumentType || undefined;
                        vm.additionalDocumentId = data.additionalDocumentId || undefined;
                        vm.additionalName1 = data.additionalName1 || undefined;
                        vm.additionalName2 = data.additionalName2 || undefined;
                        vm.additionalSurname1 = data.additionalSurname1 || undefined;
                        vm.additionalSurname2 = data.additionalSurname2 || undefined;
                        vm.additionalBirthDate = new Date(data.additionalBirthDate) || undefined;
                        vm.additionalDocumentExpDate = new Date(data.additionalDocumentExpDate) || undefined;
                        vm.additionalGender = data.additionalGender || undefined;
                        vm.additionalCellphone = data.additionalCellphone || undefined;
                        vm.additionalResidenceAddress = data.additionalResidenceAddress || undefined;
                        vm.kinshipPrincipal = data.kinshipPrincipal || undefined;

                        loaded = true;
                    }
                    return loaded;
                },
                getGenders: function () {
                    return toolsForm.localGender();
                },

                init: function () {
                    vm.additionalDocumentType = "1";

                    vm.documentTypes = params.getParam("parametrics_tiposIdentificacion"); //params.tiposIdentificacion;
                    vm.kinships = params.getParam("parametrics_parentescos");
                    vm.genders = base.getGenders();
                    vm.dateOptionsBirth = toolsForm.nestedControlDate.dateOptionsBirth(18);
                    vm.dateOptionsExped = toolsForm.nestedControlDate.dateOptionsExped();

                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));
                    vm.data_formbasicdataadd = angular.fromJson($rootScope.storage.get("form_basic_data_additional"));
                    vm.data_formeconomicactivity = angular.fromJson($rootScope.storage.get("form_economic_activity"));
                    vm.data_formReferences = angular.fromJson($rootScope.storage.get("form_references"));
                    
                    var load = base.loadLocalData();

                    if (load) {
                        vm.fromLoaded = true;
                    }
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });
    }]);
