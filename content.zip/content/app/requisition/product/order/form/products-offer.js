﻿app.controller("offerProductsController", ['$scope', '$rootScope', '$filter', 'profilingSource', 'otpSource', 'centerRiskSource', '$log',
    function ($scope, $rootScope, $filter, profilingSource, otpSource, centerRiskSource, $log) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;

        vm.products = [];
        vm.history = [];
        vm.enabledForCheckeds = false;

        vm.checked = function (id, verify) {
            verify = verify || false;

            vm.products[id].checked = !verify ? true : vm.products[id].checked ? false : true;
            vm.enabledForCheckeds = base.enabledChecked();
        }

        vm.nextWarning = function () {
            parent.finally.activeCancellationFlag = true;
            parent.productPath = parent.link.formBDataAdic;
        }
        vm.next = function () {
            //var prod = base.validateForDataCredit();
            //vm.error = {
            //    status: true,
            //    message: "Cliente <strong>Rechazado</strong> por Políticas Internas.",
            //}
            //vm.passive = prod.passive;            
            /*################################*/

            base.validateProducts();
            var prod = base.validateForDataCredit();

            if (prod.active != -1) {
                var value = base.dataForValidateDC();
                value.dataCreditoConsultarReq.dataCreditoConsultar.idProducto = prod.active;

                vm.initDataCred = true;
                centerRiskSource.validateDataCredit(JSON.stringify(value)).then(function (data_) {
                    if (data_.status) {

                        var d = data_.data;

                        if (d.dataCreditoConsultarResp.informacionOperacion.codigoOperacion == "0000") {
                            if (d.dataCreditoConsultarResp.resultados.dataCreditoConsultarResult == true) {
                                $log.info("200 Validación de DataCredito Exitosa.");

                                parent.finally.activeCancellationFlag = true;
                                parent.productPath = parent.link.formBDataAdic;
                            } else {
                                vm.error = {
                                    status: true,
                                    message: "Cliente Rechazado por Políticas Internas." // - Validación DataCredito",
                                }
                                vm.passive = prod.passive;

                                /*******************************/
                                /*                             */
                                /*  FINALIZACION DE SOLICITUD  */
                                /*                             */
                                /*******************************/
                                if (!vm.passive) parent.finally.result = "R";
                                parent.finally.message = vm.error.message;
                                parent.finally.createJson();
                            }
                        } else {
                            vm.error = {
                                status: true,
                                message: d.dataCreditoConsultarResp.informacionOperacion.glosaOperacion,
                            }
                        }

                    } else {
                        vm.error = {
                            status: true,
                            exception: true,
                            message: data_.data,
                        }

                        $log.error("500 Error en Servicio DataCredito: " + vm.error.message);
                    }

                    vm.initDataCred = false;
                });
            } else {
                parent.productPath = parent.link.formBDataAdic;
            }
        }
        vm.pair = function (index) {
            if (index % 2 == 0) return true;
            return false;
        }


        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                actives: [0, 1, 2, 3, 4, 5, 6],
                validStatePrevRequest: function (state) {
                    switch (state) {
                        case "Aprobada":
                            return "A";
                            break;
                        case "Vencida":
                            return "R";
                            break;
                        case "Rechazada":
                            return "R";
                            break;
                        default:
                            return "A";
                            break;
                    }
                },
                formatDateFromJson: function (dateString) {
                    if (dateString != undefined || dateString != null) {
                        var iof = dateString.indexOf("-");

                        if (iof > 0) {
                            var spl = dateString.split("-");
                            return spl[0] + "-" + spl[1] + "-" + spl[2].substring(0, 2);
                        } else {
                            return dateString;
                        }
                    } else {
                        return "";
                    }
                },
                getProductsFromStorage: function (storageData) {
                    var prod = [];

                    angular.forEach(storageData, function (item, index) {
                        prod.push({
                            nombreProducto: item.descripcion,
                            abreviacionProducto: item.abreviacion,
                            idProducto: parseInt(index) + parseInt(1)
                        });
                    });

                    return prod;
                }
            }
            return {
                validateProducts: function () {
                    //Comparar los productos_disponibles con los productos_ofertados
                    //Los productos no encontrados en perfilamiento que estén en los seleccionados disponibles, se marcan con R. 
                    //Los seleccionados en perfilamiento se marcan con F
                    //Los productos no seleccionados en perfilamiento se marcan con C.
                    var pdis = params.getParam("product_available_checkeds");
                    var poff = vm.products;
                    var ptotal = [];

                    angular.forEach(poff, function (item, index) {
                        if (!item.checked) {
                            item.finalState = "C";
                        }
                    })
                    angular.forEach(pdis, function (item, index) {
                        var exist = false;
                        var prior = 0;
                        var state = "";

                        angular.forEach(poff, function (sitem, index) {
                            if (item.tempAdmisionesId == sitem.id) {
                                exist = true;
                                prior = sitem.priority;
                                state = sitem.finalState;
                            }
                        })
                        var nobj = {
                            description: item.descripcion,
                            id: item.tempAdmisionesId,
                            idProd: item.id,
                            finalState: state,
                            idName: "ProdOffer" + item.tempAdmisionesId,
                            image: "card-empty.png",
                            abreviation: item.abreviacion,
                            minAge: item.edadMinima,
                            priority: prior,
                        };

                        if (!exist) {
                            nobj.checked = false;
                            nobj.finalState = "R";
                        }

                        ptotal.push(nobj);
                    })
                    //angular.forEach(poff, function (item, index) {
                    //    ptotal.push(item);
                    //})                    
                    $rootScope.storage.set("products_finally", ptotal);

                    //console.log(pdis);
                    //console.log(poff);
                    //console.log(ptotal);
                    $log.info(ptotal);
                },
                validateForDataCredit: function () {
                    var actives = local.actives;
                    var prods = vm.products;
                    var datacreditOk = -1;
                    var passiveExist = 0;
                    var pcheck = $filter("filter")(vm.products, { checked: true });

                    angular.forEach(pcheck, function (item, index) {
                        if (item.checked) {
                            var isPassive = true;
                            for (var i = 0; i < actives.length; ++i) {
                                if (parseInt(item.id) == actives[i]) {
                                    datacreditOk = parseInt(item.id);
                                    isPassive = false;

                                    break;
                                }
                            }
                            passiveExist = isPassive ? passiveExist + 1 : passiveExist;
                        }
                    });

                    return data = { active: datacreditOk, passive: passiveExist > 0 ? true : false };
                },
                dataForValidateDC: function () {

                    var value = {
                        dataCreditoConsultarReq: {
                            cabecera: {
                                country: "CO",
                                channel: "admisionMovil",
                                IOsID: "0"
                            },
                            dataCreditoConsultar: {
                                apellido: vm.data_formbasicdata.surname1,
                                tipoDocumento: vm.data_formbasicdata.documentType,
                                numeroDocumento: vm.data_formbasicdata.documentId,

                                codigoOficina: 0,
                                login: "",
                                idProducto: 0
                            }
                        }
                    };

                    return value;
                },
                dataForCustomer: function (terminal) {
                    var data = vm.data_formbasicdata;
                    var prod = vm.data_prodAvailables;
                    var lprod = local.getProductsFromStorage(prod);

                    var value = {
                        Id: 0,
                        TypeIdentity: data.documentType || "",
                        Identity: data.documentId || "",
                        FirstName: data.name1 || "",
                        SecondName: data.name2 || "",
                        Surname: data.surname1 || "",
                        SecondSurname: data.surname2 || "",
                        BirthDate: data.birthDate || "",
                        CityBirth: data.birthLocalization.idCiudad || "",
                        ResidentTime: data.residenceTime || "",
                        occupation: data.activity || "",
                        falEmployee: data.falEmployee || "",
                        activityTime: data.activityAge || "",
                        previousCompanyTerm: data.prevCompanyDuration || "",
                        dateRetPreCompany: data.prevCompanyDate || "",
                        externalIdentity: data.documentIdRef || "",
                        force: data.militaryForce || "",
                        range: data.militaryRank || "",
                        mainActivityIncome: data.mainActivityIncome || "",
                        otherIncome: data.otherIncome || "",
                        costExpensesMainActivity: data.CEActivityIncome || "",
                        descripOtherIncome: data.otherIncomeDescription || "",
                        otherExpenditures: data.otherExpend || "",
                        descripOtherExpenditures: data.otherExpendDescription || "",
                        totalIncome: data.totalIncome || "",
                        totalExpenditures: data.totalExpend || "",
                        totalLiabilities: data.totalLiabilities || "",
                        totalAssets: data.totalAssets || "",
                        heritage: data.totalHeritage || "",
                        civilStatus: data.civilStatus || "",
                        idOficina: terminal || "",
                        DateExpeditionDoc: data.documentExpDate || "",
                        Gender: data.gender || "",
                        CityResidence: data.residenceLocalization.idCiudad || "",
                        CellPhone: data.cellphone || "",
                        Nationality: data.nationality || "",
                        email: data.email || "",
                        typeidentitySpouse: data.documentTypeSpouce || "",
                        identitySpouse: data.documentIdSpouce || "",
                        firstNameSpouse: data.nameSpouce || "",
                        SurnameSpouse: data.surnameSpouce || "",
                        occupationSpouse: data.activitySpouce || "",
                        CellPhoneSpouse: data.cellphoneSpouce || "",
                        mainActivityIncomeSpouse: data.mainActivityIncomeSpouce || "",
                        Productos: lprod || ""
                    };

                    value.BirthDate = local.formatDateFromJson(value.BirthDate);
                    value.DateExpeditionDoc = local.formatDateFromJson(value.DateExpeditionDoc);

                    return value;
                },
                dataForPreRequest: function () {
                    var data = vm.data_formbasicdata;

                    var value = {
                        Id: 0,
                        TypeIdentity: data.documentType || "",
                        Identity: data.documentId || "",
                        FirstName: data.name1 || "",
                        SecondName: data.name2 || "",
                        Surname: data.surname1 || "",
                        SecondSurname: data.surname2 || "",
                        BirthDate: data.birthDate || "",
                        CityBirth: data.birthLocalization.idCiudad || "",
                        PlaceExpedition: data.expeditionLocalization.idCiudad || "",
                        Gender: data.gender || ""
                    };
                    value.BirthDate = local.formatDateFromJson(value.BirthDate);

                    return value;
                },
                getHistoryRequest: function () {
                    var value = base.dataForPreRequest();
                    vm.loadingHist = true;
                    vm.historyEmpty = false;

                    profilingSource.getHistoryRequest(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;
                            if (d.status != null || d.status != undefined) {

                                if (d.status.code == "0000") {
                                    if (d.results.length > 0) {
                                        angular.forEach(d.results, function (item, index) {
                                            vm.history.push({
                                                id: index,
                                                name: item.productName,
                                                date: item.dateRequest,
                                                requisitionId: item.request,
                                                requisitionDesc: item.channel,
                                                state: local.validStatePrevRequest(item.state.trim()),
                                                stateName: item.state,
                                                description: item.comments.trim() || "Sin comentarios"
                                            });
                                        });
                                    } else {
                                        vm.history = [];
                                        vm.historyEmpty = true;
                                    }
                                } else {
                                    vm.error = {
                                        status: true,
                                        message: "Error al consultar el servicio Perfilamiento / requisitions anteriores.",
                                    }
                                    vm.history = [];
                                }
                            } else {
                                vm.error = {
                                    status: true,
                                    message: "Error al consultar el servicio Perfilamiento / requisitions anteriores.",
                                }
                                vm.history = [];
                            }
                        }
                        else {
                            vm.error = {
                                status: true,
                                message: data_.data,
                            }
                            vm.history = [];
                        }

                        vm.loadingHist = false;
                    });
                },
                getCustomerProfiling: function () {
                    otpSource.getTerminal().then(function (data_) {

                        if (data_.status) {

                            var terminal = data_.data;
                            var value = base.dataForCustomer(terminal.terminalId);
                            vm.loadingProd = true;

                            profilingSource.getCustomerProfile(JSON.stringify(value)).then(function (data_) {
                                if (data_.status) {
                                    var d = data_.data;

                                    if (d.status != null || d.status != undefined) {
                                        if (d.status.code == "0000") {
                                            angular.forEach(d.results, function (item, index) {
                                                vm.products.push({
                                                    id: item.id,
                                                    description: item.description,
                                                    priority: item.priority,
                                                    image: "card-empty.png",
                                                    idName: "ProdOffer" + item.id,
                                                    finalState: "F"
                                                });
                                            });
                                        } else {
                                            vm.error = {
                                                status: true,
                                                message: "Error al consultar el servicio Perfilamiento.",
                                            }
                                            vm.products = [];
                                        }
                                    } else {
                                        vm.error = {
                                            status: true,
                                            message: "Error al consultar el servicio Perfilamiento.",
                                        }
                                        vm.products = [];
                                    }
                                } else {
                                    vm.error = {
                                        status: false,
                                        message: data_.data,
                                    }
                                    vm.products = [];
                                }

                                vm.loadingProd = false;
                            });
                        } else {
                            vm.error = {
                                status: false,
                                message: data_.data,
                            }
                        }
                    });
                },
                enabledChecked: function () {
                    var pcheckeds = [];
                    angular.forEach(vm.products, function (item, index) {
                        if (item.checked) {
                            pcheckeds.push(item);
                        }
                    })
                    $rootScope.storage.set("product_offer_checkeds", pcheckeds);

                    return pcheckeds.length == 0 || pcheckeds == null ? false : true;
                },

                init: function () {
                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));
                    vm.data_prodAvailables = angular.fromJson($rootScope.storage.get("product_available_checkeds"));

                    vm.enabledForCheckeds = base.enabledChecked();

                    base.getCustomerProfiling();
                    base.getHistoryRequest();
                }
            }
        }();
        base.init();
    }]);