﻿app.controller("formBasicDataAdditionalController", ['$scope', '$rootScope', 'toolsForm',
    function ($scope, $rootScope, toolsForm) {

        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var formName = "formBasicDataAdditional";

        vm.sendForm = 0;
        vm.provinces = [];
        vm.methodSendingCorresp = [];
        vm.dayPayments = [];
        vm.epss = [];
                        
        vm.back = function () {
            base.saveLocalData();
            parent.productPath = parent.link.formBData;
        }
        vm.submit = function () {
            if ($scope[formName].$invalid) {               
                vm.sendForm = -1;
                return false;
            } else {
                vm.sendForm = 1;

                var validatePath = base.validateIfEnableEconoActivity();
                if (validatePath) {
                    parent.productPath = parent.link.formEcoActivity;
                } else {
                    parent.productPath = parent.link.formReferences;
                }

                base.saveLocalData();
                return true;
            }
        }



        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {            
            return {
                validateIfEnableEconoActivity: function () {
                    activity = parseInt(vm.data_formbasicdata.activity);

                    if (activity == 1) activity = parseInt(vm.data_formbasicdata.activitySpouce);

                    if (activity == 3 || activity == 6) return false;
                    return true;
                },
                saveLocalData: function () {
                    var data = {
                        residenceLocalization: vm.residenceLocalization || null,
                        address: vm.address || null,
                        district: vm.district || null,
                        residencePhone: vm.residencePhone || null,
                        sendingCorresp: vm.sendingCorresp || null,
                        payday: vm.payday || null,
                        eps: vm.eps || null,
                        payrollAccount: vm.payrollAccount || null,
                        exemptGMFAccount: vm.exemptGMFAccount || null,
                    }

                    $rootScope.storage.set("form_basic_data_additional", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_basic_data_additional"));
                    var loaded = false;

                    if (data != null) {
                        vm.residenceLocalization = data.residenceLocalization || undefined;
                        vm.address = data.address || undefined;
                        vm.district = data.district || undefined;
                        vm.residencePhone = data.residencePhone || undefined;
                        vm.sendingCorresp = data.sendingCorresp || undefined;
                        vm.payday = data.payday || undefined;
                        vm.eps = data.eps || undefined;
                        vm.payrollAccount = data.payrollAccount || undefined;
                        vm.exemptGMFAccount = data.exemptGMFAccount || undefined;

                        loaded = true;
                    }
                    return loaded;
                },
                getLocalization: function () {
                    var loc = params.getParam("parametrics_localizaciones");
                    var prov = [];

                    prov = toolsForm.localization.getAll(angular.fromJson(loc), "COLOMBIA");

                    return prov;
                },
                getResidenceCity: function(){
                    var data = vm.data_formbasicdata;
                    if (data) {
                        return data.residenceLocalization;
                    } else {
                        return "";
                    }            
                },
                init: function () {
                    vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));

                    vm.provinces = base.getLocalization();
                    vm.methodSendingCorresp = params.getParam("parametrics_enviosCorrespondencia"); 
                    vm.dayPayments = params.getParam("parametrics_diasPagos");  
                    vm.epss = params.getParam("parametrics_eps");
                    vm.cityForAddress = base.getResidenceCity();

                    var load = base.loadLocalData();

                    if (parent.productVars.basicData_address) vm.address = parent.productVars.basicData_address;
                    if (parent.productVars.basicData_phone) vm.residencePhone = parent.productVars.basicData_phone;
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/       
        $rootScope.$watch('parametrics.state',
            function (nValue, oValue) {
                if (nValue != oValue) {
                    base.init();
                } else {
                    return false;
                }
            });



        /*#######################################################################################*/

        vm.preload = function () {
            vm.address = "CL 144 # 141 C - 30";
            vm.district = "fontanar";
            vm.residencePhone = "2525412";
            vm.sendingCorresp = "3";
            vm.payday = "5";
            vm.payrollAccount = "no";
            vm.exemptGMFAccount = "no";
            vm.eps = { "direccion": "", "id": "33", "idEstado": "46", "nit": "", "nombre": "COMPENSAR EPS", "telefono": "" };
                        
            var prd = [
                {
                    "abreviacion": "TC",
                    "anioMaximo": "2017",
                    "anioMinimo": "1992",
                    "descripcion": "Tarjeta de crédito CMR Falabella",
                    "edadMinima": "25",
                    "id": 1,
                    "idOcupacion": "1",
                    "estado": "1",
                    "tempAdmisionesId": "0",
                    "idName": true,
                    "checked": true,
                    "image": "card-empty.png",
                    "$$hashKey": "object:80"
                }
            ];
            $rootScope.storage.set("product_available_checkeds", prd);
        }

    }]);