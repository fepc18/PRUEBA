﻿app.controller("documentFilesController", ['$scope', '$rootScope', 'reqInsertSource', '$log', '$filter',
    function ($scope, $rootScope, reqInsertSource, $log, $filter) {
        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        
        vm.legacyCheck = false;
        vm.next = function () {
            parent.productPath = parent.link.formBData;
        }
        vm.back = function () {
            parent.productPath = parent.link.docFinger;
        }
        vm.result = {
            state: true
        };
        vm.verify = 0;
        vm.documentTypes = params.getParam("parametrics_tiposIdentificacion");
        vm.docScanner = {};

        vm.verifyDoc=function() {
            vm.verify = 1;

            /*var jsonDocValid = {
                Document: vm.documentId,
                User: "7075",
                CodProfile: "ADM", 
                CodSis: "", 
                Suffix: ""
            }*/

            var jsonDocValid = {
                Document: vm.documentId,
                User: "", 
                Suffix: ""
            }

            reqInsertSource.docScanValidate(jsonDocValid).then(function (data_) {
                var code = "0";
                var msg = "";

                if (data_.status) {
                    if (data_.data.code == "200") {
                        msg = String.format("Documento validado");

                        //console.log(data_.data);
                        vm.verify = 4;

                        $log.info(msg);
                    } else if (data_.data.code == "404") {
                        msg = "Documento no encontrado";
                        vm.verify = 2;
                    }
                } else {
                    code = "500";
                    msg = String.format("Error 500 Documento PDF: {0}", data_.data);
                    $log.error(msg);

                    vm.verify = 3;
                }
                vm.result.code = code;
                vm.result.message = msg;
            });
        }

        vm.setPropertyDocumentFromTypeDoc = function (itemName, slave, property, persist) {
            var ob = vm[itemName];
            var find = $filter("filter")(vm.documentTypes, { id: ob });

            vm[slave] = !persist ? null : vm[slave] || null;
            vm[itemName + "_" + property] = find[0][property];
        };
    }]);