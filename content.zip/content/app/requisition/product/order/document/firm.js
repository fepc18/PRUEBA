﻿app.controller("documentFirmController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var parent = $scope.$parent.$parent;
        
        vm.legacyCheck = false;
        vm.next = function () {
            parent.productPath = "content/app_views/requisition/product/order/otp/register.html";
        }
    }]);