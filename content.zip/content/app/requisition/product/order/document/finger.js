﻿app.controller("documentFingerController", ['$scope', '$rootScope', '$timeout', 'reqInsertSource', '$filter', '$log',
    function ($scope, $rootScope, $timeout, reqInsertSource, $filter, $log) {
        var vm = this;
        var parent = $scope.$parent.product;
        var params = $rootScope.parametrics;
        var code = "0";
        var msg = "";
       
        var base = function () {
            return {
                getHandFingerName: function (id) {
                    var hand = (id <= 4 ? "izquierda" : "derecha");
                    var finger = "indefinido";

                    switch (id) {
                    case 0:
                    case 9:
                        finger = "meñique";
                        break;
                    case 1:
                    case 8:
                        finger = "anular";
                        break;
                    case 2:
                    case 7:
                        finger = "corazón";
                        break;
                    case 3:
                    case 6:
                        finger = "índice";
                        break;
                    case 4:
                    case 5:
                        finger = "pulgar";
                        break;
                    }
                    return {
                        hand: hand,
                        finger: finger
                    }
                }
            }
        }();
        
        vm.legacyCheck = false;
        vm.verify = 0;
        vm.documentTypes = params.getParam("parametrics_tiposIdentificacion");
        vm.result = {
            state: true
        };
        vm.fingerPrint = {};

        vm.next = function () {
            parent.productPath = parent.link.docScan;
        }
        vm.back = function () {
            parent.productPath = parent.link.offerLegacy;
        }
        
        vm.verifyFinger = function () {
            vm.verify = 1;

            var jsonFingerValid = {
                DocumentType: vm.documentType,
                Document: vm.documentId
            }

            reqInsertSource.fingerValidate(jsonFingerValid).then(function (data_) {
                if (data_.status) {
                    if (data_.data.code === "200") {
                        
                        msg = String.format("Huella validada Id Auth #{0}", data_.data.idAuthorization);
                        $log.info(msg);

                        var jsonFingerImage = {
                            DocumentType: vm.documentType,
                            Document: vm.documentId,
                            IdAuthorization: data_.data.idAuthorization
                        }
                        reqInsertSource.fingerGetImage(jsonFingerImage).then(function (result_) {
                            if (result_.status) {

                                var handFinger = base.getHandFingerName(result_.data.idFinger);
                                
                                vm.print = {
                                    image: result_.data.image,
                                    imageMin: result_.data.imageMin,
                                    idFinger: result_.data.idFinger,
                                    finger: handFinger.finger,
                                    hand: handFinger.hand
                                }
                                vm.verify = 4;
                                $rootScope.storage.set("form_finger", vm.print);

                                //var x = $rootScope.storage.get("form_finger");
                                //console.log(x);

                                msg = "Imagen de huella verificada";
                                $log.info(msg);

                            } else {
                                msg = String.format("Inconvenientes al obtener imagen de huella. {0}: {1}",result_.data.code, result_.data.message);
                                
                                vm.verify = 3;

                                $log.error(msg);
                            }
                        });
                        
                    } else if (data_.data.code === "404") {
                        msg = "Huella no encontrada";
                        vm.verify = 2;

                    } else {
                        msg = String.format("Inconvenientes al validar huella. {0}: {1}",data_.data.code, data_.data.message);
                        vm.verify = 3;

                        $log.error(msg);
                    }

                    code = data_.data.code;
                } else {
                    code = "500";
                    msg = String.format("Error 500 Huellas. {1}: {0}", data_.data);
                    $log.error(msg);

                    vm.verify = 3;
                }
                vm.result.code = code;
                vm.result.message = msg;
            });


        }
        vm.setPropertyDocumentFromTypeDoc = function (itemName, slave, property, persist) {
            var ob = vm[itemName];
            var find = $filter("filter")(vm.documentTypes, { id: ob });

            vm[slave] = !persist ? null : vm[slave] || null;
            vm[itemName + "_" + property] = find[0][property];
        };
        
    }]);