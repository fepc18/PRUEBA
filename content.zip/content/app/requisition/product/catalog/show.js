﻿app.controller("catalogShowController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;
              

        vm.next = function () {
            pr.catalogPath = "";
        }
    }]);