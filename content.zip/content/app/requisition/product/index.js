﻿app.controller("productController", ['$scope', '$rootScope', 'routeInclude', 'jsonStructure', '$log',
    function ($scope, $rootScope, routeInclude, jsonStructure, $log) {

        var vm = this;
        var nameProdOfferStorage = "product_offer_checkeds";

        vm.catalogVars = {}
        vm.adnVars = {}

        vm.uncheckedProductsSelected = function () {
            base.uncheckedProductsSelected();            
            base.goToProductsSelected();
        }
        vm.existProductsSelected = function () {
            return $rootScope.storage.get(nameProdOfferStorage) && $rootScope.storage.get(nameProdOfferStorage).length > 0;
        }
        vm.countProductsSelected = function () {
            return $rootScope.storage.get(nameProdOfferStorage).length;
        }
        vm.productVars = {
            regPhone: false,
            verifyOtp: false,
            phone: ""
        }

        //TODO PENDIENTE DE VERIFICACION
        vm.finally = {
            result: "",
            message: "",
            activeCancellationFlag: false,
            backCancellationPath: "",
            goCancellation: function () {
                vm.finally.backCancellationPath = vm.productPath;
                vm.productPath = routeInclude.requisition.product.cancelRequisition;
            },
            createJson: function () {
                vm.productPath = routeInclude.requisition.product.formFinally;                
            },            
        }

        vm.productPath = routeInclude.requisition.product.docFinger; //.docScan; //offerLegacy; //docFinger; //formBData; //otpRegister;
        vm.catalogPath = routeInclude.requisition.catalog.show;
        vm.adnPath = routeInclude.requisition.adn.show;
        vm.link = routeInclude.requisition.product;


        /***************************************************/
        /*                                                 */
        /*  LOCAL                                          */
        /*                                                 */
        /***************************************************/
        var base = {
            clearStorageForms: function(){
                for (var i = 0; i < localStorage.length; i++) {
                    var name = localStorage.key(i);

                    if (!name.includes("parametrics_")) {
                        $rootScope.storage.clearItem(name);
                    }
                }
                $rootScope.storage.clearItem("product_offer_checkeds");
            },
            uncheckedProductsSelected: function () {
                var products = $rootScope.parametrics.getParam("product_offer_checkeds");

                angular.forEach(products, function (item, index) {
                    item.checked = false;
                })
            },
            goToProductsSelected: function () {
                $rootScope.storage.clearItem(nameProdOfferStorage);
                vm.productPath = routeInclude.requisition.product.formProdOffer;
            }
        }
        


        /*####################*/
        vm.saltarOtp = function () {
            vm.productPath = routeInclude.requisition.product.offerList;
        }

    }]);