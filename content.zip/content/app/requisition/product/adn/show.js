﻿app.controller("adnShowController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;
              

        vm.next = function () {
            pr.adnPath = "";
        }
    }]);