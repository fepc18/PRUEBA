﻿app.controller("dashboardController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {

        var vm = this;
        var list = $rootScope.configuration.verticalmenu;

        vm.items = [];
        vm.click = function () {

        }

        function getSubitems(items) {
            //if (items.submenu) {
            //    angular.forEach(items.submenu, function (item, index) {
            //        if (item.direct) {
            //            vm.items.push(item);
            //        }
            //        if (item.submenu) getSubitems(item);
            //    });
            //}

            angular.forEach(items, function (item, index) {
                if (item.submenu) {
                    if(item.direct) vm.items.push(item);
                    if(item.submenu) getSubitems(item.submenu);
                } else if (item.direct) {
                    vm.items.push(item);
                }
            });
        }
        getSubitems(list);
    }]);