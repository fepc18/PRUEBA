﻿app.controller("historyRiskController", ['$scope', '$rootScope', 'centerRiskSource', '$filter', '$routeParams', 'filterFilter',
    function ($scope, $rootScope, centerRiskSource, $filter, $routeParams, filterFilter) {
        var vm = this;

        vm.date = new Date();
        vm.idConsulta = $routeParams.idConsulta;

        vm.back = function () {
            $rootScope.navigate.go('/center-risk/history');
        };

        vm.haveItems = function (array_) {
            if (array_) {
                return (filterFilter(array_).length > 0) ? true : false;
            }
            else
                return false;
        };

        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
            }
            return {
                loadHeader: function () {
                    centerRiskSource.getHeader(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.header = data_.data;
                        }
                    });
                },
                loadCalification: function () {
                    centerRiskSource.getCalification(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.calification = data_.data;
                        }
                    });
                },
                loadVigency: function () {
                    centerRiskSource.getVigency(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.vigency = data_.data;
                            vm.totalItems_tb01 = vm.vigency.length || 0;
                        }
                    });
                },
                loadNoVigency: function () {
                    centerRiskSource.getNoVigency(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.novigency = data_.data;
                            vm.totalItems_tb02 = vm.novigency.length || 0;
                        }
                    });
                },
                loadBalance: function () {
                    centerRiskSource.getBalance(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.balance = data_.data;
                            vm.totalItems_tb03 = vm.balance.length || 0;
                        }
                    });
                },
                loadIndebtedness: function () {
                    centerRiskSource.getIndebtedness(vm.idConsulta).then(function (data_) {

                        if (data_.status) {
                            vm.indebtedness = data_.data;
                            vm.totalItems_tb04 = vm.indebtedness.length || 0;
                        }
                    });
                },
                loadReclaims: function () {
                    centerRiskSource.getReclaims(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.reclaims = data_.data;
                            vm.totalItems_tb05 = vm.reclaims.length || 0;
                        }
                    });
                },
                //loadAlerts: function () {
                //    centerRiskSource.getAlerts(vm.idConsultay).then(function (data_) {
                //        if (data_.status) {
                //            vm.alerts = data_.data;
                //            vm.totalItems_tb06 = vm.alerts.length || 0;
                //        }
                //    });
                //},
                loadQueryes: function () {
                    centerRiskSource.getQueryes(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.queryes = data_.data;
                            vm.totalItems_tb07 = vm.queryes.length || 0;
                        }
                    });
                },
                loadResume: function () {
                    centerRiskSource.getResume(vm.idConsulta).then(function (data_) {
                        if (data_.status) {
                            vm.resume = {};
                            vm.resume.codeudor = $filter("filter")(data_.data, { group: "Codeudor" });
                            vm.resume.titular = $filter("filter")(data_.data, { group: "Titular" });
                            vm.resume.total = $filter("filter")(data_.data, { group: "Total" });
                        }
                    });
                },
                init: function () {
                    base.loadHeader();
                    base.loadCalification();
                    base.loadVigency();
                    base.loadNoVigency();
                    base.loadBalance();
                    base.loadIndebtedness();
                    base.loadReclaims();
                    //base.loadAlerts();
                    base.loadQueryes();
                    base.loadResume();
                }
            }
        }();
        base.init();


        /*DEFAULT ITEMS PER TABLE*/
        vm.totalItems_tb01 = 0;
        vm.totalItems_tb02 = 0;
        vm.totalItems_tb03 = 0;
        vm.totalItems_tb04 = 0;
        vm.totalItems_tb05 = 0;
        vm.totalItems_tb06 = 0;
        vm.totalItems_tb07 = 0;
        vm.current_tb01 = 1
        vm.current_tb02 = 1;
        vm.current_tb03 = 1;
        vm.current_tb04 = 1;
        vm.current_tb05 = 1;
        vm.current_tb06 = 1;
        vm.current_tb07 = 1;
    }]);