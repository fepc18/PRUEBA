﻿app.controller("onDemandRiskController", ['$scope', '$rootScope', 'centerRiskSource', '$filter', '$routeParams','filterFilter',
    function ($scope, $rootScope, centerRiskSource, $filter, $routeParams, filterFilter) {
        var vm = this;

        vm.date = new Date();
        vm.typeidentity = '';
        vm.identity = '';
        vm.lastName = '';

        /*-AJUSTE PARA TAB FIJO-*/
        vm.include = $scope.fromInclude ? true : false;

        if (!vm.include) {
            vm.typeidentity = $routeParams.typeidentity;
            vm.identity = $routeParams.identity;
            vm.lastName = $routeParams.lastName;
        } else {
            var data = $scope.$parent.$parent.centralRisk.includeResultData;

            vm.typeidentity = data.typeidentity;
            vm.identity = data.identity;
            vm.lastName = data.lastName;
        }
                
        vm.expandCompressInclude = function (compress) {
            var par = $("#px-collapses");
            var ang = angular.element(par);

            angular.forEach(ang[0].children, function (item, index) {
                var itm = angular.element(item);
                var sec = itm[0].children[1];
                sec = angular.element(sec);

                var cls = sec[0] ? sec[0].className : "";

                vm.situationCollapse = {
                    match: !compress ? "collapsed": "in",
                    oposit: compress ? "collapsed" : "in",
                    status: !compress ? true: false
                };

                if (cls == "") vm.situationCollapse.status = false;
                if (cls.match(vm.situationCollapse.match)) {
                    cls = cls.replace(vm.situationCollapse.match, vm.situationCollapse.oposit);

                    sec[0].className = cls;
                }

                //if (!compress) {
                //    if (cls.match("collapsed")) {
                //        cls = cls.replace("collapsed", "in");

                //        sec[0].className = cls;
                //        vm.expandCompressStatus = true;
                //    }
                //} else {
                //    if (cls.match("in")) {
                //        cls = cls.replace("in", "collapsed");

                //        sec[0].className = cls;
                //        vm.expandCompressStatus = false;
                //    }
                //}            
            });
        }
        /*----------------------*/

        vm.back = function () {
            $rootScope.navigate.go('/center-risk/ondemand');
        };

        vm.haveItems = function (array_) {
            if (array_) {
                return (filterFilter(array_).length > 0) ? true : false;
            }
            else
                return false;
        };

        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
            }
            return {
                dataForValidateDC: function () {
                    var value = {
                        dataCreditoConsultarReq: {
                            cabecera: {
                                country: "CO",
                                channel: "admisionMovil",
                                IOsID: "0"
                            },
                            dataCreditoConsultar: {
                                apellido: vm.lastName,
                                tipoDocumento: vm.typeidentity,
                                numeroDocumento: vm.identity,

                                codigoOficina: 0,
                                login: "",
                                idProducto: 0
                            }
                        }
                    };

                    return value;
                },
                executeWebService : function (){
                    var value = base.dataForValidateDC();

                    centerRiskSource.validateDataCredit(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;

                            if (d.dataCreditoConsultarResp.informacionOperacion.codigoOperacion == "0000") {
                                if (d.dataCreditoConsultarResp.resultados.dataCreditoConsultarResult == true) {
                                    //parent.productPath = parent.link.formBDataAdic;
                                } else {
                                    vm.errorDC = {
                                        status: true,
                                        message: "No continua por Políticas Internas.",
                                    }
                                }
                            } else {
                                vm.errorDC = {
                                    status: true,
                                    message: d.dataCreditoConsultarResp.informacionOperacion.glosaOperacion,
                                }
                            }
                            base.getLastQuery();
                        } else {
                            vm.errorDC = {
                                status: true,
                                message: d.dataCreditoConsultarResp.informacionOperacion.glosaOperacion,
                            }
                        }
                    });
                },
                getLastQuery: function () {
                    centerRiskSource.getLastQuery(vm.typeidentity, vm.identity).then(function (data_) {
                        if (data_.status) {
                            vm.lastQuery = data_.data;
                            base.loadHeader(vm.lastQuery);
                            base.loadCalification(vm.lastQuery);
                            base.loadVigency(vm.lastQuery);
                            base.loadNoVigency(vm.lastQuery);
                            base.loadBalance(vm.lastQuery);
                            base.loadIndebtedness(vm.lastQuery);
                            base.loadReclaims(vm.lastQuery);
                            base.loadAlerts(vm.lastQuery);
                            base.loadQueryes(vm.lastQuery);
                            base.loadResume(vm.lastQuery);
                        }
                        else {
                            vm.errorDC = {
                                status: true,
                                message: "No continua por Políticas Internas.",
                            }
                        }
                    });
                },
                //getRequireWebService: function () {
                //    centerRiskSource.requireWebService(vm.typeidentity, vm.identity, vm.lastName).then(function (data_) {
                //        if (data_.status) {
                //            vm.result = data_.data;
                //            if (vm.result == 1) {
                //                console.log("se lanza el metodo para obtener el id, ejecuto los otros servicios");
                //                base.getLastQuery();
                //            }
                //            else {
                //                console.log("se lanza el web service, luego en el callback se ejecutan los otros servicios");
                //                base.ExecuteWebService();
                //            }
                //        }
                //    });
                //},
                loadHeader: function (lastQuery_) {
                    centerRiskSource.getHeader(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.header = data_.data;
                        }
                    });
                },
                loadCalification: function (lastQuery_) {
                    centerRiskSource.getCalification(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.calification = data_.data;
                        }
                    });
                },
                loadVigency: function (lastQuery_) {
                    centerRiskSource.getVigency(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.vigency = data_.data;
                            vm.totalItems_tb01 = vm.vigency.length || 0;
                        }
                    });
                },
                loadNoVigency: function (lastQuery_) {
                    centerRiskSource.getNoVigency(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.novigency = data_.data;
                            vm.totalItems_tb02 = vm.novigency.length || 0;
                        }
                    });
                },
                loadBalance: function (lastQuery_) {
                    centerRiskSource.getBalance(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.balance = data_.data;
                            vm.totalItems_tb03 = vm.balance.length || 0;
                        }
                    });
                },
                loadIndebtedness: function (lastQuery_) {
                    centerRiskSource.getIndebtedness(lastQuery_).then(function (data_) {
                        
                        if (data_.status) {
                            vm.indebtedness = data_.data;
                            vm.totalItems_tb04 = vm.indebtedness.length || 0;
                        }
                    });
                },
                loadReclaims: function (lastQuery_) {
                    centerRiskSource.getReclaims(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.reclaims = data_.data;
                            vm.totalItems_tb05 = vm.reclaims.length || 0;
                        }
                    });
                },
                loadAlerts: function (lastQuery_) {
                    centerRiskSource.getAlerts(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.alerts = data_.data;
                            vm.totalItems_tb06 = vm.alerts.length || 0;
                        }
                    });
                },
                loadQueryes: function (lastQuery_) {
                    centerRiskSource.getQueryes(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.queryes = data_.data;
                            vm.totalItems_tb07 = vm.queryes.length || 0;
                        }
                    });
                },
                loadResume: function (lastQuery_) {
                    centerRiskSource.getResume(lastQuery_).then(function (data_) {
                        if (data_.status) {
                            vm.resume = {};
                            vm.resume.codeudor = $filter("filter")(data_.data, {group:"Codeudor"});
                            vm.resume.titular = $filter("filter")(data_.data, { group: "Titular" });
                            vm.resume.total = $filter("filter")(data_.data, { group: "Total" });
                        }
                    });
                },
                validateDataCredit: function () {
                    centerRiskSource.validateDataCredit(data).then(function (data_) {
                        if (data_.status) {
                            vm.header = data_.data;
                        }
                    });
                },
                init: function () {
                    //base.getRequireWebService();
                    base.executeWebService();
                }
            }
        }();
        base.init();


        /*DEFAULT ITEMS PER TABLE*/
        vm.totalItems_tb01 = 0;
        vm.totalItems_tb02 = 0;
        vm.totalItems_tb03 = 0;
        vm.totalItems_tb04 = 0;
        vm.totalItems_tb05 = 0;
        vm.totalItems_tb06 = 0;
        vm.totalItems_tb07 = 0;
        vm.current_tb01 = 1
        vm.current_tb02 = 1;
        vm.current_tb03 = 1;
        vm.current_tb04 = 1;
        vm.current_tb05 = 1;
        vm.current_tb06 = 1;
        vm.current_tb07 = 1;
    }]);

