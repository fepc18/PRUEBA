﻿app.controller("oFacController", ['$scope', '$rootScope', '$location', 'oFacSources', '$filter',
function ($scope, $rootScope, $location, oFacSources, $filter) {

    var vm = this;
    vm.configForm = {};
    vm.auth = {
        state: true,
        message: ""
    }

    vm.submit = function () {
        if ($scope["formCentralRisk"].$invalid) {
            vm.sendForm = -1;
            return false;
        }
        else {
            vm.sendForm = 1;
            if (vm.optionSearch == "1")
            {
                vm.names = vm.criteria;
                vm.documentId = "";
            }
            else
            {
                vm.names = "";
                vm.documentId = vm.criteria;
            }
            vm.loadingQuest = true;
            oFacSources.getListOfac(vm.names, vm.documentId).then(function (data_) {
                    if (data_.status) {
                        vm.listOfac = data_.data;
                        base.setPaginator(vm.listOfac.length);
                        //vm.loadingQuest = false;
                        //return true;
                    } else {
                        vm.auth.state = false;
                        vm.auth.message = data_.data;
                        vm.listOfac = [];
                    }
                    vm.loadingQuest = false;
                });
        }
    }

    vm.clearParams = function () {
    vm.names = "";
    vm.criteria = "";
    vm.documentId = "";
    }

    vm.apliOrder = function (order_) {
        vm.paginator.order = order_;
    };


/***************************************************/
/*                                                 */
/*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
/*                                                 */
/***************************************************/
    var base = function () {
        var local = {
        }
        return {
            setPaginator: function(totalItems_) {
                vm.paginator.totalItems = totalItems_;
                var totalPages = (vm.paginator.totalItems / vm.paginator.itemsByPage);
                var noFraction = parseInt(totalPages);
                vm.paginator.totalPages = (totalPages - noFraction == 0) ? noFraction : (noFraction + 1);
            },
            init: function () {
                vm.paginator = {
                    currentPage: 1,
                    order: "lastName",
                    itemsByPage: 10,
                    totalItems: 0,
                    totalPages: 0,
                };
            },
            clearParams: function () {
                vm.names = "";
                vm.criteria = "";
                vm.documentId = "";
            }
        }
    }();
    base.init();

}]);