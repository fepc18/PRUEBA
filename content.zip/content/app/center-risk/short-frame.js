﻿app.controller("shortFrameController", ['$scope', '$rootScope', 'centerRiskSource', '$routeParams',
    function ($scope, $rootScope, centerRiskSource, $routeParams) {
        var vm = this;

        $scope.date = new Date();

        vm.typeidentity = $routeParams.typeidentity;
        vm.identity = $routeParams.identity;
        vm.lastName = $routeParams.lastName;

        $scope.back = function () {
            $rootScope.navigate.go('/center-risk/shortframe');
        };


        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
            }
            return {
                dataForValidateDC: function () {
                    var value = {
                        dataCreditoConsultarReq: {
                            cabecera: {
                                country: "CO",
                                channel: "admisionMovil",
                                IOsID: "0"
                            },
                            dataCreditoConsultar: {
                                apellido: vm.lastName,
                                tipoDocumento: vm.typeidentity,
                                numeroDocumento: vm.identity,

                                codigoOficina: 0,
                                login: "",
                                idProducto: 0
                            }
                        }
                    };

                    return value;
                },
                ExecuteWebService: function () {
                    var value = base.dataForValidateDC();
                    vm.statusQuery = false;
                    centerRiskSource.validateDataCredit(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;

                            if (d.dataCreditoConsultarResp.informacionOperacion.codigoOperacion == "0000") {
                                if (d.dataCreditoConsultarResp.resultados.dataCreditoConsultarResult == true) {
                                    //parent.productPath = parent.link.formBDataAdic;
                                } else {
                                    vm.statusQuery = true;
                                    vm.errorDC = {
                                        status: true,
                                        message: "No continua por Políticas Internas.",
                                    }
                                }
                            } else {
                                vm.statusQuery = true;
                                vm.errorDC = {
                                    status: true,
                                    message: d.dataCreditoConsultarResp.informacionOperacion.glosaOperacion,
                                }
                            }
                            base.getLastQuery();
                        } else {
                            vm.statusQuery = true;
                            vm.errorDC = {
                                status: true,
                                message: d.dataCreditoConsultarResp.informacionOperacion.glosaOperacion,
                            }
                        }
                    });
                },
                getQueryShortFrame: function (lastQuery_) {
                    centerRiskSource.getShortFrame(lastQuery_).then(function (data_) {
                        vm.statusQuery = true;
                        if (data_.status) {
                            vm.result = data_.data;
                        }
                        else {
                            console.log(data_.error);
                        }
                    });
                },
                getLastQuery: function () {
                    centerRiskSource.getLastQuery(vm.typeidentity, vm.identity).then(function (data_) {
                        if (data_.status) {
                            vm.lastQuery = data_.data;
                            base.getQueryShortFrame(vm.lastQuery);
                        }
                        else {
                            vm.statusQuery = true;
                            vm.errorDC = {
                                status: true,
                                message: "No continua por Políticas Internas.",
                            }
                        }
                    });
                },
                //getRequireWebService: function () {
                //    centerRiskSource.requireWebService(vm.typeidentity, vm.identity, vm.lastName).then(function (data_) {
                //        if (data_.status) {
                //            vm.result = data_.data;
                //            if (vm.result == 1) {
                //                console.log("se lanza el metodo para obtener el id, ejecuto los otros servicios");
                //                base.getLastQuery();
                //            }
                //            else {
                //                console.log("se lanza el web service, luego en el callback se ejecutan los otros servicios");
                //                base.ExecuteWebService();
                //            }
                //        }
                //    });
                //},
                init: function () {
                    //base.getRequireWebService();
                    base.ExecuteWebService();
                }
            }
        }();
        base.init();
    }]);