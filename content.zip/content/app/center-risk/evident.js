﻿app.controller("evidentRiskController", ['$scope', '$rootScope', '$filter', 'toolsForm', 'evidentSource',
    function ($scope, $rootScope, $filter, toolsForm, evidentSource) {

        var vm = this;

        var formName = "formDataClient";

        vm.fromLoaded = false;
        vm.sendForm = 0;

        vm.reload = function () {
            vm.dataRequested = false;
            vm.send = false;
            vm.error.status = false;
            vm.identity = "";
            vm.lastName1 = "";
            vm.lastName2 = "";
            vm.firstName = "";
            vm.expeditionDate = "";
        };

        vm.getQuestions = function () {
            if ($scope[formName].$invalid) {
                vm.sendForm = -1;
                vm.dataRequested = false;
                return false;
            }
            else {
                vm.sendForm = 1;
                base.getAsks();
                vm.dataRequested = true;
            }
        }

        vm.asks = [];
        vm.askResponse = [];
        vm.isCheckedAsk = false;

        vm.currentPage = 0;
        vm.totalItems = 0;
        vm.askCurrent = null;
        vm.send = false;

        vm.dataRequested = false;

        vm.nextAsk = function (index) {
            vm.isCheckedAsk = false;
            vm.askCurrent = vm.asks[index];
        }
        vm.setAskChecked = function (item) {
            var index = vm.currentPage;
            base.saveAskSelected(vm.asks[index], item);
        }
        vm.validateAsks = function () {
            base.validationAsks();
        }
        vm.reset = function () {

        }

        vm.checkstyle = function (field) {
            if (vm.askResponse.length > 0 && vm.askResponse.length > vm.currentPage) {
                var find = vm.askResponse[vm.currentPage];

                if (find.idRespuestaField == field) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        vm.setPropertyDocumentFromTypeDoc = function (itemName, slave, property, persist) {
            var ob = vm[itemName];
            var find = $filter("filter")(vm.documentTypes, { id: ob });

            vm[slave] = !persist ? null : vm[slave] || null;
            vm[itemName + "_" + property] = find[0][property];
        };

        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
                formatDateFromJson: function (dateString) {
                    if (dateString != undefined || dateString != null) {
                        var iof = dateString.indexOf("-");

                        if (iof > 0) {
                            var spl = dateString.split("-");
                            return spl[2].substring(0, 2) + "/" + spl[1] + "/" + spl[0];
                        } else {
                            return dateString;
                        }
                    } else {
                        return "";
                    }
                },
                formatZeroLeft: function (val, zeroLeft) {
                    var max = parseInt(zeroLeft);

                    while (val.toString().length < max) {
                        val = "0" + val.toString();
                    }

                    return val;
                }
            }
            return {
                saveLocalData: function () {
                    var data = {

                    }

                    $rootScope.storage.set("form_evident", data);
                },
                loadLocalData: function () {
                    var data = angular.fromJson($rootScope.storage.get("form_evident"));
                    var loaded = false;

                    if (data != null) {


                        loaded = true;
                    }
                    return loaded;
                },
                dataForAsks: function () {
                    //var data = vm.data_formbasicdata;

                    var value = {
                        Head: {
                            country: "CO",
                            channel: "admisionWeb",
                            IOsID: ""
                        },
                        //NumeroIdentificacion: data.documentId || "",
                        //TipoDocumento: data.documentType || "",
                        //Nombres: (data.name1 + (data.name2 ? " " + data.name2 : "")) || "",
                        //PrimerApellido: data.surname1 || "",
                        //SegundoApellido: data.surname2 || "",
                        //FechaExpedicion: data.documentExpDate || "",
                        //NumeroIdentificacion: "79886653",
                        //NumeroIdentificacion: "52801070",
                        //NumeroIdentificacion: "27093275",
                        //TipoDocumento: "1",
                        //Nombres: "pedro",
                        //PrimerApellido: "perez",
                        //SegundoApellido: "",
                        //FechaExpedicion: new Date("1996-02-23T05:00:00.000Z"),
                        NumeroIdentificacion: vm.identity,
                        TipoDocumento: vm.documentType,
                        Nombres: vm.firstName,
                        PrimerApellido: vm.lastName1,
                        SegundoApellido: vm.lastName2,
                        FechaExpedicion: vm.expeditionDate,
                    };
                    return value;
                },
                dataForValidation: function () {
                    var data =  base.dataForAsks();

                    var value = {
                        Head: {
                            country: "CO",
                            channel: "admisionWeb",
                            IOsID: ""
                        },
                        Answer: {
                            identificacionField: {
                                tipoField: data.TipoDocumento || "",
                                numeroField: data.NumeroIdentificacion || "",
                            },
                            idCuestionarioField: vm.refAsk.id,
                            regCuestionarioField: vm.refAsk.register,
                            respuestaField: vm.askResponse
                        }
                    }

                    return value;
                },
                saveAskSelected: function (item, response) {
                    var find = $filter("filter")(vm.askResponse, { idPreguntaField: item.ordenField });

                    if (find.length == 0) {
                        vm.askResponse.push(
                            {
                                idPreguntaField: local.formatZeroLeft(item.ordenField, 2),
                                idRespuestaField: response,
                            }
                        );
                    } else {
                        var idx = 0;
                        angular.forEach(vm.askResponse, function (item, index) {
                            if (item.idPreguntaField == find[0].idPreguntaField) {
                                idx = index;
                            }
                        });
                        if (vm.askResponse[idx].idRespuestaField != response)
                            vm.askResponse[idx].idRespuestaField = response;
                    }
                    vm.isCheckedAsk = true;
                },

                getAsks: function () {
                    var value = base.dataForAsks();
                    vm.loadingAsks = true;

                    evidentSource.getAsks(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;
                            if (d.status != null || d.status != undefined) {
                                if (d.status.code == "0200" && d.result.questionnaire && d.result.questionnaire.preguntaField) {
                                    var vec = d.result.questionnaire;

                                    vm.asks = [];
                                    vm.refAsk = {
                                        id: vec.idField,
                                        register: vec.registroField
                                    }

                                    angular.forEach(vec.preguntaField, function (item, index) {
                                        vm.asks.push(item);
                                    });

                                    vm.totalItems = parseInt(vm.asks.length) - 1;
                                    vm.nextAsk(0);

                                } else {
                                    vm.error = {
                                        status: true,
                                        message: d.status.detail,
                                    }
                                    vm.asks = [];
                                }
                            } else {
                                vm.error = {
                                    status: true,
                                    message: d.status.detail,
                                }
                                vm.asks = [];
                            }
                        } else {
                            vm.error = {
                                status: true,
                                message: data_.message,
                            }
                            vm.asks = [];
                        }

                        vm.loadingAsks = false;
                    });

                },
                validationAsks: function () {

                    var value = base.dataForValidation();
                    vm.loadingValidation = true;
                    vm.send = true;

                    evidentSource.validationAsks(JSON.stringify(value)).then(function (data_) {
                        if (data_.status) {
                            var d = data_.data;
                            if (d.status != null || d.status != undefined) {
                                if (d.status.code == "0200") {
                                    vm.error = {
                                        status: false,
                                    }
                                } else {
                                    vm.error = {
                                        status: true
                                    }
                                    switch (d.status.code) {
                                        case "0201":
                                            vm.error.message = "El cliente no existe.";
                                            break;
                                        case "0203":
                                            vm.error.message = "Ha superado el número máximo de intentos por día.";
                                            break;
                                        case "0204":
                                            vm.error.message = "La validación NO fue exitosa.";
                                            break;
                                        default:
                                            vm.error.message = d.status.detail;
                                            break;
                                    }
                                }

                            } else {
                                vm.error = {
                                    status: true,
                                    message: d.status.detail,
                                }
                            }
                        } else {
                            vm.error = {
                                status: true,
                                message: data_.message,
                            }
                        }

                        vm.loadingValidation = false;
                    });

                },

                init: function () {
                    
                    vm.documentTypes = $rootScope.parametrics.getParam("parametrics_tiposIdentificacion");
                    vm.documentType = "1"; // Tipo de documento que se carga por default
                    vm.setPropertyDocumentFromTypeDoc('documentType', 'identity', 'expReg')
                    //vm.data_formbasicdata = angular.fromJson($rootScope.storage.get("form_basic_data"));
                    //var load = base.loadLocalData();

                    //base.getAsks();
                }
            }
        }();
        base.init();



        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        //$rootScope.$watch('parametrics.state',
        //    function (nValue, oValue) {
        //        if (nValue != oValue) {
        //            base.init();
        //        } else {
        //            return false;
        //        }
        //    });


        /*#############*/
        //vm.send = true;
        //vm.loadingAsks = false;
        //vm.error = {
        //    status: true,
        //    message: "Error en el procesamiento de evidente."
        //}
        /*#############*/
    }]);