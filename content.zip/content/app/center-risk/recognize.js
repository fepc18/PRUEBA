﻿app.controller("recognizeRiskController", ['$scope', '$rootScope', 'recognizeSources', '$filter', '$routeParams', 'filterFilter',
    function ($scope, $rootScope, recognizeSources, $filter, $routeParams, filterFilter) {
        var vm = this;

        vm.date = new Date();

        vm.typeidentity = $routeParams.typeidentity;
        vm.identity = $routeParams.identity;
        vm.lastName = $routeParams.lastName;
        vm.compress = false;

        vm.expandCompressInclude = function (compress) {     
            var headers = document.getElementsByClassName("panel-heading");
            for (var i = 0; i < headers.length; i++) {
                var nodeHeader = headers[i]; //
                if (nodeHeader.attributes) {
                    for (var z = 0; z < nodeHeader.attributes.length; z++) {
                        if (nodeHeader.attributes[z].name == "aria-controls") {
                            var idPanel = nodeHeader.attributes[z].value;
                            var nodePanel = document.getElementById(idPanel);
                            var cls = nodePanel.className; //
                            if (!compress) {
                                if (!cls.match("in")) headers[i].click();
                            } else {
                                if (cls.match("in")) headers[i].click();
                            }
                        }
                    }
                }
            }
            vm.compress = vm.compress ? false : true;

            //var par = $("#px-collapses");
            //var ang = angular.element(par);

            //"panel-body panel-collapse collapse in";

            //angular.forEach(ang[0].children, function (item, index) {
            //    var itm = angular.element(item);
            //    var sec = itm[0].children[1];
            //    sec = angular.element(sec);
            //    var result = document.getElementsByClassName("panel-collapse");
            //    var cls = sec[0] ? sec[0].className : "";

            //    if (sec[0] && cls.trim() != "panel-body") {
            //        if (cls.match("in")) {
            //            cls = cls.replace("in", "");
            //        } else {
            //            cls = cls + "in";
            //        }
            //        sec[0].className = cls;
            //    }


                //vm.situationCollapse = {
                //    match: !compress ? "collapsed" : "in",
                //    oposit: compress ? "collapsed" : "in",
                //    status: !compress ? true : false
                //};

                //if (cls == "") vm.situationCollapse.status = false;
                //if (cls.match(vm.situationCollapse.match)) {
                //    cls = cls.replace(vm.situationCollapse.match, vm.situationCollapse.oposit);

                //    sec[0].className = cls;
                //} else {
                //    if (!cls.match(vm.situationCollapse.oposit)) cls = cls + " " + vm.situationCollapse.oposit;
                //    if (sec[0] && !cls.match("panel-body")) sec[0].className = cls;
                //}

            //});
        }
        /*----------------------*/

        vm.back = function () {
            $rootScope.navigate.go('/center-risk/recognize');
        };

        vm.haveItems = function (array_) {
            if (array_) {
                return (filterFilter(array_).length > 0) ? true : false;
            }
            else
                return false;
        };

        /***************************************************/
        /*                                                 */
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /*                                                 */
        /***************************************************/
        var base = function () {
            var local = {
            }
            return {
                getRecognizeData: function () {
                    recognizeSources.getDataRecognize(vm.typeidentity, vm.identity, vm.lastName).then(function (data_) {
                        if (data_.status) {
                            vm.dataClient = data_.data;

                            vm.totalItems_tb01 = vm.dataClient.listaDirecciones.length || 0;
                            vm.totalItems_tb02 = vm.dataClient.listaTelefonos.length || 0;
                            vm.totalItems_tb03 = vm.dataClient.listaCelulares.length || 0;
                            vm.totalItems_tb04 = vm.dataClient.listaEmail.length || 0;

                            angular.forEach(vm.dataClient.listaIndicadorMovilidad, function (indicador) {
                                switch (indicador.tipo) {
                                    case 'R':
                                        vm.vectorR = [];
                                        for (i = 0; i < indicador.vectorDirecciones.length; i++) {
                                            objInd = {};
                                            objInd.month = new Date(indicador.fechaInicial);
                                            objInd.month = objInd.month.setMonth(objInd.month.getMonth() + (i + 1));
                                            objInd.state = indicador.vectorDirecciones.substring(i, i + 1);
                                            vm.vectorR.push(objInd);
                                        }
                                        break;
                                    case 'L':
                                        vm.vectorL = [];
                                        for (i = 0; i < indicador.vectorDirecciones.length; i++) {
                                            objInd = {};
                                            objInd.month = new Date(indicador.fechaInicial);
                                            objInd.month = objInd.month.setMonth(objInd.month.getMonth() + (i + 1));
                                            objInd.state = indicador.vectorDirecciones.substring(i, i + 1);
                                            vm.vectorL.push(objInd);
                                        }
                                        break;
                                    case 'C':
                                        vm.vectorC = [];
                                        for (i = 0; i < indicador.vectorDirecciones.length; i++) {
                                            objInd = {};
                                            objInd.month = new Date(indicador.fechaInicial);
                                            objInd.month = objInd.month.setMonth(objInd.month.getMonth() + (i + 1));
                                            objInd.state = indicador.vectorDirecciones.substring(i, i + 1);
                                            vm.vectorC.push(objInd);
                                        }
                                        break;
                                    default:

                                }
                            });
                            console.log(vm.dataClient);
                            console.log(vm.vectorR);
                            console.log(vm.vectorL);
                            console.log(vm.vectorC);
                        }
                        else {
                            vm.errorDC = {
                                status: true,
                                message: "Error cargando los datos",
                            }
                        }
                    });
                },
                init: function () {
                    base.getRecognizeData();
                }
            }
        }();
        base.init();


        /*DEFAULT ITEMS PER TABLE*/
        vm.totalItems_tb01 = 0;
        vm.totalItems_tb02 = 0;
        vm.totalItems_tb03 = 0;
        vm.totalItems_tb04 = 0;
        vm.current_tb01 = 1
        vm.current_tb02 = 1;
        vm.current_tb03 = 1;
        vm.current_tb04 = 1;
    }]);

