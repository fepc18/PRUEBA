﻿app.controller("centerRiskController", ['$scope', '$rootScope','$location', 'centerRiskSource', '$filter',
function ($scope, $rootScope, $location, centerRiskSource, $filter) {

    var vm = this;
    vm.configForm = {};

    vm.paginator = {
        currentPage : 1,
        order: "queryDate",
        itemsByPage:5,
        totalItems: 0,
        totalPages:0,
    };

    vm.detailHistory = function(idConsulta_)
    {
        $rootScope.navigate.go(vm.configForm.goDetail + idConsulta_);
    }

    vm.submit = function () {
        if ($scope["formCentralRisk"].$invalid) {
            vm.sendForm = -1;
            return false;
        }
        else {
            vm.sendForm = 1;
            if (vm.configForm.typeFormHistory) {
                vm.loadingQuest = true;
                centerRiskSource.getHistory(vm.documentType, vm.documentId).then(function (data_) {
                    if (data_.status) {
                        vm.loadingQuest = false;
                        vm.history = data_.data;
                        base.setPaginator(vm.history.length);
                        return true;
                    }
                });
            }
            else {
                $location.path(vm.configForm.goDetail).search({ typeidentity: vm.documentType, identity: vm.documentId, lastName: vm.lastName });
                return true;
            }
        }
    }

    vm.apliOrder = function (order_) {
        vm.paginator.order = order_;
    };


    vm.setPropertyDocumentFromTypeDoc = function (itemName, slave, property, persist) {
        var ob = vm[itemName];
        var find = $filter("filter")(vm.documentTypes, { id: ob });

        vm[slave] = !persist ? null : vm[slave] || null;
        vm[itemName + "_" + property] = find[0][property];
    };


/***************************************************/
/*                                                 */
/*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
/*                                                 */
/***************************************************/
    var base = function () {
        var local = {
        }
        return {
            setPaginator: function(totalItems_) {
                vm.paginator.totalItems = totalItems_;
                var totalPages = (vm.paginator.totalItems / vm.paginator.itemsByPage);
                var noFraction = parseInt(totalPages);
                vm.paginator.totalPages = (totalPages - noFraction == 0) ? noFraction : (noFraction + 1);
            },
            setForm: function () {
                //vm.documentTypes = $rootScope.parametrics.getParam("parametrics_tiposIdentificacion");
                // TODO : los tipos de documento deben leerse del servicio de reconocer
                vm.documentTypes = [
                    {
                        descripcion: "CÉDULA DE CIUDADANÍA",
                        expReg: "[0-9]{6,10}",
                        id: "1",
                        idMensajeError: "3"
                    },
                    {
                        descripcion: "CÉDULA DE EXTRANJERÍA",
                        expReg: "[0-9]{6,10}",
                        id: "4",
                        idMensajeError: "3"
                    }
                ];

                console.log(vm.documentTypes);
                vm.documentType = "1"; // Tipo de documento precargado por default "cedula"
                vm.setPropertyDocumentFromTypeDoc('documentType','documentId', 'expReg')
                var launchPath = $rootScope.navigate.getPath();
                switch (launchPath) {
                    case '/center-risk/shortframe':
                        vm.configForm.goDetail = '/center-risk/shortframe/result';
                        vm.configForm.title = 'Consulta centrales de riesgo por demanda - Trama corta';
                        vm.configForm.typeForm = true;
                        break;
                    case '/center-risk/history':
                        vm.configForm.goDetail = '/center-risk/history/';
                        vm.configForm.title = 'Consultas historicas a datacredito';
                        vm.configForm.typeFormHistory = true;
                        break;
                    case '/center-risk/ondemand':
                        vm.configForm.goDetail = '/center-risk/ondemand/result';
                        vm.configForm.title = 'Consulta centrales de riesgo por demanda';
                        vm.configForm.typeForm = true;
                        break;
                    case '/center-risk/recognize':
                        vm.configForm.goDetail = '/center-risk/recognize/result';
                        vm.configForm.title = 'Consulta reconocer';
                        vm.configForm.typeForm = true;
                        break;
                    default:
                        vm.configForm.goDetail = '/';
                        vm.configForm.title = 'Acceso sin parametrizar';
                        break;
                }
            },
            init: function () {
                base.setForm();
            }
        }
    }();
    base.init();
}]);