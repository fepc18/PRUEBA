﻿app.controller("biometricsVerificationController", ['dynamicFormFactory', 'biometricsFactory', '$scope', '$rootScope',
    function (dynamicFormFactory, biometricsFactory, $scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;


        vm.test = true;
        //vm.documentFeatures = {};
        vm.listDocumentFeatures = [];
        vm.documentFrontImg = "";
        vm.documentBackImg = "";

        vm.dynamicSections = [];
        vm.fields = {};
        vm.flowModule = [];
        var module = "002";
        var ecoActivity = "0";


        vm.numPage = 1;
        vm.img = 0;
        vm.fingerprint = [
            {
                id: 0,
                name: "Indice Derecho",
                url: "/content/style/img/fingerprint-1.jpg"
            },
            {
                id: 1,
                name: "Indice Izquierdo",
                url: "/content/style/img/fingerprint-2.jpg"
            },
            {
                id: 2,
                name: "Pulgar Derecho",
                url: "/content/style/img/fingerprint-3.jpg"
            },
        ];


        vm.LoadHelpDocument = function () {

        }




        vm.imgSelect = vm.fingerprint[vm.img];

        vm.navigateFinger = function (dir) {
            if (dir == "next")
                vm.img++;
            else if (dir == "prev")
                vm.img--;

            vm.imgSelect = vm.fingerprint[vm.img];
        };

        vm.navigateForm = function (dir) {
            if (dir == "next")
                vm.numPage++;
            else if (dir == "prev")
                vm.numPage--;
        };

        vm.falseDoc = function () {
            vm.numPage = 3;
        };

        /***************************************************/
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /***************************************************/

        var base = function () {
            var local = {

            }
            return {
                getValidationHelp: function (dataInput) {
                    biometricsFactory.getValidationHelp(dataInput).then(function (result) {
                        if (result.status) {
                            vm.listDocumentFeatures = result.data.dataDocumentFeature.documentFeatureList;
                            vm.documentFrontImg = result.data.identityTypes.obverseImage;
                            vm.documentBackImg = result.data.identityTypes.backImage;
                            return true;
                        } else {
                            console.log("No se han cargado los tipos de documento");
                        }
                    })
                },

                createDynamicForm: function () {
                    dynamicFormFactory.getAllByModule(module, ecoActivity).then(function (result) {

                        if (result.status) {
                            vm.dynamicSections = result.data.questionSections;
                            vm.flowModule = result.data.questionFlow;

                            angular.forEach(vm.dynamicSections, function (value, index) {

                                angular.forEach(value.questions, function (val, index) {
                                    var pre = "";
                                    switch (val.idQuestionType) {
                                        case "01": {
                                            pre = "text_";
                                        } break;
                                        case "02": {
                                            pre = "area_";
                                        } break;
                                        case "03": {
                                            pre = "ddl_";
                                        } break;
                                        case "04": {
                                            pre = "radio_";
                                        } break;
                                        case "05": {
                                            pre = "check_";
                                        } break;
                                    }

                                    vm.fields[pre + val.idQuestion] = "";
                                });
                            });

                            return true;

                        } else {
                            console.log("No se cargo el modulo");
                        }
                    })
                },

                init: function () {
                    vm.dataInput = {
                        'IdIdentityType': 1,
                        'IdentityNumber': 1
                    };

                    //base.getValidationHelp(vm.dataInput);
                    base.createDynamicForm(module, ecoActivity);
                }
            }
        }();
        base.init();

    }]);