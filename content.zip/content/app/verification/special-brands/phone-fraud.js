﻿app.controller("phoneFraudSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.resultPhones = [];
        vm.resultFraud = [];

        //vm.resultFraud = [
        //    {
        //        id: 0298345670,
        //        city: "Bogotá",
        //        date: "23/02/2007 03:00:30 p.m.",
        //        office: "HC Sur",
        //        detail: {
        //            d1: "Nombres",
        //            d2: "Apellidos"
        //        },
        //        flag: false
        //    },
        //    {
        //        id: 0298345671,
        //        city: "Bogotá",
        //        date: "03/04/2010 02:40:30 p.m.",
        //        office: "HC Sur",
        //        detail: {
        //            d1: "Nombres",
        //            d2: "Apellidos"
        //        },
        //        flag: false
        //    },
        //    {
        //        id: 0298345672,
        //        city: "Bogotá",
        //        date: "03/12/2011 02:05:30 p.m.",
        //        office: "HC Sur",
        //        detail: {
        //            d1: "Nombres",
        //            d2: "Apellidos"
        //        },
        //        flag: false
        //    },
        //    {
        //        id: 0298345673,
        //        city: "Bogotá",
        //        date: "15/04/2016 02:40:30 p.m.",
        //        office: "HC Sur",
        //        detail: {
        //            d1: "Nombres",
        //            d2: "Apellidos"
        //        },
        //        flag: false
        //    },

        //];


        __tmp_llenar();


        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        vm.resultPhones_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
        vm.resultPhones_Current = 1;
        vm.resultPhones_TotalItems = vm.resultPhones.length;

        vm.resultFraud_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
        vm.resultFraud_Current = 1;
        vm.resultFraud_TotalItems = vm.resultFraud.length;

        //$scope.$watch("formRevFraud.$pristine", function (newVal, oldVal) {
        //    if (newVal != oldVal) {
        //        pr.specialBrands.phoneFraud_Save = 0;
        //    }
        //})
        vm.setPristine = function () {
            //$scope["formRevFraud"].$pristine = false;
            pr.specialBrands.phoneFraud_Save = 0;
        }
        vm.save = function () {           
            if ($scope["formRevFraud"].$invalid) {
                pr.specialBrands.phoneFraud_Save = 0;

                angular.forEach($scope["formRevFraud"].$error.required, function (field) {
                    field.$setTouched();
                });

            } else {
                pr.specialBrands.phoneFraud_Save = 1;
            }
        }




        /*-----------------------------------------*/
        function __tmp_llenar() {
            for (var i = 0; i < 20; ++i) {
                vm.resultPhones.push({
                    state: "Fraudes OK",
                    cross: "Telefono Residencia " + i + ": OK"
                });
            }

            for (var i = 0; i < 10; ++i) {
                vm.resultFraud.push({
                        id: 029834567 + i,
                        city: "Bogotá",
                        date: "23/02/2007 03:00:3" + i + "p.m.",
                        office: "HC Sur",
                        detail: {
                            d1: "Nombres",
                            d2: "Apellidos"
                        }
                    });
            }
        }
    }]);