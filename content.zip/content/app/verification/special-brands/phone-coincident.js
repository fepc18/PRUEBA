﻿app.controller("phoneCoincidentSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.resultPhones = [];

        /*TEMPORAL*/
        __tmp_llenar();
        /*TEMPORAL*/




        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        vm.resultPhones_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
        vm.resultPhones_Current = 1;
        vm.resultPhones_TotalItems = vm.resultPhones.length;

        vm.setPristine = function (textContain) {
            pr.specialBrands.phoneCoincident_Save = 0;
        }
        vm.save = function () {
            if ($scope["formPhoneCoincident"].$invalid) {  
                pr.specialBrands.phoneCoincident_Save = 0;
                
                angular.forEach($scope["formPhoneCoincident"].$error.required, function (field) {
                    field.$setTouched();
                });    

            } else {
                pr.specialBrands.phoneCoincident_Save = 1; 
            }            
        }
       
        /*-----------------------------------------*/
        function __tmp_llenar() {
            for (var i = 0; i < 50; ++i) {
                vm.resultPhones.push({
                    id: "0" + i,
                    document: i + "54665" + i,
                    store: "Home Center",
                    date: "03/11/2017 03:53:02 p.m.",
                    verify: "Verificación",
                    phone: "547485" + i,
                    origin: "Teléfono Residencia",
                    state: "Vencido",
                    negation: "No viable por políticas",
                    inFraud: "OK"
                });
            }
        }

    }]);