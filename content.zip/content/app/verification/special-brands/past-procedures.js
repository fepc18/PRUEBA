﻿app.controller("pastProceduresSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.infoPrueba = [
             {
                 l: "Nombre:",
                 t: "Ana Sofía Henao Estrada"
             },
             {
                 l: "Documento:",
                 t: "CC. 43878327"
             },
             {
                 l: "Fecha de nacimiento:",
                 t: "19/06/1982"
             },
             {
                 l: "Edad:",
                 t: "34"
             },
             {
                 l: "Ciudad de residencia:",
                 t: "Medellín"
             },
             {
                 l: "Celular:",
                 t: "3184016612"
             },
             {
                 l: "Actividad:",
                 t: "Prestador de Servicios"
             },
             {
                 l: "Empleado falabella:",
                 t: "OK / NO"
             },
             {
                 l: "Tienda:",
                 t: "Santa fe Medellín"
             },
             {
                 l: "Fecha y hora de solicitud:",
                 t: "04/12/2016 – 10:15 am"
             },
             {
                 l: "Nro. Solicitud:",
                 t: "7858585"
             },
             {
                 l: "Tipo de tramite:",
                 t: "Continua el proceso"
             },
             {
                 l: "Nombre:",
                 t: "Ana Sofía Henao Estrada"
             },
             {
                 l: "Documento:",
                 t: "CC. 43878327"
             },
             {
                 l: "Fecha de nacimiento:",
                 t: "19/06/1982"
             },
             {
                 l: "Edad:",
                 t: "34"
             },
             {
                 l: "Ciudad de residencia:",
                 t: "Medellín"
             },
             {
                 l: "Celular:",
                 t: "3184016612"
             },
             {
                 l: "Actividad:",
                 t: "Prestador de Servicios"
             },
             {
                 l: "Empleado falabella:",
                 t: "OK / NO"
             },
             {
                 l: "Tienda:",
                 t: "Santa fe Medellín"
             },
             {
                 l: "Fecha y hora de solicitud:",
                 t: "04/12/2016 – 10:15 am"
             },
             {
                 l: "Nro. Solicitud:",
                 t: "7858585"
             },
             {
                 l: "Tipo de tramite:",
                 t: "Continua el proceso"
             },

        ];

        vm.req1 = {
            infoBasica: {
                    fecha: '21/11/2010 03:53:02 p.m.',
                    solicitud: '1336576',
                    oficina: 'Falabella Hayuelos',
                    producto: 'TDC NUEVA',
                    estado: 'aprobada',
                    tipoCliente: 'Registraduria OK - Verificacion automatica OK',
                    actividadEco: 'Empleado privado',
                    nivelEstudio: 'Postgrado',
                    eps: 'Cotizante',
                    personasCargo: '1',
                    hijos: '1',
                    direccion: 'CR 64 22 41 TR 3 APTO 604',
                    tiempoResid: '24',
                    tipoVivienda: 'Propia',
                    telefono: '3543414',
                    celular: '3212415847'
            },
            infoFinanciera: {
                ingresos: '15000000',
                honorarios: '--',
                arrendamientos: '--',
                otrosIngresos: '--',
                costosGastos: '--',
                cuotasCredito: '--',
                gastosArrenda: '--',
                gastosPersonales: '--',
                descNomina: '--',
                otrosEgresos: '1000000'
            }
        };
            
        vm.req2 = {
            infoBasica: {
                fecha: '14/01/2012 02:46:06 p.m.',
                solicitud: '7575757',
                oficina: 'Falabella Hayuelos',
                producto: 'TDC NUEVA',
                estado: 'rechazada',
                tipoCliente: '--',
                actividadEco: 'Empleado privado',
                nivelEstudio: 'Postgrado',
                eps: 'Cotizante',
                personasCargo: '1',
                hijos: '1',
                direccion: 'CR 64 22 41 TR 3 APTO 604',
                tiempoResid: '48',
                tipoVivienda: 'Propia',
                telefono: '3543414',
                celular: '3212415847'
            },
            infoFinanciera: {
                ingresos: '20000000',
                honorarios: '--',
                arrendamientos: '--',
                otrosIngresos: '--',
                costosGastos: '--',
                cuotasCredito: '--',
                gastosArrenda: '--',
                gastosPersonales: '--',
                descNomina: '--',
                otrosEgresos: '200000'
            }
        };

        vm.req3 = {
            infoBasica: {
                fecha: '21/11/2016 10:53:15 a.m.',
                solicitud: '8456212',
                oficina: 'Falabella Hayuelos',
                producto: 'TDC NUEVA',
                estado: 'rechazada',
                tipoCliente: '--',
                actividadEco: 'Empleado privado',
                nivelEstudio: 'Postgrado',
                eps: 'Cotizante',
                personasCargo: '2',
                hijos: '2',
                direccion: 'CR 64 22 41 TR 3 APTO 604',
                tiempoResid: '96',
                tipoVivienda: 'Propia',
                telefono: '3543414',
                celular: '3212415847'
            },
            infoFinanciera: {
                ingresos: '20000000',
                honorarios: '--',
                arrendamientos: '--',
                otrosIngresos: '--',
                costosGastos: '--',
                cuotasCredito: '--',
                gastosArrenda: '--',
                gastosPersonales: '--',
                descNomina: '--',
                otrosEgresos: '100000'
            }
        };

        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        //$scope.$watch("formPastProcedure.$pristine", function (newVal, oldVal) {
        //    if (newVal != oldVal) {
        //        pr.specialBrands.pastProcedure = 0;
        //    }
        //})
        vm.setPristine = function () {
            //$scope["formPastProcedure"].$pristine = false;
            pr.specialBrands.pastProcedure = 0;
        }
        vm.save = function () {
            if ($scope["formPastProcedure"].$invalid) {
                pr.specialBrands.pastProcedure = 0;

                angular.forEach($scope["formPastProcedure"].$error.required, function (field) {
                    field.$setTouched();
                });

            } else {
                pr.specialBrands.pastProcedure = 1;
            }
        }
    }]);