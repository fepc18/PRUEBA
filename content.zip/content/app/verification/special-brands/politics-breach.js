﻿app.controller("politicsBreachSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        //vm.subMatchingPolBreach = "no";

        vm.politicalBreachContent = [           
            {
                politic: "Edad mínima",
                state: true
            },
            {
                politic: "Edad máxima",
                state: true
            },
            {
                politic: "Ingreso Cónyugue",
                state: true
            },
            {
                politic: "Tiempo de pensionado",
                state: true
            },
            {
                politic: "Tiempo experiencia independiente",
                state: false
            },
            {
                politic: "Políticas de barrio elegibles",
                state: true
            },
            {
                politic: "Biometría",
                state: true
            },
            {
                politic: "Celular obligatorio",
                state: false
            },
            {
                politic: "Tipo de trámite",
                state: true
            }
        ];


        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        //$scope.$watch("formPoliticsBreach.$pristine", function (newVal, oldVal) {
        //    if (newVal != oldVal) {
        //        pr.specialBrands.politicalBreach_Save = 0;
        //    }
        //})
        vm.setPristine = function () {
            //$scope["formPoliticsBreach"].$pristine = false;
            pr.specialBrands.politicalBreach_Save = 0;
        }
        vm.save = function () {            
            if ($scope["formPoliticsBreach"].$invalid) {
                pr.specialBrands.politicalBreach_Save = 0;

                angular.forEach($scope["formPoliticsBreach"].$error.required, function (field) {
                    field.$setTouched();
                });

            } else {
                pr.specialBrands.politicalBreach_Save = 1;
            }
        }

    }]);