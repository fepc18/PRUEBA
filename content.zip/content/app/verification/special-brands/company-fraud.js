﻿app.controller("companyFraudSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;
        
        vm.resultCompany = [];

        __tmp_llenar();

       

        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        vm.resultCompany_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
        vm.resultCompany_Current = 1;
        vm.resultCompany_TotalItems = vm.resultCompany.length;

        //$scope.$watch("formCompanyFraud.$pristine", function (newVal, oldVal) {
        //    if (newVal != oldVal) {
        //        pr.specialBrands.companyFraud_Save = 0;
        //    }
        //})
        vm.setPristine = function () {
            //$scope["formCompanyFraud"].$pristine = false;
            pr.specialBrands.companyFraud_Save = 0;
        }
        vm.save = function () {            
            if ($scope["formCompanyFraud"].$invalid) {
                pr.specialBrands.companyFraud_Save = 0;

                angular.forEach($scope["formCompanyFraud"].$error.required, function (field) {
                    field.$setTouched();
                });

            } else {
                pr.specialBrands.companyFraud_Save = 1;
            }
        }

   
        /*-----------------------------------------*/
        function __tmp_llenar() {          

            for (var i = 0; i < 10; ++i) {
                vm.resultCompany.push({
                    nit: "9005468762" + i,
                    socialReason: "La liga de la justicia",
                    city: "Ciudad Gotica",
                    department: "Cundinamarca",
                    calification: "buena",
                    phone: "7564545" + i,
                    extension: "12" + i,
                    contact: "bruce@wayne.co",
                    address: "AV 19 120 - 71"
                });
            }
        }
    }]);