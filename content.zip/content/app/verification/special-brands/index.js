﻿app.controller("specialBrandsVerificationController", ['$scope', '$rootScope', '$timeout',
    function ($scope, $rootScope, $timeout) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.phoneCoincident_Save = 0;
        vm.phoneFraud_Save = 0;
        vm.companyFraud_Save = 0;
        vm.politicalBreach_Save = 0;
        vm.expeditionDate_Save = 0;
        vm.birthDate_Save = 0;
        vm.pastProcedure = 0;

        vm.progressTotal = 0;
        vm.progressCurrent = 0;
        vm.progressCurrentPer = 0;

        startEnables();

        vm.enableEndModule = function () {
            var wrong = calculatingEnablesNoSaved();
            var result = (wrong == 0 ? true : false);

            vm.progressCurrent = vm.progressTotal - wrong;
            vm.progressCurrentPer = calculatingProgressCurrent(vm.progressCurrent);
                        
            changeSemaphore(result);

            return result;
        }
        function changeSemaphore(state) {
            var nstate = state ? $rootScope.configuration.stateVerify.COMPLETE.id : $rootScope.configuration.stateVerify.INCOMPLETE.id;

            $rootScope.configuration.verticalmenu[2].submenu[0].semaphoreStatus = nstate;
        }

        function startEnables() {
            var wrong = calculatingEnablesNoSaved();

            vm.progressTotal = wrong;
        }
        function calculatingProgressCurrent(current) {
            if (current != vm.progressTotal) {
                return Math.round(current * 100 / vm.progressTotal);
            } else {
                return 100;
            }
        }
        function calculatingEnablesNoSaved() {
            var wrong = 0;

            wrong = vm.phoneCoincident_Save == 0 ? wrong += 1 : wrong;
            wrong = vm.phoneFraud_Save == 0 ? wrong += 1 : wrong;
            wrong = vm.companyFraud_Save == 0 ? wrong += 1 : wrong;
            wrong = vm.politicalBreach_Save == 0 ? wrong += 1 : wrong;
            wrong = vm.expeditionDate_Save == 0 ? wrong += 1 : wrong;
            wrong = vm.birthDate_Save == 0 ? wrong += 1 : wrong;
            wrong = vm.pastProcedure == 0 ? wrong += 1 : wrong;

            return wrong;
        }
        function activeElement() {
            var el = $("#tabsProduct");
            var ngel = angular.element(el);
            var chl = ngel[0].children[0];

            chl.className = "tab-icon active ng-scope";
                        
            var el = $("#tabsProductContent");
            var ngel = angular.element(el);
            var chl = ngel[0].children[0];

            chl.className = "tab-pane active ng-scope";
        }

        $timeout(activeElement, 0);

        //vm.politicalBreachContent = [
        //    "Edad mínima",
        //    "Edad máxima",
        //    "Ingreso Cónyugue",
        //    "Tiempo de pensionado",
        //    "Tiempo experiencia independiente",
        //    "Políticas de barrio elegibles",
        //    "Biometría",
        //    "Celular obligatorio",
        //    "Tipo de trámite"
        //];

        //vm.infoPrueba = [
        //    {
        //        l: "Nombre:",
        //        t: "Ana Sofía Henao Estrada"
        //    },
        //    {
        //        l: "Documento:",
        //        t: "CC. 43878327"
        //    },
        //    {
        //        l: "Fecha de nacimiento:",
        //        t: "19/06/1982"
        //    },
        //    {
        //        l: "Edad:",
        //        t: "34"
        //    },
        //    {
        //        l: "Ciudad de residencia:",
        //        t: "Medellín"
        //    },
        //    {
        //        l: "Celular:",
        //        t: "3184016612"
        //    },
        //    {
        //        l: "Actividad:",
        //        t: "Prestador de Servicios"
        //    },
        //    {
        //        l: "Empleado falabella:",
        //        t: "OK / NO"
        //    },
        //    {
        //        l: "Tienda:",
        //        t: "Santa fe Medellín"
        //    },
        //    {
        //        l: "Fecha y hora de solicitud:",
        //        t: "04/12/2016 – 10:15 am"
        //    },
        //    {
        //        l: "Nro. Solicitud:",
        //        t: "7858585"
        //    },
        //    {
        //        l: "Tipo de tramite:",
        //        t: "Continua el proceso"
        //    },
        //    {
        //        l: "Nombre:",
        //        t: "Ana Sofía Henao Estrada"
        //    },
        //    {
        //        l: "Documento:",
        //        t: "CC. 43878327"
        //    },
        //    {
        //        l: "Fecha de nacimiento:",
        //        t: "19/06/1982"
        //    },
        //    {
        //        l: "Edad:",
        //        t: "34"
        //    },
        //    {
        //        l: "Ciudad de residencia:",
        //        t: "Medellín"
        //    },
        //    {
        //        l: "Celular:",
        //        t: "3184016612"
        //    },
        //    {
        //        l: "Actividad:",
        //        t: "Prestador de Servicios"
        //    },
        //    {
        //        l: "Empleado falabella:",
        //        t: "OK / NO"
        //    },
        //    {
        //        l: "Tienda:",
        //        t: "Santa fe Medellín"
        //    },
        //    {
        //        l: "Fecha y hora de solicitud:",
        //        t: "04/12/2016 – 10:15 am"
        //    },
        //    {
        //        l: "Nro. Solicitud:",
        //        t: "7858585"
        //    },
        //    {
        //        l: "Tipo de tramite:",
        //        t: "Continua el proceso"
        //    },
        //];

    }]);