﻿app.controller("birthDateSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        //vm.subMatchingBirthDate = "no";
        vm.compareDataBirthDate = false;
        vm.birthDateDataCredit = "1999-08-14";
        vm.birthDateAdmisiones = "1999-08-14";

        function compareDate() {
            var dDaC = new Date(vm.birthDateDataCredit);
            var dAdm = new Date(vm.birthDateAdmisiones);

            if (dDaC.getTime() == dAdm.getTime()) {
                vm.compareDataBirthDate = true;
            }
        }
        
        compareDate();

        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        //$scope.$watch("formBirthDate.$pristine", function (newVal, oldVal) {
        //    if (newVal != oldVal) {
        //        pr.specialBrands.birthDate_Save = 0;
        //    }
        //})
        vm.setPristine = function () {
            //$scope["formBirthDate"].$pristine = false;
            pr.specialBrands.birthDate_Save = 0;
        }
        vm.save = function () {
            if ($scope["formBirthDate"].$invalid) {
                pr.specialBrands.birthDate_Save = 0;

                angular.forEach($scope["formBirthDate"].$error.required, function (field) {
                    field.$setTouched();
                });

            } else {
                pr.specialBrands.birthDate_Save = 1;
            }
        }
    }]);