﻿app.controller("expeditionDateSVController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;
                
        vm.compareDataExpDate = false;
        vm.expDateDataCredit = "2017-03-28";
        vm.expDateAdmisiones = "2017-02-17";

        function compareDate() {
            var dDaC = new Date(vm.expDateDataCredit);
            var dAdm = new Date(vm.expDateAdmisiones);

            if (dDaC.getTime() == dAdm.getTime()) {
                vm.compareData = true;
            }
        }
        
        compareDate();

        /*****************************************/
        /* PAGINACION TABLAS + GUARDADO SECCION  */
        /*****************************************/

        //$scope.$watch("formExpeditionDate.$pristine", function (newVal, oldVal) {
        //    if (newVal != oldVal) {
        //        pr.specialBrands.expeditionDate_Save = 0;
        //    }
        //})
        vm.setPristine = function () {
            //$scope["formExpeditionDate"].$pristine = false;
            pr.specialBrands.expeditionDate_Save = 0;
        }
        vm.save = function () {            
            if ($scope["formExpeditionDate"].$invalid) {
                pr.specialBrands.expeditionDate_Save = 0;

                angular.forEach($scope["formExpeditionDate"].$error.required, function (field) {
                    field.$setTouched();
                });

            } else {
                pr.specialBrands.expeditionDate_Save = 1;
            }
        }

    }]);