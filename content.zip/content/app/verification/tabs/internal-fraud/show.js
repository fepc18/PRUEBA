﻿app.controller("internalFraudShowController", ['$scope', '$rootScope','bueSources',
function ($scope, $rootScope,bueSources) {
        var vm = this;
        var pr = $scope.$parent.$parent;
        var formName = "formInternalFraud";
        vm.processState = 0;
        vm.processMessage = "";
        $scope.date = new Date();
        vm.validation = false;
        vm.observation = "";
        vm.verification = false;
        //$scope.switch = vm.verification;
        vm.visualitationLogin = false;
        vm.send = 0;
        vm.iFraud = {}
        //    idEvento: "22",
        //    catEvento: "2",
        //    Observacion: "",
        //    fechaEvento: $scope.date,     //Fecha correspondiente al dia en que se esta ingresando
        //    fecInicioEvento: $scope.date, //Fecha correspondiente al dia en que se esta ingresando
        //    fechaFinEvento: $scope.date,  //Fecha correspondiente al dia en que se esta ingresando 
        //    tipoProducto: 1,
        //    gerencia: 5,
        //    areaPresentaEvento: 41,
        //    idProceso: 94,
        //    idSistema: 1
        //}

        vm.sendIfraud = function () {
            vm.viewModal = true;
            console.log(vm.observation);
            console.log(vm.iFraud);
            vm.iFraud.Observacion = vm.observation;
            vm.send = 1;
            vm.json = JSON.stringify(vm.iFraud)
            vm.validation

        }
        vm.showLogin = function (state) {
            vm.processState = state;
        }
        


        /***************************************************/
        /*                                                 */
        /*  OBSERVADOR DE ASINCRONIA                       */
        /*                                                 */
        /***************************************************/
        //$rootScope.$watch('switch',
        //    function (nValue, oValue) {
        //        if (nValue != true) {
        //            console.log("Enviar servicio");
        //        } else {
        //            return false;
        //        }
        //    });
        vm.endDirective = function () {
            console.log("Enviar servicio");
            vm.iFraud.AI = 0;
            vm.iFraud.Amount = 0;
            vm.iFraud.DateDes = new Date();
            vm.iFraud.DateStart = new Date();
            vm.iFraud.DateEnd = new Date(); 
            vm.iFraud.Description =  vm.observation;
            vm.iFraud.IdArea = 196;
            vm.iFraud.IdAreaUser = 10;
            vm.iFraud.IdEvent = 98;
            vm.iFraud.IdProcess = 0;
            vm.iFraud.IdProduct = 5;
            vm.iFraud.IdSystem = 29;            
            vm.iFraud.IdUser = 9050;
            vm.iFraud.IdAreaUser = 0;
            debugger;
            vm.send = 1;
            vm.json = JSON.stringify(vm.iFraud);
            try {
                bueSources.createInternalFraudBue(vm.json).then(function (data_) {
              
                    if (data_.state) {
                        debugger;
                        vm.processMessage = "Bue creada con número:" + data_.info;
                        vm.processSuccess = true;
                        vm.showLogin(2);
                    
                    } else {
                        vm.processError = true;
                        vm.processMessage = "La Bue no puede ser creada:" + data_.data;
                        vm.showLogin(3);
                    }
                });
            }
            catch (err) {
                vm.processError = true;
                vm.processMessage = err;
                vm.showLogin(3);
            }
            
        }
    }]);