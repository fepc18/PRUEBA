﻿app.controller("infoBaseShowController", ['$scope', '$rootScope', 'tabVerificationSources', 'fileUpLoadSources', 'Post',
    function ($scope, $rootScope, tabVerificationSources, fileUpLoadSources, Post) {
        var vm = this;
        vm.ShowMessageUpload = false;
        vm.MessageUpload = "";
        vm.TypeMessageUpload = "";
        var pr = $scope.$parent.$parent;
        
        vm.searchTypes = [
            {
                id: 1,
                description: "San Andresitos"               
            },
            {
                id: 2,
                description: "Ciudades"                
            },
            {
                id: 3,
                description: "Cooperativas"
            },
            {
                id: 4,
                description: "Cupo por Salario"
            },
            {
                id: 5,
                description: "Empleados"
            },
            {
                id: 6,
                description: "Escalafon Docente"
            },
            {
                id: 7,
                description: "Iglesias"
            },
            {
                id: 8,
                description: "Links"
            },
            {
                id: 9,
                description: "ONG"
            },
            {
                id: 10,
                description: "Políticas de Crédito"
            },
            {
                id: 11,
                description: "Rangos Fuerzas Armadas"
            },
            {
                id: 12,
                description: "Tiendas"
            }
            ,
            {
                id: 13,
                description: "Transporte Público"
            }

        ];

        vm.resultCities = {};
        vm.resultSanAndresitos= {};
        vm.resultSearch = false;
        /*------------------------------------------------------------------*/
        vm.submit = function () {
            var option = vm.searchType;
            vm.sendForm = 1;
            vm.data = {};

            vm.data.Value = vm.searchText;
            vm.resultCitiesSearch = false;
            vm.resultSanAndresitosSearch = false;
            vm.resultCooperativesSearch = false;
            vm.result = false;
            var dataJson = JSON.stringify(vm.data);
            if (option == 1) {
                tabVerificationSources.getSanAndresitos(dataJson).then(function (data_) {

                    if (data_.status) {

                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultSanAndresitosSearch = true;
                        return true;
                    } else {
                        vm.resultSanAndresitosSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;
                return true;
            }
            else if (option == 2) {

                tabVerificationSources.getCities(dataJson).then(function (data_) {

                    if (data_.status) {
                        vm.resultCities = data_.data;
                        vm.warningLoadData = false;
                        vm.resultCitiesSearch = true;
                        return true;
                    } else {
                        vm.resultCitiesSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.resultCities_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.resultCities_Current = 1;
                vm.resultCities_TotalItems = vm.resultCities.length;
                vm.loading = false;

                return true;
            }
            else if (option == 3) {

                tabVerificationSources.getCooperatives(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultCooperativesSearch = true;
                        return true;
                    } else {
                        vm.resultCooperativesSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 4) {

                tabVerificationSources.getQuotas(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultQuotasSearch = true;
                        return true;
                    } else {
                        vm.resultQuotasSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 5) {

                tabVerificationSources.getEmployees(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultEmployeesSearch = true;
                        return true;
                    } else {
                        vm.resultEmployeesSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 6) {

                tabVerificationSources.getTeacherScales(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultTeacherScalesSearch = true;
                        return true;
                    } else {
                        vm.resultTeacherScalesSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 7) {

                tabVerificationSources.getChurch(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultChurchSearch = true;
                        return true;
                    } else {
                        vm.resultChurchSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 8) {
                tabVerificationSources.getLinks(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultLinksSearch = true;
                        return true;
                    } else {
                        vm.resultLinksSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 9) {
                tabVerificationSources.getONG(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultONGSearch = true;
                        return true;
                    } else {
                        vm.resultONGSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 10) {
                tabVerificationSources.getCreditPolicy(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultCreditPolicySearch = true;
                        return true;
                    } else {
                        vm.resultCreditPolicySearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 11) {
                tabVerificationSources.getArmedForcesRanks(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultArmedForcesRanksSearch = true;
                        return true;
                    } else {
                        vm.resultArmedForcesRanksSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 12) {
                tabVerificationSources.getStores(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultStoresSearch = true;
                        return true;
                    } else {
                        vm.resultStoresSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
            else if (option == 13) {
                tabVerificationSources.getPublicTransport(dataJson).then(function (data_) {
                    debugger;
                    if (data_.status) {
                        debugger;
                        vm.result = data_.data;
                        vm.warningLoadData = false;
                        vm.resultPublicTransportSearch = true;
                        return true;
                    } else {
                        vm.resultPublicTransportSearch = false;
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.result_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
                vm.result_Current = 1;
                vm.result_TotalItems = vm.result.length;
                vm.loading = false;

                return true;
            }
        };
     


        vm.uploadFile = function () {
            debugger;
                        /*loading.loadingAlert('Procesando Archivo, este proceso puede demorar', 'alert-warning');
            loading.cargabf();*/
            var file = $scope.archivoCargado;
            console.log('file is ');
            console.dir(file);

            var fd = new FormData();          
            fd.append("File", file);
           
            vm.ShowMessageUpload = false;
            vm.MessageUpload = "";
            vm.TypeMessageUpload = "";
            Post.create({}, fd).$promise.then(function (res) {
                debugger;
                if (res.state) {
                    vm.ShowMessageUpload = true;
                    vm.MessageUpload = "Archivo cargado correctamente.";
                    vm.TypeMessageUpload = "Info";
                }
                else {
                    vm.ShowMessageUpload = true;
                    vm.MessageUpload = res.Message;
                    vm.TypeMessageUpload = "Warning";
                }                

              
            }).catch(function (err) {
                self.newPostError = true;
                throw err;
            });
                        
        };





    }]);