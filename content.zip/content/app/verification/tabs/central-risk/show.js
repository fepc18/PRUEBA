﻿app.controller("centralRiskShowController", ['$scope', '$rootScope','centerRiskSource', '$filter', 'filterFilter',
    function ($scope, $rootScope, centerRiskSource, $filter, filterFilter) {
        var vm = this;
        var pr = $scope.$parent.$parent;
        
        vm.include = "/content/app_views/center-risk/on-demand.html";
        vm.includeResult = "";
        vm.includeResultData = {
            typeidentity: "1",
            identity: "80725070",
            lastName: "LINARES"
        };




















        ///*##### CONSULTA EN DB POR ID SOLICITUD #####*/
        ///*##### PENDIENTE!!!     (PARENT)       #####*/
        ///*###########################################*/
       

        //vm.date = new Date();
        //vm.typeidentity = "1";
        //vm.identity = "80725070";
        //vm.lastName = "";               
        //vm.calification = "ok";

        //vm.haveItems = function (array_) {
        //    if (array_) {
        //        return (filterFilter(array_).length > 0) ? true : false;
        //    }
        //    else
        //        return false;
        //};

        ///***************************************************/
        ///*                                                 */
        ///*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        ///*                                                 */
        ///***************************************************/
        //var base = function () {
        //    var local = {
        //    }
        //    return {                
        //        getLastQuery: function () {
        //            centerRiskSource.getLastQuery(vm.typeidentity, vm.identity).then(function (data_) {
        //                if (data_.status) {
        //                    vm.lastQuery = data_.data;
        //                    base.loadHeader(vm.lastQuery);
        //                    base.loadCalification(vm.lastQuery);
        //                    base.loadVigency(vm.lastQuery);
        //                    base.loadNoVigency(vm.lastQuery);
        //                    base.loadBalance(vm.lastQuery);
        //                    base.loadIndebtedness(vm.lastQuery);
        //                    base.loadReclaims(vm.lastQuery);
        //                    base.loadAlerts(vm.lastQuery);
        //                    base.loadQueryes(vm.lastQuery);
        //                    base.loadResume(vm.lastQuery);
        //                }
        //                else {
        //                    vm.errorDC = {
        //                        status: true,
        //                        message: "No continua por Políticas Internas.",
        //                    }
        //                }
        //            });
        //        },               
        //        loadHeader: function (lastQuery_) {
        //            centerRiskSource.getHeader(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.header = data_.data;
        //                }
        //            });
        //        },
        //        loadCalification: function (lastQuery_) {
        //            centerRiskSource.getCalification(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.calification = data_.data;                            
        //                }
        //            });
        //        },
        //        loadVigency: function (lastQuery_) {
        //            centerRiskSource.getVigency(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.vigency = data_.data;
        //                }
        //            });
        //        },
        //        loadNoVigency: function (lastQuery_) {
        //            centerRiskSource.getNoVigency(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.novigency = data_.data;
        //                }
        //            });
        //        },
        //        loadBalance: function (lastQuery_) {
        //            centerRiskSource.getBalance(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.balance = data_.data;
        //                }
        //            });
        //        },
        //        loadIndebtedness: function (lastQuery_) {
        //            centerRiskSource.getIndebtedness(lastQuery_).then(function (data_) {

        //                if (data_.status) {
        //                    vm.indebtedness = data_.data;
        //                }
        //            });
        //        },
        //        loadReclaims: function (lastQuery_) {
        //            centerRiskSource.getReclaims(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.reclaims = data_.data;
        //                }
        //            });
        //        },
        //        loadAlerts: function (lastQuery_) {
        //            centerRiskSource.getAlerts(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.alerts = data_.data;
        //                }
        //            });
        //        },
        //        loadQueryes: function (lastQuery_) {
        //            centerRiskSource.getQueryes(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.queryes = data_.data;
        //                }
        //            });
        //        },
        //        loadResume: function (lastQuery_) {
        //            centerRiskSource.getResume(lastQuery_).then(function (data_) {
        //                if (data_.status) {
        //                    vm.resume = {};
        //                    vm.resume.codeudor = $filter("filter")(data_.data, { group: "Codeudor" });
        //                    vm.resume.titular = $filter("filter")(data_.data, { group: "Titular" });
        //                    vm.resume.total = $filter("filter")(data_.data, { group: "Total" });
        //                }
        //            });
        //        },
                
        //        init: function () {                   
        //            base.getLastQuery();
        //        }
        //    }
        //}();
        //base.init();

    }]);