﻿app.controller("consultFraudShowController", ['$scope', '$rootScope', 'bueSources',
    function ($scope, $rootScope, bueSources) {
        var vm = this;
        var pr = $scope.$parent.$parent;
        var formName = "formConsultFraud";

        vm.sendForm = 0;
        vm.loading = false;
        vm.rev_searchBy = "";
        vm.rev_searchText = "";
        vm.documentTypes = [];
        vm.documentTypeBue = 0;
        vm.regex = {};
        vm.data = {};

        vm.submit = function () {
            if ($scope[formName].$invalid) {
                vm.sendForm = -1;
                return false;
            } else {
                vm.sendForm = 1;

                switch (vm.rev_searchBy) {
                    // Caso 1 Busqueda por Identificacion
                    case '1':
                        {
                            vm.data.Type = 1;
                            vm.data.DocumentType = vm.documentTypeBue;
                            vm.data.Document = vm.rev_searchText;
                        }
                        break;
                    case '2':
                        {
                            vm.data.Type = 2;
                            vm.data.Account = vm.rev_searchText;
                        }
                        break;
                    case '3':
                        {
                            vm.data.Type = 3;
                            vm.data.Request = vm.rev_searchText;
                        }
                        break;
                    case '4':
                        {
                            vm.data.Type = 4;
                            vm.data.Phone = vm.rev_searchText;
                        }
                        break;
                }
                vm.warningLoadData = false;
                vm.loading = true;
                var dataJson = JSON.stringify(vm.data);

                bueSources.getMasterBue(dataJson).then(function (data_) {
                    if (data_.status) {
                        vm.listBue = data_.data;
                        vm.warningLoadData = false;
                        return true;
                    } else {
                        vm.warningLoadData = true;
                        vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                    }
                    vm.loading = false;
                });
                vm.loading = false;
                return true;
            }
        }

        vm.showDetailBue = function (document, flag) {
            if (!flag) {
                vm.loadingDetail = true;
                vm.warningLoadDataDetail = false;
                //var documentString = JSON.stringify(document);
                bueSources.getDetailBue(document).then(function (dataDetail) {
                    if (dataDetail.status) {
                        vm.listDetailBue = dataDetail.data;
                        return true;
                    } else {
                        vm.warningLoadDataDetail = true;
                        vm.warningTextDetail = "No es posible consultar el detalle para este registro";
                    }
                    vm.loadingDetail = false;
                });
                vm.loadingDetail = false;
                return true;
            }
        }

        vm.assignRegex = function () {
            if (vm.rev_searchBy == '1' && vm.documentTypeBue == '3'){
                vm.regex = {
                    RegExp: $rootScope.regex.basic.value,
                    ExpDesc: $rootScope.regex.basic.description
                };
            } else if (vm.rev_searchBy == '4') {
                vm.regex = {
                    RegExp: $rootScope.regex.phoneNumber.value,
                    ExpDesc: $rootScope.regex.phoneNumber.description
                };
            } else {
                vm.regex = {
                    RegExp: $rootScope.regex.numeric.value,
                    ExpDesc: $rootScope.regex.numeric.description
                };
            }
        }




        /***************************************************/
        /*  PROPIEDADES Y METODOS LOCALES DEL CONTROLADOR  */
        /***************************************************/

        var base = function () {
            var local = {

            }
            return {
                getDocumentTypes: function () {
                    bueSources.getDocumentTypes().then(function (data_) {
                        if (data_.status) {
                            vm.documentTypes = data_.data;
                            return true;
                        } else {
                            console.log("No se han cargado los tipos de documento");
                        }
                    })
                },


                init: function () {
                    base.getDocumentTypes();
                }
            }
        }();
        base.init();
    }]);