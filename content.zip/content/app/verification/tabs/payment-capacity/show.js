﻿app.controller("paymentCapacityShowController", ['$scope', '$rootScope', '$filter','tabVerificationSources',
function ($scope, $rootScope, $filter,tabVerificationSources ) {
        var vm = this;
        var pr = $scope.$parent.$parent;
        vm.Resquest = {};
        vm.Resquest.IdRequisition = 0;
        vm.Resquest.Section = 0;
        vm.Resquest.DocumentType = 0;
        vm.Resquest.Document = '';
    
        vm.responseDataReportedRequisition = {}; // Se almacena para posterior almacenamiento en Log
    
        vm.fechasolicitud = "";
        vm.tipoDocumento = "";
        vm.documentNumber = "";
        vm.office = "";
        vm.birthdate = "";
        vm.gender = "";
        vm.civilStatus = "";
        vm.department = "";
        vm.city = "";
        vm.stratum = "";
        vm.occupation = "";
        vm.activityConjugal = "";

        vm.timeActivity = "";
        vm.timeActivityPrevious = "";
        vm.typeContract = "";

        vm.CentralClassification="Continua";
        vm.CausalReject="Mora Vigente (M 30)";

        //*****************************************//
        // VARIABLES DE ParametersPaymentCapacity //
        //***************************************//

        vm.minimumSalary = 0;
        vm.listCapacityFactor = {};
        vm.listIncomeRange = {};
        vm.listOtherExpenses = {};
        vm.listPersonalExpenses = {};
        vm.listRangeScore = {};


        vm.revenueMainActivityReported = 0;
        vm.revenueMainActivityVerified = 0;
        vm.revenueMainActivityDefinitive = 0;
        
        vm.otherIncomeReported = 0;
        vm.otherIncomeVerified = 0;
        vm.otherIncomeDefinitive = 0;


        vm.totalIncomeReported = 0;
        vm.totalIncomeVerified = 0;
        vm.totalIncomeDefinitive = 0;


        
        vm.mainActivityCostsReported = 0;
        vm.mainActivityCostsVerified = 0;
        vm.mainActivityCostsDefinitive = 0;
        
        vm.othersExpensesReported = 0;
        vm.othersExpensesVerified = 0;
        vm.othersExpensesDefinitive = 0;

        vm.totalExpensesReported = 0;
        vm.totalExpensesVerified = 0;
        vm.totalExpensesDefinitive = 0;

        vm.differenceIncomeEgress = 0;

        
        vm.paymentCapacity = 0;
        
        //*****************************************//
        // VARIABLES DE LOG PaymentCapacity      //
        //***************************************//

        vm.LogPaymentCapacity = {}
        vm.LogPaymentCapacity.RequisitionDate="";
        vm.LogPaymentCapacity.RequisitionId="";
        vm.LogPaymentCapacity.DocumentType="";
        vm.LogPaymentCapacity.DocumentNumber="";
        vm.LogPaymentCapacity.Office="";
        vm.LogPaymentCapacity.Birthdate="";
        vm.LogPaymentCapacity.Gender="";
        vm.LogPaymentCapacity.CivilStatus="";
        vm.LogPaymentCapacity.City="";
        vm.LogPaymentCapacity.Department="";
        vm.LogPaymentCapacity.TimeActivity="";
        vm.LogPaymentCapacity.Occupation="";
        vm.LogPaymentCapacity.TimeActivityPrevious="";
        vm.LogPaymentCapacity.TypeContract="";
        vm.LogPaymentCapacity.ActivityConjugal="";
        vm.LogPaymentCapacity.CentralClassification="";
        vm.LogPaymentCapacity.CausalReject="";
        vm.LogPaymentCapacity.ScoreGrant="";
        vm.LogPaymentCapacity.RevenueMainActivityReported="";
        vm.LogPaymentCapacity.RevenueMainActivityVerified="";
        vm.LogPaymentCapacity.RevenueMainActivityDefinitive="";
        vm.LogPaymentCapacity.OtherIncomeReported="";
        vm.LogPaymentCapacity.OtherIncomeVerified="";
        vm.LogPaymentCapacity.OtherIncomeDefinitive="";
        vm.LogPaymentCapacity.ExpensesActivityMainReported="";
        vm.LogPaymentCapacity.ExpensesActivityMainVerified="";
        vm.LogPaymentCapacity.ExpensesActivityMainDefinitive="";
        vm.LogPaymentCapacity.OtherEgressReported="";
        vm.LogPaymentCapacity.OtherEgressVerified="";
        vm.LogPaymentCapacity.OtherEgressDefinitive="";
        vm.LogPaymentCapacity.Contingent="";
        vm.LogPaymentCapacity.CapacityPayment="";
        vm.LogPaymentCapacity.NSMMLV="";
        vm.LogPaymentCapacity.PersonalSpendingPercentage="";
        vm.LogPaymentCapacity.PersonalExpenditure="";
        vm.LogPaymentCapacity.IncomeRange="";
        vm.LogPaymentCapacity.RangeScore="";
        vm.LogPaymentCapacity.VarFactorCapacity="";
        vm.LogPaymentCapacity.FactorCapacity="";
        



        vm.ParametersPaymentCapacity = function () {
            tabVerificationSources.getParametersPaymentCapacity().then(function (data_) {

                if (data_.status) {
                    debugger;
                    vm.resultMessages = data_.data;
                    vm.minimumSalary = data_.data.minimumSalary;
                    vm.listCapacityFactor = data_.data.listCapacityFactor;
                    vm.listIncomeRange = data_.data.listIncomeRange;
                    vm.listOtherExpenses = data_.data.listOtherExpenses;
                    vm.listPersonalExpenses = data_.data.listPersonalExpenses;
                    vm.listRangeScore = data_.data.listRangeScore;


                    vm.warningLoadData = false;
                    vm.resultSearch = true;
                    vm.reload();
                    return true;
                } else {
                    vm.resultSearch = false;
                    vm.warningLoadData = true;
                    vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                }
                vm.loading = false;
            });        
            return true;
        }
    
        vm.calcPaymentCapacity = function () {
            debugger;

            //INGRESOS ACTIVIDAD PRINCIPAL

            if (vm.revenueMainActivityVerified > 0)
                vm.revenueMainActivityDefinitive = vm.revenueMainActivityVerified;
            else
                vm.revenueMainActivityDefinitive = vm.revenueMainActivityReported;

            //OTROS INGRESOS

            if (vm.revenueMainActivityVerified == 0)
                vm.otherIncomeDefinitive = vm.otherIncomeReported;
            else
                vm.otherIncomeDefinitive = vm.otherIncomeVerified;

            vm.totalIncomeReported = parseFloat(vm.revenueMainActivityReported) + parseFloat(vm.otherIncomeReported);
            vm.totalIncomeVerified = parseFloat(vm.revenueMainActivityVerified) + parseFloat(vm.otherIncomeVerified);
            vm.totalIncomeDefinitive = parseFloat(vm.revenueMainActivityDefinitive) + parseFloat(vm.otherIncomeDefinitive);


            //GASTOS ACTIVIDAD PRINCIPAL


            vm.mainActivityCostsDefinitive = Math.round(porcentajeGP * DirectNetIncome);
            if (vm.mainActivityCostsDefinitive > vm.mainActivityCostsReported) {
                if (vm.mainActivityCostsDefinitive > vm.mainActivityCostsVerified) { // el calculado                   
                }
                else {
                    vm.mainActivityCostsDefinitive = vm.mainActivityCostsVerified;  // el verificado                  
                }
            }
            else {
                if (vm.mainActivityCostsReported > vm.mainActivityCostsVerified) {
                    vm.mainActivityCostsDefinitive = vm.mainActivityCostsReported;// el reportado
                }
                else {
                    vm.mainActivityCostsDefinitive = vm.mainActivityCostsVerified;//el verificado                    
                }
            }

            
            var DirectNetIncome = parseFloat(vm.totalIncomeDefinitive) - parseFloat(vm.mainActivityCostsDefinitive); //Ingresos  gastos (actividad Principal)
            var nSMMLV;
            var porcentajeGP = 0;
            if (vm.minimumSalary > 0)
                nSMMLV = DirectNetIncome / vm.minimumSalary;
            else
                nSMMLV = 0;

            debugger;
            for (var i in vm.listPersonalExpenses) {
                var personalExpenses = vm.listPersonalExpenses[i];
                if (nSMMLV >= personalExpenses.lowerRank && nSMMLV <= personalExpenses.upperRange) {
                    porcentajeGP = parseFloat(personalExpenses.percentage);
                    break;
                }

            }
            porcentajeGP = porcentajeGP / 100;
            vm.othersExpensesDefinitive = Math.round(porcentajeGP * DirectNetIncome)

            //OTROS GASTOS
            if (vm.othersExpensesDefinitive > vm.othersExpensesVerified) {
                if (vm.othersExpensesDefinitive > vm.othersExpensesReported) {

                }
                else
                    vm.othersExpensesDefinitive = vm.othersExpensesReported;
            }
            else {
                if (vm.othersExpensesReported > vm.othersExpensesVerified) {
                    vm.othersExpensesDefinitive = vm.othersExpensesReported;
                }
                else {
                    vm.othersExpensesDefinitive = vm.othersExpensesVerified;
                }
            }
            
            vm.totalExpensesReported = parseFloat(vm.mainActivityCostsReported) + parseFloat(vm.othersExpensesReported);
            vm.totalExpensesVerified = parseFloat(vm.mainActivityCostsVerified) + parseFloat(vm.othersExpensesVerified);
            vm.totalExpensesDefinitive = parseFloat(vm.mainActivityCostsDefinitive) + parseFloat(vm.othersExpensesDefinitive);

            var rangoIngreso = 0;

            for (var i in vm.listIncomeRange) {
                var incomeRange = vm.listIncomeRange[i];
                if (nSMMLV >= incomeRange.limit1 && nSMMLV <= incomeRange.limit2) {
                    rangoIngreso = parseFloat(incomeRange.rangeFactor);
                    break;
                }

            }

           var rangoScore = 0;

           for (var i in vm.listRangeScore) {
                var rangeScore = vm.listRangeScore[i];
                if (vm.scoreGranting >= rangeScore.limit1 && vm.scoreGranting <= rangeScore.limit2) {
                    rangoScore = parseFloat(rangeScore.rangeFactor);
                    break;
                }

            }

            var varFactorCapacidad = rangoScore.toString() + rangoIngreso.toString();
            var factorCapacidad = 0;

            for (var i in vm.listCapacityFactor) {
                var capacityFactor = vm.listCapacityFactor[i];
                if (varFactorCapacidad == capacityFactor.variable) {
                    capacityFactor = parseFloat(capacityFactor.factor);
                    break;
                }

            }
            vm.differenceIncomeEgress = parseFloat(vm.totalIncomeDefinitive) - parseFloat(vm.totalExpensesDefinitive)
            //      vm.paymentCapacity = (vm.differenceIncomeEgress - parseFloat(vm.contingent)) * capacityFactor;
            vm.paymentCapacity = (vm.differenceIncomeEgress) * capacityFactor;

            //*****************************//
            // ALMACENAMIENTO PARA LOG     //
            //*****************************//
            vm.LogPaymentCapacity.RevenueMainActivityReported=vm.revenueMainActivityReported;
            vm.LogPaymentCapacity.RevenueMainActivityVerified= vm.revenueMainActivityVerified;
            vm.LogPaymentCapacity.RevenueMainActivityDefinitive=vm.revenueMainActivityDefinitive;
            vm.LogPaymentCapacity.OtherIncomeReported=vm.otherIncomeReported;
            vm.LogPaymentCapacity.OtherIncomeVerified=vm.otherIncomeVerified;
            vm.LogPaymentCapacity.OtherIncomeDefinitive=vm.otherIncomeDefinitive;
            vm.LogPaymentCapacity.ExpensesActivityMainReported=vm.mainActivityCostsReported;
            vm.LogPaymentCapacity.ExpensesActivityMainVerified=vm.mainActivityCostsVerified;
            vm.LogPaymentCapacity.ExpensesActivityMainDefinitive=vm.mainActivityCostsDefinitive;
            vm.LogPaymentCapacity.OtherEgressReported=vm.othersExpensesReported;
           vm.LogPaymentCapacity.OtherEgressVerified=vm.othersExpensesVerified;
           vm.LogPaymentCapacity.OtherEgressDefinitive=vm.othersExpensesDefinitive;

           
           vm.LogPaymentCapacity.CapacityPayment=vm.paymentCapacity;
           vm.LogPaymentCapacity.NSMMLV=nSMMLV;
           vm.LogPaymentCapacity.PersonalSpendingPercentage=porcentajeGP;
           vm.LogPaymentCapacity.PersonalExpenditure=vm.othersExpensesDefinitive;
           vm.LogPaymentCapacity.IncomeRange=rangoIngreso;
           vm.LogPaymentCapacity.RangeScore=rangoScore;
           vm.LogPaymentCapacity.VarFactorCapacity=varFactorCapacidadM
           vm.LogPaymentCapacity.FactorCapacity=capacityFactor;

        }

        vm.reload = function () {
            vm.loading = true;
              vm.Resquest.IdRequisition = "4";
              vm.Resquest.Section = "1";
              vm.Resquest.DocumentType = "1";
              vm.Resquest.Document = "52801070";
              debugger;
              var dataJson = JSON.stringify(vm.Resquest);
            
            tabVerificationSources.getDataReportedRequisition(dataJson).then(function (data_) {

                if (data_.status) {
                    
                    vm.responseDataReportedRequisition = data_.data;
                    vm.data = {}
                    vm.data.income = data_.data.incomeList;
                    vm.data.expend = data_.data.expendList;

                    vm.fechasolicitud = data_.data.requisitionDate;
                    vm.tipoDocumento = data_.data.documentType;
                    vm.documentNumber = data_.data.documentNumber;
                    vm.office = data_.data.office;
                    vm.birthdate = data_.data.birthdate;
                    vm.gender = data_.data.gender;
                    vm.civilStatus = data_.data.civilStatus;
                    vm.department = data_.data.department;
                    vm.city = data_.data.city;
                   
                    vm.occupation = data_.data.occupation;
                    vm.activityConjugal = data_.data.activityConjugal;
                    vm.contingent = data_.data.contingent;

                    vm.timeActivity = data_.data.timeActivity;
                    vm.timeActivityPrevious = data_.data.timeActivityPrevious;
                    vm.typeContract = data_.data.typeContract;



                    /*REPORTADOS*/
                    vm.mainActivityCostsReported = parseFloat(data_.data.expensesActivityMain);                    
                    vm.othersExpensesReported = parseFloat(data_.data.otherEgress);
                    vm.totalExpensesReported = parseFloat(data_.data.expensesActivityMain) + parseFloat(data_.data.otherEgress);                    

                    vm.revenueMainActivityReported = parseFloat(data_.data.revenueMainActivity);
                    vm.otherIncomeReported = parseFloat(data_.data.otherIncome);
                    vm.totalIncomeReported =parseFloat( data_.data.revenueMainActivity) + parseFloat(data_.data.otherIncome);


                    //************************//
                    //  INICIO DATOS PARA LOG //
                    //************************//
                    vm.LogPaymentCapacity.RequisitionDate=vm.fechasolicitud;
                    vm.LogPaymentCapacity.RequisitionId=vm.Resquest.IdRequisition;
                    vm.LogPaymentCapacity.DocumentType=data_.data.idDocumentType;
                    vm.LogPaymentCapacity.DocumentNumber=data_.data.documentNumber;
                    vm.LogPaymentCapacity.Office=data_.data.idOffice;
                    vm.LogPaymentCapacity.Birthdate=data_.data.birthdate;
                    vm.LogPaymentCapacity.Gender=data_.data.idGender;
                    vm.LogPaymentCapacity.CivilStatus=data_.data.idCivilStatus;
                    vm.LogPaymentCapacity.City=data_.data.idCity;
                    vm.LogPaymentCapacity.Department=data_.data.idDepartment;
                    vm.LogPaymentCapacity.TimeActivity=data_.data.timeActivity;
                    vm.LogPaymentCapacity.Occupation=data_.data.idOccupation;
                    vm.LogPaymentCapacity.TimeActivityPrevious=data_.data.timeActivityPrevious;
                    vm.LogPaymentCapacity.TypeContract=data_.data.idTypeContract;
                    vm.LogPaymentCapacity.ActivityConjugal=data_.data.idActivityConjugal;
                    vm.LogPaymentCapacity.Contingent= data_.data.contingent;
                    //************************//
                    // FIN DATOS PARA LOG     //
                    //************************//




                    vm.warningLoadData = false;
                    vm.resultSearch = true;                   
                    vm.calcPaymentCapacity();
                    return true;
                } else {
                    vm.resultSearch = false;
                    vm.warningLoadData = true;
                    vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                }
                vm.loading = false;
            });
            vm.resultMessages_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
            vm.resultMessages_Current = 1;
            vm.resultMessages_TotalItems = vm.resultMessages.length;
            
          

            vm.loading = false;
            return true;

        }
        var base = function () {
            return {
                init: function () {
                    
                    vm.ParametersPaymentCapacity();
                   // vm.reload();
                   
                }
            }
        }();

        base.init();
     


        vm.savePaymentCapacity = function () {

            debugger;
            vm.LogPaymentCapacity.CentralClassification =vm.CentralClassification;
            vm.LogPaymentCapacity.CausalReject=vm.CausalReject;
            vm.LogPaymentCapacity.ScoreGrant=vm.scoreGranting;
           

            var dataJson = JSON.stringify(vm.LogPaymentCapacity);
            tabVerificationSources.savePaymentCapacity(dataJson).then(function (data_) {

                if (data_.status) {
                    debugger;                  

                    vm.warningLoadData = false;
                    vm.resultSearch = true;
                    
                    return true;
                } else {
                    vm.resultSearch = false;
                    vm.warningLoadData = true;
                    vm.warningText = "No fue posible guardar la capacidad de pago. " + "Mensaje de Error: " + data_.data;
                }
                vm.loading = false;
            });
            return true;
        }
      

    }]);