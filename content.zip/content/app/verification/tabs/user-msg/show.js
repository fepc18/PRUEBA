﻿app.controller("userMsgShowController", ['$scope', '$rootScope', 'tabVerificationSources',
    function ($scope, $rootScope, tabVerificationSources) {
        var vm = this;
        var pr = $scope.$parent.$parent;
        var formName = "formUserMsg";
        vm.data = {};

        vm.resultMessages = [];
        vm.resultSearch = false;
        vm.submit = function () {
         
            /*   if ($scope[formName].$invalid) {
                   vm.sendForm = -1;
                   return false;
               } else {*/
            vm.sendForm = 1;          

            vm.data.Attribute = vm.searchBy;
            vm.data.Value = vm.searchText;

            var dataJson = JSON.stringify(vm.data);
           
            tabVerificationSources.getUserMessages(dataJson).then(function (data_) {
              
                if (data_.status) {
                    vm.resultMessages = data_.data;
                    vm.warningLoadData = false;
                    vm.resultSearch = true;
                    return true;
                } else {
                    vm.resultSearch = false;
                    vm.warningLoadData = true;
                    vm.warningText = "No fue posible realizar la consulta. " + "Mensaje de Error: " + data_.data;
                }
                vm.loading = false;
            });
            vm.resultMessages_ItemsPage = $rootScope.paginationTables.maxItemsDefault;
            vm.resultMessages_Current = 1;
            vm.resultMessages_TotalItems = vm.resultMessages.length;
            vm.loading = false;

            return true;




            
        }
        // }

        /*------------------------------------------------------------------*/

        /*  function __tmp_llenar() {
              for (var i = 0; i < 35; ++i) {
                  vm.resultMessages.push({
                      id: 1234 + i,
                      user: "Oscar Perez",
                      date: "03/02/2017 03:53:0" + i + " p.m.",
                      observation: "Tabla de prueba para mensajes de ususarios"
                  });
              }
          }       
          */
    }]);