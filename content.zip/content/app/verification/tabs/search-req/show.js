﻿app.controller("searchReqShowController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.include = "/content/app_views/requisition/consult/consultView.html";
        vm.includeResult = "";
        vm.includeResultData = {};

    }]);