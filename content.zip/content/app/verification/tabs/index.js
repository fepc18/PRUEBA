﻿app.controller("fixedTabsVerificationController", ['$scope', '$rootScope', 'routeInclude',
function ($scope, $rootScope, routeInclude) {
    var vm = this;
    
    vm.internalFraudPath = routeInclude.verification.tabs.internalFraud;
    vm.searchReqPath = routeInclude.verification.tabs.searchReq;
    vm.userMsgPath = routeInclude.verification.tabs.userMsg;
    vm.infoBasePath = routeInclude.verification.tabs.infoBase;
    vm.consultFraudPath = routeInclude.verification.tabs.consultFraud;
    vm.paymentCapacityPath = routeInclude.verification.tabs.paymentCapacity;
    vm.centralRiskPath = routeInclude.verification.tabs.centralRisk;

    //vm.clickCollapse = function () {

    //    vm.collapse = vm.collapse ? false : true;
        
    //    var infoClientIni = $("#verification_body").height();
    //    var infoClientFin = 0;

    //    var secondPanelIni = $(".include-submenu").css("margin-top").replace("px", "");
    //    var heightPad = 0
    //    var total = 0

    //    setTimeout(heightP, 10);

    //    function heightP() {
    //        infoClientFin = $("#verification_body").height();
    //        heightPad = parseInt(infoClientFin) - parseInt(infoClientIni);

    //        if (vm.infoclient) {
    //            var op = $(".include-submenu").css("margin-top", (parseInt(secondPanelIni) + parseInt(heightPad)).toString() + "px");
    //            total = parseInt(secondPanelIni) + parseInt(heightPad);
    //        } else {
    //            var op = $(".include-submenu").css("margin-top", (parseInt(secondPanelIni) + parseInt(heightPad)).toString() + "px");
    //            total = parseInt(secondPanelIni) + parseInt(heightPad);
    //        }

    //        console.log("Panel basico inicio: " + infoClientIni, "Panel basico fin: " + infoClientFin);
    //        console.log("Container inicio: " + secondPanelIni, "Desplazamiento: " + heightPad);
    //        console.log("Posicion container: " + total);
    //    }
    //}
    
}]);
