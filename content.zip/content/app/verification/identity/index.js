﻿app.controller("identityVerificationController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.data = [
            {
                id: 0,
                fallenPage:"Veedurias",
                crossInfo: [
                    "¿Celular o mail cruza con veedurias?",
                    "¿Cruza direccion o telefono fijo con veedurias?"
                ]
            },
            {
                id: 1,
                fallenPage: "Google Identidad",
                crossInfo: [
                    "Celular cruza con Google",
                    "Imagen cruza con Google",
                    "Firma cruza con contratos google"
                ]
            },
            {
                id: 2,
                fallenPage: "Reconocer",
                crossInfo: [
                    "Reconocer"
                ]
            },
            {
                id: 3,
                fallenPage: "Otras paginas",
                crossInfo: [
                    "Imagen cruza con la base"
                ]
            },
            {
                id: 4,
                fallenPage: "Ponal",
                crossInfo: [
                    "¿Tiene registro en ponal?",
                    "¿Es consistente registro en ponal?"
                ]
            },
            {
                id: 5,
                fallenPage: "Registraduria",
                crossInfo: [
                    "¿Tiene registro en registraduria?",
                    "¿Es consistente registro en registraduria?"
                ]
            }
        ]

    }]);