﻿app.controller("activityVerificationController", ['$scope', '$rootScope', 'toolsForm',
    function ($scope, $rootScope, toolsForm) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.dateOptions = toolsForm.dateOptions;
        vm.optType = "7";
        vm.optStage = "1";

        vm.validation = {
            //negation: function (type, stage) {
            //    if (vm.optType == type || vm.optStage == stage) {
            //        return false;
            //    }
            //},
            and: function (type, stage) {
                if (vm.optType == type && vm.optStage == stage) {
                    return true;
                }
            }
        }


        /*TEMPORAL*/
        vm.optStages = [
            {
                id: 1,
                description: "VA - positivo"
            },
            {
                id: 2,
                description: "VA - negativo"
            },
            {
                id: 3,
                description: "VA - sin información"
            },
        ];
        vm.optTypes = [
            {
                id: 1,
                description: "Empleado Privado/Publico"
            },
            {
                id: 2,
                description: "Pensionado"
            },
            {
                id: 3,
                description: "Independiente - Persona Natural"
            },
            {
                id: 4,
                description: "Independiente - Persona Juridica"
            },
            {
                id: 5,
                description: "Prestador"
            },
            {
                id: 6,
                description: "Militar Policia"
            },
            {
                id: 7,
                description: "Transportador"
            }
        ];

    }]);