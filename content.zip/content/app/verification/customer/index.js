﻿app.controller("customerVerificationController", ['$scope', '$rootScope',
    function ($scope, $rootScope) {
        var vm = this;
        var pr = $scope.$parent.$parent;

        vm.actEcoType == 0;
        vm.spouse = false;
        vm.spouseVal = 0;
        vm.VerOpt = "2";

        vm.referenceContactList = [
            {
                id: 1,
                description: "OK Contacto"
            },
            {
                id: 2,
                description: "No contesta"
            },
            {
                id: 3,
                description: "Contesta no da informacion"
            },
            {
                id: 4,
                description: "Telefono errado"
            },
            {
                id: 5,
                description: "Telefono no pertenece"
            },
            {
                id: 6,
                description: "Telefono fuera de servicio"
            },
            {
                id: 7,
                description: "Telefono apagado"
            },
            {
                id: 8,
                description: "Por instrucción administrativa"
            }
        ];
        vm.actEcoTypes = [
            {
                id: 1,
                description: "Empleado Publico Privado"
            },
            {
                id: 2,
                description: "Militar Policia"
            },
            {
                id: 3,
                description: "Cliente Independiente"
            },
            {
                id: 4,
                description: "Prestador"
            },
            {
                id: 5,
                description: "Transportador"
            },
            {
                id: 6,
                description: "Rentista"
            },
            {
                id: 7,
                description: "Pensionado"
            },
            {
                id: 8,
                description: "Ama de Casa"
            }
        ];

        vm.filterForms = {
            match: function (actEco, spouse) {
                if (vm.actEcoType == actEco && vm.spouseVal == spouse) {
                    return true;
                    debugger;
                }
            }
        }
    }]);