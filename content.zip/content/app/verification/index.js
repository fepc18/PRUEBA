﻿app.controller("verificationController", ['$scope', '$rootScope', 'routeInclude', '$window', '$interval', '$filter', 'dynamicFormFactory',
function ($scope, $rootScope, routeInclude, $window, $interval, $filter, dynamicFormFactory) {
    var vm = this;
    var valueContrac = 260;
    var contrac = false;
    var timer;

    vm.expanded = false;
    vm.full = false;

    vm.infoClientPath = routeInclude.verification.infoClient;
    vm.fixedTabsPath = routeInclude.verification.tabs.index;

    vm.fullScreen = function () {
        vm.full = vm.full ? false : true;
        if (vm.full) {
            var HeightWrapper = $(window).height();
            $(".section-fixed-tabs").css("height", (parseInt(HeightWrapper) - 60).toString() + "px");
            $(".section-fixed-tabs .fixed-content").css("height", (parseInt(HeightWrapper) - 115).toString() + "px");
        } else {
            $(".section-fixed-tabs").css("height", "auto");
            $(".section-fixed-tabs .fixed-content").css("height", "260px");
        }
    }
    vm.dynPanels = {
        expand: function () {
            vm.expanded = vm.expanded ? false : true;

            var sc = $window.scrollY;
            var tmp = sc;

            if (vm.expanded) {
                sc = sc - valueContrac;

                if (sc < valueContrac) {
                    sc = tmp;
                    contrac = true;
                }
            } else {
                sc = sc + valueContrac;
            }

            window.scrollTo(0, sc);
        }
    }

    vm.finallyModule = function () {        
        $rootScope.timerVerify.stop(true);
        $rootScope.navigate.go("/verification");
    }
    
    vm.stateRequisition = vm.stateRequisition || 0;
    vm.listResult = [];
    vm.validState = 0;
        
    vm.returnVerification = function () {        
        $rootScope.timerVerify.state = $rootScope.timerVerify.states.STOPPED;
        $rootScope.navigate.go("/verification/special-brands");
    }
    vm.authenticate = function () {
        var existRejected = base.validateRejected();
        var existPending = base.validatePending();
                        
        vm.stateRequisition = existPending ? (existRejected ? -1 : 0) : (existRejected ? -1 : 1);
        vm.validState = 1;
    }
    
    vm.next = function () {
        console.log("click mensaje finalizacion solicitud: estado");
        base.clearVerifySections();

        $rootScope.timerVerify.clear();
        $rootScope.navigate.go("/");
    }

    var base = function () {

        return {
            clearVerifySections: function(){
                var items = $rootScope.configuration.verticalmenu[2].submenu;

                angular.forEach(items, function (item, index) {                  
                    item.semaphoreStatus = $rootScope.configuration.stateVerify.INCOMPLETE.id;
                });
            },
            validateListResult: function () {
                var items = $rootScope.configuration.verticalmenu[2].submenu;

                angular.forEach(items, function (item, index) {
                    var state = item.semaphoreStatus;

                    vm.listResult.push({
                        name: item.text,
                        status: parseInt(item.semaphoreStatus)
                    });
                });
            },
            validateRejected: function () {
                var items = $rootScope.configuration.verticalmenu[2].submenu;
                var rejectedCount = 0;

                angular.forEach(items, function (item, index) {
                    var state = item.semaphoreStatus;

                    if (state == $rootScope.configuration.stateVerify.REJECTED.id) {
                        rejectedCount += 1;
                    }
                });

                return rejectedCount == 0 ? false: true;
            },
            validatePending: function () {
                var items = $rootScope.configuration.verticalmenu[2].submenu;
                var pendingCount = 0;

                angular.forEach(items, function (item, index) {
                    var state = item.semaphoreStatus;

                    if (state == $rootScope.configuration.stateVerify.PENDING_OFFICE.id || state == $rootScope.configuration.stateVerify.PENDING_TRANSIT.id) {
                        pendingCount += 1;
                    }
                });

                return pendingCount == 0 ? false : true;
            },           
            validateContinue: function () {
                var items = $rootScope.configuration.verticalmenu[2].submenu;
                var incompleteCount = 0;

                angular.forEach(items, function (item, index) {
                    var state = item.semaphoreStatus;

                    if (state == $rootScope.configuration.stateVerify.INCOMPLETE.id) {
                        incompleteCount += 1;
                    }
                });

                vm.validState = incompleteCount == 0 ? 0 : -1;
            },
            verifyAuthenticate: function () {
                var existRejected = base.validateRejected();

                if (!existRejected && vm.validState != -1) vm.validState = 1;
            },
            init: function () {
                angular.element($window).bind("scroll", function () {
                    if (contrac) {
                        window.scrollTo(0, $window.scrollY - valueContrac);
                        contrac = false;
                    }
                });
                if ($rootScope.timerVerify.state == $rootScope.timerVerify.states.STOPPED
                    || $rootScope.timerVerify.state == $rootScope.timerVerify.states.DISABLED) {

                    $rootScope.timerVerify.start();
                }

                base.validateListResult();
                base.validateContinue();
                base.verifyAuthenticate();
                if (vm.validState == 1) {
                    vm.authenticate();
                }
            }
        }
    }();
    base.init();
    
}]);
