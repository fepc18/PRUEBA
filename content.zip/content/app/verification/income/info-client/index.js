﻿app.controller("infoClientVerificationController", ['$scope', '$rootScope', 'routeInclude',
function ($scope, $rootScope, routeInclude) {
    var vm = this;

    vm.data = [
        {
            l: "Nombre",
            t: "Ana Sofía Henao Estrada"
        },
        {
            l: "Documento",
            t: "CC. 43878327"
        },
        {
            l: "Fecha de nacimiento",
            t: "19/06/1982"
        },
        {
            l: "Edad",
            t: "34"
        },
        {
            l: "Ciudad de residencia",
            t: "Medellín"
        },
        {
            l: "Celular",
            t: "3184016612"
        },
        {
            l: "Actividad",
            t: "Prestador de Servicios"
        },
        {
            l: "Empleado falabella",
            t: "OK / NO"
        },
        {
            l: "Tienda",
            t: "Santa fe Medellín"
        },
        {
            l: "Fecha y hora de solicitud",
            t: "04/12/2016 – 10:15 am"
        },
        {
            l: "Nro. Solicitud",
            t: "7858585"
        },
        {
            l: "Tipo de tramite",
            t: "Continua el proceso"
        }
        
    ];
    
    vm.hideSlidebar = function () {
        vm.hide = vm.hide ? false : true;
    }

    vm.clickCollapse = function () {
              
        vm.info = vm.info ? false : true;

        var infoClientIni = $("#verification_body").height();
        var infoClientFin = 0;

        var secondPanelIni = $(".include-submenu").css("padding-top").replace("px", "");
        var heightPad = 0
        var total = 0

        setTimeout(heightP, 5);

        function heightP() {
            infoClientFin = $("#verification_body").height();
            heightPad = parseInt(infoClientFin) - parseInt(infoClientIni);
                       
            if (vm.infoclient) {
                var op = $(".include-submenu").css("padding-top", (parseInt(secondPanelIni) + parseInt(heightPad)).toString() + "px");
                total = parseInt(secondPanelIni) + parseInt(heightPad);
            } else {
                var op = $(".include-submenu").css("padding-top", (parseInt(secondPanelIni) + parseInt(heightPad)).toString() + "px");
                total = parseInt(secondPanelIni) + parseInt(heightPad);
            }

            //console.log("Panel basico inicio: " + infoClientIni, "Panel basico fin: " + infoClientFin);
            //console.log("Container inicio: " + secondPanelIni, "Desplazamiento: " + heightPad);
            //console.log("Posicion container: " + total);           
         
        }
    }
    
}]);
