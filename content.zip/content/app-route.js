﻿app.config(['$httpProvider', '$routeProvider', '$locationProvider', function ($httpProvider, $routeProvider, $locationProvider) {
       
    $locationProvider.hashPrefix('!');

    $routeProvider
        .when('/', {
            templateUrl: '/content/app_views/dashboard/index.html',
            controller: 'dashboardController'
        })
        .when('/requisition', {
            templateUrl: '/content/app_views/requisition/index.html',
            controller: 'requisitionController',
            controllerAs: 'requisition'
        })
        .when('/requisition/product', {
            templateUrl: '/content/app_views/requisition/product/index.html',
            controller: 'productController',
            controllerAs: 'product'
        })
        .when('/requisition/consult', {
             templateUrl: '/content/app_views/requisition/consult/consultView.html',
             controller: 'consultController',
             controllerAs: 'consult'
        })
        .when('/requisition/print', {
             templateUrl: '/content/app_views/requisition/consult/print/printReqView.html',
             controller: 'printController',
             controllerAs: 'print'
         })
        .when('/requisition/consult/:idConsulta', {
            templateUrl: '/content/app_views/requisition/consult/consultDetailView.html',
            controller: 'consultDetailController',
            controllerAs: 'consultDetail'
        })
        .when('/verification', {
            templateUrl: '/content/app_views/verification/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/special-brands', {
            templateUrl: '/content/app_views/verification/special-brands/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/biometrics', {
            templateUrl: '/content/app_views/verification/biometrics/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/identity', {
            templateUrl: '/content/app_views/verification/identity/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/customer', {
            templateUrl: '/content/app_views/verification/customer/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/activity', {
            templateUrl: '/content/app_views/verification/activity/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/income', {
            templateUrl: '/content/app_views/verification/income/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/verification/google-sarlaft', {
            templateUrl: '/content/app_views/verification/google-sarlaft/index.html',
            controller: 'verificationController',
            controllerAs: 'verification'
        })
        .when('/center-risk/shortframe', {
            templateUrl: '/content/app_views/center-risk/index.html',
            controller: 'centerRiskController',
            controllerAs: 'risk'
        })
        .when('/center-risk/shortframe/result', {
            templateUrl: '/content/app_views/center-risk/short-frame.html',
            controller: 'shortFrameController',
            controllerAs: 'shortframe'
        })
        .when('/center-risk/history', {
            templateUrl: '/content/app_views/center-risk/index.html',
            controller: 'centerRiskController',
            controllerAs: 'risk'
        })
        .when('/center-risk/history/:idConsulta', {
            templateUrl: '/content/app_views/center-risk/history.html',
            controller: 'historyRiskController',
            controllerAs: 'history'
        })
        .when('/center-risk/ondemand', {
            templateUrl: '/content/app_views/center-risk/index.html',
            controller: 'centerRiskController',
            controllerAs: 'risk'
        })
        .when('/center-risk/ondemand/result', {
            templateUrl: '/content/app_views/center-risk/on-demand.html',
            controller: 'onDemandRiskController',
            controllerAs: 'ondemand'
        })
        .when('/center-risk/ofac', {
            templateUrl: '/content/app_views/center-risk/o-fac.html',
            controller: 'oFacController',
            controllerAs: 'ofac'
        })
        .when('/center-risk/evident', {
            templateUrl: '/content/app_views/center-risk/evident.html',
            controller: 'evidentRiskController',
            controllerAs: 'evident'
        })
        .when('/center-risk/recognize', {
            templateUrl: '/content/app_views/center-risk/index.html',
            controller: 'centerRiskController',
            controllerAs: 'risk'
        })
        .when('/center-risk/recognize/result', {
            templateUrl: '/content/app_views/center-risk/recognize.html',
            controller: 'recognizeRiskController',
            controllerAs: 'recognize'
        })
        .when('/404', {
            templateUrl: '/content/style/templates/404.html'           
        })
        .when('/500', {
            templateUrl: '/content/style/templates/500.html'            
        })
        .otherwise({
            redirectTo: '/404'
        });
}]);

