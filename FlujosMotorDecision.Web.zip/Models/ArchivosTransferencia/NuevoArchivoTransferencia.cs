﻿using FlujosMotorDecision.Web.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FlujosMotorDecision.Web.Models
{
    public class NuevoArchivoTransferencia
    {
        [Required(ErrorMessage = "Por favor seleccione un archivo.")]
        [ValidateInputFile]
        public HttpPostedFileBase Archivo { get; set; }

        public string ExtensionesPermitidas { get; set; }

        public string SeparadorArchivoEntrada { get; set; }

        public int TamanoMaximoArchivo { get; set; }
    }
}