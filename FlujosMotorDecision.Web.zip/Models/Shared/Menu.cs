﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FlujosMotorDecision.Web.Models
{
    public class SidebarVM
    {
        public bool Clientes { get; set; }
        public bool NoClientes { get; set; }
        public bool ArchivosTransferencia { get; set; }
        public bool CreditoEmpleados{ get; set; }
        public bool CargaClientesOds { get; set; }
        public bool TasasConsumo { get; set; }
        public bool Parametros { get; set; }
        
    }
}