﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FlujosMotorDecision.Core.Entities;

namespace FlujosMotorDecision.Web.Models
{
    public class Breadcrumbs
    {
        public int InstanciaProcesoId{ get; set; }
        public string NombreActividad{ get; set; }
        public TipoProceso TipoProceso { get; set; }        
    }
}