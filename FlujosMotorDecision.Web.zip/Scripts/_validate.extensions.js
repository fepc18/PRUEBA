﻿(function ($) {
    var defaultOptions = {
        errorClass: 'has-error',
        validClass: 'has-success',
        highlight: function (element, errorClass, validClass) {
            $(element).closest(".form-group")
                .addClass(errorClass)
                .removeClass(validClass);
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).closest(".form-group")
            .removeClass(errorClass)
            .addClass(validClass);
        }
    };

    $.validator.setDefaults(defaultOptions);
    $.validator.defaults.ignore = ":hidden"

    $.validator.unobtrusive.options = {
        errorClass: defaultOptions.errorClass,
        validClass: defaultOptions.validClass,
    };

    $.validator.addMethod('date',
    function (value, element) {
        var isChrome = window.chrome;
        // make correction for chrome
        if (isChrome) {
            return true;
        }
            // leave default behavior
        else {
            return this.optional(element) ||
            !/Invalid|NaN/.test(new Date(value));
        }
    });
})(jQuery);