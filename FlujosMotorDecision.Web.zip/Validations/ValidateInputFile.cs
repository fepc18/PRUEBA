﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace FlujosMotorDecision.Web.Validations
{
    public class ValidateInputFile : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            int maxContent = int.Parse(WebConfigurationManager.AppSettings["TamanoMaxArchivo"]);
            var extPermitidas = WebConfigurationManager.AppSettings["ExtPermitidas"].Split('|');

            var file = value as HttpPostedFileBase;            

            if (file == null)
            {
                return new ValidationResult("Por favor seleccione un archivo.");
            }
            else if(file.ContentLength == 0)
            {                
                return new ValidationResult("El archivo está vacío.");
            }
            else if (!extPermitidas.Contains(Path.GetExtension(file.FileName)))
            {
                return new ValidationResult("Por favor suba un archivo de tipo: " + string.Join(", ", extPermitidas));
            }
            else if (file.ContentLength > maxContent)
            {
                return new ValidationResult("El archivo es muy grande, el máximo permitido es de: " + (maxContent / 1048576).ToString() + "MB");
            }
            return ValidationResult.Success;
        }
    }
}