﻿using Model.RequestService;
using Modelo.Seguridad;
using Models.Response;
using ServicesABC.Helpers;
using ServicesABC.Interfaces;
using ServicesABC.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServicesABC.Action
{
    public class AuthenticateAction : IActions
    {
        private AuthenticateRequest dataDocument;
        private HeaderRequest headerRequest;
        private ResponseStatus response = new ResponseStatus();
        private SrvValidateHeader validateHeader;
        private FinancyContext db = new FinancyContext();

        public AuthenticateAction(HeaderRequest paramHeaderRequest, AuthenticateRequest _dataDocument)
        {
            dataDocument = _dataDocument;            
            headerRequest = paramHeaderRequest;
            if (Valid())
            {
                validateHeader= new SrvValidateHeader(paramHeaderRequest);                
                Execute();                
            }
            else
            {
                HlpLog.Warning(eService.ServiceAuthentication, "", CodeMessages.InvalidBodyDocument);
                response = HlpGenerateResponse.GeneratePostResponse("0501", "invalid parameters", "Undefined", string.Empty, "0");
                response.Result.Add("Errors", "The request body is empty or invalid");
               
            }

        }
        public ResponseStatus ActionResult
        {
            get
            {
                return this.response;
            }
        }

        private void Execute()
        {

            var n = db.Usuario.Where(x => x.Login == dataDocument.Authenticate.User).Where(x => x.Password == dataDocument.Authenticate.Password).Count();
            if (n > 0)
            {
                //Notificar en caso de que deba cambiar la clave por vencimiento o por ingreso primera vez
            
                HlpLog.Information(eService.ServiceAuthentication, "", CodeMessages.SuccessfulTransaction);
                response = HlpGenerateResponse.GeneratePostResponse("0200", HlpLog.GetEnumDescription(CodeMessages.SuccessfulTransaction), dataDocument.Head.IOsID, string.Empty, "1");
                response.Result.Add("result", "Authentication Successful");
            }
            else
            {
                // aumentar intentos fallidos
                // bloquear de ser necesario
                HlpLog.Information(eService.ServiceAuthentication, "", CodeMessages.AuthenticationInvalid);
                response = HlpGenerateResponse.GeneratePostResponse("0201", HlpLog.GetEnumDescription(CodeMessages.AuthenticationInvalid), dataDocument.Head.IOsID, string.Empty, "0");
                response.Result.Add("result", "Authentication Invalid");
            }
        }
        private bool Valid()
        {
            return dataDocument == null ? false : true;
        }
        
       
          
    }
}