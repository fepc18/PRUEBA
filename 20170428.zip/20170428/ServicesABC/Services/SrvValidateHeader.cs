﻿using System;
using System.Text;
using Api.Models.Response;
using Model.RequestService;


namespace ServicesABC.Services
{
    public class SrvValidateHeader
    {
        private ValidateStatus validateStatus = null;
        private HeaderRequest dataHeaderRequested = null;

        public ValidateStatus StatusHeader { get { return validateStatus; } }

        public SrvValidateHeader(HeaderRequest dataHeaderRequested)
        {
            validateStatus = ValidateHeader(dataHeaderRequested);
        }

        private ValidateStatus ValidateHeader(HeaderRequest ParamDataHeaderRequested)
        {
            var headderStatus = new ValidateStatus();

            dataHeaderRequested = ParamDataHeaderRequested;

            if (dataHeaderRequested.Authorization != null && !string.IsNullOrEmpty(dataHeaderRequested.Authorization.Parameter.ToString()))
            {
                if (!ValidateCredentials(dataHeaderRequested.Authorization.Parameter))
                {
                    headderStatus.ErrorList.Add("Unauthorized user");
                }
            }
            else
            {
                headderStatus.ErrorList.Add("Required credentials");
            }

            if (dataHeaderRequested.ContentType != "application/json")
            {
                headderStatus.ErrorList.Add("Content-Type invalid");
            }
            headderStatus.CalculateCurrentStatus();
            return headderStatus;
        }

        private bool ValidateCredentials(string Parameter)
        {
            var encoding = Encoding.GetEncoding("iso-8859-1");

            Parameter = encoding.GetString(Convert.FromBase64String(Parameter));
            return Parameter.Equals("usertest:usertest") ? true : false;

        }
        public String User()
        {
            var encoding = Encoding.GetEncoding("iso-8859-1");

            String Parameter = encoding.GetString(Convert.FromBase64String(dataHeaderRequested.Authorization.Parameter));
            return Parameter.Split(':')[0];

        }
    }
}