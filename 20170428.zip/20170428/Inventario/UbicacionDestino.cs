﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Inventario
{
    [Table("UbicacionDestino")]
    public class UbicacionDestino
    {
        [Display(Name = "Id")]
        [Required(ErrorMessage = "Campo Requerido")]
        public int UbicacionDestinoId { get; set; }
        [Display(Name = "Código")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Codigo { get; set; }
        [Display(Name = "Descripción")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Descripcion { get; set; }
       
    }


}
