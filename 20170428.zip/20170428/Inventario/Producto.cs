﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace Modelo.Inventario
{
    [Table("Productos")]
    public class Producto
    {
        [Display(Name = "Id")]
        public int ProductoId { get; set; }
        [Required(ErrorMessage = "Campo Requerido")]
        public String Referencia { get; set; }
        [Display(Name = "Marca")]
        public int MarcaId { get; set; }
        [Display(Name = "Marca")]
        public virtual Marca Marca { get; set; }
        [Display(Name = "Descripción")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Descripcion { get; set; }
        [Display(Name = "Grupo")]
        public int GrupoInventarioId { get; set; }
        [Display(Name = "Grupo")]
        public virtual GrupoInventario GrupoInventario { get; set; }
        [Required(ErrorMessage = "Campo Requerido")]
        public int Iva { get; set; }
        [Display(Name = "Unidad Medida")]
        public int UnidadMedidaId { get; set; }
        [Display(Name = "Unidad Medida")]
        public virtual UnidadMedida UnidadMedida { get; set; }
        [Display(Name = "Presentación")]
        public int PresentacionId { get; set; }
        [Display(Name = "Presentación")]
        public virtual Presentacion Presentacion { get; set; }
        [Display(Name = "Concentración")]
        public String Concentracion { get; set; }
        [Display(Name = "Observación")]
        public String Observacion { get; set; }
        [Display(Name = "Código Barras")]
        public String CodigoBarras { get; set; }
        public Boolean Loteado { get; set; }
        public Boolean Control { get; set; }        
        public Boolean Activo { get; set; }
        [Display(Name = "Maneja Stock")]
        public Boolean ManejaStock { get; set; }
        [Display(Name = "Venta")]
        public Boolean Venta { get; set; }
        [Display(Name = "Insumo")]
        public Boolean Insumo { get; set; }
        
        public override string ToString()
        {
            return Referencia+" - "+Descripcion;
        }

    }
    public class Marca
    {
        [Display(Name = "Id")]
        public int MarcaId { get; set; }
        [Display(Name = "Descripción")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Descripcion { get; set; }
    }
    [Table("GrupoInventario")]
    public class GrupoInventario {
        [Display(Name = "Id")]
        public int GrupoInventarioId { get; set; }
        [Display(Name = "Descripción")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Descripcion { get; set; }
    }
    [Table("UnidadesMedida")]
    public class UnidadMedida {
        [Display(Name = "Id")]
        public int UnidadMedidaId { get; set; }
        [Required(ErrorMessage = "Campo Requerido")]
        public String Simbolo { get; set; }
        [Display(Name = "Descripción")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Descripcion { get; set; }
    }
    [Table("Presentaciones")]
    public class Presentacion {
        [Display(Name = "Id")]
        public int PresentacionId { get; set; }
        [Display(Name = "Descripción")]
        [Required(ErrorMessage = "Campo Requerido")]
        public String Descripcion { get; set; }
    }

    public class ProductoListaPrecio
    {
        public int ProductoListaPrecioId { get; set; }
        public int ListaPrecioId { get; set; }
        public int ProductoId { get; set; }       
        public decimal Precio { get; set; }

    }
    public class ListaPrecio
    {
        public int ListaPrecioId { get; set; }
        public String Codigo { get; set; }
        public String Descripcion { get; set; }
        public Boolean Activo { get; set; }

    }
    public enum TipoProducto
    {
        Producto,
        Servicio,
        ProductoModificador,
        Comentario
    }
    
}
