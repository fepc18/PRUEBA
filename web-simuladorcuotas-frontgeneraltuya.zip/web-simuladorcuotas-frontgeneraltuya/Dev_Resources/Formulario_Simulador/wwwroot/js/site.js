﻿/* Recapcha google */
function onSubmit(token) {
    if (!fnValidateRecaptchaResponse())
        return;

    document.getElementById("frmSimulador").submit();
}

function validate(event) {
    event.preventDefault();

    if (document.getElementById('idValor').value) {
        errorSpan = document.getElementById("valorSpan");
        errorSpan.innerHTML = "";
    }

    if (!document.getElementById('producto_tipo').value) {
        errorSpan = document.getElementById("producto_tipo_span");
        errorSpan.innerHTML = "El campo producto es requerido.";
    }
    else if (!document.getElementById('tipoUtilizacion').value && document.getElementById('producto_tipo').value !== "CrediCompras") {
        var errorSpan = document.getElementById("tipoUtilizacionSpan");
        errorSpan.innerHTML = "El campo tipo de transacción es requerido para productos mastercard y privada.";
    }
    else if (!document.getElementById('idValor').value) {
        errorSpan = document.getElementById("valorSpan");
        errorSpan.innerHTML = "El campo cantidad es requerido.";
    }
    else if (document.getElementById('numValor').value.length>10) {
        errorSpan = document.getElementById("valorSpan");
        errorSpan.innerHTML = "Ingresa un valor mas pequeño";
    }
    else if (/^([0-9])*$/.test(document.getElementById('numValor').value) === false)
    {
        errorSpan = document.getElementById("valorSpan");
        errorSpan.innerHTML = "Cantidad no válida, ingresa sólo números.";
    }
    else if (!document.getElementById('numeroCuotas').value) {
        errorSpan = document.getElementById("numeroCuotasSpan");
        errorSpan.innerHTML = "El campo número de cuotas es requerido.";
    }
    else {
        grecaptcha.execute();
    }
}

function onload() {
    if ($('#action').length) {
        var element = document.getElementById('action');
        element.onclick = validate;
    } 
}
onload();


function fnValidateRecaptchaResponse(){
    var recaptchaFromElement = document.getElementById("g-recaptcha-response").value;
    if(recaptchaFromElement == '' || recaptchaFromElement == null)
        return false;

    var recaptchaResponse = grecaptcha.getResponse();
    if (recaptchaResponse !== recaptchaFromElement)
        return false;
    
    return true;
}
/* Fin recapcha */

/* Validación de solo números */
function valideKey(evt) {
    var code = evt.which ? evt.which : evt.keyCode;
    if (code === 8) {
        //backspace
        return true;
    } else if (code >= 48 && code <= 57) {
        //is a number
        return true;
    } else {
        return false;
    }
}

/*Slider número de cuotas*/
$(function () {
    $("#slider-range-min").slider({
        range: "min",
        value: 12,
        min: 1,
        max: 48,
        slide: function (event, ui) {
            $("#numeroCuotas").val(ui.value);
        }
    });
    $("#numeroCuotas").val($("#slider-range-min").slider("value"));
});


function updateSlider(val) {
    $("#slider-range-min").slider({ value: $("#numeroCuotas").val() });
}

$(document).ready(function () {
    //Disable cut copy paste
    $("#idValor").bind('cut copy paste', function (e) {
        e.preventDefault();
    });

    //Disable mouse right click
    $("#idValor").on("contextmenu", function (e) {
        return false;
    });

    $("#idValor").change(function (event) {
        var valor = event.target.value.split(",")[0].replace("$", "").replace(/\./g, "").trim();

        $("#numValor").val(valor);

        var format = Intl.NumberFormat("es-CO",
            { style: "currency", currency: "COP" }).format(valor);
        event.target.value = format;
    });

    $("#idValor").keypress(function (event) {
        if (event.target.value.length >= 10) {
            return false;
        }
    });

    if (document.getElementById('producto_tipo')!=null) {
        habilitar(document.getElementById('producto_tipo').value);
    }
});

function habilitar(value) {
    if (value === "CrediCompras") {
        // ocultamos
        document.getElementById("divTipoUtilizacion").style.display = 'none';
        document.getElementById("tipoUtilizacion").selectedIndex = 0;
        document.getElementById("valorHelp").innerHTML = "¿Cuál es el valor de tu crédito? Ten en cuenta los topes por lineas de crédito que tenemos disponibles.";

        var select = $("#minbeds");
        select[0].selectedIndex = 0;
        $("#slider-range-min").slider({
            min: 1,
            max: 4,
            range: "min",
            value: select[0].selectedIndex + 1,
            slide: function (event, ui) {
                select[0].selectedIndex = ui.value - 1;
                $("#numeroCuotas").val(select[0].value);
            }
        });
        $("#numeroCuotas").val(select[0].value);

    } else {
        // mostramos
        document.getElementById("divTipoUtilizacion").style.display = 'flex';
        document.getElementById("valorHelp").innerHTML = "¿Cuál es el valor de tu compra/avance en pesos?";

        $("#slider-range-min").slider({
            range: "min",
            value: 12,
            min: 1,
            max: 48,
            slide: function (event, ui) {
                $("#numeroCuotas").val(ui.value);
            }
        });
        $("#numeroCuotas").val($("#slider-range-min").slider("value"));
    }
}
