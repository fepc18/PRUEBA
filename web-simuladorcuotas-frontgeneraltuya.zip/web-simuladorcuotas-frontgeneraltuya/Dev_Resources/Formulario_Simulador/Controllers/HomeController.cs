﻿using Formulario_Simulador.Class;
using Formulario_Simulador.Models;
using Formulario_Simulador.Services;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using reCAPTCHA.AspNetCore;
using reCAPTCHA.AspNetCore.Attributes;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;

namespace Formulario_Simulador.Controllers
{
    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IRecaptchaService _recaptcha;
        private readonly TelemetryClient _telemetryClient;
        private readonly double _minimunScore;

        public HomeController(
            ILogger<HomeController>
            logger, IConfiguration iConfig,
            IRecaptchaService recaptcha,
            TelemetryClient telemetryClient)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _configuration = iConfig ?? throw new ArgumentNullException(nameof(iConfig));
            _recaptcha = recaptcha ?? throw new ArgumentNullException(nameof(recaptcha));
            _telemetryClient = telemetryClient ?? throw new ArgumentNullException(nameof(telemetryClient));
            _minimunScore = 0.3;
        }

        public IActionResult Index(short cod = 0)
        {
            TelemetryLog(GetType().Assembly.GetName().Name, MethodBase.GetCurrentMethod().DeclaringType.Name);

            ViewData["sitio"] = _configuration.GetSection("MySettings").GetSection("sitio").Value;
            ViewData["recapcha"] = _configuration.GetSection("RecaptchaSettings")["SiteKey"];

            switch (cod)
            {
                case 401:
                    ViewData["Message"] = TempData["errorMsj"].ToString();
                    break;
                case 501:
                    ViewData["Message"] = TempData["errorMsj"].ToString();
                    break;
                default:
                    ViewData["Message"] = null;
                    break;

            }
            return View();
        }

        public IActionResult Privacy()
        {
            TelemetryLog(GetType().Assembly.GetName().Name, MethodBase.GetCurrentMethod().DeclaringType.Name);
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            TelemetryLog(GetType().Assembly.GetName().Name, MethodBase.GetCurrentMethod().DeclaringType.Name);
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        [ValidateRecaptcha(0.5)]
        public async Task<ActionResult> SimularCuotas(Transaccion objTransaccion)
        {
            TelemetryLog(GetType().Assembly.GetName().Name, MethodBase.GetCurrentMethod().DeclaringType.Name);
            _logger.LogInformation("{method} {name} running at: {time}",
                Request.Method, MethodBase.GetCurrentMethod().DeclaringType.Name, DateTimeOffset.Now);

            try
            {
                ViewData["sitio"] = _configuration.GetSection("MySettings").GetSection("sitio").Value;
                if (!Util.DatosValidos(objTransaccion, out string mensaje))
                {
                    ModelState.AddModelError("Recaptcha", mensaje);
                    TempData["errorMsj"] = mensaje;
                    return RedirectToAction("Index", "Home", new { cod = 401 });
                }
                else
                {
                    var recaptcha = await _recaptcha.Validate(Request);
                    if (!recaptcha.success || recaptcha.score != 0 && recaptcha.score < _minimunScore)
                    {
                        ModelState.AddModelError("Recaptcha", "Error en la validación del ReCaptcha de Google");
                        TempData["errorMsj"] = "Error en la validación del ReCaptcha de Google";
                        return RedirectToAction("Index", "Home", new { cod = 401 });
                    }
                    else
                    {
                        objTransaccion.producto.tipo = (objTransaccion.producto.tipo.Equals(tipoProducto.CrediCompras.ToString())) ? "credicompra" : objTransaccion.producto.tipo;
                        objTransaccion.tokenRecaptcha = _configuration.GetSection("MySettings").GetSection("SecretSec").Value;

                        Simulador objSimulador = new Simulador(_configuration);
                        Simulacion objSimulacion = objSimulador.ObtenerSimulacionAsync(objTransaccion).Result;
                        if (!(objSimulacion.Error is null))
                            throw new ArgumentNullException(objSimulacion.Error);

                        return View("PartialViewSimulacion", objSimulacion);
                    }
                }

            }
            catch (Exception e)
            {
                TempData["errorMsj"] = "No se pudo realizar la simulación, por favor intenta más tarde:";
                _logger.LogError(e.ToString());
                return RedirectToAction("Index", "Home", new { cod = 501 });
            }

        }

        private void TelemetryLog(string assembly, string message)
        {
            _telemetryClient.TrackTrace(
                message,
                SeverityLevel.Information,
                new Dictionary<string, string> { { "Componente", assembly } });
        }
    }
}
