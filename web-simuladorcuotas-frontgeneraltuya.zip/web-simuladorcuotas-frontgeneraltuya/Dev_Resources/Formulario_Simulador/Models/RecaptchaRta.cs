﻿using System.Collections.Generic;

namespace Formulario_Simulador.Models
{
    public class RecaptchaRta
    {
        public bool Success { get; set; }
        public List<string> Errorcodes { get; set; }
    }
}
