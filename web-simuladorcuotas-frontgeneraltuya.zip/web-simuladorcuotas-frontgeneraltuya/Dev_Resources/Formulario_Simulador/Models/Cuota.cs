﻿using System.ComponentModel.DataAnnotations;

namespace Formulario_Simulador.Models
{
    public class Cuota
    {
        public int NroCuota { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,###,###,###}")]
        public double Valor { get; set; }

        [DisplayFormat(DataFormatString = "{0:#,###,###,###}")]
        public double Saldo { get; set; }
    }
}
