﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Formulario_Simulador.Models
{
    public class Producto
    {
        public String marca { get; set; }

        [Required(ErrorMessage = "Selecciona el tipo de producto.")]
        public String tipo { get; set; }

    }

    public enum tipoProducto
    {
        Privada,
        Mastercard,
        CrediCompras
    }

    public enum tipoProductoAlkosto
    {
        Privada,
        Mastercard
    }
}
