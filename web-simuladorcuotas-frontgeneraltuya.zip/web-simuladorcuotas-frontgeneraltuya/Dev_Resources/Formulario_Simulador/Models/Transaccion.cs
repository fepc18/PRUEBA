﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Formulario_Simulador.Models
{
    public class Transaccion
    {
        [Required(ErrorMessage = "Seleciona el producto")]
        public Producto producto { get; set; }
        [Required(ErrorMessage = "El campo tipo de transacción es requerido para productos Mastercard y Privada")]
        public String tipoUtilizacion { get; set; }


        [DisplayFormat(DataFormatString = "{0:#,###,###,###}")]
        [Required(ErrorMessage = "La cantidad es obligatoria.")]
        public double? valor { get; set; }

        [Required(ErrorMessage = "El número de cuotas es obligatorio.")]
        [Range(1, 48, ErrorMessage = "Solo puedes seleccionar entre 1 y 48 cuotas.")]
        public int? numeroCuotas { get; set; }
        public string tokenRecaptcha { get; set; }
    }

    public enum utilizacion
    {
        Avance,
        Compra
    }
}
