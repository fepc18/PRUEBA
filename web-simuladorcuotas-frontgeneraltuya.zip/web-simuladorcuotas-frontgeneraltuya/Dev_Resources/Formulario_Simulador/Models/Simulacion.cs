﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Formulario_Simulador.Models
{
    public class Simulacion
    {
        public List<Cuota> Cuotas { get; set; }
        public String Tasa { get; set; }

        [DisplayFormat(DataFormatString = "{0:###,###,###,###,###}")]
        public string Valor { get; set; }

        public Transaccion Transaccion { get; set; }

        public string Error { get; set; }
    }
}
