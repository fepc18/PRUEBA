﻿using Formulario_Simulador.Models;
using System;

namespace Formulario_Simulador.Class
{
    public static class Util
    {
        public static bool ContieneLetras(string valor)
        {
            bool rta = true;
            decimal number;
            try
            {
                rta = decimal.TryParse(valor, out number);
            }
            catch (Exception)
            {
                return true;
                throw;
            }

            return !rta;
        }

        public static bool DatosValidos(Transaccion objTransaccion, out string mensaje)
        {
            if (objTransaccion.valor == 0)
            {
                mensaje = "Ingresa una cantidad mayor a $0.";
                return false;
            }
            else if (ContieneLetras(objTransaccion.valor.ToString()))
            {
                mensaje = "No se permiten letras o espacios en blanco en el campo 'Cantidad'";
                return false;
            }
            else if (objTransaccion.valor.ToString().Length > 10)
            {
                mensaje = "Ingresa máximo 10 números en el campo 'Cantidad'";
                return false;
            }
            else if (objTransaccion.producto.tipo == null)
            {
                mensaje = "Por favor selecciona el producto.";
                return false;
            }
            else if (!objTransaccion.producto.tipo.Equals(tipoProducto.CrediCompras.ToString()) && objTransaccion.tipoUtilizacion == null)
            {
                mensaje = "Por favor selecciona el tipo de transacción";
                return false;
            }
            else
            {
                mensaje = "";
                return true;
            }
        }
    }
}
