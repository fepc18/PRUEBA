﻿using Formulario_Simulador.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Formulario_Simulador.Services
{
    public class Simulador
    {
        static readonly HttpClient _httpClient = new HttpClient();
        private readonly IConfiguration _configuration;

        public Simulador(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<Simulacion> ObtenerSimulacionAsync(Transaccion transaccion)
        {
            string urlBase = _configuration.GetSection("Resources")["SIMULATOR_URL"];
            string requestUri = urlBase;

            HttpContent content = new StringContent(
                JsonConvert.SerializeObject(transaccion),
                Encoding.UTF8,
                "application/json"
            );

            HttpResponseMessage message = await _httpClient.PostAsync(requestUri, content);
            message.EnsureSuccessStatusCode();

            string data = await message.Content.ReadAsStringAsync();
            Simulacion rpSimulacion = JsonConvert.DeserializeObject<Simulacion>(data);
            rpSimulacion.Transaccion = transaccion;
            rpSimulacion.Valor = ((double)transaccion.valor).ToString("C");
            return rpSimulacion;
        }

    }
}
